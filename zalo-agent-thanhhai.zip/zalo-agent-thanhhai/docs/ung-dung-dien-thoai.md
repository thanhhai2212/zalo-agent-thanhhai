# Ứng dụng điện thoại

Xem Zalo Agent ngay trên điện thoại: sức khỏe máy chủ, tài khoản Zalo có đang chạy không, khách mới, khách nhắn gấp, nhật ký và báo cáo. Có thể bật thông báo đẩy để bot tự báo khi có chuyện cần bạn xem.

Đây là **công cụ theo dõi**. Bạn xem được hội thoại và đánh dấu "Đã xử lý", nhưng chưa trả lời khách hay đổi quyền từ điện thoại. Những việc đó vẫn làm trên bảng điều khiển (dashboard).

## Bạn xem được gì

| Màn | Nội dung |
|---|---|
| Trang chủ | Điểm sức khỏe, tin hôm nay, lỗi 24 giờ, việc cần làm, việc sắp tới, nút gửi báo cáo ngay |
| VPS | RAM, ổ đĩa, CPU, thời gian bot chạy, biểu đồ xu hướng 24 giờ và 7 ngày |
| Zalo | Từng tài khoản đang chạy hay mất kết nối, danh sách hội thoại (chỉ xem), Khách mới |
| Nhật ký | Cảnh báo và sự kiện, xem theo tháng, tuần, ngày; bấm "Đã xử lý" khi bạn lo xong |
| Báo cáo | Tin khách, lượt AI, liên hệ mới theo ngày, 7 hoặc 30 ngày |
| Thông báo và cảnh báo | Bật thông báo đẩy, chọn loại cảnh báo, giờ yên tĩnh, ngưỡng RAM và ổ đĩa |

## Điều kiện

- **Máy chạy bot phải đang bật.** Nếu bot chạy trên máy Windows của bạn, tắt máy hoặc để máy ngủ thì bot dừng và app không có gì để hiện. Hãy tắt chế độ ngủ của Windows. Bot chạy trên VPS thì không bị vấn đề này.
- **Điện thoại và máy chạy bot nối chung một mạng riêng ảo Tailscale** (miễn phí). App không mở ra internet, chỉ máy của bạn vào được.
- iPhone: iOS 16.4 trở lên, dùng Safari. Android: dùng Chrome.

## Bước 1. Cài Tailscale trên máy chạy bot

1. Vào https://tailscale.com/download, tải bản cho Windows hoặc Linux (VPS) và cài.
2. Đăng nhập bằng một tài khoản (Google hoặc Microsoft đều được). Ghi nhớ tài khoản này, điện thoại sẽ dùng đúng tài khoản đó.

## Bước 2. Bật HTTPS cho Tailscale (làm một lần)

Thông báo đẩy và việc thêm app vào màn hình chính cần địa chỉ HTTPS.

1. Mở https://login.tailscale.com/admin/dns, đăng nhập cùng tài khoản.
2. Bật **MagicDNS** nếu chưa bật, rồi bấm **Enable HTTPS** (trong mục HTTPS Certificates).

## Bước 3. Chia sẻ dashboard qua Tailscale

Mở PowerShell (Windows) hoặc terminal (VPS) trên máy chạy bot và chạy:

```bash
tailscale serve --bg 3910
```

(3910 là cổng dashboard mặc định. Nếu bạn đã đổi `DASHBOARD_PORT` thì dùng số đó.)

Xem địa chỉ vừa tạo:

```bash
tailscale serve status
```

Bạn sẽ thấy một dòng dạng `https://ten-may.tail1234.ts.net`. Đó là địa chỉ để mở trên điện thoại.

Có thể kiểm bằng `corepack pnpm zalo-doctor`: mục "Ứng dụng điện thoại" sẽ báo địa chỉ này khi đã đúng.

**Không dùng `tailscale funnel`.** Lệnh đó mở dashboard ra cả internet.

## Bước 4. Cài Tailscale trên điện thoại

1. Cài ứng dụng **Tailscale** từ App Store hoặc Google Play.
2. Đăng nhập **cùng tài khoản** ở bước 1.
3. Bật công tắc kết nối.

## Bước 5. Mở app và thêm vào màn hình chính

1. Trên điện thoại, mở trình duyệt (Safari trên iPhone) và vào `https://ten-may.tail1234.ts.net/m` (thêm `/m` ở cuối).
2. Đăng nhập bằng mật khẩu dashboard.
3. Thêm vào màn hình chính:
   - **iPhone:** bấm nút Chia sẻ, chọn **Thêm vào Màn hình chính**, bấm Thêm.
   - **Android:** bấm menu ba chấm, chọn **Cài đặt ứng dụng** (hoặc Thêm vào màn hình chính).
4. Từ giờ mở app bằng biểu tượng ở màn hình chính, không mở bằng trình duyệt nữa.

## Bước 6. Bật thông báo đẩy

**Trên iPhone, phải mở app từ biểu tượng ở màn hình chính** (không phải từ Safari), nếu không thì mục bật thông báo không hiện.

1. Trong app vào **Tôi**, chọn **Thông báo và cảnh báo**.
2. Bấm **Bật thông báo trên máy này**, cho phép khi điện thoại hỏi.
3. Bấm **Gửi thử**. Máy sẽ rung và hiện một thông báo thử.
4. Chọn những loại cảnh báo bạn muốn nhận và đặt giờ yên tĩnh nếu cần. Cảnh báo "quan trọng" (máy chủ sự cố, Zalo đứt) vẫn báo kể cả trong giờ yên tĩnh.

## Bước 7 (nên làm). Trạm báo độc lập

Khi cả máy chủ sập hoặc mất mạng, tin Zalo và thông báo đẩy đều không đi được. Trạm báo là một dịch vụ bên ngoài: bot gửi tín hiệu "tôi còn sống" mỗi phút, ngừng gửi thì dịch vụ đó báo cho bạn.

1. Tạo tài khoản miễn phí ở https://healthchecks.io và tạo một check.
2. Đặt chu kỳ **1 phút**, thời gian chờ **5 phút**.
3. Thêm kênh nhận báo (email, Telegram...).
4. Dán địa chỉ ping vào ô trong **Thông báo và cảnh báo**, bấm **Ping thử**.

## Đổi tên và biểu tượng app theo thương hiệu của bạn

Vào dashboard, mục **Thương hiệu**:

1. Tải logo lên (PNG, JPEG hoặc WebP, nên vuông, tối thiểu 256 x 256 px).
2. Ở khung **Ứng dụng điện thoại**, gõ **Tên ứng dụng** (tối đa 12 ký tự) và chọn **Nền biểu tượng** (trắng, đen than hoặc màu chủ đạo).
3. Bấm **Lưu thương hiệu**.

Điện thoại chỉ nhận tên và biểu tượng mới khi bạn **xóa app khỏi màn hình chính rồi thêm lại** (bước 5).

## Khi có vấn đề

| Hiện tượng | Cách xử lý |
|---|---|
| Mở địa chỉ không được | Kiểm tra Tailscale trên điện thoại đang bật và đăng nhập đúng tài khoản. Chạy `tailscale serve status` trên máy bot xem còn dòng địa chỉ không. |
| Báo lỗi chứng chỉ | Chưa bật HTTPS ở bước 2. Bật rồi chạy lại `tailscale serve --bg 3910`. |
| Không thấy nút bật thông báo (iPhone) | Phải mở app từ biểu tượng màn hình chính, iOS từ 16.4. |
| Gửi thử không có thông báo | Vào Cài đặt điện thoại, Thông báo, bật cho app. Tắt chế độ Tập trung. Bật lại thông báo trong app. |
| App trống hoặc báo không kết nối được máy chủ | Bot đang tắt. Với máy Windows: bật máy, chạy Start-Bot.cmd. |
| Ô CPU chưa có số ở lần mở đầu tiên | Bình thường: CPU cần hai lần đo mới tính được. Đợi vài giây. |
| Quên mật khẩu dashboard | Xem file `.env` trên máy bot (mục DASHBOARD_PASSWORD) hoặc hỏi người cài đặt. |

## An toàn

- App dùng chính mật khẩu dashboard, không có tài khoản riêng. Đừng chia sẻ địa chỉ và mật khẩu cho người lạ.
- Chỉ những thiết bị đăng nhập cùng tài khoản Tailscale (hoặc được bạn mời vào mạng) mới mở được địa chỉ. Muốn cho nhân viên xem thì mời họ vào mạng Tailscale của bạn thay vì mở cổng ra ngoài.
- Cuộc hội thoại với khách hiện trên điện thoại. Hãy đặt khóa màn hình cho máy.
