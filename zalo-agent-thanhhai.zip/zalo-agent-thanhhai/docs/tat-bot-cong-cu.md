# Tắt tính năng không cần dùng

Mỗi công cụ đang bật là một đoạn mô tả gửi kèm mọi lượt chat. Tắt những công cụ bạn không cần giúp bot **đỡ tốn token**, trả lời nhanh hơn, ít nhầm lẫn và an toàn hơn. Tắt không xóa mã, bật lại bất kỳ lúc nào.

## Nguyên tắc
Một công cụ chỉ dùng được khi **không bên nào tắt**: cấp agent và cấp tài khoản Zalo đều phải để bật. Muốn tắt, tắt ở một trong hai chỗ. Tắt ở agent là gọn nhất, vì mỗi agent chọn bộ công cụ riêng.

## Cách 1: trên Dashboard (khuyên dùng)
1. Vào trang **Agent**, mở agent cần chỉnh.
2. Tìm mục **Công cụ**, gạt tắt từng công cụ, bấm Lưu thay đổi.
3. Có hiệu lực ngay, không cần khởi động lại.

## Cách 2: nhờ trợ lý AI (Claude, Codex, Antigravity)
Đưa cho trợ lý đoạn sau cùng danh sách bên dưới:

> Hãy đăng nhập Dashboard Zalo Agent của tôi và tắt các công cụ trong danh sách dưới đây cho agent `<id agent>`. Chỉ tắt đúng danh sách, không đụng thứ khác. Cách làm: gọi `PATCH /api/agents/<id agent>` (đã đăng nhập Dashboard) với nội dung `{ "disabledTools": [ ...danh sách đầy đủ gồm các công cụ ĐANG tắt và các công cụ cần tắt thêm... ] }`. Trước tiên đọc `GET /api/agents/<id agent>` để lấy danh sách đang tắt và **giữ nguyên** chúng, đừng ghi đè mất. Không in khóa API hay mật khẩu ra màn hình.

**Lưu ý cho trợ lý:** `disabledTools` là danh sách đầy đủ, không phải phần cộng thêm. Ghi đè mà quên các mục đang tắt sẽ bật lại chúng.

## Danh sách gợi ý tắt

**Công việc trong nhóm** (tắt nếu bot không ở nhóm Zalo nào):
`get_group_info`, `tag_member`, `bao_chu_xin_y_kien`

**Gửi tin chủ động** (chỉ chủ bot ra lệnh được; tắt nếu không dùng):
`gui_vao_nhom`, `gui_tin_ca_nhan`

**Định dạng file ít dùng:**
`create_html_file`, `create_csv_file`, `create_text_file`, `tao_so_do_quy_trinh`

**Bộ công cụ nội dung** (tắt nếu bạn không làm nội dung đăng mạng xã hội):
`huong_dan_nghien_cuu_doi_thu`, `bao_cao_doi_thu`, `huong_dan_ke_hoach_content`, `ke_hoach_content`, `huong_dan_viet_caption`, `viet_caption`, `huong_dan_anh_bai_dang`, `tao_anh_bai_dang`, `huong_dan_do_luong`, `bao_cao_do_luong`

**Tra cứu phụ:**
`search_wikipedia`

Giữ bật: `web_search`, `web_fetch`, `doc_youtube`, `kb_search`, `read_image`, `save_memory`, `schedule_task`, `create_image`, `create_voice`, `create_music`, `create_word_document`, `create_excel_file`, `create_pdf_file`, `create_powerpoint_file`, `create_markdown_file`, `send_file`, `tai_video`, `tai_mp3`, `soan_email`, `huong_dan_soan_email`, `nap_huong_dan`, `luu_quy_trinh`, và nếu làm nội dung thì giữ năm cặp công cụ của quy trình năm khâu (xem `docs/noi-dung/`): `huong_dan_nghien_cuu_doi_thu`/`bao_cao_doi_thu`, `huong_dan_ke_hoach_content`/`ke_hoach_content`, `huong_dan_viet_caption`/`viet_caption`, `huong_dan_anh_bai_dang`/`tao_anh_bai_dang`, `huong_dan_do_luong`/`bao_cao_do_luong`.

## Các tính năng tự chạy nền (không phải công cụ)
Những thứ này có công tắc riêng, không nằm trong danh sách công cụ:
- Tự kick bot spam trong nhóm: công tắc "Cho phép tự động kick" khi sửa nick ở trang **Tài khoản Zalo** (mặc định tắt).
- Tự đánh giá tin nhóm không tag, ngưỡng phát hiện dồn dập, chờ giữa 2 lần tự tag lại: trang **Cấu hình** (nhóm tương ứng).
- Báo khách nhắn gấp, báo khi có người tag tên chủ, báo cáo VPS: trang **Cấu hình**, nhóm "Báo cho chủ".
- Insight nhóm tự chạy hằng ngày: trang **Cấu hình**, nhóm "Chung". Second brain Notion: trang **Second brain**.
Tắt những cái bạn không dùng.

## Kiểm tra sau khi tắt
Nhắn bot "bạn làm được những gì?" xem danh sách khả năng đã gọn đúng ý chưa, rồi thử một việc bạn hay nhờ bot để chắc không tắt nhầm công cụ cần thiết.
