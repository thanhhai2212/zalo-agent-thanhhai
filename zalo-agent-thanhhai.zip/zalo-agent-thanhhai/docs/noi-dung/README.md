# Bộ công cụ nội dung: quy trình năm khâu

Một trong các nhóm công cụ của Zalo Agent, dành cho ai cần làm nội dung đăng mạng xã hội: đi từ tìm hiểu đối thủ, lên lịch đăng, viết bài, tạo ảnh, đến đo kết quả. Không làm nội dung thì cứ tắt nhóm này đi (xem [../tat-bot-cong-cu.md](../tat-bot-cong-cu.md)), bot vẫn làm mọi việc khác như thường.

## Năm khâu

| Khâu | Bot làm | File trả về |
|---|---|---|
| 1. Nghiên cứu đối thủ | Tìm và đọc nguồn công khai, so sánh giá, thông điệp, kênh; mỗi đối thủ có nguồn là địa chỉ web thật | Word |
| 2. Kế hoạch nội dung | Trụ cột nội dung, lịch nhiều ngày, câu mở đầu, câu chuyện, lời kêu gọi, ngày thật | Excel |
| 3. Viết caption | Caption đầy đủ theo kênh, hashtag, lời kêu gọi, gợi ý hình | Word |
| 4. Tạo ảnh bài đăng | Bộ tối đa 6 ảnh, đồng nhất phong cách thương hiệu, cắt đúng tỉ lệ từng kênh | Ảnh gửi vào chat |
| 5. Đo lường | Từ số liệu bạn đưa: tỉ lệ tương tác, so sánh theo trụ cột, kênh, định dạng | Excel |

Kết quả khâu trước là đầu vào khâu sau. Năm khâu chỉ chủ bot gọi được. Chi tiết và câu nhắn mẫu: [quy-trinh-5-khau.md](quy-trinh-5-khau.md). Sơ đồ luồng: [so-do-quy-trinh-noi-dung.html](so-do-quy-trinh-noi-dung.html) (mở bằng trình duyệt).

## Bắt đầu

1. Trên Dashboard, tạo một agent và dán persona mẫu trong [persona-tro-ly-noi-dung.md](persona-tro-ly-noi-dung.md).
2. Chọn model vẽ ảnh ở trang Công cụ (dòng "Vẽ ảnh AI").
3. Nhắn thử: `nghiên cứu đối thủ giúp mình: [sản phẩm], [thị trường]`.
4. Muốn thử khâu đo lường: dùng file Excel mẫu `docs/mau/so-lieu-mau-hat-moc.xlsx` (số liệu bịa, chỉ để thử).

## Lưu ý

- Bot chỉ đọc nguồn công khai. Chỗ thiếu số liệu, giá, câu chuyện thật thì bot để trống cho bạn điền.
- Ảnh do AI vẽ là ảnh minh họa.
- Số liệu đo lường do máy tính; nhận định và đề xuất do AI viết, có nhãn "cần kiểm chứng".
- Nghiên cứu sâu và vẽ ảnh tốn hạn mức nhà cung cấp. Một lượt nghiên cứu đối thủ có thể dùng hàng trăm nghìn token, nên hãy đặt trần chi phí trong khóa API và trần ảnh mỗi giờ (nút Giới hạn ở dòng "Vẽ ảnh AI", trang Công cụ).
