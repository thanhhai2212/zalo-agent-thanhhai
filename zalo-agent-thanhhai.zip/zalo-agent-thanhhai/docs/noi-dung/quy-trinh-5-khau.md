# Quy trình năm khâu: cách dùng và ví dụ câu nhắn

Mỗi khâu nối tiếp khâu trước: kết quả khâu 1 là đầu vào khâu 2, và cứ thế. Bot nhớ nội dung trong cùng cuộc trò chuyện, nên bạn có thể nói "từ báo cáo này" hoặc "từ lịch này". Nếu cuộc trò chuyện đã dài hoặc đã đổi ngày, gửi lại file kết quả trước đó cho bot đọc.

## 1. Nghiên cứu đối thủ
Câu nhắn mẫu: `nghiên cứu đối thủ giúp mình: bán cà phê rang xay nguyên chất online toàn quốc, quan tâm giá và thông điệp, để lên kế hoạch content`

- Tin của bạn đã nêu sản phẩm, thị trường, khía cạnh quan tâm và mục đích thì bot làm ngay, nếu thiếu thì hỏi một lần.
- Mất khoảng 2 đến 4 phút.
- Kết quả: file Word gồm tóm tắt, từng đối thủ (định vị, giá, thông điệp, kênh, điểm mạnh, điểm yếu, độ tin cậy, nguồn), bảng so sánh, cơ hội, đề xuất, giới hạn dữ liệu.
- **Đọc kỹ:** điểm mạnh, yếu và giá là dữ kiện có nguồn; mục "Nhận định của AI", cơ hội và đề xuất là phân tích cần bạn kiểm chứng. Độ tin cậy "Cao" chỉ khi có từ hai tên miền nguồn khác nhau.

## 2. Kế hoạch content
Câu nhắn mẫu: `lên content calendar 30 ngày từ báo cáo này, đăng Facebook và TikTok, 5 bài mỗi tuần, bắt đầu 06/10`

- Bot hỏi: mục tiêu, khách mục tiêu, giọng thương hiệu, có quay video hoặc chụp ảnh được không, điều không được nói.
- Kết quả: file Excel gồm Lịch nội dung (ngày, thứ, kênh, định dạng, trụ cột, tiêu đề, hook, ý chính, CTA, trạng thái), Trụ cột nội dung (tỷ trọng đề ra và thực tế), Tổng quan.
- **Bot không tự dựng chuyện cá nhân** của bạn. Chỗ cần chuyện riêng ghi `[điền chuyện thật của bạn: ...]`.

## 3. Viết caption
Câu nhắn mẫu: `viết caption tuần 1 của lịch`

- Mỗi lần tối đa khoảng 12 bài, lịch dài thì chia theo tuần.
- Kết quả: file Word, mỗi bài có caption, CTA, hashtag, gợi ý hình, và dòng "Cần bạn điền trước khi đăng" nếu còn chỗ trống.
- Bot cảnh báo khi caption TikTok quá 2200 ký tự, quá nhiều hashtag, hoặc có câu giống tuyên bố sức khỏe.

## 4. Tạo ảnh bài đăng
Câu nhắn mẫu: `vẽ ảnh cho 3 bài đầu tuần 1, ảnh chụp thực tế, ánh sáng tự nhiên, màu nâu kem xanh rêu, không chữ`

- Tối đa 6 ảnh mỗi lần, mỗi ảnh 1 đến 3 phút, bot gửi từng ảnh khi xong.
- Ảnh được cắt đúng tỉ lệ kênh: 1:1, 4:5, 9:16, 16:9.
- Mặc định **không chữ trên ảnh** vì model hay sai dấu tiếng Việt. Chữ dài, giá, số điện thoại nên thêm bằng Canva.
- Ảnh AI là ảnh **minh họa**. Cần ảnh sản phẩm hay vườn thật thì dùng ảnh bạn chụp.

## 5. Đo lường
Câu nhắn mẫu: gửi file Excel số liệu kèm `đo lường các bài này giúp mình, kỳ 06/10 đến 28/10`

- Số liệu lấy từ file xuất của Meta Business Suite hoặc TikTok Analytics, bạn nhập tay, hoặc ảnh chụp màn hình thống kê. Bot **không tự lấy** số từ tài khoản của bạn.
- Số thiếu để **trống**, không điền 0.
- Mọi phép tính do máy làm. Tỉ lệ tương tác tách theo nền tính (tính trên tiếp cận hoặc lượt xem) vì hai loại không so sánh trực tiếp được.
- Dưới 5 bài thì bot không kết luận. Nhóm dưới 3 bài cùng nền chỉ để tham khảo.
- File mẫu để thử: `docs/mau/so-lieu-mau-hat-moc.xlsx`. Số liệu bịa, mọi sheet đều ghi "DỮ LIỆU MẪU".

## Khi bot không làm theo
- Bot hỏi lại quá ít hoặc làm ngay khi thiếu thông tin: nói rõ "hỏi tôi trước khi làm".
- Báo cáo thiếu nguồn hoặc nguồn nghi ngờ: nhờ "kiểm lại nguồn của đối thủ X".
- Lượt chạy quá lâu hoặc hết hạn mức: xem log và trần ảnh mỗi giờ trong Dashboard, trang Cấu hình.
