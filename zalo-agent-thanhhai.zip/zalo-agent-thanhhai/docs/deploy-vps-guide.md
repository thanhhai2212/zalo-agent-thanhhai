# Triển khai bản Thanh Hải trên VPS

Gói `zalo-agent-thanhhai` do **Bùi Thanh Hải** cấu hình và phát hành. Dùng đúng ZIP được bàn giao. Điều khoản sử dụng nằm trong LICENSE.

## Chuẩn bị

- VPS Linux, Node.js >=22.13 và Corepack/pnpm theo `package.json` nếu chạy trực tiếp.
- Hoặc Docker Engine và Docker Compose v2 nếu chạy container.
- Dùng tài khoản Zalo riêng nếu chạy song song bot khác.
- Mỗi bản có thư mục dữ liệu và khóa mã hóa riêng. Không chép phiên đăng nhập hoặc khóa từ bản khác.

## Cách 1: Docker

Tải ZIP đã sửa lên VPS và giải nén vào thư mục riêng, ví dụ `/opt/zalo-agent-thanhhai/current`. Trong thư mục có `package.json`, chạy:

```bash
bash cai-dat/cai-dat-docker.sh
```

Script tạo `.env` nếu chưa có. Lưu lại mật khẩu và sao lưu `.env` cùng `data/`. Dashboard chỉ publish tại `127.0.0.1:3910`.

Từ máy cá nhân, mở SSH tunnel:

```bash
ssh -L 3910:127.0.0.1:3910 user@VPS
```

Mở `http://127.0.0.1:3910`. Nếu cổng máy cá nhân bị chiếm, đổi vế trái thành `13910`, rồi mở cổng 13910.

```bash
docker compose logs -f zalo-agent-thanhhai
docker compose exec zalo-agent-thanhhai corepack pnpm zalo-doctor
docker compose stop zalo-agent-thanhhai
```

## Cách 2: systemd

Giải nén mã vào `/opt/zalo-agent-thanhhai/current`, xác nhận `node --version` >=22.13 và `corepack pnpm --version` chạy được. Không phụ thuộc runtime của bot khác.

```bash
sudo useradd --system --home /var/lib/zalo-agent-thanhhai --create-home --shell /usr/sbin/nologin zalo-agent-thanhhai
sudo install -d -o zalo-agent-thanhhai -g zalo-agent-thanhhai -m 700 /var/lib/zalo-agent-thanhhai/data
cd /opt/zalo-agent-thanhhai/current
corepack pnpm install --frozen-lockfile
corepack pnpm run build:web
cp .env.production.example .env
```

Nếu user đã tồn tại thì bỏ qua `useradd`. Chỉnh `.env` trước khi bật dịch vụ:

```dotenv
DATA_DIR=/var/lib/zalo-agent-thanhhai/data
DASHBOARD_HOST=127.0.0.1
DASHBOARD_PORT=3910
DASHBOARD_BEHIND_PROXY=false
```

Điền `CREDENTIALS_ENCRYPTION_KEY` mới (64 ký tự hex) và `DASHBOARD_PASSWORD` riêng (ít nhất 8 ký tự). Sao lưu khóa, không đưa vào ZIP chia sẻ. Nếu dùng reverse proxy HTTPS thay SSH tunnel, đặt `DASHBOARD_BEHIND_PROXY=true`.

```bash
sudo chown root:zalo-agent-thanhhai .env
sudo chmod 640 .env
sudo cp deploy/zalo-agent-thanhhai.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now zalo-agent-thanhhai
sudo journalctl -u zalo-agent-thanhhai -f
```

User dịch vụ cần quyền đọc mã và thư viện. Nếu Node nằm ngoài `/usr/local/bin` hoặc `/usr/bin`, sửa PATH/ExecStart trong unit. Truy cập dashboard qua SSH tunnel như trên; không mở trực tiếp cổng ra Internet.

## Thiết lập sau cài đặt

1. Tên dashboard và ứng dụng điện thoại mặc định: **zalo Bot**. Đổi tại trang Thương hiệu.
2. Cấu hình nhà cung cấp AI và model trong dashboard.
3. Thêm tài khoản Zalo, quét QR bằng đúng tài khoản muốn dùng.
4. Trợ lý mặc định mới dùng persona EOB hỗ trợ anh Bùi Thanh Hải. Sửa trong trang Agent; không tự ghi đè persona đã lưu.

Dừng riêng bản này: `sudo systemctl stop zalo-agent-thanhhai`. Dữ liệu bot khác không bị tác động.
