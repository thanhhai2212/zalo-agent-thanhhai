# Đổi account Zalo (mất SIM/bị khóa) mà không mất trí nhớ

Zalo dùng `zca-js` (API không chính thức) nên account phụ có thể bị Zalo khóa
hoặc quét bất cứ lúc nào. File này là hướng dẫn thao tác khi phải chuyển sang
SIM/tài khoản Zalo khác cho MỘT nhân sự (agent) đang dùng.

## Hiểu đúng trước khi làm: "não" và "trí nhớ" tách rời nhau

- **"Não" (persona, model, prompt, cấu hình TTS/STT/Apify/tool)** nằm ở bảng
  `agents`, KHÔNG gắn với account Zalo nào cả. Đổi account xong chỉ cần trỏ
  account mới sang **đúng `agent_id` cũ** (dashboard, mục Accounts) là nhân sự
  đó lập tức có nguyên cấu hình cũ - không cần dựng lại đăng cái gì.
- **"Trí nhớ" hội thoại** (lịch sử chat, tóm tắt nhóm, fact đã nhớ, danh sách
  liên hệ) nằm ở 4 bảng `messages`/`threads`/`memories`/`contacts` - **tất cả
  đều khóa theo `account_id`** (tài khoản Zalo, không phải agent). Account
  Zalo mới = `account_id` mới hoàn toàn -> mặc định trí nhớ về SỐ 0, dù đã
  gán đúng agent cũ.

Script `scripts/migrate-account-data.ts` xử lý đúng vế thứ hai: chuyển trí nhớ
từ account cũ sang account mới.

## Vị trí file và cách chạy

Script nằm tại **`scripts/migrate-account-data.ts`** (gốc repo), chạy bằng
lệnh đã khai trong `package.json`:

```bash
pnpm migrate-account <account-id-cu> <account-id-moi>
```

Không có tuỳ chọn nào khác ngoài `--apply` (xem bên dưới). Chạy được từ bất kỳ
đâu miễn đứng trong thư mục gốc repo (`<thư-mục-gốc-repo>`).

## Các bước làm

### 0. TRƯỚC KHI đổi SIM: ra lệnh cho agent tự tóm tắt + ghi nhớ

Làm bước này khi SIM CŨ **vẫn còn đăng nhập được** - đây là lúc DUY NHẤT bot
còn đọc được lịch sử chat cũ để tóm tắt.

Vì sao cần: bảng `memories` (fact bot nhớ về từng người, khóa theo UID người
đối diện) là thứ DUY NHẤT trong 4 bảng trí nhớ chắc chắn "sống lại" đúng ở
account mới - `threads`/`messages` của chat 1-1 gần như chắc chắn KHÔNG tự nối
lại được (xem lý do ở mục dưới). Nếu quan hệ với ai đó quan trọng, đừng để hết
trong `messages` chờ script chuyển - chủ động ép nó thành 1 dòng `memories`
TRƯỚC khi đổi.

Vào từng thread quan trọng (1-1 hoặc nhóm), nhắn cho bot kiểu:

```
Hãy tóm tắt và ghi nhớ lại toàn bộ bối cảnh, thông tin, yêu cầu của
[Tên người/nhóm] vào memory để lưu trữ lâu dài.
```

Bot dùng tool `save_memory` có sẵn (không cần thêm code) để ghi fact vào đúng
bảng `memories` của account hiện tại. Làm cho MỌI mối quan hệ 1-1 quan trọng -
đây là bước tốn công nhất nhưng KHÔNG có cách nào tự động hóa được (xem mục
"Vì sao chọn tóm tắt tay..." ở cuối file nếu muốn hiểu vì sao chưa tự động
hóa bước này).

Xong bước này rồi mới qua bước 1.

### 1. Đăng nhập account Zalo mới TRƯỚC

```bash
pnpm zalo-login <account-id-moi>
```

Quét QR bằng SIM/tài khoản Zalo mới. Xong bước này mới có `account-id-moi` để
dùng ở bước sau.

### 2. Tạo account đó trên dashboard + gán Agent cũ

Vào dashboard -> Accounts -> thêm account mới (đúng id vừa login) -> phần "não"
chọn **đúng Agent** mà account cũ đang dùng. Bước này làm persona/model/tool
có ngay lập tức, không phụ thuộc script.

### 3. Xem trước (dry-run) - KHÔNG ghi gì

```bash
pnpm migrate-account <account-id-cu> <account-id-moi>
```

In ra số dòng dự kiến chuyển cho từng bảng (`memories`, `contacts`, `messages`,
`threads`). Đọc kỹ trước khi qua bước 4 - đây là bước AN TOÀN, chạy bao nhiêu
lần cũng được, không đụng dữ liệu.

Script tự chặn nếu:
- 2 id truyền vào giống nhau.
- account cũ không tồn tại trong DB (gõ sai id).
- account mới CHƯA tồn tại (chưa làm xong bước 1-2).

### 4. Ghi thật

```bash
pnpm migrate-account <account-id-cu> <account-id-moi> --apply
```

## Cái gì được chuyển, cái gì không

| Bảng | Khóa theo | Kết quả |
|---|---|---|
| `memories` | UID người đối diện (`subject_id`) | Luôn chuyển đúng - UID người ta không đổi dù bot đổi account |
| `contacts` | UID người đối diện (`user_id`) | Chuyển đúng, TRỪ người mà account mới **đã từng gặp rồi** (giữ bản ghi mới, không ghi đè) |
| `messages` | id riêng từng dòng | Luôn chuyển được (không có gì để xung đột) |
| `threads` | `thread_id` do chính Zalo cấp | Xem mục riêng bên dưới - đây là phần PHỨC TẠP nhất |

### Vì sao `threads`/`messages` không đơn giản như 2 bảng kia

`thread_id` là Zalo cấp, không phải mình tự sinh. Suy luận hợp lý (**chưa xác
nhận 100% từ source `zca-js`**):

- **Nhóm chat**: nhiều khả năng giữ NGUYÊN `thread_id` dù account nào trong
  nhóm cũng thấy cùng 1 id đó -> account mới join lại đúng nhóm là lịch sử cũ
  có cơ hội "sống lại" (bot đọc được summary/history cũ của nhóm đó).
- **Chat riêng (1-1)**: gần như chắc chắn `thread_id` đổi theo QUAN HỆ với
  từng account -> lịch sử cũ **không tự hiện lại** dù đã chuyển. Không mất dữ
  liệu (vẫn nằm trong DB, gắn đúng account mới), chỉ là account mới sẽ không
  bao giờ nhận đúng `thread_id` đó nữa nên không đọc tới.

### Xung đột thì xử lý sao

Nếu account mới đã từng có mặt ở đúng nhóm/người đó (trước khi chạy script):
- **`contacts`**: bỏ qua dòng cũ, giữ nguyên bản ghi của account mới.
- **`threads`**: KHÔNG ghi đè - GỘP summary cũ vào ĐẦU summary mới (đánh dấu rõ
  "[Bối cảnh từ tài khoản cũ, trước khi đổi SIM]"), rồi xóa dòng thread cũ.
  Không mất ngữ cảnh, agent đọc được cả 2 giai đoạn.

## Đổi CẢ MÁY chạy bot (không chỉ đổi SIM) - dùng nút Export/Import trên dashboard

Script `migrate-account-data.ts` ở trên chỉ chạy được khi **cùng 1 máy, cùng 1
file DB** (`data/zalo-agent.db` cũ và account mới nằm chung 1 SQLite). Nếu bạn
đổi luôn sang máy khác/VPS khác (DB mới hoàn toàn trống, không có gì để script
đó chuyển), dùng thay bằng 2 nút trên trang **Accounts** của dashboard:

- **"⬇️ Xuất file"**: tải về 1 file JSON (`zalo-agent-memory-<account>-<ngày>.json`)
  chứa TRỌN VẸN cả `memories` (chat 1-1, khóa theo UID người đối diện) LẪN
  tóm tắt các nhóm (`threads.summary`) - khác `migrate-account-data.ts` chỉ
  chuyển được trong cùng DB, file này mang đi đâu cũng được.
- Copy file đó sang máy/VPS mới (USB, cloud, email... tùy bạn).
- Trên máy mới: `pnpm zalo-login` + tạo account mới + gán agent như Bước 1-2 ở
  trên, rồi bấm **"⬆️ Phục hồi"**, chọn đúng file vừa copy.
- Kết quả: chat 1-1 nạp thẳng vào `memories` (dedup - phục hồi lại nhiều lần
  vẫn an toàn); nhóm CHƯA từng thấy ở máy mới thì tạo 1 dòng thread "giữ chỗ"
  với đúng `summary` (chờ account mới join lại đúng nhóm, tin thật tới sẽ tự
  khớp lên đúng dòng này); nhóm ĐÃ từng thấy rồi thì gộp summary y hệt cách
  `migrate-account-data.ts` xử lý xung đột ở trên.

Cả hai đường (script cùng máy, hoặc Export/Import khác máy) đều xử lý được
TRỌN VẸN cả 1-1 lẫn nhóm - chọn đường nào tùy bạn có còn truy cập được DB cũ
trực tiếp hay không.

## Sau khi chạy xong

1. Vào dashboard kiểm tra lại: account mới có đúng số liệu (số thread, số
   contact) tăng lên như log đã báo không.
2. Account cũ (nếu đã đổi hẳn, không dùng lại): tắt/xóa trên dashboard cho
   sạch - dữ liệu account cũ ĐÃ được chuyển đi thì các bảng đó rỗng, xóa
   account không mất gì thêm (trừ credentials Zalo cũ, vốn không dùng được
   nữa nếu SIM đã bị khóa).
3. Khởi động lại bot (`pnpm dev`) nếu đang chạy, để account mới bắt đầu nhận
   tin.

## Vì sao chọn "tóm tắt tay trước khi đổi" thay vì tự động hóa hoàn toàn

Đã cân nhắc 3 hướng khi thiết kế phần này (2026-09-05):

1. **Ánh xạ `thread_id` cũ -> mới ngay lúc chạy script migrate** - BẾ TẮC: lúc
   chạy script, người kia CHƯA hề nhắn cho SIM mới nên `thread_id` mới chưa hề
   tồn tại, không có gì để ánh xạ tới.
2. **Tóm tắt tay + `save_memory` trước khi đổi SIM (đã chọn - Bước 0 ở trên)**
   - dùng ĐÚNG hạ tầng có sẵn (`memories` khóa theo UID người đối diện,
     `migrate-account-data.ts` đã chuyển bảng này), không sửa dòng code nào.
     Cái giá là phải LÀM TAY cho từng mối quan hệ quan trọng.
3. **Tự nối luồng lúc runtime** (agent tự dò `messages` của account CŨ theo UID
   người gửi khi gặp thread mới trống trơn, rồi ghép ngữ cảnh) - tự động hóa
   hoàn toàn nhưng KHÔNG chọn, vì 2 lý do: (a) dự án này đã cố ý xây cách ly
   ngữ cảnh rất chặt giữa các thread/account (từng vá lỗi rò fact chéo NHÓM -
   xem `learned_in_thread_id` ở `memory-store.ts`) - tự động nối lịch sử xuyên
   ACCOUNT (có thể xuyên cả AGENT khác nhau, vd Trợ Lý Kế Toán và Trợ Lý Số)
   có nguy cơ tái hiện đúng loại rò rỉ đó ở tầng cao hơn nếu không thiết kế kỹ;
   (b) phức tạp hơn hẳn - phải sửa vào đúng đường nạp context
   (`history-to-model-messages.ts`), và phải định nghĩa rõ "coi là cùng 1
   người" nghĩa là gì khi có nhiều account cũ. Để dành làm sau nếu thực tế thấy
   việc tóm tắt tay quá tốn công (vd danh sách liên hệ quan trọng quá dài).

## Đã kiểm chứng thế nào

Chạy thật trên **bản sao của DB production** (copy file `data/zalo-agent.db`
ra thư mục tạm, trỏ `DATA_DIR` vào đó) - cả nhánh không xung đột lẫn nhánh có
xung đột dàn dựng thủ công (tạo sẵn 1 contact + 1 thread trùng ở account
"mới"). Không phải chạy trên fixture giả.
