# zalo Bot — bản Thanh Hải

## Nguồn và phạm vi

Người cấu hình và phát hành gói: **Bùi Thanh Hải**.

- Tên mặc định dashboard và ứng dụng điện thoại: **zalo Bot**, người dùng đổi trong trang Thương hiệu.
- Chủ thể công việc: **Bùi Thanh Hải – Giám đốc Ban Quản lý Tòa nhà Eurowindow Office Building (EOB)**. Danh tính trợ lý mới nằm trong `docs/danh-tinh-thanhhai.md`, có thể sửa qua trang Agent. Không ghi đè persona đã lưu.
- Tên gói/container/dịch vụ: `zalo-agent-thanhhai`; tác vụ Windows: `ZaloAgentThanhhai`; cổng mặc định: **3910**.
- Đồng bộ bộ cài, lệnh kiểm tra, Docker healthcheck và tài liệu với tên/cổng mới. Giới hạn nút Dừng theo thư mục của bot.
- Giữ nguyên phần xử lý nhóm, quy tắc công cụ và chức năng của mã gốc. Không thêm cầu nối Boss Telegram hay module phiếu sự cố từ gói Thanh Hải cũ.
- Thông báo bản quyền và điều khoản sử dụng được giữ trong LICENSE.

## Cài đặt

Giải nén gói này vào thư mục riêng. Trong thư mục có `package.json`, xem `HUONG-DAN-CHO-TRO-LY-AI.md` và chạy bộ cài trong `cai-dat/`. Dùng đúng gói được bàn giao.

Gói không chứa khóa API, mật khẩu thật hoặc phiên Zalo. Cần cấu hình nhà cung cấp AI, tài khoản và quyền hoạt động của bot sau cài đặt. Giao diện web đã được dựng sẵn; thư viện vẫn cần cài qua bộ cài.

## Kiểm tra

- 137 kiểm thử cấu hình, agent, persona, chẩn đoán và thương hiệu: đạt.
- TypeScript và build web: đạt.
- Cú pháp PowerShell và shell: đạt.
- Đối chiếu ZIP gốc: không thay đổi mã xử lý nhóm, quy tắc công cụ, LICENSE hoặc lockfile.

Chưa triển khai container thực hoặc đăng nhập Zalo thật. Dữ liệu có sẵn vẫn giữ tên/persona mà người dùng đã lưu; mặc định mới áp dụng khi cài mới hoặc khôi phục mặc định.
