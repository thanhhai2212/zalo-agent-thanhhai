' Chay run-bot.cmd voi cua so AN THAT SU (SW_HIDE=0).
' Task Scheduler goi file nay thay vi goi thang run-bot.cmd, vi co "Hidden"
' trong cai dat Task Scheduler chi an TAC VU khoi danh sach hien thi, KHONG
' an cua so console cua tien trinh - hai thu khac nhau. WScript.Shell.Run
' voi tham so thu 2 = 0 moi that su ep cua so o che do an.
Set objShell = CreateObject("WScript.Shell")
Set objFso = CreateObject("Scripting.FileSystemObject")
strThuMucGoc = objFso.GetParentFolderName(WScript.ScriptFullName)
objShell.Run """" & strThuMucGoc & "\run-bot.cmd""", 0, True
