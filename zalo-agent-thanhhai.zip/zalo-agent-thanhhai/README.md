# zalo Bot — bản Thanh Hải

**Trợ lý AI chạy trên nick Zalo cá nhân. Bạn nhắn cho nó như nhắn cho một nhân viên.**

Bot trả lời khách trong chat riêng và trong nhóm, tìm thông tin trên web, đọc ảnh, tin thoại và file bạn gửi, soạn file Word, Excel, PDF, PowerPoint rồi gửi lại ngay trong cuộc chat. Bạn dạy nó bằng tài liệu và bộ kỹ năng của riêng mình, nối thêm công cụ ngoài qua MCP, và quản lý mọi thứ trên một dashboard web chạy trên máy của chính bạn.

- **Tự lưu trữ:** chạy trên máy Windows của bạn hoặc một VPS Linux. Dữ liệu nằm trên máy bạn, chỉ phần cần trả lời mới gửi tới nhà cung cấp model AI bạn chọn.
- **Không phụ thuộc một hãng AI:** dùng được Gemini, Claude, GPT, DeepSeek... qua bất kỳ cổng tương thích OpenAI nào (khuyên dùng 9Router).
- **Nhiều nick, nhiều "nhân sự":** nhiều nick Zalo chạy chung một tiến trình, mỗi nick gắn một agent với tính cách, model và bộ công cụ riêng.
- **Mã nguồn mở,** giấy phép MIT.

> [!WARNING]
> Bot đăng nhập Zalo qua [zca-js](https://github.com/RFS-ADRENO/zca-js), một thư viện **không chính thức**. Zalo có thể khóa nick dùng cách này. **Chỉ dùng nick phụ, SIM phụ**, không dùng nick chính của bạn.

## Cách bot hoạt động

![Luồng một tin nhắn: Zalo, lọc, gộp tin, agent AI gọi công cụ, làm sạch, trả lời](docs/hinh/luong-tin-nhan.svg)

1. **Lọc trước, gọi AI sau.** Tin nhắn ở cuộc chat đang tắt bot, hoặc tin trong nhóm không tag bot (khi nhóm đặt "chỉ trả lời khi được tag"), bị bỏ qua trước khi gọi model nên không tốn token.
2. **Gộp tin.** Người ta hay nhắn ba bốn tin liền nhau. Bot chờ họ nhắn xong rồi trả lời một lần cho cả cụm.
3. **Agent tự chọn công cụ.** Model đọc persona, lịch sử cuộc chat và trí nhớ về người đang nhắn, rồi tự quyết cần tìm web, tra Kho tri thức, mở một kỹ năng hay tạo file. Nó có thể gọi nhiều công cụ nối tiếp nhau trong một lượt.
4. **Làm sạch rồi gửi.** Câu trả lời được đổi sang định dạng Zalo hiểu (chữ đậm, màu, danh sách), chặn những đoạn lộ hướng dẫn nội bộ, cắt thành nhiều tin nếu quá dài, và tự tag lại người đã hỏi trong nhóm.

### Các thành phần

![Kiến trúc: người nhắn qua Zalo tới Zalo Agent trên máy bạn, dữ liệu SQLite, dashboard, 9Router, model AI và máy chủ MCP](docs/hinh/kien-truc.svg)

## Bot làm được gì

### Trong chat

- **Tìm và đọc thông tin:** tìm web, đọc trang web, đọc lời thoại video YouTube, tra Wikipedia.
- **Đọc thứ bạn gửi:** ảnh, tin nhắn thoại (tự chuyển thành chữ), file PDF, Word, Excel, PowerPoint và file chữ.
- **Tạo file:** Word, Excel, PDF, PowerPoint, Markdown, CSV, HTML, sơ đồ quy trình, email soạn sẵn.
- **Tạo nội dung:** vẽ và sửa ảnh, đọc thành giọng nói, sáng tác nhạc.
- **Tải về:** video TikTok, Facebook, Instagram, YouTube (không logo), hoặc chỉ phần âm thanh thành MP3.
- **Ghi nhớ và hẹn giờ:** nhớ thông tin từng người qua nhiều cuộc chat, tự nhắn nhắc việc theo lịch.
- **Trong nhóm Zalo:** trả lời khi được tag và tự tag lại người hỏi; báo riêng cho bạn khi có người tag tên bạn hoặc khách nhắn gấp.
- **Quy trình nội dung năm khâu (tùy chọn):** nghiên cứu đối thủ, lên lịch đăng, viết caption, tạo ảnh bài đăng, đo kết quả. Xem [docs/noi-dung/](docs/noi-dung/README.md). Không dùng thì tắt đi.

### Kỹ năng (skill)

![Trang Kỹ năng: các bộ kỹ năng thu gọn theo nhóm, mỗi kỹ năng có mô tả một dòng](docs/hinh/dashboard-ky-nang.png)

Kỹ năng là cách bạn dạy bot một quy trình làm việc: cách tư vấn một khóa học, cách viết báo giá, cách xử lý khiếu nại...

- **Tải lên trên trang Kỹ năng:** một file `SKILL.md`, hoặc file `.zip` chứa một hay nhiều thư mục kỹ năng (các file tài liệu kèm trong cùng thư mục được nạp theo). Tên và mô tả lấy từ phần đầu file (`name:`, `description:`).
- **Gom theo bộ:** mỗi file zip thành một bộ, thu gọn và mở ra được; gán agent, đổi tên hoặc xóa cả bộ một lần.
- **Bot chỉ đọc khi cần:** mỗi lượt, bot chỉ thấy tên và mô tả một dòng của từng kỹ năng. Khi việc đang làm khớp với một kỹ năng, bot mới mở toàn văn (kỹ năng dài thì đọc từng phần), nên có nhiều kỹ năng cũng không làm mỗi tin nhắn tốn thêm nhiều token.
- **Bot tự lưu quy trình:** làm xong một việc, bạn nói *"lưu cách làm này thành quy trình X"*, bot đúc kết lại thành một kỹ năng mới để lần sau làm theo.
- **Xem và sửa tay** toàn văn mọi kỹ năng ngay trên dashboard.
- Script đi kèm trong gói (`.py`, `.js`, `.sh`) **không được chạy**: bot đọc tin của người lạ, chạy mã từ gói tải lên là mở đường cho người khác điều khiển máy của bạn.

### Kết nối MCP

Nối thêm công cụ của dịch vụ khác qua giao thức MCP (máy chủ HTTP), ví dụ Apify để lấy dữ liệu mạng xã hội công khai, Notion, Canva.

- **Đăng nhập bằng khóa hoặc OAuth:** dán khóa vào phần header, hoặc bấm đăng nhập OAuth với dịch vụ hỗ trợ (như Canva).
- **Gán theo agent:** server chưa gán thì agent không thấy công cụ của nó.
- **Chỉ chủ bot:** bật cho server nào cầm dữ liệu riêng của bạn (danh sách khách, tài khoản thiết kế). Công cụ của nó chỉ chạy khi chính bạn nhắn riêng cho bot; có thể cho phép thêm trong nhóm, nhưng chỉ ở lượt mà mọi tin đều là của bạn.
- **Tự phát hiện máy chủ đổi công cụ:** nếu máy chủ âm thầm đổi mô tả hay tham số công cụ, bot ngừng dùng và chờ bạn bấm "Duyệt lại".

### Trên dashboard

Menu bên trái gom theo việc thành các nhóm thu gọn được (Hội thoại, Lịch và đăng bài, Bộ não, Phân tích, Kết nối, Hệ thống). Nhóm chứa trang đang xem tự mở ra, và dashboard nhớ những nhóm bạn để mở.

- **Tài khoản Zalo và Agent:** đăng nhập nick bằng mã QR, gán mỗi nick một agent, viết persona, chọn model, bật tắt từng công cụ.
- **Phân quyền Bot:** cho từng nhóm và từng người: bật tắt trả lời, chỉ trả lời khi được tag, tắt bớt công cụ, giới hạn riêng tư, model riêng.
- **Kho tri thức:** nạp tài liệu (PDF, Word, Excel, PowerPoint, văn bản) để bot tra cứu và trả lời đúng theo tài liệu của bạn.
- **Insight nhóm:** phân tích tin nhắn các nhóm bạn chọn thành báo cáo câu hỏi, khó khăn, mong muốn của thành viên, xuất Word, Excel, PDF.
- **Second brain:** đồng bộ các cặp hỏi đáp hay sang Notion.
- **Đăng bài nhóm (tùy chọn):** bot soạn bài và ảnh cho nhóm bạn làm chủ hoặc phó nhóm, chỉ đăng sau khi bạn duyệt.
- **Lịch hẹn, Trí nhớ, Nhật ký, Theo dõi agent:** xem và sửa mọi thứ bot đã lên lịch, đã nhớ, đã làm.
- **Thương hiệu:** đổi tên, logo, màu cho dashboard và ứng dụng điện thoại.
- **Ứng dụng điện thoại:** theo dõi bot, khách mới, cảnh báo máy chủ ngay trên điện thoại. Cài theo [docs/ung-dung-dien-thoai.md](docs/ung-dung-dien-thoai.md).

## Cài đặt

![Năm bước: cài đặt, nối model AI, đăng nhập Zalo, tạo agent, nạp tri thức và nhắn thử](docs/hinh/bat-dau.svg)

Cần: Node.js 22.13 trở lên, một nick Zalo phụ, và một khóa API của nhà cung cấp model AI (hoặc 9Router).

### Cách 1. Windows, để trợ lý AI cài giúp

Nếu bạn dùng Claude Code, Codex hay Antigravity: tải mã nguồn về, mở thư mục đó trong trợ lý rồi nói *"Đọc file HUONG-DAN-CHO-TRO-LY-AI.md rồi cài giúp tôi"*. File đó hướng dẫn trợ lý từng bước, kể cả cài 9Router.

### Cách 2. Windows, tự cài

```powershell
# Giải nén gói zalo-agent-thanhhai.zip, rồi mở PowerShell trong thư mục có package.json.
powershell -ExecutionPolicy Bypass -File cai-dat\cai-dat.ps1
```

Script kiểm tra Node.js, cài thư viện, tạo file `.env` với khóa ngẫu nhiên, dựng giao diện và in ra **mật khẩu dashboard** ở cuối. Hãy ghi lại mật khẩu này. Sau đó bấm đúp `cai-dat\Khoi-dong.cmd` để chạy bot.

### Cách 3. VPS Linux (chạy 24/7)

Làm theo [docs/deploy-vps-guide.md](docs/deploy-vps-guide.md): nối máy với VPS qua Tailscale, cài 9Router, chạy bot bằng systemd, mở dashboard qua mạng riêng thay vì mở cổng ra internet. Cũng có thể cài bằng Docker: `bash cai-dat/cai-dat-docker.sh`.

### Sau khi chạy

1. Mở `http://localhost:3910` và đăng nhập bằng mật khẩu dashboard.
2. **Cấu hình > Nhà cung cấp LLM:** nhập địa chỉ router, tên model và khóa API. Làm bước này trước tiên.
3. **Tài khoản Zalo:** thêm nick, quét mã QR bằng điện thoại để đăng nhập.
4. **Agent:** tạo agent, viết persona (vai trò, giọng nói, điều không được làm), rồi gán agent vào nick.
5. **Kho tri thức, Kỹ năng:** nạp tài liệu và bộ kỹ năng của bạn, gán cho agent.
6. Nhắn thử cho nick bot một câu hỏi về chính tài liệu bạn vừa nạp.

Gặp lỗi thì chạy `corepack pnpm zalo-doctor` để chẩn đoán (thêm `--fix` để tự sửa những lỗi sửa được).

### Tắt bớt công cụ

Mỗi công cụ đang bật là một đoạn mô tả gửi kèm mọi lượt chat. Tắt những thứ bạn không dùng giúp bot tốn ít token hơn, trả lời nhanh hơn và ít nhầm hơn. Xem [docs/tat-bot-cong-cu.md](docs/tat-bot-cong-cu.md).

## Phát triển tiếp

```bash
corepack pnpm install        # cài thư viện
corepack pnpm dev            # chạy bot, tự tải lại khi sửa code
corepack pnpm dev:web        # chỉ chạy giao diện dashboard (không đụng Zalo)
corepack pnpm typecheck      # kiểm tra kiểu, chạy trước mỗi lần commit
corepack pnpm test           # chạy toàn bộ test
corepack pnpm build:web      # dựng giao diện cho bản chạy thật
```

Dùng `corepack pnpm` thay cho `pnpm` để đúng phiên bản pnpm ghim trong `package.json`.

**Mỗi nick Zalo chỉ chạy ở một nơi.** Nếu nick đó đang chạy ở máy khác hoặc trên VPS, đừng chạy `pnpm dev` với cùng thư mục `data/`: hai bên sẽ đá nhau liên tục. Khi phát triển, hãy dùng một nick thử riêng.

### Cấu trúc thư mục

| Thư mục | Nội dung |
|---|---|
| `src/zalo/` | Đăng nhập Zalo, nhận tin, lọc, gộp tin, gửi trả lời |
| `src/agent/` | Vòng lặp agent: gọi model, gọi công cụ, chữa lỗi nhà cung cấp |
| `src/agent/tools/` | Từng công cụ bot gọi được, mỗi công cụ một file |
| `src/knowledge/` | Kho tri thức và Kỹ năng (tìm kiếm toàn văn, nạp gói skill) |
| `src/mcp/` | Kết nối máy chủ MCP, đăng nhập OAuth, phát hiện đổi công cụ |
| `src/noi-dung/` | Quy trình nội dung năm khâu |
| `src/conversation/` | Lịch sử, trí nhớ, cơ sở dữ liệu SQLite |
| `src/scheduler/` | Lịch hẹn và tin nhắn chủ động |
| `src/server/` | API của dashboard |
| `web/src/` | Giao diện dashboard (React) |
| `docs/` | Hướng dẫn cài đặt và vận hành |

## Bản này không có

Quản trị nhóm qua chat (kick, phó nhóm, duyệt thành viên), tạo video AI, slide thiết kế, văn bản hành chính, chạy script của bộ kỹ năng, gói thuê bao và giới hạn lượt dùng theo từng khách, gửi tin hàng loạt kiểu chiến dịch CRM.

## Tài liệu

- [HUONG-DAN-CHO-TRO-LY-AI.md](HUONG-DAN-CHO-TRO-LY-AI.md): cài trên Windows bằng trợ lý AI
- [docs/deploy-vps-guide.md](docs/deploy-vps-guide.md): triển khai lên VPS
- [docs/ung-dung-dien-thoai.md](docs/ung-dung-dien-thoai.md): ứng dụng điện thoại
- [docs/tat-bot-cong-cu.md](docs/tat-bot-cong-cu.md): tắt bớt công cụ không dùng
- [docs/account-migration-guide.md](docs/account-migration-guide.md): đổi nick Zalo hoặc chuyển máy mà không mất trí nhớ hội thoại
- [docs/noi-dung/](docs/noi-dung/README.md): quy trình nội dung năm khâu, persona mẫu, file Excel mẫu
- [CHANGELOG.md](CHANGELOG.md): lịch sử thay đổi

## Giấy phép

MIT, xem [LICENSE](LICENSE).

Phần mềm được cung cấp nguyên trạng, không kèm bảo đảm. Bạn tự chịu trách nhiệm về nick Zalo của mình và nội dung bot gửi đi.

## Bản Thanh Hải

Gói do **Bùi Thanh Hải** cấu hình và phát hành. Tên mặc định **zalo Bot**, đổi được trong trang Thương hiệu. Danh tính mặc định mới hỗ trợ **Bùi Thanh Hải – Giám đốc Ban Quản lý Tòa nhà Eurowindow Office Building (EOB)**, sửa được trong trang Agent. Không ghi đè danh tính đã lưu. Cổng mặc định 3910; tác vụ Windows `ZaloAgentThanhhai`; Docker service `zalo-agent-thanhhai`.

Người phát hành và phụ trách cấu hình: **Bùi Thanh Hải**. Xem `BAN-THANHHAI.md`.
