@echo off
REM Bam dup file nay de DUNG zalo-agent. Bot se KHONG tu chay lai cho den khi
REM ban bam dup Start-Bot.cmd, hoac dang xuat/dang nhap lai Windows.
REM
REM Cua so nay TU DONG DONG sau 3 giay - khong can bam phim.
schtasks /End /TN "ZaloAgentThanhhai"
echo.
echo Da yeu cau dung ZaloAgentThanhhai.
echo.
echo Cua so nay se tu dong tat...
timeout /t 3 >nul
