@echo off
REM Script chay boi Task Scheduler (task "ZaloAgentThanhhai") - KHONG phai bam tay.
REM Doc lap voi moi phien Claude Code / terminal: chuyen the, dong terminal,
REM tat Claude Code deu KHONG anh huong den tien trinh nay.
REM
REM %~dp0 = chinh thu muc chua file nay, nen chay dung du goi tu dau.
cd /d "%~dp0"
corepack pnpm dev >> "data\logs\process-supervisor.log" 2>&1
