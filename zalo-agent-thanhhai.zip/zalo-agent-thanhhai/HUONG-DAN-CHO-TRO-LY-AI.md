# Hướng dẫn dành cho trợ lý AI (Claude Code / Codex / Antigravity)

File này viết cho **trợ lý AI** đang giúp khách cài Zalo Agent trên Windows. Khách chỉ cần nói: "Đọc file HUONG-DAN-CHO-TRO-LY-AI.md rồi cài giúp tôi". Hãy làm đúng theo thứ tự dưới đây.

## Quy tắc bắt buộc

1. **Không in, không ghi vào chat, không commit** bất kỳ khóa nào: `CREDENTIALS_ENCRYPTION_KEY`, `DASHBOARD_PASSWORD`, API key, token, cookie Zalo. Script cài đặt tự tạo và tự ghi vào `.env`.
2. **Mật khẩu dashboard**: script in ra MỘT lần ở cuối. Hãy chuyển nguyên văn cho khách và dặn khách tự ghi lại. Đừng lưu vào file nào khác.
3. **Chỉ dùng Zalo phụ** (nick phụ, SIM phụ). zca-js là API không chính thức, nick chính có nguy cơ bị khóa. Nhắc khách nếu họ định đăng nhập nick chính.
4. **Mỗi nick Zalo chỉ chạy một nơi.** Nếu khách đã chạy bot cùng nick trên máy/VPS khác, KHÔNG bật bot ở máy này (hai bên sẽ đá nhau liên tục).
5. **Không sửa mã nguồn** trong `src/` khi cài đặt. Cài đặt chỉ cần chạy script, không cần sửa code.
6. **Không tự chạy lệnh xóa** (`rm -rf`, `Remove-Item -Recurse`) lên thư mục `data/` hoặc file `.env`. Hai nơi này chứa phiên Zalo và khóa mã hóa, mất là không lấy lại được.
7. Không nối bất kỳ công cụ chuyển tiền, thanh toán nào vào bot.
8. Mọi thao tác cần đăng nhập (Google, OpenRouter, Zalo QR...) là việc của **khách**. Hướng dẫn rồi chờ khách làm, không nhập hộ mật khẩu.

## Bước 0. Chuẩn bị

Yêu cầu: Windows 10/11, kết nối mạng, khoảng 2 GB trống.

Nếu khách nhận gói dạng file `.zip`: giải nén vào thư mục KHÔNG có dấu và KHÔNG có khoảng trắng, ví dụ `C:\ZaloAgent`. Nếu có sẵn thư mục thì dùng luôn.

## Bước 1. Cài đặt tự động

Mở PowerShell trong thư mục Zalo Agent và chạy:

```powershell
powershell -ExecutionPolicy Bypass -File cai-dat\cai-dat.ps1
```

Script sẽ lần lượt: kiểm tra Node.js (cần 22.13+; thiếu thì cài bằng winget), cài thư viện, tạo `.env` với khóa ngẫu nhiên, dựng giao diện dashboard, cài 9Router, rồi chạy kiểm tra.

- Nếu script báo "Đã cài Node.js, hãy đóng cửa sổ và mở lại": làm đúng như vậy rồi chạy lại cùng lệnh.
- Chạy lại nhiều lần là an toàn: thứ gì có rồi thì bỏ qua, `.env` có rồi thì giữ nguyên.
- Tùy chọn: `-KhongCaiRouter` (đã có router), `-TuKhoiDong` (tự bật khi đăng nhập Windows), `-ChayLuon` (cài xong bật luôn).

Cuối script có dòng **Mật khẩu dashboard**. Báo cho khách ghi lại.

## Bước 2. Kiểm tra

```powershell
powershell -ExecutionPolicy Bypass -File cai-dat\kiem-tra.ps1
```

Mọi dòng `[OK]` là đạt. Dòng `[LOI]` có kèm hướng xử lý ngay bên dưới. Dòng `[--]` là cảnh báo nhẹ.

## Bước 3. Bật bot và mở dashboard

Bấm đúp `cai-dat\Khoi-dong.cmd` (chạy ẩn). Đợi khoảng 15 giây, mở `http://127.0.0.1:3910`, đăng nhập bằng mật khẩu ở Bước 1. Dừng bot bằng `cai-dat\Dung.cmd`.

Chạy `kiem-tra.ps1` lần nữa: lúc này phải thấy "Zalo Agent đang chạy".

## Bước 4. Nối model AI (việc của khách, hướng dẫn từng bước)

Làm theo video hướng dẫn tương ứng, thứ tự:

1. Mở 9Router: chạy `9router --port 20128 --host 127.0.0.1`, vào `http://127.0.0.1:20128`.
2. Thêm nhà cung cấp model (OpenRouter có nạp tiền, hoặc tài khoản Google/Antigravity). Chọn model.
3. Trong 9Router tạo một API key. Trong dashboard Zalo Agent, trang **Cấu hình > Nhà cung cấp LLM**, chọn kiểu kết nối OpenAI-compatible, nhập Base URL `http://127.0.0.1:20128/v1` và key vừa tạo.
4. Tạo agent đầu tiên (trang **Agents**), đăng nhập nick Zalo phụ bằng QR (trang **Tài khoản**), nhắn thử một tin để kiểm tra.

## Lưu ý theo nền tảng

- Bản này chạy **đủ mọi tính năng trên Windows**: chat, quy trình nội dung 5 khâu, công cụ tìm kiếm/đọc web, tạo file Word/Excel/PDF/PowerPoint, vẽ ảnh, giọng đọc (Gemini/ElevenLabs...), tạo nhạc, tải video/MP3, Kho tri thức, Kỹ năng, MCP, lịch hẹn, dashboard, ứng dụng điện thoại.
- VPS Linux chỉ cần khi khách muốn bot chạy 24/7 không phụ thuộc máy tính. Khi đó hướng dẫn thuê VPS Ubuntu 24.04 và làm theo `docs/deploy-vps-guide.md`.

## Lỗi thường gặp

| Triệu chứng | Cách xử lý |
|---|---|
| `corepack pnpm` báo lỗi | `npm install -g corepack` rồi chạy lại script. Không dùng `corepack enable` (cần quyền quản trị). |
| Cổng 3910 đã bị chiếm | Đổi `DASHBOARD_PORT` trong `.env` rồi khởi động lại. |
| Dashboard không mở được | Chạy `kiem-tra.ps1`. Chưa chạy thì bấm `Khoi-dong.cmd`, xem `data\logs\process-supervisor.log`. |
| Đăng nhập Zalo QR rồi bot "mất kết nối" liên tục | Nick đang mở ở nơi khác (Zalo Web, máy khác). Đóng nơi đó, đăng nhập QR lại. |
| Quên mật khẩu dashboard | Mở `.env`, sửa dòng `DASHBOARD_PASSWORD=` (tối thiểu 8 ký tự), khởi động lại bot. |
| Bot không trả lời | Kiểm tra: đã nối model ở 9Router chưa, agent đã gán cho nick chưa, nhóm có bật "cần @mention" không. |

## Khi hoàn tất

Báo khách tóm tắt: đã cài xong, địa chỉ dashboard, nhắc sao lưu file `.env` và thư mục `data\` ở nơi an toàn, và nhắc không chia sẻ chúng cho người khác.

Hỏi khách có muốn xem bot trên điện thoại không (tùy chọn, không bắt buộc). Nếu có, đưa khách file `docs/ung-dung-dien-thoai.md` và để khách tự làm theo: các bước đều là đăng nhập tài khoản của khách (Tailscale, điện thoại), bạn không làm hộ.
