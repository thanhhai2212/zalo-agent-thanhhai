@echo off
REM Bam dup de BAT Zalo Agent (chay an, khong hien cua so).
REM Neu da dang ky tac vu tu chay (cai-dat.ps1 -TuKhoiDong) thi goi tac vu do;
REM chua thi chay thang. Cua so nay tu dong dong sau vai giay.
schtasks /Query /TN "ZaloAgentThanhhai" >nul 2>&1
if %errorlevel%==0 (
  schtasks /Run /TN "ZaloAgentThanhhai" >nul
) else (
  start "" wscript.exe "%~dp0chay-an.vbs"
)
echo.
echo Da yeu cau khoi dong Zalo Agent. Doi khoang 15 giay roi mo:
echo     http://127.0.0.1:3910
echo.
timeout /t 5 >nul
