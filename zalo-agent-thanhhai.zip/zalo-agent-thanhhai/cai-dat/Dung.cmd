@echo off
REM Bam dup de DUNG Zalo Agent. Bot dung han cho den khi ban bam Khoi-dong.cmd.
schtasks /End /TN "ZaloAgentThanhhai" >nul 2>&1
REM Tat tien trinh bot dang chay (neu bat bang tay hoac bang Khoi-dong.cmd)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0dung-bot.ps1"
echo.
echo Da dung Zalo Agent.
echo.
timeout /t 3 >nul
