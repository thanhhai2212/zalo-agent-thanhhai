# Stop only Node processes launched from this package, never another bot folder.
param([switch]$ChiKiemTra)
$Goc = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))

function Test-BotCommandLine([string]$CommandLine, [string]$Root) {
    if (-not $CommandLine) { return $false }
    $line = $CommandLine.Replace('\', '/').ToLowerInvariant()
    $botRoot = $Root.Replace('\', '/').TrimEnd('/').ToLowerInvariant()
    $hasRoot = $line.Contains($botRoot + '/node_modules/') -or $line.Contains($botRoot + '/src/index.ts')
    return $hasRoot -and $line.Contains('src/index.ts')
}

if (-not $ChiKiemTra) {
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object {
        Test-BotCommandLine $_.CommandLine $Goc
    } | ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }
}
