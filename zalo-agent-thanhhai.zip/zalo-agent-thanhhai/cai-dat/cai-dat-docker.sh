#!/usr/bin/env bash
# Cài Zalo Agent bằng Docker - một lệnh, chạy trong thư mục code đã tải về:
#   bash cai-dat/cai-dat-docker.sh
# Linux / macOS / Windows (WSL2). Cần Docker Engine + Docker Compose v2.
set -euo pipefail
cd "$(dirname "$0")/.."

do_() { printf '\033[31m%s\033[0m\n' "$*"; }
xanh() { printf '\033[32m%s\033[0m\n' "$*"; }

command -v docker >/dev/null || { do_ "Chưa có Docker. Cài tại https://docs.docker.com/engine/install/ rồi chạy lại."; exit 1; }
docker compose version >/dev/null 2>&1 || { do_ "Chưa có Docker Compose v2 (lệnh 'docker compose')."; exit 1; }

if [ ! -f .env ]; then
  if [ -f data/zalo-agent.db ]; then
    do_ "Có dữ liệu cũ trong ./data nhưng thiếu .env - KHÔNG tạo khóa mới (khóa mới làm mất phiên Zalo và API key đã lưu)."
    do_ "Chép lại file .env cũ (có CREDENTIALS_ENCRYPTION_KEY) rồi chạy lại."
    exit 1
  fi
  khoa=$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')
  matkhau=$(head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n')
  cat > .env <<ENV
LOG_LEVEL=info
LOG_FILE_ENABLED=true
LOG_FILE_KEEP_DAYS=7
DASHBOARD_BEHIND_PROXY=false
CREDENTIALS_ENCRYPTION_KEY=$khoa
DASHBOARD_PASSWORD=$matkhau
ENV
  chmod 600 .env
  xanh "Đã tạo .env. Mật khẩu dashboard lần đầu: $matkhau  (đổi ngay trên web sau khi vào)"
  echo "Sao lưu file .env cùng thư mục data/: mất khóa trong .env thì bản sao lưu dữ liệu vô dụng."
fi

mkdir -p data
# Container chạy bằng user 'node' (uid 1000) - cho nó quyền ghi ./data.
if [ "$(id -u)" = "0" ]; then chown -R 1000:1000 data; fi

echo "Đang dựng và khởi động (lần đầu mất vài phút)..."
docker compose up -d --build

for _ in $(seq 1 30); do
  if curl -fs -o /dev/null http://127.0.0.1:3910/ 2>/dev/null; then
    xanh "Zalo Agent đang chạy: http://127.0.0.1:3910"
    echo "Tiếp theo: vào dashboard > Cấu hình > Nhà cung cấp LLM, rồi Accounts > thêm tài khoản và quét QR."
    echo "Chẩn đoán khi lỗi: docker compose exec zalo-agent-thanhhai corepack pnpm zalo-doctor"
    exit 0
  fi
  sleep 3
done
do_ "Chưa thấy dashboard trả lời sau 90 giây. Xem log: docker compose logs -f"
exit 1
