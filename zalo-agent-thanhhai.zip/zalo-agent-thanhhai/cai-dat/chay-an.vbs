' Chay Zalo Agent o che do AN (khong hien cua so den), dung cho tac vu tu chay
' ZaloAgentThanhhai va nut Khoi-dong.cmd. Nhat ky ghi o data\logs\process-supervisor.log.
Set objShell = CreateObject("WScript.Shell")
Set objFso = CreateObject("Scripting.FileSystemObject")
strGoc = objFso.GetParentFolderName(objFso.GetParentFolderName(WScript.ScriptFullName))
If Not objFso.FolderExists(strGoc & "\data\logs") Then
    If Not objFso.FolderExists(strGoc & "\data") Then objFso.CreateFolder strGoc & "\data"
    objFso.CreateFolder strGoc & "\data\logs"
End If
objShell.CurrentDirectory = strGoc
objShell.Run "cmd /c corepack pnpm start >> data\logs\process-supervisor.log 2>&1", 0, True
