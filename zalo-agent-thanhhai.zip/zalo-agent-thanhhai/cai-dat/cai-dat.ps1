# Cai dat Zalo Agent tren Windows bang MOT lenh.
#
#   Mo PowerShell trong thu muc Zalo Agent roi chay:
#       powershell -ExecutionPolicy Bypass -File cai-dat\cai-dat.ps1
#
# Tuy chon:
#   -MatKhau "abc12345"   Mat khau dashboard (de trong thi tu tao ngau nhien)
#   -KhongCaiRouter       Bo qua cai 9Router (da co san hoac dung router khac)
#   -TuKhoiDong           Dang ky chay nen, tu bat khi dang nhap Windows
#   -ChayLuon             Cai xong khoi dong bot ngay
#
# Script chay lai nhieu lan duoc: cai roi thi bo qua, .env co roi thi giu nguyen.
# Khong gui du lieu di dau, khong can quyen quan tri (tru khi tu cai Node qua winget).
# Cac thong bao viet khong dau de PowerShell cu hien dung.
param(
    [string]$MatKhau = "",
    [switch]$KhongCaiRouter,
    [switch]$TuKhoiDong,
    [switch]$ChayLuon
)

$ErrorActionPreference = "Stop"
$Goc = Split-Path -Parent $PSScriptRoot
Set-Location $Goc

function Buoc($so, $tong, $noiDung) { Write-Host ""; Write-Host "[$so/$tong] $noiDung" -ForegroundColor Cyan }
function Ok($noiDung) { Write-Host "  OK  $noiDung" -ForegroundColor Green }
function Canh($noiDung) { Write-Host "  !!  $noiDung" -ForegroundColor Yellow }
function Dung($noiDung) { Write-Host ""; Write-Host "  LOI  $noiDung" -ForegroundColor Red; exit 1 }

$TONG = 7
Write-Host ""
Write-Host "=== Cai dat Zalo Agent ===" -ForegroundColor White
Write-Host "Thu muc: $Goc"

# ---- 1. Node.js ----
Buoc 1 $TONG "Kiem tra Node.js (can phien ban 22.13 tro len)"
$nodeOk = $false
try {
    $v = (& node -v) -replace "^v", ""
    $p = $v.Split(".")
    if ([int]$p[0] -gt 22 -or ([int]$p[0] -eq 22 -and [int]$p[1] -ge 13)) { $nodeOk = $true; Ok "Node.js $v" }
    else { Canh "Node.js $v qua cu" }
} catch { Canh "Chua cai Node.js" }

if (-not $nodeOk) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "  Dang cai Node.js LTS bang winget (co the hien hop thoai xin quyen)..."
        & winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
        Write-Host ""
        Write-Host "  Da cai Node.js. HAY DONG cua so PowerShell nay, mo cua so MOI roi chay lai lenh cai dat." -ForegroundColor Yellow
        exit 0
    }
    Dung "Hay cai Node.js LTS tai https://nodejs.org roi chay lai script nay."
}

# ---- 2. pnpm qua corepack ----
Buoc 2 $TONG "Kiem tra pnpm (di kem Node.js qua corepack)"
# Khong dung 'corepack enable' vi can quyen quan tri; goi thang 'corepack pnpm' thi khong can.
try {
    $pv = (& corepack pnpm --version) 2>&1 | Select-Object -Last 1
    if ($LASTEXITCODE -ne 0) { throw "corepack loi" }
    Ok "pnpm $pv"
} catch { Dung "Khong chay duoc 'corepack pnpm'. Thu: npm install -g corepack roi chay lai." }

# ---- 3. Cai thu vien ----
Buoc 3 $TONG "Cai thu vien (lan dau mat 2-5 phut)"
& corepack pnpm install --frozen-lockfile
if ($LASTEXITCODE -ne 0) { Dung "pnpm install that bai. Kiem tra ket noi mang roi chay lai." }
Ok "Da cai xong thu vien"

# ---- 4. Tao .env ----
Buoc 4 $TONG "Tao file cau hinh .env (khoa ma hoa + mat khau dashboard)"
$envFile = Join-Path $Goc ".env"
if (-not (Test-Path $envFile)) { Copy-Item (Join-Path $Goc ".env.example") $envFile }
$noiDung = Get-Content $envFile -Raw -Encoding UTF8

function Doc-Gia-Tri($ten) {
    $m = [regex]::Match($noiDung, "(?m)^$ten=(.*)$")
    if ($m.Success) { return $m.Groups[1].Value.Trim() } else { return "" }
}
function Dat-Gia-Tri($ten, $giaTri) {
    if ([regex]::IsMatch($script:noiDung, "(?m)^$ten=")) {
        $script:noiDung = [regex]::Replace($script:noiDung, "(?m)^$ten=.*$", "$ten=$giaTri")
    } else {
        $script:noiDung = $script:noiDung.TrimEnd() + "`r`n$ten=$giaTri`r`n"
    }
}

$matKhauMoi = ""
if (-not (Doc-Gia-Tri "CREDENTIALS_ENCRYPTION_KEY")) {
    $bytes = New-Object byte[] 32
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($bytes)
    $khoa = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
    Dat-Gia-Tri "CREDENTIALS_ENCRYPTION_KEY" $khoa
    Ok "Da tao khoa ma hoa moi"
    Canh "SAO LUU file .env. Mat khoa nay thi mat toan bo phien Zalo va API key da nhap."
} else { Ok "Giu nguyen khoa ma hoa da co" }

if (-not (Doc-Gia-Tri "DASHBOARD_PASSWORD")) {
    if (-not $MatKhau) {
        $kyTu = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789".ToCharArray()
        $b = New-Object byte[] 12
        [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
        $MatKhau = -join ($b | ForEach-Object { $kyTu[$_ % $kyTu.Length] })
    }
    if ($MatKhau.Length -lt 8) { Dung "Mat khau dashboard phai tu 8 ky tu tro len." }
    Dat-Gia-Tri "DASHBOARD_PASSWORD" $MatKhau
    $matKhauMoi = $MatKhau
    Ok "Da dat mat khau dashboard"
} else { Ok "Giu nguyen mat khau dashboard da co" }

[System.IO.File]::WriteAllText($envFile, $noiDung, (New-Object System.Text.UTF8Encoding($false)))

# ---- 5. Build giao dien ----
Buoc 5 $TONG "Dung giao dien dashboard"
& corepack pnpm run build:web
if ($LASTEXITCODE -ne 0) { Dung "Build giao dien that bai." }
Ok "Da dung xong giao dien"

# ---- 6. 9Router ----
Buoc 6 $TONG "Cai 9Router (bo dinh tuyen model AI)"
if ($KhongCaiRouter) { Canh "Bo qua theo yeu cau -KhongCaiRouter" }
elseif (Get-Command 9router -ErrorAction SilentlyContinue) { Ok "9Router da co san" }
else {
    & npm install -g 9router
    if ($LASTEXITCODE -ne 0) { Canh "Cai 9Router that bai. Co the chay lai sau: npm install -g 9router" }
    else { Ok "Da cai 9Router" }
}

# ---- 7. Chay nen / tien ich ----
Buoc 7 $TONG "Tao nut Khoi dong / Dung"
$dir = Join-Path $Goc "cai-dat"
if ($TuKhoiDong) {
    $vbs = Join-Path $dir "chay-an.vbs"
    $tr = "wscript.exe `"$vbs`""
    & schtasks /Create /TN "ZaloAgentThanhhai" /TR $tr /SC ONLOGON /RL LIMITED /F | Out-Null
    if ($LASTEXITCODE -eq 0) { Ok "Da dang ky tu chay khi dang nhap Windows (tac vu ZaloAgentThanhhai)" }
    else { Canh "Khong dang ky duoc tac vu tu chay. Van chay tay duoc bang Khoi-dong.cmd" }
}
Ok "Dung cai-dat\Khoi-dong.cmd de bat, cai-dat\Dung.cmd de tat"

# ---- Kiem tra ----
Write-Host ""
& powershell -ExecutionPolicy Bypass -File (Join-Path $dir "kiem-tra.ps1") -ChiKiemTraCaiDat

Write-Host ""
Write-Host "=== XONG ===" -ForegroundColor Green
if ($matKhauMoi) {
    Write-Host ""
    Write-Host "  Mat khau dashboard cua ban:  $matKhauMoi" -ForegroundColor White
    Write-Host "  (Ghi lai ngay. Vao dashboard roi doi mat khau o trang Cau hinh.)"
}
Write-Host ""
Write-Host "  Buoc tiep theo:"
Write-Host "   1. Bat bot:   cai-dat\Khoi-dong.cmd   (hoac: corepack pnpm start)"
Write-Host "   2. Mo dashboard: http://127.0.0.1:3910"
Write-Host "   3. Mo 9Router:   http://127.0.0.1:20128  (chay lenh: 9router --port 20128 --host 127.0.0.1)"
Write-Host "   4. Lam theo video huong dan: noi model AI -> dang nhap Zalo -> tao agent"
Write-Host ""

if ($ChayLuon) {
    Write-Host "Dang khoi dong bot..." -ForegroundColor Cyan
    Start-Process -FilePath "wscript.exe" -ArgumentList "`"$(Join-Path $dir 'chay-an.vbs')`""
    Start-Sleep -Seconds 12
    & powershell -ExecutionPolicy Bypass -File (Join-Path $dir "kiem-tra.ps1")
}
