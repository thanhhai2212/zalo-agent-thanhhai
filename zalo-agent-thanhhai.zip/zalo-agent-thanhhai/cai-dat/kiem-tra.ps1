# Kiem tra Zalo Agent da cai dung chua / dang chay khong.
#   powershell -ExecutionPolicy Bypass -File cai-dat\kiem-tra.ps1
# Chi DOC, khong sua gi, khong in ra khoa hay mat khau.
param([switch]$ChiKiemTraCaiDat)

$Goc = Split-Path -Parent $PSScriptRoot
Set-Location $Goc
$loi = 0
$dashboardPort = 3910
$envPath = Join-Path $Goc ".env"
if (Test-Path $envPath) {
    $match = [regex]::Match((Get-Content $envPath -Raw -Encoding UTF8), '(?m)^DASHBOARD_PORT=["'']?(\d+)["'']?\s*$')
    if ($match.Success) { $dashboardPort = [int]$match.Groups[1].Value }
}

function Ket($dat, $ten, $huongDan) {
    if ($dat) { Write-Host "  [OK]   $ten" -ForegroundColor Green }
    else { Write-Host "  [LOI]  $ten" -ForegroundColor Red; if ($huongDan) { Write-Host "         -> $huongDan" -ForegroundColor Yellow }; $script:loi++ }
}
function Canh($ten, $ghiChu) { Write-Host "  [--]   $ten  ($ghiChu)" -ForegroundColor DarkYellow }
function Co-Gia-Tri($tep, $ten) {
    if (-not (Test-Path $tep)) { return $false }
    $m = [regex]::Match((Get-Content $tep -Raw -Encoding UTF8), "(?m)^$ten=(.+)$")
    return ($m.Success -and $m.Groups[1].Value.Trim().Length -gt 0)
}
function Cong-Mo($port) {
    try {
        $c = New-Object System.Net.Sockets.TcpClient
        $ar = $c.BeginConnect("127.0.0.1", $port, $null, $null)
        $ok = $ar.AsyncWaitHandle.WaitOne(1500) -and $c.Connected
        $c.Close(); return $ok
    } catch { return $false }
}

Write-Host ""
Write-Host "=== Kiem tra Zalo Agent ===" -ForegroundColor White

$nodeOk = $false
try {
    $v = (& node -v) -replace "^v", ""; $p = $v.Split(".")
    $nodeOk = ([int]$p[0] -gt 22) -or ([int]$p[0] -eq 22 -and [int]$p[1] -ge 13)
} catch {}
Ket $nodeOk "Node.js 22.13 tro len" "Cai Node.js LTS tai nodejs.org"
Ket (Test-Path (Join-Path $Goc "node_modules")) "Da cai thu vien (node_modules)" "Chay: corepack pnpm install"
Ket (Test-Path (Join-Path $Goc "web\dist\index.html")) "Da dung giao dien dashboard" "Chay: corepack pnpm run build:web"
Ket (Co-Gia-Tri (Join-Path $Goc ".env") "CREDENTIALS_ENCRYPTION_KEY") "Co khoa ma hoa trong .env" "Chay lai cai-dat\cai-dat.ps1"
Ket (Co-Gia-Tri (Join-Path $Goc ".env") "DASHBOARD_PASSWORD") "Co mat khau dashboard trong .env" "Chay lai cai-dat\cai-dat.ps1"

if (Get-Command 9router -ErrorAction SilentlyContinue) { Ket $true "Da cai 9Router" "" }
else { Canh "Chua cai 9Router" "bo qua neu dung router khac; cai bang: npm install -g 9router" }

if (-not $ChiKiemTraCaiDat) {
    Write-Host ""
    Write-Host "  Dich vu dang chay:" -ForegroundColor White
    if (Cong-Mo $dashboardPort) { Ket $true "Zalo Agent dang chay (http://127.0.0.1:$dashboardPort)" "" } else { Ket $false "Zalo Agent chua chay" "Bam cai-dat\Khoi-dong.cmd" }
    if (Cong-Mo 20128) { Ket $true "9Router dang chay (http://127.0.0.1:20128)" "" } else { Canh "9Router chua chay" "mo bang: 9router --port 20128 --host 127.0.0.1" }
}

Write-Host ""
if ($loi -eq 0) { Write-Host "  Tat ca dat." -ForegroundColor Green } else { Write-Host "  Con $loi muc can xu ly (xem dong [LOI] o tren)." -ForegroundColor Red }
exit $loi
