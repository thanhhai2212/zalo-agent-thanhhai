@echo off
REM Bam dup file nay de KHOI DONG lai zalo-agent bat cu luc nao (vd sau khi
REM bam Stop-Bot.cmd, hoac muon chay ngay ma khong doi den lan dang nhap sau).
REM
REM Cua so nay CHI la nut bam, se TU DONG DONG sau 3 giay - khong phai bot.
REM Bot chay AN, do Windows Task Scheduler quan ly, khong lien quan gi den
REM cua so nay con mo hay dong.
schtasks /Run /TN "ZaloAgentThanhhai"
echo.
echo Da yeu cau khoi dong ZaloAgentThanhhai (chay an, khong hien cua so).
echo Kiem tra: mo http://127.0.0.1:3910 hoac xem file data\logs\bot.*.log
echo.
echo Cua so nay se tu dong tat...
timeout /t 3 >nul
