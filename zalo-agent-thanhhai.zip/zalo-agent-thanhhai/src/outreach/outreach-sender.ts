import { ThreadType, type API } from "zca-js";
import { getAccount } from "../config/account-store.js";
import { getTuning } from "../config/runtime-tuning-settings.js";
import { appendMessage } from "../conversation/history-store.js";
import { recordThreadActivity } from "../conversation/thread-store.js";
import { enqueueSend } from "../middleware/rate-limiter.js";
import { createLogger } from "../shared/logger.js";
import { getRunningAccountApi } from "../zalo/account-manager.js";
import { guiChoChuQuaZalo } from "../zalo/send-to-owner.js";
import { dienTen } from "./outreach-phone.js";
import { boMucConCho, capNhatMuc, doiTrangThaiLo, dsMuc, demDaGui24h, lanGuiGanNhat, mucKeTiep, type LoNhan } from "./outreach-store.js";

/**
 * Gửi nền các lô "nhắn riêng khách" ĐÃ được chủ bot xác nhận - mỗi lần MỘT người,
 * cách nhau `OUTREACH_GAP_SECONDS` cộng thêm 0-60 giây ngẫu nhiên (nhịp đều tăm
 * tắp là dấu hiệu máy). Dừng lô (tam_dung) và báo chủ khi chạm trần 24 giờ hoặc
 * 3 lỗi gửi liên tiếp (nghi Zalo đang chặn nick). Số không có Zalo không tính là
 * lỗi. Xong lô thì nhắn chủ bảng kết quả.
 */

const log = createLogger("outreach");
const NHIP_MS = 15_000;
const LOI_LIEN_TIEP_TOI_DA = 3;

const duocGuiLuc = new Map<string, number>();
const loiLienTiep = new Map<string, number>();
let dangChay = false;

export type GuiDeps = { layApi: (accountId: string) => API | undefined; now: () => number; ngauNhienMs: () => number };
const DEPS_THAT: GuiDeps = { layApi: getRunningAccountApi, now: () => Date.now(), ngauNhienMs: () => Math.floor(Math.random() * 60_000) };

async function baoChu(api: API, lo: LoNhan, noiDung: string): Promise<void> {
  const cfg = getAccount(lo.accountId);
  if (!cfg?.ownerUserId) return;
  await guiChoChuQuaZalo(api)(cfg, noiDung).catch((err) => log.warn({ err, batchId: lo.id }, "Không báo được chủ bot"));
}

export function tomTatLo(lo: LoNhan): string {
  const ds = dsMuc(lo.id);
  const dem = (t: string) => ds.filter((m) => m.trangThai === t).length;
  const dong = (t: string, nhan: string) => {
    const ms = ds.filter((m) => m.trangThai === t);
    return ms.length ? `\n${nhan} (${ms.length}):\n${ms.map((m) => `- ${m.ten || "(không tên)"} ${m.so}${m.loi ? ` - ${m.loi}` : ""}`).join("\n")}` : "";
  };
  return (
    `Lô ${lo.id}: đã gửi ${dem("da_gui")}/${ds.length}, chưa gửi ${dem("cho")}, không có Zalo ${dem("khong_zalo")}, lỗi ${dem("loi")}, bỏ ${dem("bo_qua")}.` +
    dong("khong_zalo", "Số không tìm thấy tài khoản Zalo (nên gọi điện/email)") +
    dong("loi", "Gửi lỗi")
  );
}

async function ketThucNeuXong(api: API, lo: LoNhan): Promise<void> {
  if (dsMuc(lo.id).some((m) => m.trangThai === "cho")) return;
  doiTrangThaiLo(lo.id, "xong");
  await baoChu(api, lo, `Đã xong lô nhắn riêng khách.\n${tomTatLo(lo)}`);
}

export async function chayMotNhip(deps: GuiDeps = DEPS_THAT): Promise<"rong" | "cho" | "da_xu_ly"> {
  if (dangChay) return "cho";
  dangChay = true;
  try {
    const tiep = mucKeTiep();
    if (!tiep) return "rong";
    const { lo, muc } = tiep;
    const api = deps.layApi(lo.accountId);
    if (!api) return "cho";
    const now = deps.now();
    const gapMs = getTuning("OUTREACH_GAP_SECONDS") * 1000;
    const tu = duocGuiLuc.get(lo.accountId) ?? lanGuiGanNhat(lo.accountId) + gapMs;
    if (now < tu) return "cho";

    if (demDaGui24h(lo.accountId, now) >= getTuning("OUTREACH_MAX_PER_DAY")) {
      doiTrangThaiLo(lo.id, "tam_dung", "chạm trần 24 giờ");
      await baoChu(api, lo, `Tạm dừng lô nhắn riêng khách vì đã chạm trần ${getTuning("OUTREACH_MAX_PER_DAY")} tin/24 giờ của nick này. Nhắn "tiếp tục lô ${lo.id}" sau để gửi nốt.\n${tomTatLo(lo)}`);
      return "da_xu_ly";
    }

    let uid = "";
    let tenZalo = "";
    try {
      const u = await api.findUser(muc.so);
      uid = String(u?.uid ?? "");
      tenZalo = String(u?.display_name || u?.zalo_name || "");
    } catch (err) {
      log.info({ err, batchId: lo.id, stt: muc.stt }, "Không tra được số trên Zalo");
    }
    if (!uid) {
      capNhatMuc(lo.id, muc.stt, { trangThai: "khong_zalo", loi: "không tìm thấy tài khoản Zalo hoặc người này ẩn số" });
      duocGuiLuc.set(lo.accountId, now + 5_000);
      await ketThucNeuXong(api, lo);
      return "da_xu_ly";
    }

    const tin = dienTen(lo.noiDung, muc.ten);
    try {
      await enqueueSend(`${lo.accountId}:${uid}`, () => api.sendMessage({ msg: tin }, uid, ThreadType.User));
      capNhatMuc(lo.id, muc.stt, { trangThai: "da_gui", uid, guiLuc: now });
      loiLienTiep.delete(lo.accountId);
      recordThreadActivity({ accountId: lo.accountId, threadId: uid, threadType: ThreadType.User, displayName: tenZalo || muc.ten, lastSenderName: "" });
      appendMessage(lo.accountId, uid, { role: "assistant", content: tin });
      log.info({ batchId: lo.id, stt: muc.stt }, "Đã nhắn riêng khách");
    } catch (err) {
      const loi = err instanceof Error ? err.message : String(err);
      capNhatMuc(lo.id, muc.stt, { trangThai: "loi", uid, loi: loi.slice(0, 200) });
      const so = (loiLienTiep.get(lo.accountId) ?? 0) + 1;
      loiLienTiep.set(lo.accountId, so);
      log.warn({ err, batchId: lo.id, stt: muc.stt }, "Nhắn riêng khách thất bại");
      if (so >= LOI_LIEN_TIEP_TOI_DA) {
        loiLienTiep.delete(lo.accountId);
        doiTrangThaiLo(lo.id, "tam_dung", `${so} lỗi gửi liên tiếp`);
        await baoChu(api, lo, `Tạm dừng lô nhắn riêng khách sau ${so} lỗi gửi liên tiếp (có thể Zalo đang chặn nick). Lỗi gần nhất: ${loi.slice(0, 150)}\n${tomTatLo(lo)}`);
        return "da_xu_ly";
      }
    }
    duocGuiLuc.set(lo.accountId, now + gapMs + deps.ngauNhienMs());
    await ketThucNeuXong(api, lo);
    return "da_xu_ly";
  } finally {
    dangChay = false;
  }
}

/** Hủy lô: mục chưa gửi thành bỏ qua. Trả số mục bị bỏ. */
export function huyLo(lo: LoNhan): number {
  const bo = boMucConCho(lo.id);
  doiTrangThaiLo(lo.id, "huy");
  return bo;
}

export function resetChoTest(): void {
  duocGuiLuc.clear();
  loiLienTiep.clear();
  dangChay = false;
}

export function batDauGuiNhanRieng(): () => void {
  const t = setInterval(() => void chayMotNhip().catch((err) => log.warn({ err }, "Vòng nhắn riêng khách lỗi")), NHIP_MS);
  t.unref();
  return () => clearInterval(t);
}
