/**
 * Chuẩn hóa số điện thoại Việt Nam về dạng 0xxxxxxxxx (10 số) cho lệnh nhắn
 * riêng khách. Nhận "+84 912 345 678", "84912345678", "0912.345.678"...
 * Số không hợp lệ trả null - KHÔNG đoán sửa (gửi nhầm người là lỗi tệ nhất).
 */
export function chuanHoaSo(raw: string): string | null {
  let s = raw.replace(/[\s.\-()]/g, "");
  if (s.startsWith("+")) s = s.slice(1);
  if (s.startsWith("84") && s.length === 11) s = `0${s.slice(2)}`;
  return /^0[35789]\d{8}$/.test(s) ? s : null;
}

/** Thay {ten} trong nội dung; không có tên thì dùng "bạn". */
export function dienTen(noiDung: string, ten: string | undefined): string {
  return noiDung.replace(/\{ten\}/gi, ten?.trim() || "bạn");
}
