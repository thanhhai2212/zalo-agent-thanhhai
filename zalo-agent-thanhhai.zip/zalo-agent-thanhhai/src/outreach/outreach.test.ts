import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import type { API } from "zca-js";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";
import { chuanHoaSo, dienTen } from "./outreach-phone.js";

let dataDir: string;
let store: typeof import("./outreach-store.js");
let sender: typeof import("./outreach-sender.js");
let toolMod: typeof import("../agent/tools/outreach-tool.js");
let history: typeof import("../conversation/history-store.js");
let database: typeof import("../conversation/database.js");
let laKetQuaLoi: typeof import("../agent/tools/tool-failure-result.js")["laKetQuaLoi"];

const ACC = "acc-outreach";
const CHU = "uid-chu";
let guiDi: { uid: string; msg: string }[] = [];
let soCoZalo: Record<string, string> = {};
let hongGui = false;
let now = Date.parse("2026-10-06T03:00:00Z");

const api = {
  findUser: async (so: string) => (soCoZalo[so] ? { uid: soCoZalo[so], display_name: `Zalo ${so}` } : { uid: "" }),
  sendMessage: async (p: { msg: string }, uid: string) => {
    if (uid === CHU) return { message: { msgId: "m-chu" } };
    if (hongGui) throw new Error("bị chặn");
    guiDi.push({ uid, msg: p.msg });
    return { message: { msgId: `m-${guiDi.length}` } };
  },
} as unknown as API;
const deps = { layApi: () => api, now: () => now, ngauNhienMs: () => 0 };

before(async () => {
  dataDir = setupTestEnv({ OUTREACH_GAP_SECONDS: "120", OUTREACH_MAX_PER_DAY: "3" });
  database = await import("../conversation/database.js");
  store = await import("./outreach-store.js");
  sender = await import("./outreach-sender.js");
  toolMod = await import("../agent/tools/outreach-tool.js");
  history = await import("../conversation/history-store.js");
  ({ laKetQuaLoi } = await import("../agent/tools/tool-failure-result.js"));
  const { createAccount, updateAccount } = await import("../config/account-store.js");
  createAccount({ id: ACC, label: "Nick test" });
  updateAccount(ACC, { ownerUserId: CHU });
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  database.db.exec("DELETE FROM outreach_batches; DELETE FROM outreach_items;");
  sender.resetChoTest();
  guiDi = [];
  hongGui = false;
  soCoZalo = { "0912000001": "u1", "0912000002": "u2", "0912000003": "u3", "0912000004": "u4" };
  now = Date.parse("2026-10-06T03:00:00Z");
});

function ctxTu(msgId: string, opts: { sender?: string; isGroup?: boolean } = {}) {
  return {
    api,
    account: { id: ACC, ownerUserId: CHU },
    agent: { id: "a" },
    message: { msgId, threadId: CHU, senderId: opts.sender ?? CHU, isGroup: opts.isGroup ?? false },
    batch: [],
  } as never;
}
const goi = (ctx: unknown, args: Record<string, unknown>) => (toolMod.createOutreachTool(ctx as never) as any).execute(args, {});
const loMoi = () => database.db.prepare("SELECT id FROM outreach_batches ORDER BY tao_luc DESC LIMIT 1").get() as { id: string };

describe("chuẩn hóa số và chèn tên", () => {
  it("nhận +84/84/khoảng trắng, từ chối số sai", () => {
    assert.equal(chuanHoaSo("+84 912 345 678"), "0912345678");
    assert.equal(chuanHoaSo("84912345678"), "0912345678");
    assert.equal(chuanHoaSo("0912.345.678"), "0912345678");
    assert.equal(chuanHoaSo("12345"), null);
    assert.equal(chuanHoaSo("0212345678"), null);
    assert.equal(dienTen("Chào {ten}!", "Lan"), "Chào Lan!");
    assert.equal(dienTen("Chào {ten}!", ""), "Chào bạn!");
  });
});

describe("gui_tin_ca_nhan - hai bước xác nhận", () => {
  it("soạn rồi gọi gửi NGAY trong cùng lượt bị từ chối; tin mới của chủ thì được", async () => {
    const xem = await goi(ctxTu("tin-1"), { action: "soan", danhSach: [{ so: "0912000001", ten: "Lan" }, { so: "sai" }], noiDung: "Chào {ten}, mời vào nhóm: link" });
    assert.match(xem, /CHƯA gửi/);
    assert.match(xem, /Bỏ 1 số không hợp lệ/);
    const { id } = loMoi();
    assert.ok(laKetQuaLoi(await goi(ctxTu("tin-1"), { action: "gui", loId: id })), "cùng lượt soạn không được tự xác nhận");
    assert.equal(store.layLo(id)?.status, "cho_xac_nhan");
    const ok = await goi(ctxTu("tin-2"), { action: "gui", loId: id });
    assert.match(ok, /Đã bắt đầu gửi/);
    assert.equal(store.layLo(id)?.status, "dang_gui");
  });

  it("người khác hoặc chủ trong nhóm bị chặn", async () => {
    assert.ok(laKetQuaLoi(await goi(ctxTu("x", { sender: "nguoi-la" }), { action: "soan", danhSach: [{ so: "0912000001" }], noiDung: "Chào bạn nhé" })));
    assert.ok(laKetQuaLoi(await goi(ctxTu("x", { isGroup: true }), { action: "soan", danhSach: [{ so: "0912000001" }], noiDung: "Chào bạn nhé" })));
  });

  it("quá 30 phút chưa xác nhận thì hủy", async () => {
    const lo = store.taoLo({ accountId: ACC, ownerThreadId: CHU, noiDung: "Chào {ten}", taoMsgId: "tin-1", danhSach: [{ so: "0912000001", ten: "" }], now: Date.now() - 31 * 60_000 });
    assert.ok(laKetQuaLoi(await goi(ctxTu("tin-2"), { action: "gui", loId: lo.id })));
    assert.equal(store.layLo(lo.id)?.status, "huy");
  });
});

describe("gửi nền", () => {
  const taoLoDangGui = (sos: string[]) => {
    const lo = store.taoLo({ accountId: ACC, ownerThreadId: CHU, noiDung: "Chào {ten}", taoMsgId: "t", danhSach: sos.map((so, i) => ({ so, ten: `K${i + 1}` })), now });
    store.doiTrangThaiLo(lo.id, "dang_gui", undefined, now);
    return lo;
  };

  it("gửi từng người cách nhau đủ khoảng, số không Zalo ghi riêng, xong thì báo chủ", async () => {
    const lo = taoLoDangGui(["0912000001", "0999999999", "0912000002"]);
    await sender.chayMotNhip(deps);
    assert.deepEqual(guiDi, [{ uid: "u1", msg: "Chào K1" }]);
    now += 60_000;
    assert.equal(await sender.chayMotNhip(deps), "cho", "chưa đủ 120 giây");
    now += 61_000;
    await sender.chayMotNhip(deps); // số không có Zalo
    now += 10_000;
    await sender.chayMotNhip(deps);
    assert.deepEqual(guiDi.map((g) => g.uid), ["u1", "u2"]);
    assert.equal(store.layLo(lo.id)?.status, "xong");
    const ds = store.dsMuc(lo.id);
    assert.equal(ds[1]?.trangThai, "khong_zalo");
    const baoCao = history.getRecentMessages(ACC, CHU, 5).map((m) => m.content).join("\n");
    assert.match(baoCao, /đã gửi 2\/3/);
    assert.match(baoCao, /0999999999/);
    assert.match(history.getRecentMessages(ACC, "u1", 5)[0]?.content ?? "", /Chào K1/, "tin gửi khách vào history để khách trả lời bot hiểu ngữ cảnh");
  });

  it("chạm trần 24 giờ thì tạm dừng và báo chủ", async () => {
    const lo = taoLoDangGui(["0912000001", "0912000002", "0912000003", "0912000004"]);
    for (let i = 0; i < 4; i++) {
      await sender.chayMotNhip(deps);
      now += 200_000;
    }
    assert.equal(guiDi.length, 3);
    assert.equal(store.layLo(lo.id)?.status, "tam_dung");
  });

  it("3 lỗi gửi liên tiếp thì tạm dừng lô", async () => {
    hongGui = true;
    const lo = taoLoDangGui(["0912000001", "0912000002", "0912000003", "0912000004"]);
    for (let i = 0; i < 3; i++) {
      await sender.chayMotNhip(deps);
      now += 200_000;
    }
    assert.equal(store.layLo(lo.id)?.status, "tam_dung");
    assert.equal(store.dsMuc(lo.id)[3]?.trangThai, "cho", "người thứ 4 chưa bị đụng tới");
  });

  it("hủy lô: người chưa gửi chuyển bỏ qua, không gửi thêm", async () => {
    const lo = taoLoDangGui(["0912000001", "0912000002"]);
    await sender.chayMotNhip(deps);
    assert.match(await goi(ctxTu("t9"), { action: "huy", loId: lo.id }), /bỏ 1 người/);
    now += 500_000;
    await sender.chayMotNhip(deps);
    assert.equal(guiDi.length, 1);
  });
});
