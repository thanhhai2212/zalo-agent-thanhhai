import { randomBytes } from "node:crypto";
import { db } from "../conversation/database.js";

/**
 * Lô "nhắn riêng khách" do CHỦ BOT ra lệnh trong chat riêng (2026-10-06).
 *
 * Vòng đời lô: cho_xac_nhan (bot vừa soạn, chờ chủ nhắn "gửi") -> dang_gui ->
 * xong | huy | tam_dung (lỗi liên tiếp - nghi bị Zalo chặn). Lô chờ xác nhận quá
 * 30 phút thì coi như hết hạn. Mọi thứ nằm trong DB nên khởi động lại giữa
 * chừng vẫn gửi tiếp đúng chỗ, không gửi trùng người đã gửi.
 */

db.exec(`
  CREATE TABLE IF NOT EXISTS outreach_batches (
    id TEXT PRIMARY KEY,
    account_id TEXT NOT NULL,
    owner_thread_id TEXT NOT NULL,
    noi_dung TEXT NOT NULL,
    status TEXT NOT NULL,
    tao_msg_id TEXT NOT NULL,
    tao_luc INTEGER NOT NULL,
    bat_dau_luc INTEGER,
    ket_thuc_luc INTEGER,
    ghi_chu TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS outreach_items (
    batch_id TEXT NOT NULL,
    stt INTEGER NOT NULL,
    so TEXT NOT NULL,
    ten TEXT NOT NULL DEFAULT '',
    trang_thai TEXT NOT NULL DEFAULT 'cho',
    uid TEXT NOT NULL DEFAULT '',
    loi TEXT NOT NULL DEFAULT '',
    gui_luc INTEGER,
    PRIMARY KEY (batch_id, stt)
  );
`);

export type TrangThaiLo = "cho_xac_nhan" | "dang_gui" | "xong" | "huy" | "tam_dung";
export type TrangThaiMuc = "cho" | "da_gui" | "khong_zalo" | "loi" | "bo_qua";
export type LoNhan = {
  id: string;
  accountId: string;
  ownerThreadId: string;
  noiDung: string;
  status: TrangThaiLo;
  taoMsgId: string;
  taoLuc: number;
  ghiChu: string;
};
export type MucNhan = { batchId: string; stt: number; so: string; ten: string; trangThai: TrangThaiMuc; uid: string; loi: string; guiLuc: number | null };

export const HAN_XAC_NHAN_MS = 30 * 60_000;

type LoRow = { id: string; account_id: string; owner_thread_id: string; noi_dung: string; status: TrangThaiLo; tao_msg_id: string; tao_luc: number; ghi_chu: string };
type MucRow = { batch_id: string; stt: number; so: string; ten: string; trang_thai: TrangThaiMuc; uid: string; loi: string; gui_luc: number | null };

const toLo = (r: LoRow): LoNhan => ({
  id: r.id,
  accountId: r.account_id,
  ownerThreadId: r.owner_thread_id,
  noiDung: r.noi_dung,
  status: r.status,
  taoMsgId: r.tao_msg_id,
  taoLuc: Number(r.tao_luc),
  ghiChu: r.ghi_chu,
});
const toMuc = (r: MucRow): MucNhan => ({
  batchId: r.batch_id,
  stt: r.stt,
  so: r.so,
  ten: r.ten,
  trangThai: r.trang_thai,
  uid: r.uid,
  loi: r.loi,
  guiLuc: r.gui_luc === null ? null : Number(r.gui_luc),
});

export function taoLo(p: {
  accountId: string;
  ownerThreadId: string;
  noiDung: string;
  taoMsgId: string;
  danhSach: { so: string; ten: string }[];
  now?: number;
}): LoNhan {
  const id = randomBytes(4).toString("hex");
  const now = p.now ?? Date.now();
  db.prepare("INSERT INTO outreach_batches (id, account_id, owner_thread_id, noi_dung, status, tao_msg_id, tao_luc) VALUES (?, ?, ?, ?, 'cho_xac_nhan', ?, ?)").run(
    id,
    p.accountId,
    p.ownerThreadId,
    p.noiDung,
    p.taoMsgId,
    now,
  );
  const ins = db.prepare("INSERT INTO outreach_items (batch_id, stt, so, ten) VALUES (?, ?, ?, ?)");
  p.danhSach.forEach((m, i) => ins.run(id, i + 1, m.so, m.ten));
  return layLo(id)!;
}

export function layLo(id: string): LoNhan | null {
  const r = db.prepare("SELECT * FROM outreach_batches WHERE id = ?").get(id) as LoRow | undefined;
  return r ? toLo(r) : null;
}

export function dsMuc(batchId: string): MucNhan[] {
  return (db.prepare("SELECT * FROM outreach_items WHERE batch_id = ? ORDER BY stt").all(batchId) as MucRow[]).map(toMuc);
}

export function doiTrangThaiLo(id: string, status: TrangThaiLo, ghiChu?: string, now = Date.now()): void {
  const cot = status === "dang_gui" ? ", bat_dau_luc = ?" : status === "cho_xac_nhan" ? "" : ", ket_thuc_luc = ?";
  const vals: (string | number)[] = [status];
  if (cot) vals.push(now);
  db.prepare(`UPDATE outreach_batches SET status = ?${cot}${ghiChu !== undefined ? ", ghi_chu = ?" : ""} WHERE id = ?`).run(
    ...vals,
    ...(ghiChu !== undefined ? [ghiChu] : []),
    id,
  );
}

/** Mục kế tiếp cần gửi của MỘT lô đang gửi bất kỳ (lô cũ trước). */
export function mucKeTiep(): { lo: LoNhan; muc: MucNhan } | null {
  const r = db
    .prepare(
      `SELECT i.* FROM outreach_items i JOIN outreach_batches b ON b.id = i.batch_id
       WHERE b.status = 'dang_gui' AND i.trang_thai = 'cho' ORDER BY b.bat_dau_luc, i.stt LIMIT 1`,
    )
    .get() as MucRow | undefined;
  if (!r) return null;
  return { lo: layLo(r.batch_id)!, muc: toMuc(r) };
}

export function capNhatMuc(batchId: string, stt: number, p: { trangThai: TrangThaiMuc; uid?: string; loi?: string; guiLuc?: number }): void {
  db.prepare("UPDATE outreach_items SET trang_thai = ?, uid = ?, loi = ?, gui_luc = ? WHERE batch_id = ? AND stt = ?").run(
    p.trangThai,
    p.uid ?? "",
    p.loi ?? "",
    p.guiLuc ?? null,
    batchId,
    stt,
  );
}

/** Bỏ các mục còn chờ của lô (hủy giữa chừng) - mục đã gửi giữ nguyên. */
export function boMucConCho(batchId: string): number {
  return Number(db.prepare("UPDATE outreach_items SET trang_thai = 'bo_qua' WHERE batch_id = ? AND trang_thai = 'cho'").run(batchId).changes);
}

/** Số tin đã gửi thật (mọi lô) của tài khoản trong 24 giờ gần nhất. */
export function demDaGui24h(accountId: string, now = Date.now()): number {
  return Number(
    (
      db
        .prepare(
          `SELECT count(*) n FROM outreach_items i JOIN outreach_batches b ON b.id = i.batch_id
           WHERE b.account_id = ? AND i.trang_thai = 'da_gui' AND i.gui_luc > ?`,
        )
        .get(accountId, now - 24 * 3600_000) as { n: number }
    ).n,
  );
}

/** Lần gửi gần nhất của tài khoản (để giữ khoảng cách cả sau khi khởi động lại). */
export function lanGuiGanNhat(accountId: string): number {
  const r = db
    .prepare(
      `SELECT max(i.gui_luc) t FROM outreach_items i JOIN outreach_batches b ON b.id = i.batch_id
       WHERE b.account_id = ? AND i.gui_luc IS NOT NULL`,
    )
    .get(accountId) as { t: number | null };
  return r.t === null ? 0 : Number(r.t);
}

export function loDangMoCuaChu(accountId: string, ownerThreadId: string): LoNhan[] {
  return (
    db
      .prepare("SELECT * FROM outreach_batches WHERE account_id = ? AND owner_thread_id = ? AND status IN ('cho_xac_nhan','dang_gui','tam_dung') ORDER BY tao_luc DESC")
      .all(accountId, ownerThreadId) as LoRow[]
  ).map(toLo);
}
