import type { AccountConfig } from "../config/account-store.js";
import type { ParsedMessage } from "../zalo/zalo-message-parser.js";

export type FilterDecision = {
  /** Bot có chạy agent + trả lời không */
  respond: boolean;
  /**
   * Không trả lời nhưng vẫn ghi vào history (passive listening): tin group
   * thiếu @mention, hoặc thread đang tắt bot. Lần tương tác sau agent sẽ
   * thấy được ngữ cảnh xung quanh thay vì chỉ các lần mention rời rạc.
   */
  record: boolean;
  reason: string;
  /**
   * Bị lọc VÌ nhóm đòi @mention mà tin không tag bot. Chỉ nhánh này mới đưa được
   * sang bộ tự đánh giá tin nhóm (src/group-judge/) - các lý do lọc khác (tắt
   * trả lời nhóm, ngoài allowlist, thread tắt bot) thì không bao giờ.
   */
  thieuTag?: true;
};

const skip = (reason: string): FilterDecision => ({ respond: false, record: false, reason });
const recordOnly = (reason: string): FilterDecision => ({ respond: false, record: true, reason });

/**
 * Quyết định bot có trả lời tin nhắn này không - chạy TRƯỚC khi gọi LLM
 * để tin bị lọc không tốn token nào.
 *
 * @param botEnabledForThread trạng thái kill switch per thread (bảng threads),
 * caller đọc từ thread-store để module này thuần, test không cần DB.
 * @param mentionOverride ghi đè yêu cầu @mention riêng cho liên hệ này (ma
 * trận phân quyền, trang dashboard "Phân quyền Bot") - null = theo
 * groupRequireMention của account như cũ.
 */
export function shouldRespond(
  account: AccountConfig,
  msg: ParsedMessage,
  botEnabledForThread = true,
  mentionOverride: "require" | "no_require" | null = null,
): FilterDecision {
  if (msg.isSelf) {
    return skip("tin của chính bot");
  }

  // Tin THOẠI có text rỗng ở giai đoạn này (chưa phiên âm - transcribeBatchVoice
  // chạy SAU, trong message-turn-processor.ts) nhưng KHÔNG PHẢI "không có nội
  // dung" - `voiceUrl` chính là nội dung, chỉ chưa được giải mã thành chữ.
  // Thiếu điều kiện này thì MỌI tin nhắn thoại bị lọc bỏ NGAY TẠI ĐÂY, trước
  // khi kịp chạm vào STT - đúng bug đã gặp thật: "Bỏ qua tin" với lý do liệt
  // kê thẳng "voice" trong ngoặc. File đính kèm (`documentUrl`) và STICKER
  // (`stickerRef`) CÙNG cảnh - chưa tra chi tiết (readBatchDocuments/
  // resolveBatchStickers chạy SAU) - áp dụng đúng bài học đó ngay từ đầu,
  // không đợi bug thật như voice.
  if (!msg.text.trim() && msg.images.length === 0 && !msg.voiceUrl && !msg.documentUrl && !msg.stickerRef) {
    return skip("không có nội dung xử lý được");
  }

  if (msg.isGroup) {
    if (!account.respondToGroups) {
      return skip("account tắt trả lời group");
    }
    const requireMention = mentionOverride ? mentionOverride === "require" : account.groupRequireMention;
    if (requireMention && !msg.mentionsMe) {
      const d = account.groupPassiveListen
        ? recordOnly("group không @mention - chỉ ghi history")
        : skip("group yêu cầu @mention bot");
      return { ...d, thieuTag: true };
    }
  }

  if (account.allowlist.mode === "list" && !account.allowlist.userIds.includes(msg.senderId)) {
    return skip(`sender ${msg.senderId} ngoài allowlist`);
  }

  // Check kill switch SAU allowlist: người ngoài allowlist không được ghi history
  // dù thread tắt bot
  if (!botEnabledForThread) {
    return recordOnly("thread đang tắt bot - chỉ ghi history");
  }

  return { respond: true, record: true, reason: "ok" };
}
