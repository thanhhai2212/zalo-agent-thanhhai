import { db } from "../conversation/database.js";

/**
 * Trạng thái "đã xử lý" của các mục trong "Việc cần làm" (2026-10-08). Mục này không có dòng trong
 * DB (suy ra từ trạng thái hệ thống mỗi lần hỏi), nên chủ bot đánh dấu bằng cặp (khoa, dấu): `dau`
 * là tiêu đề lúc đánh dấu. Tiêu đề đổi (vd số bài chờ duyệt từ 2 thành 3) thì coi là việc mới, hiện lại.
 */

db.exec(`
  CREATE TABLE IF NOT EXISTS viec_da_xu_ly (
    khoa TEXT PRIMARY KEY,
    dau TEXT NOT NULL,
    luc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`);

const datStmt = db.prepare("INSERT INTO viec_da_xu_ly (khoa, dau) VALUES (?, ?) ON CONFLICT(khoa) DO UPDATE SET dau = excluded.dau, luc = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");
const boStmt = db.prepare("DELETE FROM viec_da_xu_ly WHERE khoa = ?");
const tatCaStmt = db.prepare("SELECT khoa, dau FROM viec_da_xu_ly");

export function danhDauViecDaXuLy(khoa: string, dau: string): void {
  datStmt.run(khoa, dau);
}
export function boDanhDauViec(khoa: string): void {
  boStmt.run(khoa);
}
export function layViecDaXuLy(): Map<string, string> {
  return new Map((tatCaStmt.all() as { khoa: string; dau: string }[]).map((r) => [r.khoa, r.dau]));
}
