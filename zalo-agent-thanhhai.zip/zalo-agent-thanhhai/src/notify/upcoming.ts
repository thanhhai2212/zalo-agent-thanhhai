import { botTimeZone, getTuning } from "../config/runtime-tuning-settings.js";
import { db } from "../conversation/database.js";
import "../group-posts/gp-draft-store.js"; // tạo bảng post_drafts nếu chưa có
import { getThreadDisplayName } from "../conversation/thread-store.js";
import { todayKey, zonedWallClockToUtc } from "../shared/zone-time.js";

/**
 * "Việc sắp tới" cho ứng dụng điện thoại (2026-10-07): lịch hẹn của bot, bài nhóm đã soạn chờ đăng,
 * và mốc báo cáo VPS kế tiếp. Chỉ ĐỌC. Việc đang chạy ngay (video) lấy từ bộ đếm ở route.
 */

export type ViecSapToi = { loai: "lichHen" | "baiNhom" | "baoCaoVps"; luc: string; tieuDe: string; chiTiet: string; trangThai?: string };

const pad = (n: number) => String(n).padStart(2, "0");

/** Mốc UTC gần nhất SAU `now` trong số các giờ báo cáo (giờ địa phương, -1 = tắt). Null nếu cả hai khung đều tắt. */
export function kyBaoCaoTiepTheo(cacGio: number[], now: Date, tz: string): string | null {
  const hopLe = [...new Set(cacGio.filter((h) => Number.isInteger(h) && h >= 0 && h <= 23))];
  if (hopLe.length === 0) return null;
  const homNay = todayKey(tz, now);
  const mai = todayKey(tz, new Date(now.getTime() + 86_400_000));
  const ungVien: string[] = [];
  for (const ngay of [homNay, mai]) for (const h of hopLe) {
    const t = zonedWallClockToUtc(ngay, `${pad(h)}:00`, tz);
    if (t && t > now.toISOString()) ungVien.push(t);
  }
  return ungVien.sort()[0] ?? null;
}

type JobRow = { name: string; kind: string; account_id: string; thread_id: string; next_run_at: string; schedule_kind: string };
type PostRow = { topic_title: string; account_id: string; thread_id: string; scheduled_at: string; status: string };

export function viecSapToi(now = new Date(), gioiHan = 30): ViecSapToi[] {
  const tz = botTimeZone();
  const iso = now.toISOString();
  const kq: ViecSapToi[] = [];

  const jobs = db
    .prepare("SELECT name, kind, account_id, thread_id, next_run_at, schedule_kind FROM scheduled_jobs WHERE enabled = 1 AND next_run_at IS NOT NULL ORDER BY next_run_at ASC LIMIT ?")
    .all(gioiHan) as unknown as JobRow[];
  for (const j of jobs) {
    const noi = getThreadDisplayName(j.account_id, j.thread_id) || "một cuộc chat";
    const lap = j.schedule_kind === "once" ? "một lần" : "lặp lại";
    kq.push({ loai: "lichHen", luc: j.next_run_at, tieuDe: j.name, chiTiet: `${j.kind === "agent" ? "Bot tự làm" : "Nhắn tin"} tại ${noi} (${lap})` });
  }

  const bai = db
    .prepare("SELECT topic_title, account_id, thread_id, scheduled_at, status FROM post_drafts WHERE status IN ('cho_duyet','da_duyet') AND scheduled_at >= ? ORDER BY scheduled_at ASC LIMIT ?")
    .all(iso, gioiHan) as unknown as PostRow[];
  for (const b of bai) {
    const nhom = getThreadDisplayName(b.account_id, b.thread_id) || "một nhóm";
    kq.push({ loai: "baiNhom", luc: b.scheduled_at, tieuDe: b.topic_title || "Bài đăng nhóm", chiTiet: `Đăng vào ${nhom}`, trangThai: b.status === "cho_duyet" ? "Chờ bạn duyệt" : "Đã duyệt" });
  }

  const bc = kyBaoCaoTiepTheo([getTuning("VPS_REPORT_HOUR_1"), getTuning("VPS_REPORT_HOUR_2")], now, tz);
  if (bc) kq.push({ loai: "baoCaoVps", luc: bc, tieuDe: "Báo cáo VPS định kỳ", chiTiet: "Bot tự nhắn báo cáo máy chủ cho bạn" });

  return kq.sort((a, b) => a.luc.localeCompare(b.luc)).slice(0, gioiHan);
}
