import { z } from "zod";
import { botTimeZone } from "../config/runtime-tuning-settings.js";
import { db } from "../conversation/database.js";

/**
 * Luật thông báo cho chủ bot (2026-10-07): loại nào được báo, qua kênh nào (Zalo,
 * thông báo đẩy trên điện thoại), giờ yên tĩnh, ngưỡng VPS, và địa chỉ trạm báo độc
 * lập. Một dòng JSON trong `runtime_settings` (khóa `notify_rules`), sửa từ ứng dụng
 * điện thoại. Mặc định GIỮ NGUYÊN hành vi cũ (mọi loại bật, qua Zalo, giờ yên tĩnh
 * tắt) - bật tính năng mới không được làm đổi thứ chủ bot đang nhận.
 */

export const LOAI_THONG_BAO = ["vps", "zaloDut", "khachGap", "tagChu", "baoCao"] as const;
export type LoaiThongBao = (typeof LOAI_THONG_BAO)[number];

export const NHAN_LOAI: Record<LoaiThongBao, string> = {
  vps: "Máy chủ VPS (RAM, ổ đĩa, swap, CPU)",
  zaloDut: "Tài khoản Zalo mất kết nối",
  khachGap: "Khách nhắn gấp hoặc bực bội",
  tagChu: "Có người tag tên bạn trong nhóm",
  baoCao: "Báo cáo VPS định kỳ",
};

const gio = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Giờ phải dạng HH:MM");

const quyTac = z.object({
  bat: z.boolean(),
  zalo: z.boolean(),
  push: z.boolean(),
  /** Báo cả trong giờ yên tĩnh (sự cố nặng) */
  quanTrong: z.boolean(),
  /** Khoảng nghỉ giữa hai lần báo cùng một sự cố (chỉ loại có vòng đo lặp: vps, zaloDut) */
  lapLaiPhut: z.number().int().min(5).max(1440),
});
export type QuyTac = z.infer<typeof quyTac>;

export const cauHinhThongBaoSchema = z.object({
  imLang: z.object({ bat: z.boolean(), tu: gio, den: gio }),
  loai: z.object(Object.fromEntries(LOAI_THONG_BAO.map((l) => [l, quyTac])) as Record<LoaiThongBao, typeof quyTac>),
  nguong: z.object({
    ramTrongPhanTram: z.number().int().min(3).max(40),
    diaPhanTram: z.number().int().min(70).max(99),
  }),
  /** Địa chỉ ping của dịch vụ giám sát ngoài (vd Healthchecks.io), rỗng = tắt */
  tramBaoUrl: z.string().max(300),
});
export type CauHinhThongBao = z.infer<typeof cauHinhThongBaoSchema>;

const mau = (o: Partial<QuyTac> = {}): QuyTac => ({ bat: true, zalo: true, push: true, quanTrong: false, lapLaiPhut: 180, ...o });

export const MAC_DINH: CauHinhThongBao = {
  imLang: { bat: false, tu: "23:00", den: "06:30" },
  loai: {
    vps: mau({ quanTrong: true }),
    zaloDut: mau({ quanTrong: true }),
    khachGap: mau({ lapLaiPhut: 30 }),
    tagChu: mau({ lapLaiPhut: 10 }),
    // Báo cáo dài đã đi Zalo từ trước; thông báo đẩy mặc định tắt cho khỏi trùng.
    baoCao: mau({ push: false, lapLaiPhut: 60 }),
  },
  nguong: { ramTrongPhanTram: 10, diaPhanTram: 90 },
  tramBaoUrl: "",
};

const KHOA = "notify_rules";
const getStmt = db.prepare("SELECT value FROM runtime_settings WHERE key = ?");
const setStmt = db.prepare(`
  INSERT INTO runtime_settings (key, value, updated_at)
  VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);

/** Trộn giá trị đã lưu lên mặc định; phần hỏng hoặc thiếu rơi về mặc định (không bao giờ ném lỗi). */
export function tronMacDinh(luu: unknown): CauHinhThongBao {
  const l = (luu && typeof luu === "object" ? luu : {}) as Partial<CauHinhThongBao>;
  const ghep = {
    imLang: { ...MAC_DINH.imLang, ...(l.imLang ?? {}) },
    loai: Object.fromEntries(LOAI_THONG_BAO.map((k) => [k, { ...MAC_DINH.loai[k], ...(l.loai?.[k] ?? {}) }])),
    nguong: { ...MAC_DINH.nguong, ...(l.nguong ?? {}) },
    tramBaoUrl: typeof l.tramBaoUrl === "string" ? l.tramBaoUrl : MAC_DINH.tramBaoUrl,
  };
  const kq = cauHinhThongBaoSchema.safeParse(ghep);
  return kq.success ? kq.data : MAC_DINH;
}

export function layCauHinhThongBao(): CauHinhThongBao {
  const row = getStmt.get(KHOA) as { value: string } | undefined;
  if (!row) return MAC_DINH;
  try {
    return tronMacDinh(JSON.parse(row.value));
  } catch {
    return MAC_DINH;
  }
}

export function luuCauHinhThongBao(cauHinh: CauHinhThongBao): void {
  setStmt.run(KHOA, JSON.stringify(cauHinh));
}

const phut = (hhmm: string) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3, 5));

/** Giờ yên tĩnh theo múi giờ của bot; hỗ trợ khoảng vắt qua nửa đêm (23:00 - 06:30). */
export function dangGioImLang(c: CauHinhThongBao, now: Date, tz = botTimeZone()): boolean {
  if (!c.imLang.bat) return false;
  const p = Object.fromEntries(
    new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
      .formatToParts(now)
      .map((x) => [x.type, x.value]),
  );
  const bay = Number(p.hour) * 60 + Number(p.minute);
  const tu = phut(c.imLang.tu);
  const den = phut(c.imLang.den);
  if (tu === den) return false;
  return tu < den ? bay >= tu && bay < den : bay >= tu || bay < den;
}

export type KenhDuocPhep = { zalo: boolean; push: boolean };

/** Loại này, lúc này, được báo qua kênh nào. Sự cố "quan trọng" vượt qua giờ yên tĩnh. */
export function quyetDinhKenh(loai: LoaiThongBao, now = new Date(), c = layCauHinhThongBao()): KenhDuocPhep {
  const r = c.loai[loai];
  if (!r.bat) return { zalo: false, push: false };
  if (dangGioImLang(c, now) && !r.quanTrong) return { zalo: false, push: false };
  return { zalo: r.zalo, push: r.push };
}
