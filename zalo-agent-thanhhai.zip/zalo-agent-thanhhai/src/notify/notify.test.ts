import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import type { Hono } from "hono";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let settings: typeof import("./notify-settings.js");
let store: typeof import("./push-store.js");
let sender: typeof import("./push-sender.js");
let owner: typeof import("./notify-owner.js");
let hb: typeof import("./heartbeat.js");
let vps: typeof import("../vps-monitor/vps-monitor.js");
let database: typeof import("../conversation/database.js");
let app: Hono;
let cookie: string;
const PASSWORD = "mat-khau-notify-123";

before(async () => {
  dataDir = setupTestEnv({ DASHBOARD_PASSWORD: PASSWORD, BOT_TIMEZONE: "Asia/Ho_Chi_Minh" });
  database = await import("../conversation/database.js");
  settings = await import("./notify-settings.js");
  store = await import("./push-store.js");
  sender = await import("./push-sender.js");
  owner = await import("./notify-owner.js");
  hb = await import("./heartbeat.js");
  vps = await import("../vps-monitor/vps-monitor.js");
  const { buildDashboardApp } = await import("../server/dashboard-server.js");
  app = buildDashboardApp();
  const login = await app.request("/api/auth/login", { method: "POST", body: JSON.stringify({ password: PASSWORD }), headers: { "content-type": "application/json" } });
  cookie = login.headers.get("set-cookie")!.split(";")[0]!;
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  database.db.exec("DELETE FROM runtime_settings WHERE key LIKE 'notify_%'; DELETE FROM push_subscriptions");
});

const mocPhut = (hhmm: string) => new Date(`2026-10-07T${hhmm}:00+07:00`);

describe("cấu hình thông báo", () => {
  it("mặc định giữ nguyên hành vi cũ: mọi loại bật qua Zalo, giờ yên tĩnh tắt", () => {
    const c = settings.layCauHinhThongBao();
    assert.equal(c.imLang.bat, false);
    for (const l of settings.LOAI_THONG_BAO) assert.equal(c.loai[l].bat, true);
    assert.deepEqual(settings.quyetDinhKenh("vps", mocPhut("03:00")), { zalo: true, push: true });
    assert.deepEqual(settings.quyetDinhKenh("baoCao"), { zalo: true, push: false });
  });

  it("dữ liệu lưu hỏng hoặc thiếu thì rơi về mặc định, không ném lỗi", () => {
    database.db.prepare("INSERT OR REPLACE INTO runtime_settings (key, value) VALUES ('notify_rules', ?)").run("{không phải json");
    assert.deepEqual(settings.layCauHinhThongBao(), settings.MAC_DINH);
    const tron = settings.tronMacDinh({ loai: { vps: { zalo: false } }, nguong: { ramTrongPhanTram: 9999 } });
    assert.equal(tron.loai.vps.zalo, true, "giá trị sai kiểu/ngoài khoảng làm cả cấu hình về mặc định");
    const tot = settings.tronMacDinh({ loai: { vps: { zalo: false } } });
    assert.equal(tot.loai.vps.zalo, false);
    assert.equal(tot.loai.vps.push, true, "trường thiếu lấy từ mặc định");
  });

  it("giờ yên tĩnh vắt qua nửa đêm, tính theo múi giờ của bot", () => {
    const c = { ...settings.MAC_DINH, imLang: { bat: true, tu: "23:00", den: "06:30" } };
    assert.equal(settings.dangGioImLang(c, mocPhut("23:30")), true);
    assert.equal(settings.dangGioImLang(c, mocPhut("02:00")), true);
    assert.equal(settings.dangGioImLang(c, mocPhut("06:29")), true);
    assert.equal(settings.dangGioImLang(c, mocPhut("06:30")), false);
    assert.equal(settings.dangGioImLang(c, mocPhut("12:00")), false);
    assert.equal(settings.dangGioImLang({ ...c, imLang: { ...c.imLang, bat: false } }, mocPhut("02:00")), false);
  });

  it("trong giờ yên tĩnh chỉ sự cố quan trọng được báo; loại bị tắt thì không báo gì", () => {
    const c = { ...settings.MAC_DINH, imLang: { bat: true, tu: "23:00", den: "06:30" } };
    const dem = mocPhut("02:00");
    assert.deepEqual(settings.quyetDinhKenh("vps", dem, c), { zalo: true, push: true }, "vps mặc định là quan trọng");
    assert.deepEqual(settings.quyetDinhKenh("khachGap", dem, c), { zalo: false, push: false });
    assert.deepEqual(settings.quyetDinhKenh("khachGap", mocPhut("10:00"), c), { zalo: true, push: true });
    const tat = { ...c, loai: { ...c.loai, vps: { ...c.loai.vps, bat: false } } };
    assert.deepEqual(settings.quyetDinhKenh("vps", mocPhut("10:00"), tat), { zalo: false, push: false });
  });
});

describe("thông báo đẩy", () => {
  it("chỉ nhận địa chỉ máy chủ đẩy của trình duyệt (https)", () => {
    assert.equal(store.diaChiDayHopLe("https://web.push.apple.com/abc"), true);
    assert.equal(store.diaChiDayHopLe("https://fcm.googleapis.com/fcm/send/xyz"), true);
    assert.equal(store.diaChiDayHopLe("https://updates.push.services.mozilla.com/wpush/v2/x"), true);
    assert.equal(store.diaChiDayHopLe("http://web.push.apple.com/abc"), false);
    assert.equal(store.diaChiDayHopLe("https://evil.example.com/x"), false);
    assert.equal(store.diaChiDayHopLe("https://web.push.apple.com.evil.com/x"), false);
    assert.equal(store.diaChiDayHopLe("không phải url"), false);
  });

  it("khóa VAPID sinh một lần rồi giữ nguyên; khóa riêng mã hóa trong DB", () => {
    const a = store.layKhoaVapid();
    const b = store.layKhoaVapid();
    assert.equal(a.publicKey, b.publicKey);
    assert.equal(a.privateKey, b.privateKey);
    const raw = (database.db.prepare("SELECT value FROM runtime_settings WHERE key = 'push_vapid_private'").get() as { value: string }).value;
    assert.doesNotMatch(raw, new RegExp(a.privateKey.slice(0, 12)));
    store.datChuTheVapid("https://thanhhai.example.ts.net");
    assert.equal(store.layKhoaVapid().subject, "https://thanhhai.example.ts.net");
    store.datChuTheVapid("http://khong-https.local");
    assert.equal(store.layKhoaVapid().subject, "https://thanhhai.example.ts.net", "địa chỉ không phải https bị bỏ qua");
  });

  it("đăng ký thiết bị trùng endpoint thì cập nhật, không nhân đôi", () => {
    const t = { endpoint: "https://web.push.apple.com/a", p256dh: "k".repeat(20), auth: "a".repeat(10) };
    store.luuThietBi(t);
    store.luuThietBi({ ...t, auth: "b".repeat(10) });
    assert.equal(store.danhSachThietBi().length, 1);
    assert.equal(store.danhSachThietBi()[0]!.auth, "b".repeat(10));
  });

  it("gửi tới mọi thiết bị; 410 thì xóa thiết bị, lỗi tạm thì giữ; không có thiết bị thì không làm gì", async () => {
    assert.deepEqual(await sender.guiPushChoTatCa({ tieuDe: "x", noiDung: "y" }), { gui: 0, loi: 0 });
    for (const n of ["ok", "het-han", "loi-tam"]) store.luuThietBi({ endpoint: `https://web.push.apple.com/${n}`, p256dh: "k".repeat(20), auth: "a".repeat(10) });
    const daNhan: string[] = [];
    const kq = await sender.guiPushChoTatCa({ tieuDe: "T".repeat(200), noiDung: "N".repeat(1000), url: "/m/vps" }, async (t, body) => {
      daNhan.push(body);
      if (t.endpoint.endsWith("het-han")) throw Object.assign(new Error("gone"), { statusCode: 410 });
      if (t.endpoint.endsWith("loi-tam")) throw Object.assign(new Error("5xx"), { statusCode: 503 });
    });
    assert.deepEqual(kq, { gui: 1, loi: 2 });
    assert.deepEqual(store.danhSachThietBi().map((t) => t.endpoint.split("/").pop()).sort(), ["loi-tam", "ok"]);
    const b = JSON.parse(daNhan[0]!) as { tieuDe: string; noiDung: string; url: string };
    assert.ok(b.tieuDe.length <= 80 && b.noiDung.length <= 300);
    assert.equal(b.url, "/m/vps");
    assert.ok(store.danhSachThietBi().find((t) => t.endpoint.endsWith("/ok"))!.lanCuoiOk, "ghi nhận lần gửi thành công");
  });

  it("chữ trơn: bỏ thẻ màu và dấu đậm", () => {
    assert.equal(owner.markdownThanhChuTro("**RAM sắp cạn:** chỉ còn [do]**0.30 GB**[/do] trống"), "RAM sắp cạn: chỉ còn 0.30 GB trống");
  });

  it("đẩy theo luật: loại tắt hoặc kênh đẩy tắt thì không gửi", async () => {
    store.luuThietBi({ endpoint: "https://web.push.apple.com/z", p256dh: "k".repeat(20), auth: "a".repeat(10) });
    const c = settings.layCauHinhThongBao();
    settings.luuCauHinhThongBao({ ...c, loai: { ...c.loai, khachGap: { ...c.loai.khachGap, push: false } } });
    assert.equal(await owner.daySangDienThoai("khachGap", "t", "n"), false);
  });
});

describe("trạm báo độc lập", () => {
  it("địa chỉ ping: https công khai, không phải mạng nội bộ", () => {
    assert.equal(hb.diaChiPingHopLe("https://hc-ping.com/abc-123"), true);
    for (const x of ["http://hc-ping.com/a", "https://localhost/a", "https://127.0.0.1/a", "https://10.0.0.5/a", "https://may-chu.tailabc123.ts.net/a", "https://u:p@hc-ping.com/a", "hc-ping.com"]) {
      assert.equal(hb.diaChiPingHopLe(x), false, x);
    }
  });

  it("chưa cấu hình thì không ping; ping thường, và /fail khi có sự cố nặng; ghi lại kết quả", async () => {
    const goi: string[] = [];
    const fetchGia = (async (u: string) => (goi.push(u), { ok: true, status: 200 })) as never;
    assert.equal((await hb.pingMotLan(fetchGia, 1000, () => false)).ok, null);
    assert.equal(goi.length, 0);
    const c = settings.layCauHinhThongBao();
    settings.luuCauHinhThongBao({ ...c, tramBaoUrl: "https://hc-ping.com/abc/" });
    assert.equal((await hb.pingMotLan(fetchGia, 2000, () => false)).ok, true);
    assert.equal((await hb.pingMotLan(fetchGia, 3000, () => true)).sucoNang, true);
    assert.deepEqual(goi, ["https://hc-ping.com/abc/", "https://hc-ping.com/abc/fail"]);
  });

  it("ping lỗi (mạng, HTTP 500) được ghi nhận và không ném lỗi", async () => {
    const c = settings.layCauHinhThongBao();
    settings.luuCauHinhThongBao({ ...c, tramBaoUrl: "https://hc-ping.com/abc" });
    const hong = (async () => { throw new Error("mạng đứt"); }) as never;
    const kq = await hb.pingMotLan(hong, 5000, () => false);
    assert.deepEqual([kq.ok, kq.loi], [false, "mạng đứt"]);
    const m500 = (async () => ({ ok: false, status: 500 })) as never;
    assert.equal((await hb.pingMotLan(m500, 6000, () => false)).loi, "HTTP 500");
  });
});

describe("cảnh báo VPS theo ngưỡng chủ bot đặt", () => {
  const chiSo = { uptimeGiay: 1, soNhan: 4, tai: [0, 0, 0] as [number, number, number], ramTongMb: 4000, ramConMb: 600, swapTongMb: 0, swapDungMb: 0, diaTongGb: 100, diaDungGb: 85, botMb: 1 };

  it("ngưỡng mặc định không báo; hạ ngưỡng xuống thì báo", () => {
    assert.equal(vps.lyDoBatThuong(chiSo, [], new Set()).lyDo.size, 0);
    const chat = vps.lyDoBatThuong(chiSo, [], new Set(), { ramTrongPhanTram: 20, diaPhanTram: 80 });
    assert.deepEqual([...chat.lyDo.keys()].sort(), ["dia", "ram"]);
  });

  it("nick Zalo đứt tách riêng loại với sự cố máy chủ", () => {
    assert.equal(vps.loaiCuaLyDo("flap:acc1"), "zaloDut");
    assert.equal(vps.loaiCuaLyDo("acc:Nick A"), "zaloDut");
    assert.equal(vps.loaiCuaLyDo("ram"), "vps");
  });
});

describe("API /api/notify", () => {
  const goi = (duong: string, method = "GET", than?: unknown, dauTrang: Record<string, string> = {}) =>
    app.request(duong, { method, body: than === undefined ? undefined : JSON.stringify(than), headers: { cookie, "content-type": "application/json", ...dauTrang } });

  it("cần đăng nhập", async () => {
    assert.equal((await app.request("/api/notify/settings")).status, 401);
  });

  it("đọc và lưu cấu hình; từ chối dữ liệu sai và địa chỉ trạm báo nội bộ", async () => {
    const doc = (await (await goi("/api/notify/settings")).json()) as { cauHinh: import("./notify-settings.js").CauHinhThongBao; push: { soThietBi: number } };
    assert.equal(doc.push.soThietBi, 0);
    const moi = { ...doc.cauHinh, imLang: { bat: true, tu: "22:00", den: "07:00" }, tramBaoUrl: "https://hc-ping.com/xyz" };
    assert.equal((await goi("/api/notify/settings", "PUT", moi)).status, 200);
    assert.equal(settings.layCauHinhThongBao().imLang.tu, "22:00");
    assert.equal((await goi("/api/notify/settings", "PUT", { ...moi, imLang: { bat: true, tu: "25:00", den: "07:00" } })).status, 400);
    assert.equal((await goi("/api/notify/settings", "PUT", { ...moi, tramBaoUrl: "https://127.0.0.1/x" })).status, 400);
    assert.equal((await goi("/api/notify/settings", "PUT", { ...moi, nguong: { ramTrongPhanTram: 1, diaPhanTram: 90 } })).status, 400);
  });

  it("đăng ký và gỡ thiết bị; từ chối máy chủ đẩy lạ", async () => {
    const k = (await (await goi("/api/notify/push/key")).json()) as { publicKey: string };
    assert.ok(k.publicKey.length > 40);
    const sub = (endpoint: string) => ({ subscription: { endpoint, keys: { p256dh: "k".repeat(20), auth: "a".repeat(12) } } });
    assert.equal((await goi("/api/notify/push/subscribe", "POST", sub("https://evil.example.com/x"))).status, 400);
    const ok = await goi("/api/notify/push/subscribe", "POST", sub("https://web.push.apple.com/dev1"), { origin: "https://thanhhai.example.ts.net" });
    assert.equal(ok.status, 200);
    assert.equal(store.danhSachThietBi().length, 1);
    assert.equal(store.layKhoaVapid().subject, "https://thanhhai.example.ts.net");
    assert.equal((await goi("/api/notify/push/unsubscribe", "POST", { endpoint: "https://web.push.apple.com/dev1" })).status, 200);
    assert.equal(store.danhSachThietBi().length, 0);
    const thu = (await (await goi("/api/notify/push/test", "POST")).json()) as { gui: number };
    assert.equal(thu.gui, 0, "không có thiết bị thì không gửi");
  });
});
