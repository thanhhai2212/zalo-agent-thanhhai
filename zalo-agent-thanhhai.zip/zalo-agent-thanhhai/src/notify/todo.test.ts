import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import type { Hono } from "hono";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let td: typeof import("./todo.js");
let database: typeof import("../conversation/database.js");
let accounts: typeof import("../config/account-store.js");
let mcp: typeof import("../mcp/mcp-server-store.js");
let outreach: typeof import("../outreach/outreach-store.js");
let app: Hono;
let cookie: string;
const PASSWORD = "mat-khau-todo-123";

before(async () => {
  dataDir = setupTestEnv({ DASHBOARD_PASSWORD: PASSWORD, BOT_TIMEZONE: "Asia/Ho_Chi_Minh" });
  database = await import("../conversation/database.js");
  accounts = await import("../config/account-store.js");
  mcp = await import("../mcp/mcp-server-store.js");
  outreach = await import("../outreach/outreach-store.js");
  td = await import("./todo.js");
  const { buildDashboardApp } = await import("../server/dashboard-server.js");
  app = buildDashboardApp();
  const login = await app.request("/api/auth/login", { method: "POST", body: JSON.stringify({ password: PASSWORD }), headers: { "content-type": "application/json" } });
  cookie = login.headers.get("set-cookie")!.split(";")[0]!;
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("việc cần làm", () => {
  it("không có gì đang chờ thì danh sách rỗng", () => {
    assert.deepEqual(td.viecCanLam(), []);
  });

  it("gom đủ các nguồn, sự cố xếp trước cần chú ý", () => {
    accounts.createAccount({ id: "acc-todo", label: "Nick thử" });
    const s = mcp.taoServer({ ten: "Canva", url: "https://example.com/mcp", dungOauth: true });
    mcp.datTrangThaiServer(s.id, "loi", "401");
    database.db
      .prepare("INSERT INTO post_drafts (id, account_id, thread_id, topic_key, topic_title, source, source_note, body, discuss, infographic, has_image, similarity, status, scheduled_at) VALUES ('p1','acc-todo','g1','k','Mẹo','s','','b','','',0,0,'cho_duyet',?)")
      .run("2099-01-01T00:00:00.000Z");
    const lo = outreach.taoLo({ accountId: "acc-todo", ownerThreadId: "chu", noiDung: "x", taoMsgId: "m1", danhSach: [{ so: "0900000001", ten: "A" }] });
    outreach.doiTrangThaiLo(lo.id, "tam_dung");

    const ds = td.viecCanLam(new Date("2098-12-31T00:00:00Z"));
    const khoa = ds.map((v) => v.khoa);
    assert.ok(khoa.includes("khongchay:acc-todo"), "tài khoản bật mà không chạy");
    assert.ok(khoa.includes("mcp-dn:" + s.id), "kết nối OAuth chưa đăng nhập");
    assert.ok(khoa.includes("bai-cho-duyet"));
    assert.ok(khoa.includes("nhan-tam-dung"));
    // mọi mục "suCo" đứng trước mọi mục "chuY"
    const lanCuoiSuCo = ds.map((v) => v.muc).lastIndexOf("suCo");
    const lanDauChuY = ds.map((v) => v.muc).indexOf("chuY");
    assert.ok(lanCuoiSuCo < lanDauChuY);
  });

  it("tài khoản đã tắt thì không đòi xử lý", () => {
    accounts.updateAccount("acc-todo", { enabled: false });
    const ds = td.viecCanLam(new Date("2098-12-31T00:00:00Z"));
    assert.ok(!ds.some((v) => v.khoa === "khongchay:acc-todo"));
  });

  it("API cần đăng nhập", async () => {
    assert.equal((await app.request("/api/mobile/todo")).status, 401);
    const r = await app.request("/api/mobile/todo", { headers: { cookie } });
    assert.equal(r.status, 200);
    assert.ok(Array.isArray(((await r.json()) as { viec: unknown[] }).viec));
  });
});

describe("đã xử lý", () => {
  const post = (duong: string, body: unknown) =>
    app.request(duong, { method: "POST", headers: { cookie, "content-type": "application/json" }, body: JSON.stringify(body) });

  it("đánh dấu thì việc chuyển sang 'đã xử lý'; mở lại thì quay về 'đang chờ'", async () => {
    const s = mcp.taoServer({ ten: "Apify", url: "https://example.com/apify", dungOauth: false });
    mcp.datTrangThaiServer(s.id, "loi", "timeout");
    const khoa = `mcp-loi:${s.id}`;

    assert.ok(td.phanLoaiViecCanLam().canLam.some((v) => v.khoa === khoa));
    assert.equal((await post("/api/mobile/todo/xu-ly", { khoa, daXuLy: true })).status, 200);
    let r = td.phanLoaiViecCanLam();
    assert.ok(!r.canLam.some((v) => v.khoa === khoa));
    assert.ok(r.daXuLy.some((v) => v.khoa === khoa));

    // API trả cả hai danh sách
    const j = (await (await app.request("/api/mobile/todo", { headers: { cookie } })).json()) as { viec: { khoa: string }[]; daXuLy: { khoa: string }[] };
    assert.ok(j.daXuLy.some((v) => v.khoa === khoa) && !j.viec.some((v) => v.khoa === khoa));

    assert.equal((await post("/api/mobile/todo/xu-ly", { khoa, daXuLy: false })).status, 200);
    r = td.phanLoaiViecCanLam();
    assert.ok(r.canLam.some((v) => v.khoa === khoa));
  });

  it("việc hết hẳn thì dấu bị xóa; tái diễn là việc mới", async () => {
    const s = mcp.taoServer({ ten: "Tái diễn", url: "https://example.com/tai-dien", dungOauth: false });
    mcp.datTrangThaiServer(s.id, "loi", "x");
    const khoa = `mcp-loi:${s.id}`;
    await post("/api/mobile/todo/xu-ly", { khoa, daXuLy: true });
    mcp.datTrangThaiServer(s.id, "da_ket_noi", "");
    assert.ok(!td.phanLoaiViecCanLam().daXuLy.some((v) => v.khoa === khoa), "hết lỗi thì không còn trong 'đã xử lý'");
    mcp.datTrangThaiServer(s.id, "loi", "lại lỗi");
    assert.ok(td.phanLoaiViecCanLam().canLam.some((v) => v.khoa === khoa), "lỗi lại thì hiện lại");
  });

  it("tiêu đề đổi thì coi là việc mới, hiện lại", async () => {
    // bài chờ duyệt: tiêu đề chứa số bài
    const dem = () => td.phanLoaiViecCanLam().canLam.find((v) => v.khoa === "bai-cho-duyet");
    const truoc = dem();
    assert.ok(truoc, "đã có bài chờ duyệt từ test đầu");
    await post("/api/mobile/todo/xu-ly", { khoa: "bai-cho-duyet", daXuLy: true });
    assert.ok(!dem());
    database.db
      .prepare("INSERT INTO post_drafts (id, account_id, thread_id, topic_key, topic_title, source, source_note, body, discuss, infographic, has_image, similarity, status, scheduled_at) VALUES ('p2','acc-todo','g2','k2','Mẹo 2','s','','b','','',0,0,'cho_duyet',?)")
      .run("2099-01-02T00:00:00.000Z");
    assert.ok(dem(), "thêm một bài chờ duyệt thì mục hiện lại");
  });

  it("đòi đủ trường; khoa lạ trả 404 và không lưu chuỗi trình duyệt tự bịa", async () => {
    assert.equal((await post("/api/mobile/todo/xu-ly", { khoa: 1, daXuLy: true })).status, 400);
    assert.equal((await post("/api/mobile/todo/xu-ly", { khoa: "khong-co", daXuLy: true })).status, 404);
  });

  it("sự kiện nhật ký: đánh dấu và bỏ đánh dấu, id lạ trả 404", async () => {
    const { ghiSuKien, suKienTheoNgay } = await import("./event-log-store.js");
    const { todayKey } = await import("../shared/zone-time.js");
    ghiSuKien({ loai: "vps", muc: "chuY", tieuDe: "RAM thấp" });
    const homNay = todayKey("Asia/Ho_Chi_Minh");
    const e = suKienTheoNgay(homNay)!.find((x) => x.tieuDe === "RAM thấp")!;
    assert.equal(e.daXuLy, false);
    assert.equal((await post(`/api/mobile/events/${e.id}/xu-ly`, { daXuLy: true })).status, 200);
    assert.equal(suKienTheoNgay(homNay)!.find((x) => x.id === e.id)!.daXuLy, true);
    assert.equal((await post(`/api/mobile/events/${e.id}/xu-ly`, { daXuLy: false })).status, 200);
    assert.equal(suKienTheoNgay(homNay)!.find((x) => x.id === e.id)!.daXuLy, false);
    assert.equal((await post("/api/mobile/events/999999/xu-ly", { daXuLy: true })).status, 404);
    assert.equal((await post(`/api/mobile/events/${e.id}/xu-ly`, { daXuLy: "co" })).status, 400);
  });
});

describe("khách mới", () => {
  it("chỉ lấy chat riêng lần đầu nhắn trong khoảng, bỏ chủ bot và nhóm, kèm tin đầu", async () => {
    const { khachMoi } = await import("./new-customers.js");
    const now = new Date("2030-06-10T00:00:00Z");
    accounts.createAccount({ id: "acc-km", label: "Nick khách" });
    accounts.updateAccount("acc-km", { ownerUserId: "chu-km" });
    const them = (thread: string, type: number, ten: string) =>
      database.db.prepare("INSERT OR REPLACE INTO threads (account_id, thread_id, thread_type, display_name) VALUES ('acc-km', ?, ?, ?)").run(thread, type, ten);
    const tin = (thread: string, role: string, noiDung: string, luc: string) =>
      database.db.prepare("INSERT INTO messages (account_id, thread_id, role, content, created_at) VALUES ('acc-km', ?, ?, ?, ?)").run(thread, role, noiDung, luc);
    them("moi", 0, "Khách Mới");
    tin("moi", "user", "Chào shop,   cho mình hỏi giá\nkhóa học", "2030-06-09T10:00:00.000Z");
    tin("moi", "assistant", "Dạ em gửi anh", "2030-06-09T10:00:05.000Z");
    tin("moi", "user", "ok", "2030-06-09T10:01:00.000Z");
    them("cu", 0, "Khách Cũ");
    tin("cu", "user", "hi", "2030-05-01T10:00:00.000Z");
    them("chu-km", 0, "Chủ bot");
    tin("chu-km", "user", "test", "2030-06-09T11:00:00.000Z");
    them("nhom", 1, "Nhóm A");
    tin("nhom", "user", "hello", "2030-06-09T12:00:00.000Z");

    const ds = khachMoi(7, now);
    assert.deepEqual(ds.map((k) => k.threadId), ["moi"]);
    const k = ds[0]!;
    assert.equal(k.ten, "Khách Mới");
    assert.equal(k.tinDau, "Chào shop, cho mình hỏi giá khóa học");
    assert.equal(k.soTinKhach, 2);
    assert.equal(k.botDaTraLoi, true);
    assert.deepEqual(khachMoi(90, now).map((x) => x.threadId).sort(), ["cu", "moi"]);
  });

  it("API cần đăng nhập và chỉ nhận 1, 7 hoặc 30 ngày", async () => {
    assert.equal((await app.request("/api/mobile/new-customers")).status, 401);
    const r = await app.request("/api/mobile/new-customers?ngay=999", { headers: { cookie } });
    assert.equal(r.status, 200);
    assert.equal(((await r.json()) as { soNgay: number }).soNgay, 7);
  });
});
