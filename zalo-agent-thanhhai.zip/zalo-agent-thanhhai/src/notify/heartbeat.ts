import { listEnabledAccounts } from "../config/account-store.js";
import { createLogger } from "../shared/logger.js";
import { isAccountRunning } from "../zalo/account-manager.js";
import { nickMatKetNoi } from "../zalo/listener-flap-watch.js";
import { thuThapChiSo } from "../vps-monitor/vps-metrics.js";
import { danhGia } from "../vps-monitor/vps-report-format.js";
import { layCauHinhThongBao } from "./notify-settings.js";

/**
 * TRẠM BÁO ĐỘC LẬP (dead-man's switch). Giám sát bằng chính hệ thống bị giám sát có điểm mù:
 * VPS sập hay mất mạng thì cả tin Zalo lẫn thông báo đẩy đều không đi được. Nên bot tự "ping" một
 * dịch vụ NGOÀI (vd Healthchecks.io, miễn phí) mỗi phút; ping NGỪNG tới là dịch vụ đó báo bạn
 * (email, Telegram, ntfy...) mà không cần VPS còn sống. Gặp sự cố nặng nhưng bot vẫn chạy thì
 * ping sang địa chỉ `/fail` để báo ngay thay vì chờ hết hạn.
 *
 * Địa chỉ ping do chủ bot nhập trên dashboard; bắt buộc https và không được trỏ vào mạng nội bộ.
 */

const log = createLogger("heartbeat");
const NHIP_MS = 60_000;
const TRAN_MS = 10_000;

export function diaChiPingHopLe(url: string): boolean {
  try {
    const u = new URL(url);
    if (u.protocol !== "https:" || u.username || u.password) return false;
    const h = u.hostname.toLowerCase();
    if (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".ts.net")) return false;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(h) || h.includes(":")) return false; // địa chỉ IP trần: có thể là mạng nội bộ
    return h.includes(".");
  } catch {
    return false;
  }
}

export type TrangThaiPing = { luc: number | null; ok: boolean | null; loi: string; sucoNang: boolean };
let lanCuoi: TrangThaiPing = { luc: null, ok: null, loi: "", sucoNang: false };
export const trangThaiPing = (): TrangThaiPing => lanCuoi;

/** Có sự cố nặng (đỏ) mà bot vẫn chạy được: máy chủ quá tải hoặc nick mất kết nối. */
export function coSuCoNang(): boolean {
  const g = danhGia(thuThapChiSo());
  if (Object.values(g).includes("do")) return true;
  return listEnabledAccounts().some((a) => isAccountRunning(a.id) && nickMatKetNoi(a.id));
}

export async function pingMotLan(fetchFn: typeof fetch = fetch, now = Date.now(), suCo = coSuCoNang): Promise<TrangThaiPing> {
  const url = layCauHinhThongBao().tramBaoUrl.trim();
  if (!url) return (lanCuoi = { luc: null, ok: null, loi: "", sucoNang: false });
  if (!diaChiPingHopLe(url)) return (lanCuoi = { luc: now, ok: false, loi: "Địa chỉ ping không hợp lệ", sucoNang: false });
  const nang = suCo();
  try {
    const res = await fetchFn(nang ? `${url.replace(/\/+$/, "")}/fail` : url, { signal: AbortSignal.timeout(TRAN_MS), redirect: "error" });
    lanCuoi = { luc: now, ok: res.ok, loi: res.ok ? "" : `HTTP ${res.status}`, sucoNang: nang };
  } catch (err) {
    lanCuoi = { luc: now, ok: false, loi: err instanceof Error ? err.message : String(err), sucoNang: nang };
  }
  return lanCuoi;
}

export function batDauTramBao(): () => void {
  const id = setInterval(() => {
    void pingMotLan().catch((err) => log.warn({ err }, "Ping trạm báo lỗi"));
  }, NHIP_MS);
  id.unref?.();
  return () => clearInterval(id);
}
