import { listAccounts } from "../config/account-store.js";
import { db } from "../conversation/database.js";
import "../group-posts/gp-draft-store.js"; // tạo bảng post_drafts nếu chưa có
import "../outreach/outreach-store.js"; // tạo bảng outreach_batches nếu chưa có
import { danhSachServer } from "../mcp/mcp-server-store.js";
import { getRunningAccounts } from "../zalo/account-manager.js";
import { nickMatKetNoi } from "../zalo/listener-flap-watch.js";
import { boDanhDauViec, layViecDaXuLy } from "./viec-da-xu-ly-store.js";

/**
 * "Việc cần làm" cho ứng dụng điện thoại (2026-10-07): những thứ đang chờ chính chủ bot ra tay -
 * khác "Việc sắp tới" (lịch đã đặt, tự chạy). Chỉ ĐỌC, mỗi mục kèm đường dẫn tới trang xử lý trên
 * bảng điều khiển đầy đủ. Sắp theo mức: sự cố trước, cần chú ý sau.
 */

export type ViecCanLam = { khoa: string; muc: "suCo" | "chuY"; tieuDe: string; chiTiet: string; duong: string };

const n = (sql: string, ...tham: (string | number)[]) => (db.prepare(sql).get(...tham) as { n: number }).n;

export function viecCanLam(now = new Date()): ViecCanLam[] {
  const kq: ViecCanLam[] = [];
  const dangChay = new Set(getRunningAccounts().map((a) => a.id));

  for (const a of listAccounts()) {
    if (!a.enabled) continue;
    const ten = a.label || a.id;
    if (dangChay.has(a.id) && nickMatKetNoi(a.id, now.getTime())) {
      kq.push({ khoa: `matkn:${a.id}`, muc: "suCo", tieuDe: `${ten} mất kết nối`, chiTiet: "Zalo đóng kết nối liên tục, cần đăng nhập lại bằng QR.", duong: "/accounts" });
    } else if (!dangChay.has(a.id)) {
      kq.push({ khoa: `khongchay:${a.id}`, muc: "suCo", tieuDe: `${ten} không chạy`, chiTiet: "Tài khoản đang bật nhưng chưa kết nối được Zalo.", duong: "/accounts" });
    }
  }

  for (const s of danhSachServer()) {
    if (!s.enabled) continue;
    if (s.dungOauth && !s.daDangNhap) kq.push({ khoa: `mcp-dn:${s.id}`, muc: "chuY", tieuDe: `Kết nối ${s.ten} chưa đăng nhập`, chiTiet: "Cần bấm đăng nhập OAuth trên bảng điều khiển.", duong: "/mcp" });
    else if (s.trangThai === "can_duyet_lai") kq.push({ khoa: `mcp-dl:${s.id}`, muc: "chuY", tieuDe: `Kết nối ${s.ten} đổi công cụ`, chiTiet: "Máy chủ đổi danh sách công cụ, cần bạn duyệt lại.", duong: "/mcp" });
    else if (s.trangThai === "loi") kq.push({ khoa: `mcp-loi:${s.id}`, muc: "chuY", tieuDe: `Kết nối ${s.ten} đang lỗi`, chiTiet: s.loi.slice(0, 120) || "Không nối được máy chủ MCP.", duong: "/mcp" });
  }

  const choDuyet = n("SELECT COUNT(*) AS n FROM post_drafts WHERE status = 'cho_duyet' AND scheduled_at >= ?", now.toISOString());
  if (choDuyet > 0) kq.push({ khoa: "bai-cho-duyet", muc: "chuY", tieuDe: `${choDuyet} bài nhóm chờ bạn duyệt`, chiTiet: "Bài chưa duyệt sẽ không được đăng.", duong: "/group-posts" });
  const loiBai = n("SELECT COUNT(*) AS n FROM post_drafts WHERE status = 'loi' AND scheduled_at >= ?", new Date(now.getTime() - 3 * 86_400_000).toISOString());
  if (loiBai > 0) kq.push({ khoa: "bai-loi", muc: "chuY", tieuDe: `${loiBai} bài nhóm đăng lỗi (3 ngày qua)`, chiTiet: "Bot không tự thử lại, cần bạn xem và đăng tay.", duong: "/group-posts" });

  const tamDung = n("SELECT COUNT(*) AS n FROM outreach_batches WHERE status = 'tam_dung'");
  if (tamDung > 0) kq.push({ khoa: "nhan-tam-dung", muc: "suCo", tieuDe: `${tamDung} lô nhắn riêng đang tạm dừng`, chiTiet: "Lỗi gửi liên tiếp, nghi Zalo chặn. Nhắn \"tiếp tục\" cho bot nếu muốn gửi nốt.", duong: "/" });
  const choXn = n("SELECT COUNT(*) AS n FROM outreach_batches WHERE status = 'cho_xac_nhan' AND tao_luc >= ?", now.getTime() - 30 * 60_000);
  if (choXn > 0) kq.push({ khoa: "nhan-cho-xn", muc: "chuY", tieuDe: `${choXn} lô nhắn riêng chờ bạn xác nhận`, chiTiet: "Xác nhận bằng tin nhắn mới cho bot trong chat riêng.", duong: "/" });

  return kq.sort((a, b) => (a.muc === b.muc ? 0 : a.muc === "suCo" ? -1 : 1));
}

/**
 * Tách danh sách thành "đang chờ" và "đã xử lý" theo dấu chủ bot đã bấm. Dấu chỉ còn hiệu lực khi
 * việc đó VẪN tồn tại với cùng tiêu đề: việc hết hẳn thì xóa dấu (lần sau nó quay lại là việc mới),
 * tiêu đề đổi thì cũng coi là việc mới.
 */
export function phanLoaiViecCanLam(now = new Date()): { canLam: ViecCanLam[]; daXuLy: ViecCanLam[] } {
  const tatCa = viecCanLam(now);
  const dau = layViecDaXuLy();
  const conTon = new Set(tatCa.map((v) => v.khoa));
  for (const khoa of dau.keys()) if (!conTon.has(khoa)) boDanhDauViec(khoa);
  const canLam: ViecCanLam[] = [];
  const daXuLy: ViecCanLam[] = [];
  for (const v of tatCa) (dau.get(v.khoa) === v.tieuDe ? daXuLy : canLam).push(v);
  return { canLam, daXuLy };
}
