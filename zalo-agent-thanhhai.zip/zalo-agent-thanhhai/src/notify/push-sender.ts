import webpush from "web-push";
import { createLogger } from "../shared/logger.js";
import { danhSachThietBi, ghiNhanGuiOk, layKhoaVapid, xoaThietBi, type ThietBiDay } from "./push-store.js";

const log = createLogger("push-sender");

export type NoiDungDay = { tieuDe: string; noiDung: string; url?: string; tag?: string };

export type GuiMotThietBi = (t: ThietBiDay, body: string) => Promise<void>;

const guiThat: GuiMotThietBi = async (t, body) => {
  const k = layKhoaVapid();
  await webpush.sendNotification({ endpoint: t.endpoint, keys: { p256dh: t.p256dh, auth: t.auth } }, body, {
    vapidDetails: { subject: k.subject, publicKey: k.publicKey, privateKey: k.privateKey },
    // Cảnh báo sự cố phải tới ngay; để quá 1 giờ thì mất ý nghĩa nên không giữ lâu hơn.
    TTL: 3600,
    urgency: "high",
  });
};

/** Cắt chữ để vừa giới hạn tải trọng (Apple 4 KB) mà vẫn đủ đọc trên màn hình khóa. */
const cat = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

/**
 * Gửi tới MỌI thiết bị đã đăng ký. Thiết bị trả 404/410 (gỡ app, thu hồi quyền) bị xóa
 * khỏi danh sách; lỗi tạm (mạng, 5xx) giữ lại để lần sau thử tiếp. Không bao giờ ném lỗi:
 * thông báo đẩy là kênh PHỤ, hỏng không được làm hỏng đường báo chính.
 */
export async function guiPushChoTatCa(p: NoiDungDay, gui: GuiMotThietBi = guiThat): Promise<{ gui: number; loi: number }> {
  const ds = danhSachThietBi();
  if (ds.length === 0) return { gui: 0, loi: 0 };
  const body = JSON.stringify({ tieuDe: cat(p.tieuDe, 80), noiDung: cat(p.noiDung, 300), url: p.url ?? "/m", tag: p.tag });
  let ok = 0;
  let hong = 0;
  await Promise.all(
    ds.map(async (t) => {
      try {
        await gui(t, body);
        ghiNhanGuiOk(t.endpoint);
        ok += 1;
      } catch (err) {
        hong += 1;
        const ma = (err as { statusCode?: number }).statusCode;
        if (ma === 404 || ma === 410) xoaThietBi(t.endpoint);
        else log.warn({ ma, err: err instanceof Error ? err.message : String(err) }, "Gửi thông báo đẩy lỗi");
      }
    }),
  );
  return { gui: ok, loi: hong };
}
