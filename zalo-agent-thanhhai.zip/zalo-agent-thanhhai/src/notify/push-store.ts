import webpush from "web-push";
import { decryptSecret, encryptSecret } from "../config/secret-cipher.js";
import { db } from "../conversation/database.js";

/**
 * Kho thông báo đẩy (Web Push): thiết bị đã đăng ký + cặp khóa VAPID của máy chủ.
 * Khóa riêng mã hóa như mọi secret khác, tự sinh lần đầu cần dùng. Thiết bị chỉ do
 * chủ bot đăng ký qua dashboard (đã đăng nhập) - không có đường công khai nào.
 */

db.exec(`
  CREATE TABLE IF NOT EXISTS push_subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    endpoint TEXT NOT NULL UNIQUE,
    p256dh TEXT NOT NULL,
    auth TEXT NOT NULL,
    user_agent TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    last_ok_at TEXT
  )
`);

/** Máy chủ đẩy của trình duyệt (Apple, Google, Mozilla, Microsoft). Địa chỉ lạ bị từ chối: ta sẽ POST tới đó. */
const HOST_DAY_HOP_LE = [".push.apple.com", ".googleapis.com", ".push.services.mozilla.com", ".notify.windows.com"];

export function diaChiDayHopLe(endpoint: string): boolean {
  try {
    const u = new URL(endpoint);
    return u.protocol === "https:" && HOST_DAY_HOP_LE.some((h) => u.hostname === h.slice(1) || u.hostname.endsWith(h));
  } catch {
    return false;
  }
}

export type ThietBiDay = { id: number; endpoint: string; p256dh: string; auth: string; userAgent: string; taoLuc: string; lanCuoiOk: string | null };

type Row = { id: number; endpoint: string; p256dh: string; auth: string; user_agent: string; created_at: string; last_ok_at: string | null };
const toThietBi = (r: Row): ThietBiDay => ({ id: r.id, endpoint: r.endpoint, p256dh: r.p256dh, auth: r.auth, userAgent: r.user_agent, taoLuc: r.created_at, lanCuoiOk: r.last_ok_at });

const upsertStmt = db.prepare(`
  INSERT INTO push_subscriptions (endpoint, p256dh, auth, user_agent) VALUES (?, ?, ?, ?)
  ON CONFLICT (endpoint) DO UPDATE SET p256dh = excluded.p256dh, auth = excluded.auth, user_agent = excluded.user_agent
`);
const listStmt = db.prepare("SELECT * FROM push_subscriptions ORDER BY id");
const delStmt = db.prepare("DELETE FROM push_subscriptions WHERE endpoint = ?");
const okStmt = db.prepare("UPDATE push_subscriptions SET last_ok_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE endpoint = ?");

export function luuThietBi(t: { endpoint: string; p256dh: string; auth: string; userAgent?: string }): void {
  upsertStmt.run(t.endpoint, t.p256dh, t.auth, (t.userAgent ?? "").slice(0, 200));
}
export const danhSachThietBi = (): ThietBiDay[] => (listStmt.all() as unknown as Row[]).map(toThietBi);
export const xoaThietBi = (endpoint: string): void => void delStmt.run(endpoint);
export const ghiNhanGuiOk = (endpoint: string): void => void okStmt.run(endpoint);

const getSetting = db.prepare("SELECT value FROM runtime_settings WHERE key = ?");
const setSetting = db.prepare(`
  INSERT INTO runtime_settings (key, value, updated_at) VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);
const doc = (k: string) => (getSetting.get(k) as { value: string } | undefined)?.value;

export type KhoaVapid = { publicKey: string; privateKey: string; subject: string };

/** Khóa VAPID: sinh một lần rồi dùng mãi (đổi khóa là mọi thiết bị đã đăng ký mất hiệu lực). */
export function layKhoaVapid(): KhoaVapid {
  let pub = doc("push_vapid_public");
  let priv = doc("push_vapid_private");
  if (!pub || !priv) {
    const k = webpush.generateVAPIDKeys();
    pub = k.publicKey;
    priv = encryptSecret(k.privateKey);
    setSetting.run("push_vapid_public", pub);
    setSetting.run("push_vapid_private", priv);
  }
  return { publicKey: pub, privateKey: decryptSecret(priv), subject: doc("push_vapid_subject") || "mailto:admin@zalo-agent.local" };
}

/** Ghi lại địa chỉ dashboard (https) làm "người liên hệ" của VAPID - Apple đòi mailto hoặc https hợp lệ. */
export function datChuTheVapid(origin: string): void {
  if (/^https:\/\/[^\s/]+$/.test(origin)) setSetting.run("push_vapid_subject", origin);
}
