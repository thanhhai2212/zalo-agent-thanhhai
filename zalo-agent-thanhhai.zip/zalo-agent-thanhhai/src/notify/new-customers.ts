import { db } from "../conversation/database.js";

/**
 * "Khách mới" cho ứng dụng điện thoại (2026-10-08): người lần đầu nhắn RIÊNG cho một nick Zalo của bot
 * trong N ngày qua. Mốc "lần đầu" là tin sớm nhất của cuộc chat riêng đó trong lịch sử (lịch sử chỉ
 * giữ số tin gần nhất mỗi cuộc chat, nhưng khách vừa tới thì tin đầu vẫn còn). Bỏ chính chủ bot.
 * Chỉ ĐỌC; chỉ lấy trích đoạn ngắn tin đầu của khách (đã nằm sẵn trong lịch sử chat).
 */

export type KhachMoi = {
  accountId: string;
  threadId: string;
  ten: string;
  lanDau: string;
  tinDau: string;
  soTinKhach: number;
  botDaTraLoi: boolean;
};

type Dong = { account_id: string; thread_id: string; display_name: string; dau: string };

const ungVienStmt = db.prepare(`
  SELECT account_id, thread_id, display_name, dau FROM (
    SELECT t.account_id, t.thread_id, t.display_name,
           (SELECT MIN(m.created_at) FROM messages m WHERE m.account_id = t.account_id AND m.thread_id = t.thread_id) AS dau
    FROM threads t
    JOIN accounts a ON a.id = t.account_id
    WHERE t.thread_type = 0 AND t.thread_id != COALESCE(a.owner_user_id, '')
  )
  WHERE dau IS NOT NULL AND dau >= ?
  ORDER BY dau DESC
  LIMIT ?
`);
const tinDauStmt = db.prepare("SELECT content FROM messages WHERE account_id = ? AND thread_id = ? AND role = 'user' ORDER BY id ASC LIMIT 1");
const demKhachStmt = db.prepare("SELECT COUNT(*) AS n FROM messages WHERE account_id = ? AND thread_id = ? AND role = 'user'");
const botTraLoiStmt = db.prepare("SELECT 1 AS x FROM messages WHERE account_id = ? AND thread_id = ? AND role = 'assistant' LIMIT 1");

const cat = (s: string, n: number) => {
  const g = s.replace(/\s+/g, " ").trim();
  return g.length > n ? `${g.slice(0, n - 1)}…` : g;
};

export function khachMoi(soNgay: number, now = new Date(), gioiHan = 100): KhachMoi[] {
  const ngay = Math.min(90, Math.max(1, Math.trunc(soNgay) || 7));
  const tu = new Date(now.getTime() - ngay * 86_400_000).toISOString();
  return (ungVienStmt.all(tu, Math.min(200, Math.max(1, gioiHan))) as unknown as Dong[]).map((r) => ({
    accountId: r.account_id,
    threadId: r.thread_id,
    ten: r.display_name || "(chưa có tên)",
    lanDau: r.dau,
    tinDau: cat(String((tinDauStmt.get(r.account_id, r.thread_id) as { content?: string } | undefined)?.content ?? ""), 140),
    soTinKhach: (demKhachStmt.get(r.account_id, r.thread_id) as { n: number }).n,
    botDaTraLoi: botTraLoiStmt.get(r.account_id, r.thread_id) !== undefined,
  }));
}
