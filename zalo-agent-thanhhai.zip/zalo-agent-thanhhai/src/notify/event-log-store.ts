import { botTimeZone } from "../config/runtime-tuning-settings.js";
import { db } from "../conversation/database.js";
import { dayKeyOf, zonedWallClockToUtc } from "../shared/zone-time.js";

/**
 * Nhật ký sự kiện của hệ thống (2026-10-07), nguồn cho màn "Nhật ký" và số "Cảnh báo" trong
 * "Báo cáo" trên ứng dụng điện thoại. Chỉ ghi những điều chủ bot cần xem lại: cảnh báo, tài khoản
 * Zalo kết nối, video xong hoặc hỏng, bot khởi động. KHÔNG ghi nội dung hội thoại ngoài một trích
 * đoạn ngắn của tin khách gấp (đã nằm sẵn trong lịch sử chat). Giữ 90 ngày.
 */

export type LoaiSuKien = "vps" | "zaloDut" | "khachGap" | "tagChu" | "baoCao" | "video" | "heThong";
export type MucSuKien = "thongTin" | "chuY" | "suCo";

db.exec(`
  CREATE TABLE IF NOT EXISTS app_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    loai TEXT NOT NULL,
    muc TEXT NOT NULL,
    tieu_de TEXT NOT NULL,
    noi_dung TEXT NOT NULL DEFAULT '',
    account_id TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_app_events_time ON app_events (created_at);
`);
// Cột "đã xử lý" (2026-10-08): chủ bot tự đánh dấu tay trên điện thoại, NULL là chưa xử lý.
if (!(db.prepare("SELECT name FROM pragma_table_info('app_events')").all() as { name: string }[]).some((c) => c.name === "da_xu_ly_luc")) {
  db.exec("ALTER TABLE app_events ADD COLUMN da_xu_ly_luc TEXT");
}

const insertStmt = db.prepare("INSERT INTO app_events (loai, muc, tieu_de, noi_dung, account_id) VALUES (?, ?, ?, ?, ?)");
const pruneStmt = db.prepare("DELETE FROM app_events WHERE created_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-90 days')");
let dem = 0;

const cat = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

/** Không bao giờ ném lỗi: ghi nhật ký là việc phụ, không được làm hỏng đường báo chính. */
export function ghiSuKien(e: { loai: LoaiSuKien; muc: MucSuKien; tieuDe: string; noiDung?: string; accountId?: string }): void {
  try {
    insertStmt.run(e.loai, e.muc, cat(e.tieuDe, 120), cat((e.noiDung ?? "").replace(/\s+/g, " ").trim(), 300), e.accountId ?? null);
    dem += 1;
    if (dem % 100 === 0) pruneStmt.run();
  } catch {
    /* bỏ qua */
  }
}

export type SuKien = { id: number; luc: string; loai: LoaiSuKien; muc: MucSuKien; tieuDe: string; noiDung: string; accountId: string | null; daXuLy: boolean };
type Row = { id: number; created_at: string; loai: string; muc: string; tieu_de: string; noi_dung: string; account_id: string | null; da_xu_ly_luc: string | null };
const toSuKien = (r: Row): SuKien => ({ id: r.id, luc: r.created_at, loai: r.loai as LoaiSuKien, muc: r.muc as MucSuKien, tieuDe: r.tieu_de, noiDung: r.noi_dung, accountId: r.account_id, daXuLy: r.da_xu_ly_luc !== null });

const xuLyStmt = db.prepare("UPDATE app_events SET da_xu_ly_luc = ? WHERE id = ?");
/** Đánh dấu (hoặc bỏ đánh dấu) một sự kiện đã xử lý. Trả false nếu không có sự kiện đó. */
export function datSuKienDaXuLy(id: number, daXuLy: boolean): boolean {
  return Number(xuLyStmt.run(daXuLy ? new Date().toISOString() : null, id).changes) > 0;
}

const rangeStmt = db.prepare("SELECT * FROM app_events WHERE created_at >= ? AND created_at < ? ORDER BY id DESC LIMIT ?");

/** Mốc UTC [đầu, cuối) của một ngày địa phương `YYYY-MM-DD`. Null nếu chuỗi sai. */
export function khoangNgay(ngay: string, tz = botTimeZone()): { tu: string; den: string } | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ngay)) return null;
  const tu = zonedWallClockToUtc(ngay, "00:00", tz);
  const d = new Date(`${ngay}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 1);
  const den = zonedWallClockToUtc(d.toISOString().slice(0, 10), "00:00", tz);
  return tu && den ? { tu, den } : null;
}

export function suKienTheoNgay(ngay: string, tz = botTimeZone(), gioiHan = 200): SuKien[] | null {
  const k = khoangNgay(ngay, tz);
  if (!k) return null;
  return (rangeStmt.all(k.tu, k.den, Math.min(500, Math.max(1, gioiHan))) as unknown as Row[]).map(toSuKien);
}

/** Cộng `n` ngày vào khóa ngày `YYYY-MM-DD` (phép tính lịch thuần, không đụng múi giờ). Null nếu chuỗi sai. */
export function congNgay(ngay: string, n: number): string | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ngay)) return null;
  const d = new Date(`${ngay}T12:00:00Z`);
  if (Number.isNaN(d.getTime())) return null;
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/** Thứ Hai của tuần chứa `ngay`. */
export function dauTuan(ngay: string): string | null {
  const d = new Date(`${ngay}T12:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ngay) || Number.isNaN(d.getTime())) return null;
  return congNgay(ngay, -((d.getUTCDay() + 6) % 7));
}

/** Sự kiện của cả tuần (thứ Hai đến Chủ nhật) chứa `ngay`, gom theo ngày địa phương, cũ trước mới sau. */
export function suKienTheoTuan(ngay: string, tz = botTimeZone()): { tu: string; den: string; cacNgay: { ngay: string; suKien: SuKien[] }[] } | null {
  const tu = dauTuan(ngay);
  const den = tu && congNgay(tu, 6);
  const dau = tu && khoangNgay(tu, tz);
  const cuoi = den && khoangNgay(den, tz);
  if (!tu || !den || !dau || !cuoi) return null;
  const rows = rangeStmt.all(dau.tu, cuoi.den, 1500) as unknown as Row[];
  const cacNgay = Array.from({ length: 7 }, (_, i) => ({ ngay: congNgay(tu, i)!, suKien: [] as SuKien[] }));
  for (const r of rows.reverse()) {
    const o = cacNgay.find((x) => x.ngay === dayKeyOf(r.created_at, tz));
    if (o) o.suKien.push(toSuKien(r));
  }
  for (const o of cacNgay) o.suKien.sort((a, b) => a.luc.localeCompare(b.luc));
  return { tu, den, cacNgay };
}

const MUC_NANG: Record<MucSuKien, number> = { thongTin: 0, chuY: 1, suCo: 2 };

/** Với mỗi ngày trong tháng `YYYY-MM`: số sự kiện và mức nặng nhất (để chấm màu trên lịch). */
export function lichThang(thang: string, tz = botTimeZone()): { ngay: string; soSuKien: number; mucNangNhat: MucSuKien }[] | null {
  if (!/^\d{4}-\d{2}$/.test(thang)) return null;
  const dau = khoangNgay(`${thang}-01`, tz);
  const [y, m] = thang.split("-").map(Number) as [number, number];
  const sau = new Date(Date.UTC(y, m, 1)).toISOString().slice(0, 10);
  const cuoi = khoangNgay(sau, tz);
  if (!dau || !cuoi) return null;
  const rows = rangeStmt.all(dau.tu, cuoi.tu, 20000) as unknown as Row[];
  const theoNgay = new Map<string, { so: number; muc: MucSuKien }>();
  for (const r of rows) {
    const ngay = dayKeyOf(r.created_at, tz);
    const cu = theoNgay.get(ngay) ?? { so: 0, muc: "thongTin" as MucSuKien };
    cu.so += 1;
    if (MUC_NANG[r.muc as MucSuKien] > MUC_NANG[cu.muc]) cu.muc = r.muc as MucSuKien;
    theoNgay.set(ngay, cu);
  }
  return [...theoNgay].sort(([a], [b]) => a.localeCompare(b)).map(([ngay, v]) => ({ ngay, soSuKien: v.so, mucNangNhat: v.muc }));
}

const demMucStmt = db.prepare("SELECT COUNT(*) AS n FROM app_events WHERE created_at >= ? AND created_at < ? AND muc IN ('chuY','suCo')");
export function demCanhBao(tuUtc: string, denUtc: string): number {
  return (demMucStmt.get(tuUtc, denUtc) as { n: number }).n;
}
