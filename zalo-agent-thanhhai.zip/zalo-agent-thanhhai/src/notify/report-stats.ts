import { botTimeZone } from "../config/runtime-tuning-settings.js";
import { db } from "../conversation/database.js";
import { dayKeyOf, todayKey } from "../shared/zone-time.js";
import { demCanhBao, khoangNgay } from "./event-log-store.js";

/**
 * Số liệu cho màn "Báo cáo" trên ứng dụng điện thoại (2026-10-07): tin nhắn, lượt agent + token,
 * liên hệ mới theo ngày và theo tài khoản, số cảnh báo. Toàn bộ là phép đếm có sẵn trong DB,
 * không gọi model. Gộp theo NGÀY ĐỊA PHƯƠNG ở JS (SQLite không biết múi giờ) nhưng chỉ kéo về
 * các nhóm 10 phút (tối đa ~4.300 dòng cho 30 ngày) chứ không kéo từng tin.
 */

export type BaoCaoNgay = { ngay: string; tinKhach: number; tinBot: number; luot: number; token: number; lienHeMoi: number };
export type BaoCaoTaiKhoan = { accountId: string; tinKhach: number; tinBot: number; luot: number; token: number; lienHeMoi: number };
export type BaoCao = {
  soNgay: number;
  tu: string;
  den: string;
  tong: { tinKhach: number; tinBot: number; luot: number; token: number; lienHeMoi: number; canhBao: number };
  theoNgay: BaoCaoNgay[];
  theoTaiKhoan: BaoCaoTaiKhoan[];
};

type Nhom = { b: string; account_id: string; n: number; t?: number };

/** Danh sách `soNgay` khóa ngày địa phương kết thúc ở hôm nay, cũ -> mới. */
export function cacNgayGanDay(soNgay: number, tz: string, now = new Date()): string[] {
  const kq: string[] = [];
  for (let i = soNgay - 1; i >= 0; i--) kq.push(dayKeyOf(new Date(now.getTime() - i * 86_400_000).toISOString(), tz));
  return kq;
}

export function tinhBaoCao(soNgay: number, now = new Date(), tz = botTimeZone()): BaoCao {
  const so = Math.min(90, Math.max(1, Math.round(soNgay)));
  const ngays = cacNgayGanDay(so, tz, now);
  const dau = khoangNgay(ngays[0]!, tz);
  const cuoiNgay = khoangNgay(ngays[ngays.length - 1]!, tz);
  if (!dau || !cuoiNgay) throw new Error("tinhBaoCao: không tính được khoảng ngày");
  const tu = dau.tu;
  const den = cuoiNgay.den;

  const msgs = db
    .prepare(
      `SELECT substr(created_at,1,15) AS b, account_id, role, COUNT(*) AS n
       FROM messages WHERE created_at >= ? AND created_at < ? GROUP BY b, account_id, role`,
    )
    .all(tu, den) as unknown as (Nhom & { role: string })[];
  const turns = db
    .prepare(
      `SELECT substr(created_at,1,15) AS b, account_id, COUNT(*) AS n, COALESCE(SUM(total_tokens),0) AS t
       FROM agent_turns WHERE created_at >= ? AND created_at < ? GROUP BY b, account_id`,
    )
    .all(tu, den) as unknown as Nhom[];
  const lienHe = db
    .prepare(
      `SELECT substr(first_seen,1,15) AS b, account_id, COUNT(*) AS n
       FROM contacts WHERE first_seen >= ? AND first_seen < ? GROUP BY b, account_id`,
    )
    .all(tu, den) as unknown as Nhom[];

  const theoNgay = new Map<string, BaoCaoNgay>(ngays.map((ngay) => [ngay, { ngay, tinKhach: 0, tinBot: 0, luot: 0, token: 0, lienHeMoi: 0 }]));
  const theoTk = new Map<string, BaoCaoTaiKhoan>();
  const tk = (id: string) => {
    let v = theoTk.get(id);
    if (!v) theoTk.set(id, (v = { accountId: id, tinKhach: 0, tinBot: 0, luot: 0, token: 0, lienHeMoi: 0 }));
    return v;
  };
  // Nhóm 10 phút: "2026-10-06T15:3" -> 15:30 UTC. Gộp về ngày địa phương theo đầu nhóm.
  const ngayCua = (b: string) => dayKeyOf(`${b}0:00.000Z`, tz);

  for (const r of msgs) {
    const d = theoNgay.get(ngayCua(r.b));
    const khach = r.role === "user";
    if (d) khach ? (d.tinKhach += r.n) : (d.tinBot += r.n);
    const t = tk(r.account_id);
    khach ? (t.tinKhach += r.n) : (t.tinBot += r.n);
  }
  for (const r of turns) {
    const d = theoNgay.get(ngayCua(r.b));
    if (d) ((d.luot += r.n), (d.token += r.t ?? 0));
    const t = tk(r.account_id);
    ((t.luot += r.n), (t.token += r.t ?? 0));
  }
  for (const r of lienHe) {
    const d = theoNgay.get(ngayCua(r.b));
    if (d) d.lienHeMoi += r.n;
    tk(r.account_id).lienHeMoi += r.n;
  }

  const dsNgay = [...theoNgay.values()];
  const cong = (f: (d: BaoCaoNgay) => number) => dsNgay.reduce((s, d) => s + f(d), 0);
  return {
    soNgay: so,
    tu: ngays[0]!,
    den: todayKey(tz, now),
    tong: {
      tinKhach: cong((d) => d.tinKhach),
      tinBot: cong((d) => d.tinBot),
      luot: cong((d) => d.luot),
      token: cong((d) => d.token),
      lienHeMoi: cong((d) => d.lienHeMoi),
      canhBao: demCanhBao(tu, den),
    },
    theoNgay: dsNgay,
    theoTaiKhoan: [...theoTk.values()].sort((a, b) => b.tinKhach + b.tinBot - (a.tinKhach + a.tinBot)),
  };
}
