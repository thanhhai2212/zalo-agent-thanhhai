import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let ev: typeof import("./event-log-store.js");
let mau: typeof import("../vps-monitor/vps-samples.js");
let rp: typeof import("./report-stats.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv({ BOT_TIMEZONE: "Asia/Ho_Chi_Minh" });
  database = await import("../conversation/database.js");
  ev = await import("./event-log-store.js");
  mau = await import("../vps-monitor/vps-samples.js");
  rp = await import("./report-stats.js");
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

const TZ = "Asia/Ho_Chi_Minh";

describe("nhật ký sự kiện", () => {
  it("khoảng ngày tính theo giờ Việt Nam, sai định dạng thì null", () => {
    assert.deepEqual(ev.khoangNgay("2026-10-07", TZ), { tu: "2026-10-06T17:00:00.000Z", den: "2026-10-07T17:00:00.000Z" });
    assert.equal(ev.khoangNgay("07/10/2026", TZ), null);
  });

  it("sự kiện lúc 00:30 giờ VN thuộc ngày VN, không phải ngày UTC trước đó", () => {
    database.db
      .prepare("INSERT INTO app_events (created_at, loai, muc, tieu_de) VALUES (?, 'vps', 'suCo', 'RAM thấp')")
      .run("2026-10-06T17:30:00.000Z"); // 00:30 ngày 07/10 giờ VN
    const ngay7 = ev.suKienTheoNgay("2026-10-07", TZ)!;
    assert.equal(ngay7.length, 1);
    assert.equal(ngay7[0]!.tieuDe, "RAM thấp");
    assert.equal(ev.suKienTheoNgay("2026-10-06", TZ)!.length, 0);
  });

  it("lịch tháng chấm mức nặng nhất của ngày", () => {
    database.db.prepare("INSERT INTO app_events (created_at, loai, muc, tieu_de) VALUES (?, 'video', 'thongTin', 'Video xong')").run("2026-10-07T03:00:00.000Z");
    const l = ev.lichThang("2026-10", TZ)!;
    const d = l.find((x) => x.ngay === "2026-10-07")!;
    assert.equal(d.soSuKien, 2);
    assert.equal(d.mucNangNhat, "suCo");
    assert.equal(ev.lichThang("2026-13x", TZ), null);
  });

  it("ghiSuKien cắt nội dung dài và không bao giờ ném lỗi", () => {
    ev.ghiSuKien({ loai: "heThong", muc: "thongTin", tieuDe: "x".repeat(500), noiDung: "a\n\n b ".repeat(200) });
    const r = database.db.prepare("SELECT tieu_de, noi_dung FROM app_events ORDER BY id DESC LIMIT 1").get() as { tieu_de: string; noi_dung: string };
    assert.ok(r.tieu_de.length <= 120);
    assert.ok(r.noi_dung.length <= 300);
    assert.ok(!r.noi_dung.includes("\n"));
  });
});

describe("nhật ký theo tuần", () => {
  it("thứ Hai của tuần và cộng ngày", () => {
    assert.equal(ev.dauTuan("2026-10-07"), "2026-10-05"); // thứ Tư -> thứ Hai
    assert.equal(ev.dauTuan("2026-10-11"), "2026-10-05"); // Chủ nhật vẫn thuộc tuần đó
    assert.equal(ev.dauTuan("2026-10-05"), "2026-10-05");
    assert.equal(ev.congNgay("2026-10-31", 1), "2026-11-01");
    assert.equal(ev.congNgay("2026-12-31", 1), "2027-01-01");
    assert.equal(ev.dauTuan("hỏng"), null);
    assert.equal(ev.congNgay("2026-13-40", 1), null);
  });

  it("gom đúng ngày địa phương, sự kiện sát nửa đêm không lệch ngày, cũ trước mới sau", () => {
    const ins = database.db.prepare("INSERT INTO app_events (created_at, loai, muc, tieu_de) VALUES (?, 'heThong', 'thongTin', ?)");
    ins.run("2026-10-12T16:59:00.000Z", "Cuối ngày 12"); // 23:59 giờ VN ngày 12/10: tuần kế (thứ Hai 12)
    ins.run("2026-10-12T17:01:00.000Z", "Đầu ngày 13"); // 00:01 giờ VN ngày 13/10
    ins.run("2026-10-12T05:00:00.000Z", "Sáng ngày 12");
    const t = ev.suKienTheoTuan("2026-10-14", TZ)!;
    assert.equal(t.tu, "2026-10-12");
    assert.equal(t.den, "2026-10-18");
    assert.equal(t.cacNgay.length, 7);
    const ten = (n: string) => t.cacNgay.find((x) => x.ngay === n)!.suKien.map((s) => s.tieuDe);
    assert.deepEqual(ten("2026-10-12"), ["Sáng ngày 12", "Cuối ngày 12"]);
    assert.deepEqual(ten("2026-10-13"), ["Đầu ngày 13"]);
    assert.equal(ev.suKienTheoTuan("sai", TZ), null);
  });
});

describe("mẫu VPS", () => {
  it("một phút một mẫu và gộp theo khoảng", () => {
    const now = Date.UTC(2026, 9, 7, 5, 0, 30);
    const chiSo = { uptimeGiay: 1, soNhan: 2, tai: [0.5, 0, 0] as [number, number, number], ramTongMb: 1000, ramConMb: 400, swapTongMb: 0, swapDungMb: 0, diaTongGb: 100, diaDungGb: 50, botMb: 1 };
    for (let i = 0; i < 30; i++) {
      const m = mau.mauTuChiSo(chiSo, 10, now - i * 60_000);
      mau.ghiMau(m);
      mau.ghiMau(m); // ghi trùng cùng phút không nhân đôi
    }
    const m0 = mau.mauTuChiSo(chiSo, null, now);
    assert.equal(m0.ram, 60);
    assert.equal(m0.swap, 0); // swap tổng 0 không chia cho 0
    const ds = mau.lichSu(1, now);
    assert.ok(ds.length >= 1 && ds.length <= 60);
    assert.equal(Math.round(ds[0]!.ram), 60);
  });

  it("tỉ lệ hoạt động: phút trống làm giảm, trước mẫu đầu không bị phạt", () => {
    const now = Date.UTC(2026, 9, 7, 5, 0, 30);
    const r = mau.tiLeHoatDong(7, now)!;
    assert.ok(r > 0 && r <= 100);
    assert.equal(mau.tiLeHoatDong(7, Date.UTC(2020, 0, 1)), null);
  });
});

describe("báo cáo", () => {
  it("đếm tin theo ngày VN, theo tài khoản, và cảnh báo", () => {
    const ins = database.db.prepare("INSERT INTO messages (account_id, thread_id, role, content, created_at) VALUES (?, 't', ?, 'x', ?)");
    ins.run("a1", "user", "2026-10-06T17:10:00.000Z"); // 00:10 ngày 7 VN
    ins.run("a1", "assistant", "2026-10-07T01:00:00.000Z");
    ins.run("a2", "user", "2026-10-06T10:00:00.000Z"); // ngày 6 VN
    database.db.prepare("INSERT INTO contacts (account_id, user_id, first_seen) VALUES ('a1','u1','2026-10-07T02:00:00.000Z')").run();
    const b = rp.tinhBaoCao(3, new Date("2026-10-07T04:00:00.000Z"), TZ);
    const d7 = b.theoNgay.find((x) => x.ngay === "2026-10-07")!;
    const d6 = b.theoNgay.find((x) => x.ngay === "2026-10-06")!;
    assert.equal(d7.tinKhach, 1);
    assert.equal(d7.tinBot, 1);
    assert.equal(d7.lienHeMoi, 1);
    assert.equal(d6.tinKhach, 1);
    assert.equal(b.theoNgay.length, 3);
    assert.equal(b.tong.tinKhach, 2);
    assert.equal(b.theoTaiKhoan[0]!.accountId, "a1");
    assert.ok(b.tong.canhBao >= 1); // sự kiện "RAM thấp" ở ngày 7
  });
});
