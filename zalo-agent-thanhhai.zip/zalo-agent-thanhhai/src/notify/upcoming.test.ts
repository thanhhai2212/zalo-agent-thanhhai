import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import type { Hono } from "hono";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let up: typeof import("./upcoming.js");
let database: typeof import("../conversation/database.js");
let app: Hono;
let cookie: string;
const PASSWORD = "mat-khau-upcoming-123";
const TZ = "Asia/Ho_Chi_Minh";

before(async () => {
  dataDir = setupTestEnv({ DASHBOARD_PASSWORD: PASSWORD, BOT_TIMEZONE: TZ });
  database = await import("../conversation/database.js");
  up = await import("./upcoming.js");
  const { buildDashboardApp } = await import("../server/dashboard-server.js");
  app = buildDashboardApp();
  const login = await app.request("/api/auth/login", { method: "POST", body: JSON.stringify({ password: PASSWORD }), headers: { "content-type": "application/json" } });
  cookie = login.headers.get("set-cookie")!.split(";")[0]!;
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("kỳ báo cáo kế tiếp", () => {
  it("chọn khung gần nhất sau bây giờ, qua ngày hôm sau nếu đã quá hết", () => {
    // 09:00 giờ VN: khung 8 đã qua, khung 20 là kế tiếp
    assert.equal(up.kyBaoCaoTiepTheo([8, 20], new Date("2026-10-07T02:00:00Z"), TZ), "2026-10-07T13:00:00.000Z");
    // 22:00 giờ VN: cả hai khung hôm nay đã qua, lấy 8 giờ sáng mai
    assert.equal(up.kyBaoCaoTiepTheo([8, 20], new Date("2026-10-07T15:00:00Z"), TZ), "2026-10-08T01:00:00.000Z");
  });
  it("khung -1 là tắt, cả hai tắt thì null", () => {
    assert.equal(up.kyBaoCaoTiepTheo([-1, 20], new Date("2026-10-07T02:00:00Z"), TZ), "2026-10-07T13:00:00.000Z");
    assert.equal(up.kyBaoCaoTiepTheo([-1, -1], new Date("2026-10-07T02:00:00Z"), TZ), null);
  });
});

describe("việc sắp tới", () => {
  it("gộp lịch hẹn đang bật + bài nhóm chờ đăng, bỏ lịch đã tắt và bài đã bỏ qua, sắp theo giờ", () => {
    const ins = database.db.prepare(
      "INSERT INTO scheduled_jobs (id, account_id, thread_id, thread_type, name, kind, payload, schedule_kind, enabled, next_run_at) VALUES (?, 'a1', 't1', 0, ?, 'message', 'x', 'once', ?, ?)",
    );
    ins.run("j1", "Nhắc họp", 1, "2099-01-01T10:00:00.000Z");
    ins.run("j2", "Đã tắt", 0, "2099-01-01T09:00:00.000Z");
    const post = database.db.prepare(
      "INSERT INTO post_drafts (id, account_id, thread_id, topic_key, topic_title, source, source_note, body, discuss, infographic, has_image, similarity, status, scheduled_at) VALUES (?, 'a1', 'g1', 'k', ?, 's', '', 'b', '', '', 0, 0, ?, ?)",
    );
    post.run("p1", "Mẹo AI", "da_duyet", "2099-01-01T08:00:00.000Z");
    post.run("p2", "Bị bỏ", "bo_qua", "2099-01-01T07:00:00.000Z");
    const ds = up.viecSapToi(new Date("2098-12-31T00:00:00Z"));
    const ten = ds.map((v) => v.tieuDe);
    assert.ok(ten.includes("Nhắc họp") && ten.includes("Mẹo AI"));
    assert.ok(!ten.includes("Đã tắt") && !ten.includes("Bị bỏ"));
    assert.ok(ten.indexOf("Mẹo AI") < ten.indexOf("Nhắc họp"));
    assert.equal(ds.find((v) => v.tieuDe === "Mẹo AI")!.trangThai, "Đã duyệt");
  });

  it("API cần đăng nhập và trả đúng hình dạng", async () => {
    assert.equal((await app.request("/api/mobile/upcoming")).status, 401);
    const r = await app.request("/api/mobile/upcoming", { headers: { cookie } });
    assert.equal(r.status, 200);
    const j = (await r.json()) as { viec: unknown[]; videoDangLam: number };
    assert.ok(Array.isArray(j.viec));
    assert.equal(typeof j.videoDangLam, "number");
  });

  it("gửi báo cáo ngay: không có tài khoản chủ để gửi thì báo lỗi 502, không im lặng", async () => {
    const r = await app.request("/api/mobile/report-now", { method: "POST", headers: { cookie } });
    assert.equal(r.status, 502);
    assert.equal(((await r.json()) as { ok: boolean }).ok, false);
  });
});
