import { createLogger } from "../shared/logger.js";
import { quyetDinhKenh, type LoaiThongBao } from "./notify-settings.js";
import { guiPushChoTatCa } from "./push-sender.js";

const log = createLogger("notify-owner");

/** Bỏ thẻ màu của bot ([do]...[/do]) và dấu đậm markdown: thông báo đẩy là chữ trơn. */
export function markdownThanhChuTro(md: string): string {
  return md
    .replace(/\[\/?(?:xanh|vang|do|cam|green|yellow|red|orange|u)\]/gi, "")
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/[ \t]+/g, " ")
    .trim();
}

/**
 * Đẩy một thông báo lên điện thoại nếu luật cho phép (loại bật, kênh đẩy bật, không trong
 * giờ yên tĩnh trừ sự cố quan trọng). Trả `true` nếu đã gửi tới ít nhất một thiết bị.
 * Chạy ĐỘC LẬP với việc gửi Zalo: Zalo đứt hay VPS không có nick nào chạy thì tin đẩy vẫn đi.
 */
export async function daySangDienThoai(loai: LoaiThongBao, tieuDe: string, noiDung: string, url = "/m"): Promise<boolean> {
  try {
    if (!quyetDinhKenh(loai).push) return false;
    const kq = await guiPushChoTatCa({ tieuDe, noiDung: markdownThanhChuTro(noiDung), url, tag: loai });
    return kq.gui > 0;
  } catch (err) {
    log.warn({ err }, "Đẩy thông báo lên điện thoại lỗi");
    return false;
  }
}
