import { createCanvas, loadImage } from "@napi-rs/canvas";

/**
 * Tách nền phẳng (thường trắng) thành trong suốt cho ảnh xin "nền trong suốt"
 * mà model không làm được. Ca thật 2026-10-01: model dự phòng
 * `ag/gemini-3.1-flash-image` nhận `background: "transparent"` nhưng trả JPEG nền
 * trắng - nhân vật người que/chibi/VOX dán lên nền giấy sẽ thành khung trắng.
 *
 * Cách làm: loang (flood fill) từ MỌI điểm ở viền ảnh, chỉ qua các điểm gần màu
 * nền (lấy màu trung vị của viền), nên phần trắng BÊN TRONG nhân vật (mặt, áo)
 * không bị khoét vì không nối ra viền. Rìa được làm mềm một chút.
 */

const NGUONG = 38; // khoảng cách màu tối đa để coi là nền
const MEM = 22; // dải làm mềm rìa phía trên ngưỡng

/** PNG có kênh trong suốt (color type 4 hoặc 6 ở IHDR) */
export function coKenhTrongSuot(buf: Buffer): boolean {
  return buf.length > 26 && buf.readUInt32BE(0) === 0x89504e47 && (buf[25] === 6 || buf[25] === 4);
}

export async function tachNenPhang(anh: Buffer): Promise<Buffer> {
  const img = await loadImage(anh);
  const w = img.width;
  const h = img.height;
  const cv = createCanvas(w, h);
  const ctx = cv.getContext("2d");
  ctx.drawImage(img, 0, 0);
  const data = ctx.getImageData(0, 0, w, h);
  const px = data.data;

  // Màu nền = trung vị từng kênh của các điểm viền.
  const vien: number[][] = [[], [], []];
  const lay = (x: number, y: number) => {
    const i = (y * w + x) * 4;
    for (let k = 0; k < 3; k++) vien[k]!.push(px[i + k]!);
  };
  for (let x = 0; x < w; x++) (lay(x, 0), lay(x, h - 1));
  for (let y = 0; y < h; y++) (lay(0, y), lay(w - 1, y));
  const nen = vien.map((c) => c.sort((a, b) => a - b)[c.length >> 1]!);

  const cach = (i: number) => Math.max(Math.abs(px[i]! - nen[0]!), Math.abs(px[i + 1]! - nen[1]!), Math.abs(px[i + 2]! - nen[2]!));
  const daXet = new Uint8Array(w * h);
  const hang: number[] = [];
  const day = (x: number, y: number) => {
    const p = y * w + x;
    if (daXet[p]) return;
    daXet[p] = 1;
    if (cach(p * 4) <= NGUONG + MEM) hang.push(p);
  };
  for (let x = 0; x < w; x++) (day(x, 0), day(x, h - 1));
  for (let y = 0; y < h; y++) (day(0, y), day(w - 1, y));
  while (hang.length) {
    const p = hang.pop()!;
    const i = p * 4;
    const d = cach(i);
    // Trong ngưỡng: trong suốt hẳn và loang tiếp; dải mềm: mờ dần, không loang qua.
    px[i + 3] = d <= NGUONG ? 0 : Math.round((255 * (d - NGUONG)) / MEM);
    if (d > NGUONG) continue;
    const x = p % w;
    const y = (p / w) | 0;
    if (x > 0) day(x - 1, y);
    if (x < w - 1) day(x + 1, y);
    if (y > 0) day(x, y - 1);
    if (y < h - 1) day(x, y + 1);
  }
  ctx.putImageData(data, 0, 0);
  return cv.toBuffer("image/png");
}
