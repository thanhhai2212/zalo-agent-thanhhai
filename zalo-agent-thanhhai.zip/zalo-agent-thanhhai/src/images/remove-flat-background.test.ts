import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { createCanvas, loadImage } from "@napi-rs/canvas";
import { coKenhTrongSuot, tachNenPhang } from "./remove-flat-background.js";

describe("tách nền phẳng", () => {
  it("nền trắng thành trong suốt, phần trắng nằm TRONG nét viền vẫn giữ", async () => {
    const cv = createCanvas(100, 100);
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, 100, 100);
    ctx.strokeStyle = "#000";
    ctx.lineWidth = 6;
    ctx.strokeRect(30, 30, 40, 40); // ô vuông viền đen, ruột trắng
    const jpg = cv.toBuffer("image/jpeg");
    assert.equal(coKenhTrongSuot(jpg), false);
    const png = await tachNenPhang(jpg);
    assert.equal(coKenhTrongSuot(png), true);
    const img = await loadImage(png);
    const c2 = createCanvas(100, 100);
    c2.getContext("2d").drawImage(img, 0, 0);
    const a = (x: number, y: number) => c2.getContext("2d").getImageData(x, y, 1, 1).data[3];
    assert.equal(a(5, 5), 0, "góc nền trong suốt");
    assert.equal(a(50, 50), 255, "ruột trắng trong viền giữ nguyên");
    assert.equal(a(30, 50), 255, "nét viền giữ nguyên");
  });
});
