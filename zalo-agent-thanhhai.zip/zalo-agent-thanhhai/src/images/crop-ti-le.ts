/**
 * Cắt ảnh về ĐÚNG tỉ lệ khung hình (cắt giữa). Model vẽ ảnh bỏ qua tham số kích thước (đo thật:
 * xin 1024x1024 nhận 1536x1024), nên tỉ lệ chỉ ghi vào prompt thì không bảo đảm; bài đăng cần
 * khung chuẩn (vuông Facebook, dọc 4:5, 9:16 TikTok) nên code cắt lại sau khi vẽ.
 */

export const TI_LE_ANH = {
  "1:1": { w: 1, h: 1, mo_ta: "vuông, hợp bài Facebook/Instagram" },
  "4:5": { w: 4, h: 5, mo_ta: "dọc nhẹ, hợp bài Facebook/Instagram chiếm nhiều màn hình" },
  "9:16": { w: 9, h: 16, mo_ta: "dọc, hợp TikTok/Reels/Story" },
  "16:9": { w: 16, h: 9, mo_ta: "ngang, hợp ảnh bìa/YouTube" },
} as const;
export type TiLeAnh = keyof typeof TI_LE_ANH;

/** Vùng cắt giữa lớn nhất của ảnh w x h có tỉ lệ rw:rh (làm tròn xuống số nguyên). */
export function tinhVungCat(w: number, h: number, rw: number, rh: number): { x: number; y: number; w: number; h: number } {
  const muc = rw / rh;
  let cw = w;
  let ch = Math.round(w / muc);
  if (ch > h) {
    ch = h;
    cw = Math.round(h * muc);
  }
  return { x: Math.floor((w - cw) / 2), y: Math.floor((h - ch) / 2), w: cw, h: ch };
}

export type AnhDaCat = { data: Buffer; ext: "jpg"; daCat: boolean };

/** Cắt về tỉ lệ; ảnh đã đúng tỉ lệ (sai số 1%) thì trả nguyên. Lỗi giải mã thì ném cho caller quyết. */
export async function canTiLe(data: Buffer, tiLe: TiLeAnh): Promise<AnhDaCat | { data: Buffer; daCat: false; ext: null }> {
  const { createCanvas, loadImage } = await import("@napi-rs/canvas");
  const img = await loadImage(data);
  const { w: rw, h: rh } = TI_LE_ANH[tiLe];
  const vung = tinhVungCat(img.width, img.height, rw, rh);
  const daDung = Math.abs(img.width / img.height - rw / rh) / (rw / rh) < 0.01;
  if (daDung) return { data, daCat: false, ext: null };
  const canvas = createCanvas(vung.w, vung.h);
  canvas.getContext("2d").drawImage(img, vung.x, vung.y, vung.w, vung.h, 0, 0, vung.w, vung.h);
  return { data: canvas.toBuffer("image/jpeg", 92), ext: "jpg", daCat: true };
}
