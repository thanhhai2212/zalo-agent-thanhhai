import { AlignmentType, Document, LevelFormat, Packer, Paragraph, TextRun } from "docx";
import { parseTextRuns } from "../documents/docx-text-runs.js";
import { DOCX_STYLES, PAGE_MARGINS } from "../documents/render-docx-styles.js";

/**
 * Dựng file Word cho MỘT email công việc (bản nháp để người dùng chép đi gửi).
 * Bố cục cố định: dòng "Tiêu đề", lời chào, câu mở, thân bài (đoạn hoặc gạch
 * đầu dòng), lời đề nghị, chữ ký. Model chỉ đưa chữ, không quyết được phông/lề.
 */

export type EmailDacTa = {
  tieu_de: string;
  loi_chao: string;
  mo_dau: string;
  /** Mỗi phần tử là một đoạn; dòng bắt đầu bằng "- " thành gạch đầu dòng. */
  than_bai: string[];
  de_nghi?: string;
  /** Mỗi phần tử một dòng: "Trân trọng,", rồi họ tên, chức danh, đơn vị. */
  chu_ky: string[];
};

const BULLET = "email-bullet";

/** Mọi ô còn nằm trong ngoặc vuông - chỗ model để trống vì chưa có thông tin. */
export function choConTrong(d: EmailDacTa): string[] {
  const het = [d.tieu_de, d.loi_chao, d.mo_dau, ...d.than_bai, d.de_nghi ?? "", ...d.chu_ky].join("\n");
  const ra = new Set<string>();
  for (const m of het.matchAll(/\[[^\]\n]{1,80}\]/g)) ra.add(m[0]);
  return [...ra];
}

function doan(text: string): Paragraph[] {
  return text
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => new Paragraph({ children: parseTextRuns(l), alignment: AlignmentType.LEFT }));
}

export async function renderEmailDocx(d: EmailDacTa): Promise<Buffer> {
  const children: Paragraph[] = [
    new Paragraph({
      children: [new TextRun({ text: "Tiêu đề: ", bold: true }), ...parseTextRuns(d.tieu_de.trim(), { bold: true })],
      spacing: { after: 240 },
    }),
    ...doan(d.loi_chao),
    ...doan(d.mo_dau),
  ];
  for (const muc of d.than_bai) {
    for (const dong of muc.split("\n").map((l) => l.trim()).filter(Boolean)) {
      if (/^[-•]\s+/.test(dong)) {
        children.push(
          new Paragraph({
            children: parseTextRuns(dong.replace(/^[-•]\s+/, "")),
            numbering: { reference: BULLET, level: 0 },
            spacing: { after: 60 },
          }),
        );
      } else {
        children.push(...doan(dong));
      }
    }
  }
  if (d.de_nghi?.trim()) children.push(...doan(d.de_nghi));
  d.chu_ky.forEach((dong, i) => {
    const t = dong.trim();
    if (!t) return;
    children.push(new Paragraph({ children: parseTextRuns(t), spacing: { before: i === 0 ? 240 : 0, after: 0 } }));
  });

  const doc = new Document({
    styles: DOCX_STYLES,
    numbering: {
      config: [
        {
          reference: BULLET,
          levels: [
            {
              level: 0,
              format: LevelFormat.BULLET,
              text: "•",
              alignment: AlignmentType.LEFT,
              style: { paragraph: { indent: { left: 720, hanging: 360 } } },
            },
          ],
        },
      ],
    },
    sections: [{ properties: { page: { margin: PAGE_MARGINS } }, children }],
  });
  return Packer.toBuffer(doc);
}
