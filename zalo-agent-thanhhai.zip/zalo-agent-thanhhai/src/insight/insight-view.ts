import type { PhanKhuc } from "./insight-group-config.js";
import { CHU_DE_KHAC, LOAI_Y, laLoaiY, type CoHoi, type DuLieuInsight, type LoaiY, type YDaLuu } from "./insight-types.js";

/**
 * Lọc + tổng hợp dữ liệu insight cho MỘT lát cắt (bộ lọc). Dùng chung cho
 * dashboard lẫn mọi định dạng xuất file - một chỗ tính nên số trên màn hình
 * và số trong file luôn khớp nhau. Thuần, không chạm DB/đĩa.
 */

export type BoLoc = { pk?: PhanKhuc; loai?: LoaiY; nhom?: string; chuDe?: string; tu?: string; den?: string; q?: string };

const NGAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const TRAN_Y_TRA_VE = 500;

/** Chuẩn hóa query string - giá trị lạ bị bỏ (coi như không lọc), không ném. */
export function docBoLoc(q: Record<string, string | undefined>): BoLoc {
  const f: BoLoc = {};
  if (q.pk === "cong_dong" || q.pk === "doanh_nghiep") f.pk = q.pk;
  if (laLoaiY(q.loai)) f.loai = q.loai;
  if (q.nhom?.trim()) f.nhom = q.nhom.trim().slice(0, 200);
  if (q.chuDe?.trim()) f.chuDe = q.chuDe.trim().slice(0, 200);
  if (q.tu && NGAY_RE.test(q.tu)) f.tu = q.tu;
  if (q.den && NGAY_RE.test(q.den)) f.den = q.den;
  if (q.q?.trim()) f.q = q.q.trim().toLowerCase().slice(0, 100);
  return f;
}

export function locY(ys: YDaLuu[], f: BoLoc): YDaLuu[] {
  return ys.filter(
    (y) =>
      (!f.pk || y.pk === f.pk) &&
      (!f.loai || y.loai === f.loai) &&
      (!f.nhom || y.nhom === f.nhom) &&
      (!f.chuDe || y.chuDeGop === f.chuDe) &&
      (!f.tu || y.ngay >= f.tu) &&
      (!f.den || y.ngay <= f.den) &&
      (!f.q || `${y.chuDeGop} ${y.chuDe} ${y.moTa} ${y.trich}`.toLowerCase().includes(f.q)),
  );
}

export type ChuDeView = {
  ten: string; pk: PhanKhuc; loai: LoaiY; moTa: string;
  soY: number; soNguoi: number; soNhom: number; trich: string[];
};
export type NhomView = { ten: string; pk: PhanKhuc; soTin: number; tong: number; theoLoai: Record<LoaiY, number> };

export type ViewInsight = {
  taoLuc: string;
  phamVi: { tuNgay: string; denNgay: string };
  tuyChonNhom: { ten: string; pk: PhanKhuc }[];
  kpi: { soTin: number; soNhom: number; soY: number; soNguoi: number; theoLoai: Record<LoaiY, number> };
  theoThoiGian: { donVi: "ngay" | "tuan"; diem: { moc: string; so: number }[] };
  chuDe: ChuDeView[];
  nhom: NhomView[];
  faq: { pk: PhanKhuc; cauHoi: string }[];
  coHoi: CoHoi[];
  tomTat: { pk: PhanKhuc; y: string[] }[];
  y: YDaLuu[];
  tongY: number;
};

const demRong = (): Record<LoaiY, number> => Object.fromEntries(LOAI_Y.map((l) => [l, 0])) as Record<LoaiY, number>;
const DAY_MS = 86_400_000;
const ngayCong = (d: string, n: number) => new Date(Date.parse(`${d}T00:00:00Z`) + n * DAY_MS).toISOString().slice(0, 10);
/** Thứ Hai của tuần chứa ngày `d` (UTC). */
const dauTuan = (d: string) => ngayCong(d, -((new Date(`${d}T00:00:00Z`).getUTCDay() + 6) % 7));

function chuoiThoiGian(ys: YDaLuu[]): ViewInsight["theoThoiGian"] {
  if (ys.length === 0) return { donVi: "ngay", diem: [] };
  const ngays = ys.map((y) => y.ngay).sort();
  const dau = ngays[0]!;
  const cuoi = ngays[ngays.length - 1]!;
  const donVi = (Date.parse(cuoi) - Date.parse(dau)) / DAY_MS > 60 ? "tuan" : "ngay";
  const moc = (d: string) => (donVi === "tuan" ? dauTuan(d) : d);
  const dem = new Map<string, number>();
  for (const y of ys) dem.set(moc(y.ngay), (dem.get(moc(y.ngay)) ?? 0) + 1);
  const diem: { moc: string; so: number }[] = [];
  // Lấp mốc trống bằng 0 để đường xu hướng không nối tắt qua khoảng im lặng.
  for (let d = moc(dau); d <= moc(cuoi); d = ngayCong(d, donVi === "tuan" ? 7 : 1)) {
    diem.push({ moc: d, so: dem.get(d) ?? 0 });
  }
  return { donVi, diem };
}

export function tinhView(d: DuLieuInsight, f: BoLoc): ViewInsight {
  const ys = locY(d.y, f);
  const theoLoai = demRong();
  for (const y of ys) theoLoai[y.loai]++;

  // Gom theo TÊN, không theo (tệp, tên): hai tệp được gộp riêng nên hay ra
  // cùng một tên chủ đề - để tách thì "Top 10" hiện một chủ đề hai lần.
  const chuDe = new Map<string, { y: YDaLuu[] }>();
  for (const y of ys) (chuDe.get(y.chuDeGop) ?? chuDe.set(y.chuDeGop, { y: [] }).get(y.chuDeGop)!).y.push(y);
  const moTa = new Map(d.chuDe.map((c) => [`${c.pk}|${c.ten}`, c]));
  const chuDeView: ChuDeView[] = [...chuDe.entries()]
    .map(([ten, { y }]) => {
      const soDn = y.filter((x) => x.pk === "doanh_nghiep").length;
      const pk: PhanKhuc = soDn * 2 > y.length ? "doanh_nghiep" : "cong_dong";
      const goc = moTa.get(`${pk}|${ten}`) ?? moTa.get(`${pk === "cong_dong" ? "doanh_nghiep" : "cong_dong"}|${ten}`);
      return {
        ten,
        pk,
        loai: goc?.loai ?? y[0]!.loai,
        moTa: goc?.moTa ?? "",
        soY: y.length,
        soNguoi: new Set(y.map((x) => x.tv).filter(Boolean)).size,
        soNhom: new Set(y.map((x) => x.nhom)).size,
        trich: [...new Set(y.map((x) => x.trich).filter(Boolean))].slice(0, 3),
      };
    })
    .sort((a, b) => Number(a.ten === CHU_DE_KHAC) - Number(b.ten === CHU_DE_KHAC) || b.soY - a.soY);

  const nhomLoc = d.nhom.filter((n) => (!f.pk || n.pk === f.pk) && (!f.nhom || n.ten === f.nhom));
  const nhomView: NhomView[] = nhomLoc
    .map((n) => {
      const cua = ys.filter((y) => y.nhom === n.ten);
      const dem = demRong();
      for (const y of cua) dem[y.loai]++;
      return { ten: n.ten, pk: n.pk, soTin: n.soTin, tong: cua.length, theoLoai: dem };
    })
    .sort((a, b) => b.tong - a.tong);

  const ngays = d.y.map((y) => y.ngay).sort();
  const theoPk = <T extends { pk: PhanKhuc }>(ds: T[]) => ds.filter((x) => !f.pk || x.pk === f.pk);
  return {
    taoLuc: d.taoLuc,
    phamVi: { tuNgay: ngays[0] ?? "", denNgay: ngays[ngays.length - 1] ?? "" },
    tuyChonNhom: d.nhom.map((n) => ({ ten: n.ten, pk: n.pk })),
    kpi: {
      soTin: nhomLoc.reduce((s, n) => s + n.soTin, 0),
      soNhom: new Set(ys.map((y) => y.nhom)).size,
      soY: ys.length,
      soNguoi: new Set(ys.map((y) => y.tv).filter(Boolean)).size,
      theoLoai,
    },
    theoThoiGian: chuoiThoiGian(ys),
    chuDe: chuDeView,
    nhom: nhomView,
    faq: theoPk(d.faq),
    coHoi: theoPk(d.coHoi),
    tomTat: theoPk(d.tomTat),
    y: [...ys].sort((a, b) => b.ngay.localeCompare(a.ngay)).slice(0, TRAN_Y_TRA_VE),
    tongY: ys.length,
  };
}
