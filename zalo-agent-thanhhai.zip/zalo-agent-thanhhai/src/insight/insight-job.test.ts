import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let job: typeof import("./insight-job.js");
let cfg: typeof import("./insight-group-config.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  database = await import("../conversation/database.js");
  job = await import("./insight-job.js");
  cfg = await import("./insight-group-config.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

function themNhom(account: string, threadId: string, ten: string, tin: [string, string, string][]) {
  database.db
    .prepare("INSERT OR IGNORE INTO threads (account_id, thread_id, thread_type, display_name) VALUES (?, ?, 1, ?)")
    .run(account, threadId, ten);
  const ins = database.db.prepare(
    "INSERT INTO messages (account_id, thread_id, role, sender_id, sender_name, content, created_at) VALUES (?, ?, 'user', ?, ?, ?, ?)",
  );
  for (const [sid, sn, c] of tin) ins.run(account, threadId, sid, sn, `${sn}: ${c}`, "2026-09-20T10:00:00.000Z");
}

beforeEach(() => {
  database.db.exec("DELETE FROM messages; DELETE FROM threads; DELETE FROM runtime_settings WHERE key = 'insight_group_config'");
});

const Y_MAU = JSON.stringify([
  { loai: "noi_dau", chu_de: "cài VPS", mo_ta: "khó cài, gọi Trần Thị Mai", trich: "mãi không được", tv: "TV001", ngay: "2026-09-20" },
  { loai: "khong_hop_le", chu_de: "x", mo_ta: "", trich: "", tv: "", ngay: "" },
  { loai: "cau_hoi", chu_de: "giá gói", mo_ta: "hỏi giá", trich: "bao nhiêu tiền", tv: "sai-ma", ngay: "hôm qua" },
]);
const GOP_MAU = JSON.stringify({
  chu_de: [{ ten: "Cài đặt khó", mo_ta: "m", nhan: [1] }],
  faq: ["Giá bao nhiêu?"],
  co_hoi: [{ ten: "Gói cài sẵn", mo_ta: "m", dua_tren: "cài VPS" }],
  tom_tat: ["Điểm A"],
});

describe("chayInsight", () => {
  it("chỉ gửi tin ĐÃ ẩn danh, khử trùng nhóm 2 account cùng ghi, bỏ nhóm bị bỏ tích, lưu dữ liệu có cấu trúc", async () => {
    const tin: [string, string, string][] = [["u1", "Trần Thị Mai", "cài VPS mãi không được, số em 0912345678"]];
    themNhom("acc-a", "g1", "Nhóm học viên", tin);
    themNhom("acc-b", "g1", "Nhóm học viên", tin);
    themNhom("acc-a", "g2", "Nhóm gia đình", [["u2", "Bố", "tối nay về ăn cơm nhé cả nhà ơi"]]);
    themNhom("acc-a", "g3", "Khách Cty X", [["u3", "Lê Văn Hùng", "bot trả lời sai bảng giá sản phẩm"]]);
    cfg.datCauHinhNhom("g2", { boQua: true });
    cfg.datCauHinhNhom("g3", { phanKhuc: "doanh_nghiep" });

    const prompts: string[] = [];
    const d = await job.chayInsight(async (p) => {
      prompts.push(p);
      return p.includes("TIN NHẮN:") ? Y_MAU : GOP_MAU;
    });

    const tatCa = prompts.join("\n");
    assert.ok(!tatCa.includes("Trần Thị Mai") && !tatCa.includes("0912345678"), "tên và SĐT không được tới model");
    assert.ok(!tatCa.includes("ăn cơm"), "nhóm bỏ tích không được gửi");
    const mapHocVien = prompts.filter((p) => p.includes("TIN NHẮN:") && p.includes("Nhóm học viên"));
    assert.equal(mapHocVien[0]!.match(/cài VPS mãi/g)?.length, 1, "tin trùng do 2 account ghi chỉ gửi 1 lần");

    assert.equal(d.nhom.length, 2);
    assert.equal(d.y.length, 4, "2 nhóm x 2 ý hợp lệ; loại lạ bị bỏ");
    const y0 = d.y.find((y) => y.nhom === "Nhóm học viên" && y.loai === "noi_dau")!;
    assert.ok(!y0.moTa.includes("Trần Thị Mai"), "tên model lỡ chép lại vẫn bị xóa");
    assert.equal(y0.chuDeGop, "Cài đặt khó");
    const yCauHoi = d.y.find((y) => y.loai === "cau_hoi")!;
    assert.equal(yCauHoi.tv, "", "mã TV sai dạng bị bỏ");
    assert.equal(yCauHoi.ngay, "2026-09-20", "ngày sai dạng rơi về ngày của đoạn");
    assert.deepEqual(new Set(d.faq.map((q) => q.pk)), new Set(["cong_dong", "doanh_nghiep"]));
    assert.equal(job.docDuLieuInsight()?.taoLuc, d.taoLuc);
    assert.equal(job.trangThaiInsight().taoLuc, d.taoLuc);
  });

  it("không còn nhóm nào được chọn thì ném lỗi rõ ràng", async () => {
    themNhom("acc-a", "g1", "Nhóm", [["u1", "An", "một câu đủ dài để không bị lọc"]]);
    cfg.datCauHinhNhom("g1", { boQua: true });
    await assert.rejects(job.chayInsight(async () => "[]"), /Chưa chọn nhóm/);
  });
});

describe("batDauInsight", () => {
  it("chỉ cho một lượt chạy cùng lúc", async () => {
    themNhom("acc-a", "g1", "Nhóm", [["u1", "An", "một câu đủ dài để không bị lọc"]]);
    let tha!: () => void;
    const cho = new Promise<void>((r) => (tha = r));
    assert.equal(
      job.batDauInsight(async () => {
        await cho;
        return "[]";
      }),
      true,
    );
    assert.equal(job.batDauInsight(async () => "[]"), false);
    tha();
    const { doiChoDenKhi } = await import("../shared/doi-cho-den-khi.js");
    await doiChoDenKhi(() => !job.trangThaiInsight().dangChay, { moTa: "lượt insight kết thúc" });
  });
});

describe("dungInsight", () => {
  it("dừng giữa chừng: báo đã dừng, KHÔNG ghi đè dữ liệu dashboard cũ, gọi model ít lần", async () => {
    themNhom("acc-a", "g1", "Nhóm", [["u1", "An", "một câu đủ dài để không bị lọc"]]);
    themNhom("acc-a", "g2", "Nhóm 2", [["u2", "Bình", "một câu khác cũng đủ dài nhé"]]);
    const cu = job.docDuLieuInsight()?.taoLuc;
    let soLanGoi = 0;
    let tha!: () => void;
    const cho = new Promise<void>((r) => (tha = r));
    job.batDauInsight(async (_p, _m, signal) => {
      soLanGoi++;
      await cho;
      if (signal?.aborted) throw new Error("aborted");
      return "[]";
    });
    const { doiChoDenKhi } = await import("../shared/doi-cho-den-khi.js");
    await doiChoDenKhi(() => soLanGoi >= 1, { moTa: "lần gọi model đầu tiên" });
    // Vắng người chat nên có thể 2 đoạn đang bay cùng lúc - chốt số đang bay lúc bấm dừng.
    const dangBayKhiDung = soLanGoi;
    assert.equal(job.dungInsight(), true);
    tha();
    await doiChoDenKhi(() => !job.trangThaiInsight().dangChay, { moTa: "lượt insight dừng hẳn" });
    const tt = job.trangThaiInsight();
    assert.equal(tt.daDung, true);
    assert.equal(tt.loi, "");
    assert.equal(soLanGoi, dangBayKhiDung, "không gọi thêm đoạn nào sau khi dừng");
    assert.equal(job.docDuLieuInsight()?.taoLuc, cu, "dữ liệu dashboard cũ giữ nguyên");
    assert.equal(job.dungInsight(), false, "không có gì đang chạy thì trả false");
  });
});

describe("nhuongChoChat", () => {
  it("chờ tới khi hết hội thoại đang chạy; dừng thì thoát ngay", async () => {
    const { nhuongChoChat } = await import("./insight-llm.js");
    let dem = 1;
    setTimeout(() => (dem = 0), 50);
    const t = Date.now();
    await nhuongChoChat(undefined, () => dem);
    assert.ok(Date.now() - t >= 40);
    const dk = new AbortController();
    setTimeout(() => dk.abort(), 30);
    const t2 = Date.now();
    await nhuongChoChat(dk.signal, () => 1);
    assert.ok(Date.now() - t2 < 2000, "dừng thì không chờ đủ 90 giây");
  });
});

