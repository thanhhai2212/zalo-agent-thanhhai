import { dungKhoiVanBan, dungSheet, khoiSangMarkdown } from "./insight-export-content.js";
import type { DuLieuInsight } from "./insight-types.js";
import { locY, tinhView, type BoLoc } from "./insight-view.js";

/**
 * Xuất báo cáo insight theo bộ lọc đang chọn ra 4 định dạng. Dùng lại đúng các
 * renderer của tool tạo file (docx/exceljs/Chrome in PDF) - không dựng bộ
 * sinh file thứ hai. Import động: tránh kéo puppeteer/docx/exceljs vào lúc
 * dashboard khởi động khi chưa ai bấm xuất.
 */

export const DINH_DANG_XUAT = ["md", "pdf", "xlsx", "docx"] as const;
export type DinhDangXuat = (typeof DINH_DANG_XUAT)[number];

const MIME: Record<DinhDangXuat, string> = {
  md: "text/markdown; charset=utf-8",
  pdf: "application/pdf",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
};

const TIEU_DE = "Báo cáo Insight nhóm Zalo";

export async function xuatInsight(
  d: DuLieuInsight,
  f: BoLoc,
  dinhDang: DinhDangXuat,
): Promise<{ bytes: Buffer; mime: string; tenFile: string }> {
  const v = tinhView(d, f);
  const tenFile = `bao-cao-insight-${d.taoLuc.slice(0, 10)}.${dinhDang}`;
  const khoi = () => dungKhoiVanBan(v, f);
  let bytes: Buffer;
  if (dinhDang === "md") {
    bytes = Buffer.from(khoiSangMarkdown(TIEU_DE, khoi()), "utf8");
  } else if (dinhDang === "xlsx") {
    const { renderXlsx } = await import("../documents/render-xlsx.js");
    bytes = await renderXlsx(dungSheet(v, f, locY(d.y, f)));
  } else if (dinhDang === "docx") {
    const { renderDocx } = await import("../documents/render-docx.js");
    bytes = await renderDocx([{ type: "heading", level: 1, text: TIEU_DE }, ...khoi()], { title: TIEU_DE });
  } else {
    const { renderPdf } = await import("../documents/render-pdf.js");
    bytes = await renderPdf(khoi(), { title: TIEU_DE });
  }
  return { bytes, mime: MIME[dinhDang], tenFile };
}
