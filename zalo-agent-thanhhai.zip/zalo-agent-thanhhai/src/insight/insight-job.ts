import { randomBytes } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { dataDir } from "../config/env.js";
import { activeThreadCount } from "../middleware/message-batcher.js";
import { createLogger } from "../shared/logger.js";
import { taoBoAnDanh } from "./insight-anonymize.js";
import { danhSachNhomInsight, tenNguoiGuiCuaCacNhom, tinCuaCacNhom, type PhanKhuc } from "./insight-group-config.js";
import { goiLlmThat, LoiDaDung, type GoiLlm } from "./insight-llm.js";
import { dungDoan, rutYCacDoan } from "./insight-map.js";
import { gopChuDe } from "./insight-reduce.js";
import type { DuLieuInsight, YDaLuu } from "./insight-types.js";

/**
 * Báo cáo insight/nỗi đau từ tin nhắn nhóm - chạy NỀN, do chủ bot bấm nút trên
 * dashboard (mỗi lượt gửi nội dung nhóm, đã ẩn danh, cho nhà cung cấp model -
 * đó là quyết định của người vận hành, không tự chạy ngầm).
 *
 * CẬP NHẬT TĂNG DẦN: có dữ liệu cũ kèm `mocTin` thì chỉ rút ý từ tin MỚI sau
 * mốc của từng nhóm rồi gộp với ý cũ (vài phút thay vì hơn một tiếng). Đoạn
 * nào hỏng thì mốc nhóm đó dừng TRƯỚC đoạn hỏng và bỏ ý của các đoạn sau nó -
 * lượt sau làm lại từ đó, không mất tin cũng không nhân đôi ý. Bước gộp chủ
 * đề luôn chạy lại trên TOÀN BỘ ý (rẻ: chỉ 1 lời gọi mỗi tệp).
 */

const log = createLogger("insight-job");

export type { GoiLlm };
export type TrangThaiInsight = {
  dangChay: boolean;
  xong: number;
  tong: number;
  loi: string;
  daDung: boolean;
  taoLuc: string | null;
  /** Có dữ liệu cũ đủ điều kiện để lượt sau chỉ phân tích tin mới. */
  coTheCapNhat: boolean;
};

const state = { dangChay: false, xong: 0, tong: 0, loi: "", daDung: false };
let dieuKhien: AbortController | null = null;
const thuMuc = () => path.join(dataDir, "insight");
const fileDuLieu = () => path.join(thuMuc(), "du-lieu-moi-nhat.json");

export function docDuLieuInsight(): DuLieuInsight | null {
  try {
    return JSON.parse(fs.readFileSync(fileDuLieu(), "utf8")) as DuLieuInsight;
  } catch {
    return null;
  }
}

export function trangThaiInsight(): TrangThaiInsight {
  const d = docDuLieuInsight();
  return { ...state, taoLuc: d?.taoLuc ?? null, coTheCapNhat: !!d?.mocTin };
}

export type TuyChonChay = { toanBo?: boolean; demDangChat?: () => number };

/** Bắt đầu một lượt. `false` nếu đang có lượt khác chạy. */
export function batDauInsight(goiLlm: GoiLlm = goiLlmThat, tuyChon: TuyChonChay = {}): boolean {
  if (state.dangChay) return false;
  Object.assign(state, { dangChay: true, xong: 0, tong: 0, loi: "", daDung: false });
  const dk = new AbortController();
  dieuKhien = dk;
  void chayInsight(goiLlm, dk.signal, tuyChon)
    .catch((e: unknown) => {
      if (e instanceof LoiDaDung || dk.signal.aborted) {
        state.daDung = true;
        log.info({ xong: state.xong, tong: state.tong }, "Đã dừng báo cáo insight theo yêu cầu");
        return;
      }
      state.loi = e instanceof Error ? e.message : String(e);
      log.error({ err: e }, "Báo cáo insight thất bại");
    })
    .finally(() => {
      state.dangChay = false;
      dieuKhien = null;
    });
  return true;
}

/** Dừng lượt đang chạy. Dashboard hiện có GIỮ NGUYÊN - lượt dở dang không ghi gì. */
export function dungInsight(): boolean {
  if (!state.dangChay || !dieuKhien) return false;
  dieuKhien.abort();
  return true;
}

export async function chayInsight(goiLlm: GoiLlm, signal?: AbortSignal, tuyChon: TuyChonChay = {}): Promise<DuLieuInsight> {
  const nhom = danhSachNhomInsight().filter((n) => !n.boQua);
  if (nhom.length === 0) throw new Error("Chưa chọn nhóm nào để phân tích");
  const ids = nhom.map((n) => n.threadId);
  const theoId = new Map(nhom.map((n) => [n.threadId, n]));
  const cu = tuyChon.toanBo ? null : docDuLieuInsight();
  const tangDan = !!cu?.mocTin;
  const mocCu = tangDan ? cu!.mocTin! : {};
  const muoi = (tangDan && cu!.muoi) || randomBytes(16).toString("hex");
  const anDanh = taoBoAnDanh(tenNguoiGuiCuaCacNhom(ids), muoi);

  const tho = tinCuaCacNhom(ids).filter((t) => t.id > (mocCu[t.threadId] ?? 0));
  const { viec } = dungDoan(nhom, tho, anDanh);
  state.tong = viec.length + 2;

  const ketQua = await rutYCacDoan(viec, goiLlm, {
    signal,
    demDangChat: tuyChon.demDangChat ?? activeThreadCount,
    onXongMotDoan: () => state.xong++,
    anDanh,
  });

  // Dời mốc từng nhóm tới HẾT đoạn thành công liên tiếp đầu tiên; ý của các
  // đoạn sau một đoạn hỏng bị bỏ (lượt sau làm lại) để không nhân đôi.
  const mocMoi: Record<string, number> = Object.fromEntries(ids.filter((id) => mocCu[id]).map((id) => [id, mocCu[id]!]));
  const nhomDaHong = new Set<string>();
  const yMoi: YDaLuu[] = [];
  const daXuLy = new Map<string, number>();
  viec.forEach((v, k) => {
    if (nhomDaHong.has(v.threadId)) return;
    const r = ketQua[k];
    if (r === null || r === undefined) {
      nhomDaHong.add(v.threadId);
      return;
    }
    yMoi.push(...r);
    mocMoi[v.threadId] = Math.max(mocMoi[v.threadId] ?? 0, v.idCuoi);
    daXuLy.set(v.threadId, (daXuLy.get(v.threadId) ?? 0) + v.tin.length);
  });

  const nhomCu = new Map((cu?.nhom ?? []).filter((n) => n.threadId).map((n) => [n.threadId!, n.soTin]));
  const yCu = (tangDan ? cu!.y : [])
    .filter((y) => y.threadId && theoId.has(y.threadId))
    .map((y) => ({ ...y, nhom: theoId.get(y.threadId!)!.ten, pk: theoId.get(y.threadId!)!.phanKhuc }));
  const ys = [...yCu, ...yMoi];

  const duLieu: DuLieuInsight = {
    taoLuc: new Date().toISOString(),
    cheDo: tangDan ? "cap_nhat" : "toan_bo",
    thongKe: { soDoan: viec.length, soDoanHong: ketQua.filter((r) => r === null).length, soTinMoi: tho.length },
    nhom: nhom
      .map((n) => ({ threadId: n.threadId, ten: n.ten, pk: n.phanKhuc, soTin: (tangDan ? (nhomCu.get(n.threadId) ?? 0) : 0) + (daXuLy.get(n.threadId) ?? 0) }))
      .filter((n) => n.soTin > 0),
    mocTin: mocMoi,
    muoi,
    y: ys,
    chuDe: [],
    faq: [],
    coHoi: [],
    tomTat: [],
  };
  // Không có ý mới: dùng lại kết quả gộp cũ - khỏi tốn 2 lời gọi model.
  const dungLaiGop = tangDan && yMoi.length === 0;
  if (dungLaiGop) Object.assign(duLieu, { chuDe: cu!.chuDe, faq: cu!.faq, coHoi: cu!.coHoi, tomTat: cu!.tomTat });
  for (const pk of dungLaiGop ? [] : (["cong_dong", "doanh_nghiep"] as PhanKhuc[])) {
    if (signal?.aborted) throw new LoiDaDung();
    const cuaTep = ys.filter((y) => y.pk === pk);
    if (cuaTep.length) {
      const g = await gopChuDe(pk, cuaTep, (p, m) => goiLlm(p, m, signal));
      if (signal?.aborted) throw new LoiDaDung();
      duLieu.chuDe.push(...g.chuDe.map((c) => ({ ...c, moTa: anDanh.lamSach(c.moTa) })));
      duLieu.faq.push(...g.faq.map((cauHoi) => ({ pk, cauHoi: anDanh.lamSach(cauHoi) })));
      duLieu.coHoi.push(...g.coHoi.map((c) => ({ ...c, moTa: anDanh.lamSach(c.moTa), duaTren: anDanh.lamSach(c.duaTren) })));
      duLieu.tomTat.push({ pk, y: g.tomTat.map(anDanh.lamSach) });
    }
    state.xong++;
  }

  fs.mkdirSync(thuMuc(), { recursive: true });
  const json = JSON.stringify(duLieu);
  fs.writeFileSync(fileDuLieu(), json);
  fs.writeFileSync(path.join(thuMuc(), `du-lieu-${duLieu.taoLuc.slice(0, 10)}.json`), json);
  log.info({ cheDo: duLieu.cheDo, soTinMoi: tho.length, soYMoi: yMoi.length, soY: ys.length, soDoan: viec.length }, "Báo cáo insight xong");
  return duLieu;
}
