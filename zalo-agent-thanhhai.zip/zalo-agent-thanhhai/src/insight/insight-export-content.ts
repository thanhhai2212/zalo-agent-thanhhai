import type { DocumentBlock, Sheet, SpreadsheetCell } from "../documents/document-content-schema.js";
import type { BoLoc, ViewInsight } from "./insight-view.js";
import { NHAN_PHAN_KHUC } from "./insight-prompts.js";
import { LOAI_Y, NHAN_LOAI, type YDaLuu } from "./insight-types.js";

/**
 * Dựng nội dung xuất file từ CÙNG `ViewInsight` mà dashboard hiển thị, nên số
 * trong file luôn khớp số trên màn hình. Word/PDF/Markdown dùng chung một danh
 * sách khối; Excel có sheet riêng và chứa ĐỦ mọi ý (không cắt như bảng chi tiết).
 */

const TRAN_DONG_CHI_TIET_VAN_BAN = 200;

export function moTaBoLoc(f: BoLoc): string {
  const phan = [
    f.pk && `Tệp: ${NHAN_PHAN_KHUC[f.pk]}`,
    f.loai && `Loại: ${NHAN_LOAI[f.loai]}`,
    f.nhom && `Nhóm: ${f.nhom}`,
    f.chuDe && `Chủ đề: ${f.chuDe}`,
    (f.tu || f.den) && `Thời gian: ${f.tu ?? "..."} tới ${f.den ?? "..."}`,
    f.q && `Tìm: "${f.q}"`,
  ].filter(Boolean);
  return phan.length ? phan.join(" · ") : "Toàn bộ dữ liệu";
}

const dong = (...v: (string | number)[]) => v.map(String);

export function dungKhoiVanBan(v: ViewInsight, f: BoLoc): DocumentBlock[] {
  const k: DocumentBlock[] = [
    { type: "paragraph", text: `Dữ liệu tạo lúc ${v.taoLuc.slice(0, 16).replace("T", " ")} (UTC). Phạm vi: ${moTaBoLoc(f)}.` },
    { type: "heading", level: 1, text: "Chỉ số chính" },
    {
      type: "table",
      headers: ["Chỉ số", "Giá trị"],
      rows: [
        dong("Tin nhắn đã phân tích", v.kpi.soTin),
        dong("Nhóm có ý", v.kpi.soNhom),
        dong("Ý rút ra", v.kpi.soY),
        dong("Người nêu ý (ẩn danh)", v.kpi.soNguoi),
        ...LOAI_Y.map((l) => dong(NHAN_LOAI[l], v.kpi.theoLoai[l])),
      ],
    },
  ];
  for (const t of v.tomTat.filter((t) => t.y.length)) {
    k.push({ type: "heading", level: 2, text: `Điểm chính - ${NHAN_PHAN_KHUC[t.pk]}` }, { type: "bullets", items: t.y });
  }
  if (v.chuDe.length) {
    k.push(
      { type: "heading", level: 1, text: "Chủ đề nổi bật" },
      {
        type: "table",
        headers: ["Chủ đề", "Loại", "Tệp", "Số ý", "Số người", "Số nhóm", "Trích dẫn tiêu biểu"],
        rows: v.chuDe.map((c) =>
          dong(c.ten, NHAN_LOAI[c.loai], NHAN_PHAN_KHUC[c.pk], c.soY, c.soNguoi, c.soNhom, c.trich[0] ? `"${c.trich[0]}"` : ""),
        ),
      },
    );
  }
  if (v.nhom.length) {
    k.push(
      { type: "heading", level: 1, text: "Theo nhóm" },
      {
        type: "table",
        headers: ["Nhóm", "Tin", "Ý", ...LOAI_Y.map((l) => NHAN_LOAI[l])],
        rows: v.nhom.map((n) => dong(n.ten, n.soTin, n.tong, ...LOAI_Y.map((l) => n.theoLoai[l]))),
      },
    );
  }
  if (v.faq.length) {
    k.push({ type: "heading", level: 1, text: "Câu hỏi lặp lại (FAQ)" }, { type: "bullets", items: v.faq.map((q) => q.cauHoi) });
  }
  if (v.coHoi.length) {
    k.push(
      { type: "heading", level: 1, text: "Cơ hội sản phẩm và nội dung" },
      { type: "table", headers: ["Cơ hội", "Làm gì", "Dựa trên"], rows: v.coHoi.map((c) => dong(c.ten, c.moTa, c.duaTren)) },
    );
  }
  if (v.y.length) {
    const ds = v.y.slice(0, TRAN_DONG_CHI_TIET_VAN_BAN);
    k.push(
      { type: "heading", level: 1, text: "Dữ liệu chi tiết" },
      {
        type: "paragraph",
        text: `${ds.length}/${v.tongY} ý mới nhất. Bản Excel có đủ toàn bộ.`,
      },
      {
        type: "table",
        headers: ["Ngày", "Nhóm", "Loại", "Chủ đề", "Trích dẫn"],
        rows: ds.map((y) => dong(y.ngay, y.nhom, NHAN_LOAI[y.loai], y.chuDeGop, y.trich)),
      },
    );
  }
  return k;
}

const o = (value: string | number): SpreadsheetCell =>
  typeof value === "number" ? { kind: "number", value, format: "plain" } : { kind: "text", value };

export function dungSheet(v: ViewInsight, f: BoLoc, tatCaY: YDaLuu[]): Sheet[] {
  const phu = `Phạm vi: ${moTaBoLoc(f)}`;
  const sheet = (name: string, headers: string[], rows: (string | number)[][]): Sheet => ({
    name,
    title: name.toUpperCase(),
    subtitle: phu,
    headers,
    rows: rows.length ? rows.map((r) => r.map(o)) : [[o("(không có dữ liệu)")]],
  });
  return [
    sheet("Tổng quan", ["Chỉ số", "Giá trị"], [
      ["Tin nhắn đã phân tích", v.kpi.soTin],
      ["Nhóm có ý", v.kpi.soNhom],
      ["Ý rút ra", v.kpi.soY],
      ["Người nêu ý (ẩn danh)", v.kpi.soNguoi],
      ...LOAI_Y.map((l) => [NHAN_LOAI[l], v.kpi.theoLoai[l]] as [string, number]),
    ]),
    sheet("Chủ đề", ["Chủ đề", "Loại", "Tệp", "Số ý", "Số người", "Số nhóm", "Mô tả", "Trích dẫn"],
      v.chuDe.map((c) => [c.ten, NHAN_LOAI[c.loai], NHAN_PHAN_KHUC[c.pk], c.soY, c.soNguoi, c.soNhom, c.moTa, c.trich.join(" | ")])),
    sheet("Theo nhóm", ["Nhóm", "Tệp", "Tin", "Ý", ...LOAI_Y.map((l) => NHAN_LOAI[l])],
      v.nhom.map((n) => [n.ten, NHAN_PHAN_KHUC[n.pk], n.soTin, n.tong, ...LOAI_Y.map((l) => n.theoLoai[l])])),
    sheet("FAQ", ["Tệp", "Câu hỏi"], v.faq.map((q) => [NHAN_PHAN_KHUC[q.pk], q.cauHoi])),
    sheet("Cơ hội", ["Tệp", "Cơ hội", "Làm gì", "Dựa trên"], v.coHoi.map((c) => [NHAN_PHAN_KHUC[c.pk], c.ten, c.moTa, c.duaTren])),
    sheet("Chi tiết", ["Ngày", "Nhóm", "Tệp", "Loại", "Chủ đề", "Nhãn gốc", "Mô tả", "Trích dẫn"],
      tatCaY.map((y) => [y.ngay, y.nhom, NHAN_PHAN_KHUC[y.pk], NHAN_LOAI[y.loai], y.chuDeGop, y.chuDe, y.moTa, y.trich])),
  ];
}

const oMd = (s: string) => s.replace(/\|/g, "\\|").replace(/\r?\n/g, " ");

export function khoiSangMarkdown(tieuDe: string, khoi: DocumentBlock[]): string {
  const ra = [`# ${tieuDe}`, ""];
  for (const b of khoi) {
    if (b.type === "heading") ra.push(`${"#".repeat(Math.min(b.level + 1, 4))} ${b.text}`, "");
    else if (b.type === "paragraph") ra.push(b.text, "");
    else if (b.type === "bullets") ra.push(...b.items.map((i) => `- ${i}`), "");
    else if (b.type === "table") {
      ra.push(`| ${b.headers.map(oMd).join(" | ")} |`, `| ${b.headers.map(() => "---").join(" | ")} |`);
      ra.push(...b.rows.map((r) => `| ${r.map(oMd).join(" | ")} |`), "");
    }
  }
  return ra.join("\n");
}
