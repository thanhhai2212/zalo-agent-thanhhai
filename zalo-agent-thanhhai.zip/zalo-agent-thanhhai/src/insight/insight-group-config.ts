import { db } from "../conversation/database.js";

/**
 * Nhóm nào đưa vào báo cáo insight, và thuộc tệp đối tượng nào.
 *
 * Gom theo `thread_id` (KHÔNG theo account): cùng một nhóm Zalo có thể có 2
 * account bot cùng ở trong và cùng ghi lịch sử - đếm theo account là đếm đôi.
 *
 * Cấu hình lưu một dòng JSON trong `runtime_settings` thay vì bảng riêng: chỉ
 * là vài cờ theo nhóm do chủ bot chọn trên dashboard, không cần truy vấn.
 * Mặc định: nhóm MỚI được đưa vào, xếp tệp "cộng đồng" - chủ bot tự bỏ tích
 * nhóm gia đình/riêng tư.
 */

export type PhanKhuc = "cong_dong" | "doanh_nghiep";
export type CauHinhNhom = { boQua?: boolean; phanKhuc?: PhanKhuc };
export type NhomInsight = { threadId: string; ten: string; soTin: number; boQua: boolean; phanKhuc: PhanKhuc };

const KEY = "insight_group_config";
const getStmt = db.prepare("SELECT value FROM runtime_settings WHERE key = ?");
const setStmt = db.prepare(`
  INSERT INTO runtime_settings (key, value, updated_at)
  VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);

export function docCauHinhNhom(): Record<string, CauHinhNhom> {
  const row = getStmt.get(KEY) as { value: string } | undefined;
  if (!row) return {};
  try {
    const v: unknown = JSON.parse(row.value);
    return v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, CauHinhNhom>) : {};
  } catch {
    return {};
  }
}

export function datCauHinhNhom(threadId: string, sua: CauHinhNhom): void {
  const all = docCauHinhNhom();
  all[threadId] = { ...all[threadId], ...sua };
  setStmt.run(KEY, JSON.stringify(all));
}

/** Chọn/bỏ chọn nhiều nhóm trong MỘT lần ghi (nút "Chọn tất cả"/"Bỏ chọn tất cả"). */
export function datBoQuaNhieuNhom(threadIds: string[], boQua: boolean): void {
  const all = docCauHinhNhom();
  for (const id of threadIds) all[id] = { ...all[id], boQua };
  setStmt.run(KEY, JSON.stringify(all));
}

export function danhSachNhomInsight(): NhomInsight[] {
  const rows = db
    .prepare(
      `SELECT t.thread_id AS threadId, MAX(t.display_name) AS ten, COUNT(m.id) AS soTin
       FROM threads t JOIN messages m ON m.account_id = t.account_id AND m.thread_id = t.thread_id
       WHERE t.thread_type = 1 AND m.role = 'user'
       GROUP BY t.thread_id ORDER BY soTin DESC`,
    )
    .all() as unknown as { threadId: string; ten: string; soTin: number }[];
  const cfg = docCauHinhNhom();
  return rows.map((r) => ({
    ...r,
    ten: r.ten || r.threadId,
    boQua: cfg[r.threadId]?.boQua === true,
    phanKhuc: cfg[r.threadId]?.phanKhuc === "doanh_nghiep" ? "doanh_nghiep" : "cong_dong",
  }));
}

export type TinNhomTho = {
  id: number;
  threadId: string;
  senderId: string | null;
  senderName: string | null;
  content: string;
  createdAt: string;
};

/** Tin người thật (không phải bot) của các nhóm được chọn, theo thời gian. */
export function tinCuaCacNhom(threadIds: string[]): TinNhomTho[] {
  if (threadIds.length === 0) return [];
  const dau = threadIds.map(() => "?").join(",");
  return db
    .prepare(
      `SELECT m.id AS id, m.thread_id AS threadId, m.sender_id AS senderId, m.sender_name AS senderName,
              m.content AS content, m.created_at AS createdAt
       FROM messages m JOIN threads t ON t.account_id = m.account_id AND t.thread_id = m.thread_id
       WHERE t.thread_type = 1 AND m.role = 'user' AND m.thread_id IN (${dau})
       ORDER BY m.created_at, m.id`,
    )
    .all(...threadIds) as unknown as TinNhomTho[];
}

/**
 * Tên hiển thị của MỌI người từng gửi tin trong các nhóm - để xóa tên khỏi nội
 * dung tin. Lấy trên TOÀN lịch sử, không chỉ tin mới: lượt cập nhật tăng dần
 * chỉ đọc tin mới, nhưng tin mới vẫn hay gọi tên người đã nói từ trước.
 */
export function tenNguoiGuiCuaCacNhom(threadIds: string[]): string[] {
  if (threadIds.length === 0) return [];
  const dau = threadIds.map(() => "?").join(",");
  return (
    db
      .prepare(`SELECT DISTINCT sender_name AS ten FROM messages WHERE role = 'user' AND sender_name IS NOT NULL AND thread_id IN (${dau})`)
      .all(...threadIds) as unknown as { ten: string }[]
  ).map((r) => r.ten);
}
