import type { PhanKhuc } from "./insight-group-config.js";

/**
 * Dữ liệu có cấu trúc của một lượt báo cáo insight - nguồn DUY NHẤT cho
 * dashboard, bộ lọc và mọi định dạng xuất file. Mọi con số trên dashboard là
 * ĐẾM THẬT trên mảng `y` (máy chủ tự đếm), không phải số model ước lượng.
 */

export const LOAI_Y = ["noi_dau", "cau_hoi", "mong_muon", "rao_can", "co_hoi"] as const;
export type LoaiY = (typeof LOAI_Y)[number];

export const NHAN_LOAI: Record<LoaiY, string> = {
  noi_dau: "Nỗi đau",
  cau_hoi: "Câu hỏi",
  mong_muon: "Mong muốn",
  rao_can: "Rào cản",
  co_hoi: "Cơ hội",
};

export function laLoaiY(v: unknown): v is LoaiY {
  return typeof v === "string" && (LOAI_Y as readonly string[]).includes(v);
}

/** Một ý rút từ tin nhắn. `tv` là mã ẩn danh người nêu (đếm "bao nhiêu người", không lộ ai). */
export type YDaLuu = {
  loai: LoaiY;
  chuDe: string;
  moTa: string;
  trich: string;
  nhom: string;
  pk: PhanKhuc;
  /** YYYY-MM-DD */
  ngay: string;
  tv: string;
  /** Chủ đề sau khi gộp các nhãn cùng nghĩa - "Khác" nếu không gộp được. */
  chuDeGop: string;
  /** Nhóm gốc - để cập nhật tăng dần gắn lại tên/tệp mới và bỏ ý của nhóm đã bỏ chọn. */
  threadId?: string;
};

export type ChuDeGop = { ten: string; pk: PhanKhuc; loai: LoaiY; moTa: string };
export type CoHoi = { pk: PhanKhuc; ten: string; moTa: string; duaTren: string };

export type DuLieuInsight = {
  taoLuc: string;
  /** Lượt vừa rồi phân tích lại toàn bộ hay chỉ tin mới. */
  cheDo?: "toan_bo" | "cap_nhat";
  thongKe: { soDoan: number; soDoanHong: number; soTinMoi?: number };
  nhom: { ten: string; pk: PhanKhuc; soTin: number; threadId?: string }[];
  /**
   * Mốc cập nhật tăng dần: id tin nhắn LỚN NHẤT đã phân tích xong của từng nhóm
   * (`messages.id` tự tăng nên so sánh được). Thiếu thì lượt sau chạy toàn bộ.
   */
  mocTin?: Record<string, number>;
  /** Khóa bí mật để mã ẩn danh TVxxxx của cùng một người KHÔNG ĐỔI giữa các lượt. */
  muoi?: string;
  y: YDaLuu[];
  chuDe: ChuDeGop[];
  faq: { pk: PhanKhuc; cauHoi: string }[];
  coHoi: CoHoi[];
  tomTat: { pk: PhanKhuc; y: string[] }[];
};

export const CHU_DE_KHAC = "Khác";
