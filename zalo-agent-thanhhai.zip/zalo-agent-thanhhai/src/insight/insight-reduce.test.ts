import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { gomNhan, gopChuDe } from "./insight-reduce.js";
import type { YDaLuu } from "./insight-types.js";

const y = (loai: YDaLuu["loai"], chuDe: string, tv = "TV001"): YDaLuu => ({
  loai,
  chuDe,
  moTa: "m",
  trich: "t",
  nhom: "N",
  pk: "cong_dong",
  ngay: "2026-09-20",
  tv,
  chuDeGop: "Khác",
});

describe("gomNhan", () => {
  it("gom nhãn không phân biệt hoa thường/khoảng trắng, tách theo loại, xếp theo số lần", () => {
    const n = gomNhan([y("noi_dau", "Cài VPS"), y("noi_dau", " cài  vps "), y("cau_hoi", "cài VPS"), y("noi_dau", "giá")]);
    assert.equal(n[0]!.soLan, 2);
    assert.equal(n.length, 3);
  });
});

describe("gopChuDe", () => {
  it("gán chủ đề gộp theo SỐ THỨ TỰ nhãn model trả, loại chủ đề là loại đa số (đếm thật)", async () => {
    const ys = [y("noi_dau", "cài VPS"), y("noi_dau", "cài VPS"), y("cau_hoi", "cách cài"), y("mong_muon", "lẻ")];
    const json = JSON.stringify({ chu_de: [{ ten: "Cài đặt", mo_ta: "m", nhan: [1, 2, 99] }], faq: ["Q?"], co_hoi: [], tom_tat: ["A"] });
    const kq = await gopChuDe("cong_dong", ys, async () => `rác trước ${json} rác sau`);
    assert.deepEqual(
      ys.map((x) => x.chuDeGop),
      ["Cài đặt", "Cài đặt", "Cài đặt", "Khác"],
    );
    assert.equal(kq.chuDe.length, 1);
    assert.equal(kq.chuDe[0]!.loai, "noi_dau");
    assert.deepEqual(kq.faq, ["Q?"]);
  });

  it("model lỗi hoặc JSON hỏng: mỗi nhãn phổ biến thành chủ đề riêng, báo cáo không trống", async () => {
    const ys = [y("noi_dau", "cài VPS"), y("cau_hoi", "giá")];
    const kq = await gopChuDe("cong_dong", ys, async () => {
      throw new Error("sập");
    });
    assert.deepEqual(
      ys.map((x) => x.chuDeGop),
      ["cài VPS", "giá"],
    );
    assert.equal(kq.chuDe.length, 2);
  });
});
