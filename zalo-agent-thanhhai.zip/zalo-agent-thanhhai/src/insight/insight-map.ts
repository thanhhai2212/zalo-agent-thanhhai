import { createLogger } from "../shared/logger.js";
import { chiaDoan, laTinRac, tachDanhSachY, type BoAnDanh } from "./insight-anonymize.js";
import type { NhomInsight, PhanKhuc, TinNhomTho } from "./insight-group-config.js";
import { LoiDaDung, type GoiLlm } from "./insight-llm.js";
import { promptRutY } from "./insight-prompts.js";
import { CHU_DE_KHAC, laLoaiY, type YDaLuu } from "./insight-types.js";

/**
 * Bước 1 (map) của báo cáo insight: chia tin thành đoạn rồi nhờ model rút ý.
 *
 * Độ song song THÍCH NGHI: tối đa `TOI_DA_SONG_SONG` đoạn cùng lúc khi KHÔNG
 * ai đang chat (đêm khuya chạy nhanh gần gấp đôi), tự lùi về 1 ngay khi có
 * người chat, và lùi hẳn về 1 trong `GIAM_TOC_MS` sau mỗi lần router báo lỗi -
 * bản đầu chạy 3 song song cứng đã làm ngộp router dùng chung với chat thật.
 */

const log = createLogger("insight-map");
export const TIN_MOI_DOAN = 80;
export const TOI_DA_SONG_SONG = 2;
const GIAM_TOC_MS = 5 * 60_000;
const NGAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const TV_RE = /^TV[0-9A-F]{3,}$/;

export type Doan = {
  threadId: string;
  ten: string;
  pk: PhanKhuc;
  tin: string[];
  ngayCuoi: string;
  /** id tin nhắn lớn nhất trong đoạn - để dời mốc cập nhật tăng dần. */
  idCuoi: number;
};

/** Khử trùng (cùng nhóm do 2 account ghi), lọc tin rác, ẩn danh, chia đoạn. */
export function dungDoan(nhom: NhomInsight[], tho: TinNhomTho[], anDanh: BoAnDanh): { viec: Doan[]; soTin: Map<string, number> } {
  const theoId = new Map(nhom.map((n) => [n.threadId, n]));
  const daThay = new Set<string>();
  const tinTheoNhom = new Map<string, { dong: string; ngay: string; id: number }[]>();
  for (const t of tho) {
    const c = anDanh.lamSach(t.content).trim();
    if (laTinRac(c)) continue;
    const khoa = `${t.threadId}|${t.createdAt.slice(0, 16)}|${c.slice(0, 80)}`;
    if (daThay.has(khoa)) continue;
    daThay.add(khoa);
    const ngay = t.createdAt.slice(0, 10);
    const ds = tinTheoNhom.get(t.threadId) ?? [];
    ds.push({ dong: `${anDanh.maNguoi(t.senderId, t.senderName)} (${ngay}): ${c.slice(0, 600)}`, ngay, id: t.id });
    tinTheoNhom.set(t.threadId, ds);
  }
  const viec: Doan[] = [];
  const soTin = new Map<string, number>();
  for (const [threadId, ds] of tinTheoNhom) {
    const n = theoId.get(threadId)!;
    soTin.set(threadId, ds.length);
    for (const d of chiaDoan(ds, TIN_MOI_DOAN)) {
      viec.push({
        threadId,
        ten: n.ten,
        pk: n.phanKhuc,
        tin: d.map((x) => x.dong),
        ngayCuoi: d[d.length - 1]!.ngay,
        idCuoi: Math.max(...d.map((x) => x.id)),
      });
    }
  }
  return { viec, soTin };
}

type TuyChonRutY = {
  signal?: AbortSignal;
  demDangChat: () => number;
  onXongMotDoan: () => void;
  anDanh: BoAnDanh;
};

const ngu = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Kết quả theo ĐÚNG thứ tự `viec`; `null` = đoạn hỏng (không rút được ý nào). */
export async function rutYCacDoan(viec: Doan[], goiLlm: GoiLlm, o: TuyChonRutY): Promise<(YDaLuu[] | null)[]> {
  const kq: (YDaLuu[] | null)[] = new Array(viec.length).fill(null);
  let i = 0;
  let giamTocDen = 0;
  const lamMotDoan = async (idx: number) => {
    const v = viec[idx]!;
    let tho = tachDanhSachY("");
    for (let lan = 0; lan < 2 && tho.length === 0; lan++) {
      try {
        tho = tachDanhSachY(await goiLlm(promptRutY(v.ten, v.pk, v.tin), 4000, o.signal));
      } catch (e) {
        if (o.signal?.aborted) throw new LoiDaDung();
        giamTocDen = Date.now() + GIAM_TOC_MS;
        log.warn({ err: e, nhom: v.ten }, "Rút ý một đoạn lỗi");
      }
    }
    if (tho.length > 0) {
      kq[idx] = tho
        .filter((y) => laLoaiY(y.loai) && y.chu_de.trim())
        .map((y) => ({
          loai: y.loai as YDaLuu["loai"],
          chuDe: o.anDanh.lamSach(y.chu_de).slice(0, 80),
          moTa: o.anDanh.lamSach(y.mo_ta).slice(0, 300),
          trich: o.anDanh.lamSach(y.trich).slice(0, 200),
          nhom: v.ten,
          pk: v.pk,
          ngay: NGAY_RE.test(y.ngay) ? y.ngay : v.ngayCuoi,
          tv: TV_RE.test(y.tv) ? y.tv : "",
          chuDeGop: CHU_DE_KHAC,
          threadId: v.threadId,
        }));
    }
    o.onXongMotDoan();
  };
  const tho_ = async (thuTu: number) => {
    while (i < viec.length) {
      if (o.signal?.aborted) throw new LoiDaDung();
      // Luồng phụ chỉ nhận việc khi không ai chat và router đang khỏe.
      if (thuTu > 0 && (o.demDangChat() > 0 || Date.now() < giamTocDen)) {
        await ngu(2000);
        continue;
      }
      await lamMotDoan(i++);
    }
  };
  await Promise.all(Array.from({ length: TOI_DA_SONG_SONG }, (_, k) => tho_(k)));
  return kq;
}
