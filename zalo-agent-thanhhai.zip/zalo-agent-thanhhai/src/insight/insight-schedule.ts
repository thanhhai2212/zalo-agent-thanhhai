import { DateTime } from "luxon";
import { botTimeZone, getTuning } from "../config/runtime-tuning-settings.js";
import { db } from "../conversation/database.js";
import { createLogger } from "../shared/logger.js";
import { batDauInsight } from "./insight-job.js";

/**
 * Tự tạo báo cáo Insight nhóm mỗi ngày lúc `INSIGHT_AUTO_HOUR` (mặc định 1 giờ
 * sáng, 2026-09-30, chủ bot yêu cầu). Giống bấm "Tạo báo cáo": chỉ phân tích tin
 * mới sau lần trước, dùng đúng các nhóm đã chọn. Ngày đã chạy lưu vào
 * `runtime_settings` nên khởi động lại không chạy lần hai. Đang có lượt chạy tay
 * thì bỏ qua hôm đó (lượt tay đã cập nhật rồi).
 */

const log = createLogger("insight-schedule");
const KHOA = "insight_auto_last_date";
const KIEM_MS = 5 * 60_000;
const getStmt = db.prepare("SELECT value FROM runtime_settings WHERE key = ?");
const setStmt = db.prepare(`
  INSERT INTO runtime_settings (key, value, updated_at)
  VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);

/** Đến giờ chạy chưa: đúng giờ đã đặt (hoặc trễ tối đa 2 giờ nếu máy vừa khởi động lại) và hôm nay chưa chạy. */
export function denGioChay(gio: number, now: DateTime, ngayDaChay: string | undefined): boolean {
  if (gio < 0) return false;
  const tre = now.hour - gio;
  return tre >= 0 && tre < 3 && ngayDaChay !== now.toISODate();
}

export function kiemInsightTuDong(now = DateTime.now().setZone(botTimeZone()), batDau: () => boolean = batDauInsight): boolean {
  const gio = getTuning("INSIGHT_AUTO_HOUR");
  const daChay = (getStmt.get(KHOA) as { value: string } | undefined)?.value;
  if (!denGioChay(gio, now, daChay)) return false;
  setStmt.run(KHOA, now.toISODate());
  const ok = batDau();
  log.info({ ok }, ok ? "Tự tạo báo cáo Insight nhóm" : "Tự tạo Insight: đang có lượt khác chạy - bỏ qua hôm nay");
  return ok;
}

export function batDauHenGioInsight(): () => void {
  const t = setInterval(() => {
    try {
      kiemInsightTuDong();
    } catch (err) {
      log.warn({ err }, "Hẹn giờ Insight lỗi");
    }
  }, KIEM_MS);
  t.unref();
  return () => clearInterval(t);
}
