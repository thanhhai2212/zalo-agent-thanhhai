import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { DateTime } from "luxon";
import { setupTestEnv } from "../shared/test-env-setup.js";

setupTestEnv();
const { denGioChay, kiemInsightTuDong } = await import("./insight-schedule.js");
const luc = (iso: string) => DateTime.fromISO(iso, { zone: "Asia/Ho_Chi_Minh" });

describe("hẹn giờ Insight nhóm", () => {
  it("chạy từ đúng giờ tới trễ 2 giờ, mỗi ngày một lần, -1 là tắt", () => {
    assert.equal(denGioChay(1, luc("2026-09-30T00:59"), undefined), false);
    assert.equal(denGioChay(1, luc("2026-09-30T01:05"), undefined), true);
    assert.equal(denGioChay(1, luc("2026-09-30T03:10"), undefined), true);
    assert.equal(denGioChay(1, luc("2026-09-30T04:00"), undefined), false);
    assert.equal(denGioChay(1, luc("2026-09-30T01:30"), "2026-09-30"), false);
    assert.equal(denGioChay(-1, luc("2026-09-30T01:30"), undefined), false);
  });

  it("ghi ngày đã chạy nên lần kiểm sau không chạy lại", () => {
    let lan = 0;
    const bd = () => (lan++, true);
    assert.equal(kiemInsightTuDong(luc("2026-10-01T01:00"), bd), true);
    assert.equal(kiemInsightTuDong(luc("2026-10-01T01:05"), bd), false);
    assert.equal(lan, 1);
  });
});
