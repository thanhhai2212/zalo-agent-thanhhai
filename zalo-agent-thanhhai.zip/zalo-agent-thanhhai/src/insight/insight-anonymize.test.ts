import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { chiaDoan, laTinRac, tachDanhSachY, taoBoAnDanh } from "./insight-anonymize.js";

describe("taoBoAnDanh", () => {
  it("cùng người luôn cùng mã, người khác mã khác; tên không có id thì gom theo tên", () => {
    const b = taoBoAnDanh([]);
    assert.equal(b.maNguoi("u1", "An"), "TV001");
    assert.equal(b.maNguoi("u2", "Bình"), "TV002");
    assert.equal(b.maNguoi("u1", "An đổi tên"), "TV001");
    assert.equal(b.maNguoi(null, "Cường"), "TV003");
    assert.equal(b.maNguoi(null, "Cường"), "TV003");
  });

  it("có khóa: cùng người ra CÙNG mã ở hai bộ ẩn danh khác nhau (hai lượt chạy), khác khóa thì khác mã", () => {
    const a = taoBoAnDanh([], "khoa-1").maNguoi("u1", "An");
    assert.match(a, /^TV[0-9A-F]{6}$/);
    assert.equal(taoBoAnDanh([], "khoa-1").maNguoi("u1", "Tên khác"), a);
    assert.notEqual(taoBoAnDanh([], "khoa-1").maNguoi("u2", "Bình"), a);
    assert.notEqual(taoBoAnDanh([], "khoa-2").maNguoi("u1", "An"), a);
  });

  it("bỏ tiền tố 'Tên: ', thay tên đã thấy, SĐT, email, link, ID dài trong nội dung", () => {
    const b = taoBoAnDanh(["Nguyễn Văn An", "Bo"]);
    const s = b.lamSach(
      "Nguyễn Văn An: nhờ Nguyễn Văn An gọi 0912345678 hoặc +84912345678, mail a.b@x.vn, xem https://x.vn/a?b=1 id 7369436884417343108",
    );
    assert.ok(!s.includes("Nguyễn Văn An"), s);
    assert.ok(!s.includes("0912345678") && !s.includes("84912345678"), s);
    assert.ok(!s.includes("a.b@x.vn") && !s.includes("https://"), s);
    assert.ok(!s.includes("7369436884417343108"), s);
    assert.match(s, /^nhờ \[tên\] gọi \[sđt\]/);
  });

  it("tên quá ngắn (dưới 3 ký tự) không bị dùng để thay - tránh xóa nhầm chữ thường", () => {
    const b = taoBoAnDanh(["Bo"]);
    assert.equal(b.lamSach("bo cái này đi, Bo ơi"), "bo cái này đi, Bo ơi");
  });

  it("tên chứa ký tự đặc biệt regex không làm vỡ", () => {
    const b = taoBoAnDanh(["Anh (Sale)"]);
    assert.equal(b.lamSach("hỏi Anh (Sale) giá bao nhiêu"), "hỏi [tên] giá bao nhiêu");
  });
});

describe("laTinRac / chiaDoan", () => {
  it("tin ngắn hoặc chỉ là nhãn đính kèm là rác", () => {
    assert.ok(laTinRac("ok ạ"));
    assert.ok(laTinRac("[gửi kèm 3 ảnh, không có chữ]"));
    assert.ok(!laTinRac("cài VPS mãi không được, lỗi quyền truy cập"));
  });
  it("chia đều, đoạn cuối lẻ", () => {
    assert.deepEqual(chiaDoan([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]]);
    assert.deepEqual(chiaDoan([], 3), []);
  });
});

describe("tachDanhSachY", () => {
  it("đọc được mảng JSON bọc trong rào ```json và chữ thừa", () => {
    const ys = tachDanhSachY('Đây:\n```json\n[{"loai":"noi_dau","chu_de":"VPS","mo_ta":"khó cài","trich":"mãi không được"}]\n```');
    assert.equal(ys.length, 1);
    assert.equal(ys[0]!.chu_de, "VPS");
  });
  it("JSON hỏng hoặc thiếu chu_de thì bỏ, không ném", () => {
    assert.deepEqual(tachDanhSachY("không có gì"), []);
    assert.deepEqual(tachDanhSachY("[{bad json"), []);
    assert.deepEqual(tachDanhSachY('[{"loai":"x"}]'), []);
  });
});
