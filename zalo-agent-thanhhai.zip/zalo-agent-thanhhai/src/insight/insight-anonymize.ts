import { createHash } from "node:crypto";

/**
 * Ẩn danh tin nhắn nhóm TRƯỚC khi gửi model phân tích insight.
 *
 * Tên người gửi thay bằng mã `TVxxx` (ổn định trong một lượt báo cáo, để model
 * vẫn đếm được "nhiều người cùng than" khác "một người than nhiều lần"), rồi
 * quét thêm TRONG NỘI DUNG: tên hiển thị của mọi người đã thấy (người ta hay
 * gọi tên nhau), số điện thoại, email, UID/ID dài, đường link. Không hoàn hảo
 * (biệt danh, tên viết khác dấu vẫn lọt) nên prompt vẫn dặn model không chép
 * tên - đây là lớp giảm thiểu, không phải bảo đảm.
 */

const THOAT_REGEX = /[.*+?^${}()|[\]\\]/g;

export type BoAnDanh = { maNguoi: (senderId: string | null, senderName: string | null) => string; lamSach: (c: string) => string };

/**
 * `muoi` có mặt: mã là băm một chiều (khóa + id người gửi) nên CÙNG một người
 * luôn ra CÙNG một mã ở mọi lượt - cập nhật tăng dần mới đếm đúng "số người".
 * Không có `muoi`: đánh số TV001, TV002... theo thứ tự gặp (test, lượt đơn lẻ).
 */
export function taoBoAnDanh(tenDaThay: Iterable<string>, muoi?: string): BoAnDanh {
  const ma = new Map<string, string>();
  const ten = [...new Set(tenDaThay)].filter((t) => t.trim().length >= 3).sort((a, b) => b.length - a.length);
  const tenRe = ten.length ? new RegExp(ten.map((t) => t.replace(THOAT_REGEX, "\\$&")).join("|"), "g") : null;
  return {
    maNguoi(senderId, senderName) {
      const k = senderId || `ten:${senderName ?? ""}`;
      let m = ma.get(k);
      if (!m) {
        m = muoi
          ? `TV${createHash("sha256").update(`${muoi}|${k}`).digest("hex").slice(0, 6).toUpperCase()}`
          : `TV${String(ma.size + 1).padStart(3, "0")}`;
        ma.set(k, m);
      }
      return m;
    },
    lamSach(c) {
      // History lưu tin nhóm dạng "Tên: nội dung" - bỏ tiền tố đó trước.
      let s = c.replace(/^[^:\n]{1,60}:\s/, "");
      if (tenRe) s = s.replace(tenRe, "[tên]");
      return s
        .replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, "[email]")
        .replace(/https?:\/\/\S+/g, "[link]")
        .replace(/(\+?84|\b0)\d{9,10}\b/g, "[sđt]")
        .replace(/\b\d{12,20}\b/g, "[id]");
    },
  };
}

/** Tin không đáng phân tích: quá ngắn, hoặc chỉ là nhãn đính kèm kiểu "[gửi kèm 1 ảnh]". */
export function laTinRac(c: string): boolean {
  const s = c.trim();
  return s.length < 15 || /^\[[^\]]*\]$/.test(s);
}

export function chiaDoan<T>(ds: T[], coDoan: number): T[][] {
  const ra: T[][] = [];
  for (let i = 0; i < ds.length; i += coDoan) ra.push(ds.slice(i, i + coDoan));
  return ra;
}

export type YInsight = { loai: string; chu_de: string; mo_ta: string; trich: string; tv: string; ngay: string };

/** Đọc mảng JSON model trả về, chịu được rào ```json và chữ thừa hai đầu. Hỏng thì []. */
export function tachDanhSachY(s: string): YInsight[] {
  const a = s.indexOf("[");
  const b = s.lastIndexOf("]");
  if (a < 0 || b < a) return [];
  try {
    const v: unknown = JSON.parse(s.slice(a, b + 1));
    if (!Array.isArray(v)) return [];
    return v
      .filter((x): x is Record<string, unknown> => !!x && typeof x === "object" && typeof (x as { chu_de?: unknown }).chu_de === "string")
      .map((x) => ({
        loai: String(x.loai ?? ""),
        chu_de: String(x.chu_de),
        mo_ta: String(x.mo_ta ?? ""),
        trich: String(x.trich ?? ""),
        tv: String(x.tv ?? ""),
        ngay: String(x.ngay ?? ""),
      }));
  } catch {
    return [];
  }
}
