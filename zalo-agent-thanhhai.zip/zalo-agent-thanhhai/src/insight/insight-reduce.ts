import type { PhanKhuc } from "./insight-group-config.js";
import { promptGopChuDe } from "./insight-prompts.js";
import { CHU_DE_KHAC, type ChuDeGop, type CoHoi, type LoaiY, type YDaLuu } from "./insight-types.js";

/**
 * Bước gộp (reduce) của báo cáo insight cho MỘT tệp đối tượng.
 *
 * Model KHÔNG đếm gì cả: nó chỉ nhận danh sách nhãn đã đánh số và trả về nhãn
 * nào thuộc chủ đề gộp nào. Máy chủ tự gán `chuDeGop` cho từng ý rồi dashboard
 * đếm trên dữ liệu thật - số model "ước lượng" trong văn xuôi thì không lọc,
 * không vẽ biểu đồ được và hay lệch.
 */

const TRAN_NHAN = 800;

type Nhan = { khoa: string; loai: LoaiY; chuDe: string; soLan: number; viDu: string };
export type KetQuaGop = { chuDe: ChuDeGop[]; faq: string[]; coHoi: CoHoi[]; tomTat: string[] };

const chuanNhan = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

export function gomNhan(ys: YDaLuu[]): Nhan[] {
  const m = new Map<string, Nhan>();
  for (const y of ys) {
    const khoa = `${y.loai}|${chuanNhan(y.chuDe)}`;
    const cu = m.get(khoa);
    if (cu) cu.soLan++;
    else m.set(khoa, { khoa, loai: y.loai, chuDe: y.chuDe.trim(), soLan: 1, viDu: y.moTa.slice(0, 120) });
  }
  return [...m.values()].sort((a, b) => b.soLan - a.soLan).slice(0, TRAN_NHAN);
}

function tachObject(s: string): Record<string, unknown> | null {
  const a = s.indexOf("{");
  const b = s.lastIndexOf("}");
  if (a < 0 || b < a) return null;
  try {
    const v: unknown = JSON.parse(s.slice(a, b + 1));
    return v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

const chuoi = (v: unknown) => (typeof v === "string" ? v.trim() : "");
const mang = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);

/** Loại của chủ đề gộp = loại chiếm đa số trong các ý thuộc nó (đếm thật, không tin model). */
function loaiDaSo(ys: YDaLuu[]): LoaiY {
  const dem = new Map<LoaiY, number>();
  for (const y of ys) dem.set(y.loai, (dem.get(y.loai) ?? 0) + 1);
  return [...dem.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "noi_dau";
}

/**
 * Gán `chuDeGop` TẠI CHỖ cho các ý của tệp `pk` và trả về danh sách chủ đề.
 * JSON hỏng hoặc model lỗi: mỗi nhãn phổ biến thành một chủ đề riêng (vẫn
 * đếm đúng, chỉ là chưa gộp) - báo cáo không bao giờ trống vì một bước gộp hỏng.
 */
export async function gopChuDe(
  pk: PhanKhuc,
  ys: YDaLuu[],
  goiLlm: (prompt: string, maxOut: number) => Promise<string>,
): Promise<KetQuaGop> {
  const nhan = gomNhan(ys);
  const dong = nhan.map((n, i) => `[${i + 1}] ${n.loai} | ${n.chuDe} | ${n.soLan} | ${n.viDu}`);
  let obj: Record<string, unknown> | null = null;
  if (nhan.length) {
    try {
      obj = tachObject(await goiLlm(promptGopChuDe(pk, dong), 16000));
    } catch {
      obj = null;
    }
  }

  const khoaSangChuDe = new Map<string, string>();
  const moTaChuDe = new Map<string, string>();
  for (const c of mang(obj?.chu_de)) {
    const r = c as Record<string, unknown>;
    const ten = chuoi(r?.ten);
    if (!ten) continue;
    moTaChuDe.set(ten, chuoi(r.mo_ta));
    for (const so of mang(r.nhan)) {
      const n = nhan[Number(so) - 1];
      if (n && !khoaSangChuDe.has(n.khoa)) khoaSangChuDe.set(n.khoa, ten);
    }
  }
  if (khoaSangChuDe.size === 0) {
    for (const n of nhan.slice(0, 25)) {
      khoaSangChuDe.set(n.khoa, n.chuDe);
      moTaChuDe.set(n.chuDe, n.viDu);
    }
  }

  for (const y of ys) y.chuDeGop = khoaSangChuDe.get(`${y.loai}|${chuanNhan(y.chuDe)}`) ?? CHU_DE_KHAC;

  const chuDe: ChuDeGop[] = [...moTaChuDe.entries()]
    .map(([ten, moTa]) => ({ ten, pk, moTa, loai: loaiDaSo(ys.filter((y) => y.chuDeGop === ten)) }))
    .filter((c) => ys.some((y) => y.chuDeGop === c.ten));

  return {
    chuDe,
    faq: mang(obj?.faq).map(chuoi).filter(Boolean).slice(0, 12),
    coHoi: mang(obj?.co_hoi)
      .map((c) => c as Record<string, unknown>)
      .map((r) => ({ pk, ten: chuoi(r?.ten), moTa: chuoi(r?.mo_ta), duaTren: chuoi(r?.dua_tren) }))
      .filter((c) => c.ten)
      .slice(0, 8),
    tomTat: mang(obj?.tom_tat).map(chuoi).filter(Boolean).slice(0, 6),
  };
}
