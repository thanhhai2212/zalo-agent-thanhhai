import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { dungKhoiVanBan, dungSheet, khoiSangMarkdown } from "./insight-export-content.js";
import type { DuLieuInsight, YDaLuu } from "./insight-types.js";
import { docBoLoc, locY, tinhView } from "./insight-view.js";

const y = (p: Partial<YDaLuu>): YDaLuu => ({
  loai: "noi_dau",
  chuDe: "c",
  moTa: "m",
  trich: "t",
  nhom: "A",
  pk: "cong_dong",
  ngay: "2026-09-20",
  tv: "TV001",
  chuDeGop: "Cài đặt",
  ...p,
});

const d: DuLieuInsight = {
  taoLuc: "2026-09-25T00:00:00.000Z",
  thongKe: { soDoan: 2, soDoanHong: 0 },
  nhom: [
    { ten: "A", pk: "cong_dong", soTin: 100 },
    { ten: "B", pk: "doanh_nghiep", soTin: 40 },
  ],
  y: [
    y({}),
    y({ tv: "TV002", ngay: "2026-09-22" }),
    y({ loai: "cau_hoi", chuDeGop: "Giá", nhom: "B", pk: "doanh_nghiep", tv: "TV003", ngay: "2026-09-24", trich: "bao nhiêu tiền | có VAT" }),
    y({ chuDeGop: "Khác", ngay: "2026-09-24" }),
  ],
  chuDe: [{ ten: "Cài đặt", pk: "cong_dong", loai: "noi_dau", moTa: "mô tả" }],
  faq: [
    { pk: "cong_dong", cauHoi: "Q1" },
    { pk: "doanh_nghiep", cauHoi: "Q2" },
  ],
  coHoi: [],
  tomTat: [],
};

describe("docBoLoc", () => {
  it("giá trị lạ bị bỏ, không ném", () => {
    assert.deepEqual(docBoLoc({ pk: "x", loai: "y", tu: "hôm qua", den: "2026-09-30", q: "  VPS " }), { den: "2026-09-30", q: "vps" });
  });
});

describe("tinhView", () => {
  it("KPI đếm thật: số ý, số người (mã TV khác nhau), số tin theo nhóm", () => {
    const v = tinhView(d, {});
    assert.equal(v.kpi.soY, 4);
    assert.equal(v.kpi.soNguoi, 3);
    assert.equal(v.kpi.soTin, 140);
    assert.equal(v.kpi.theoLoai.noi_dau, 3);
    assert.deepEqual(v.phamVi, { tuNgay: "2026-09-20", denNgay: "2026-09-24" });
  });

  it("chủ đề 'Khác' luôn xếp cuối, kèm số người/nhóm và mô tả từ bước gộp", () => {
    const v = tinhView(d, {});
    assert.equal(v.chuDe[v.chuDe.length - 1]!.ten, "Khác");
    const c = v.chuDe.find((x) => x.ten === "Cài đặt")!;
    assert.deepEqual([c.soY, c.soNguoi, c.soNhom, c.moTa], [2, 2, 1, "mô tả"]);
  });

  it("cùng tên chủ đề ở 2 tệp được gộp làm MỘT dòng khi không lọc tệp", () => {
    const d2: DuLieuInsight = { ...d, y: [...d.y, y({ pk: "doanh_nghiep", nhom: "B", tv: "TV009" })] };
    const c = tinhView(d2, {}).chuDe.filter((x) => x.ten === "Cài đặt");
    assert.equal(c.length, 1);
    assert.deepEqual([c[0]!.soY, c[0]!.soNhom, c[0]!.pk], [3, 2, "cong_dong"]);
  });

  it("lọc theo tệp áp cho cả KPI, nhóm và FAQ", () => {
    const v = tinhView(d, { pk: "doanh_nghiep" });
    assert.equal(v.kpi.soY, 1);
    assert.equal(v.kpi.soTin, 40);
    assert.deepEqual(
      v.faq.map((q) => q.cauHoi),
      ["Q2"],
    );
    assert.deepEqual(
      v.nhom.map((n) => n.ten),
      ["B"],
    );
  });

  it("lọc thời gian, chủ đề và tìm chữ", () => {
    assert.equal(tinhView(d, { tu: "2026-09-22", den: "2026-09-23" }).kpi.soY, 1);
    assert.equal(tinhView(d, { chuDe: "Giá" }).kpi.soY, 1);
    assert.equal(tinhView(d, { q: "bao nhiêu" }).kpi.soY, 1);
  });

  it("chuỗi thời gian theo ngày có lấp ngày trống bằng 0", () => {
    const v = tinhView(d, {});
    assert.equal(v.theoThoiGian.donVi, "ngay");
    assert.deepEqual(
      v.theoThoiGian.diem.map((p) => p.so),
      [1, 0, 1, 0, 2],
    );
  });
});

describe("nội dung xuất file", () => {
  it("Markdown thoát ký tự | trong ô bảng, ghi rõ phạm vi lọc", () => {
    const f = { pk: "doanh_nghiep" as const };
    const md = khoiSangMarkdown("Báo cáo", dungKhoiVanBan(tinhView(d, f), f));
    assert.match(md, /Tệp: Khách hàng doanh nghiệp/);
    assert.match(md, /bao nhiêu tiền \\\| có VAT/);
  });

  it("Excel có đủ mọi ý khớp bộ lọc ở sheet Chi tiết", () => {
    const sheets = dungSheet(tinhView(d, {}), {}, locY(d.y, {}));
    const chiTiet = sheets.find((s) => s.name === "Chi tiết")!;
    assert.equal(chiTiet.rows.length, 4);
    assert.ok(sheets.every((s) => s.headers.length <= 20));
  });
});
