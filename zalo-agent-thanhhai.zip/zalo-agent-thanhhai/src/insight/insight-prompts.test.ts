import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { promptGopChuDe, promptRutY } from "./insight-prompts.js";

describe("prompt insight - giữ dấu tiếng Việt", () => {
  // Bẫy đã dính thật: "Dùng dấu câu ASCII" làm model bỏ SẠCH dấu tiếng Việt ở
  // tên chủ đề/điểm chính/FAQ. Chữ ASCII không được xuất hiện lại trong prompt.
  it("không prompt nào nhắc chữ ASCII", () => {
    for (const p of [promptGopChuDe("cong_dong", ["[1] noi_dau | x | 1 | y"]), promptRutY("N", "cong_dong", ["TV001 (2026-09-20): a"])]) {
      assert.ok(!/ascii/i.test(p), p.slice(0, 80));
    }
  });

  it("prompt gộp dặn thẳng viết tiếng Việt có dấu", () => {
    assert.match(promptGopChuDe("doanh_nghiep", []), /tiếng Việt CÓ DẤU/);
  });
});
