import { activeThreadCount } from "../middleware/message-batcher.js";
import { createLogger } from "../shared/logger.js";

/**
 * Gọi model cho báo cáo insight - cố ý "hiền" với router LLM dùng chung.
 *
 * Bài học đo thật (2026-09-25): bản đầu gửi 3 yêu cầu RẤT lớn cùng lúc qua
 * đúng 9Router mà bot dùng để chat. Router ngộp ("upstream connection lost",
 * quá 240s), mỗi đoạn hỏng lại thử lại nhiều lần, còn chat thật của thành viên
 * phải xếp hàng chung - có lượt chat kéo quá 10 phút, người dùng tưởng hệ thống
 * treo. Vì vậy: MỘT yêu cầu mỗi lúc (xem insight-job.ts), trần thời gian ngắn
 * hơn, thử lại ít hơn, và NHƯỜNG ĐƯỜNG cho chat thật trước mỗi lần gọi.
 */

const log = createLogger("insight-llm");
const TRAN_MOI_LAN_MS = 150_000;
/** Chờ chat thật xong tối đa bao lâu trước MỖI lần gọi - quá thì vẫn gọi, không kẹt vĩnh viễn. */
const TRAN_NHUONG_MS = 90_000;

export type GoiLlm = (prompt: string, maxOutputTokens: number, signal?: AbortSignal) => Promise<string>;

export class LoiDaDung extends Error {
  constructor() {
    super("Đã dừng theo yêu cầu");
  }
}

const ngu = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => {
      clearTimeout(t);
      resolve();
    });
  });

/** Chờ tới khi không còn hội thoại nào đang chờ/đang xử lý (tối đa TRAN_NHUONG_MS). */
export async function nhuongChoChat(signal?: AbortSignal, demDangChat: () => number = activeThreadCount): Promise<void> {
  const batDau = Date.now();
  while (demDangChat() > 0 && Date.now() - batDau < TRAN_NHUONG_MS) {
    if (signal?.aborted) return;
    await ngu(1000, signal);
  }
}

export const goiLlmThat: GoiLlm = async (prompt, maxOutputTokens, signal) => {
  await nhuongChoChat(signal);
  if (signal?.aborted) throw new LoiDaDung();
  const { streamText } = await import("ai");
  const { resolveLanguageModel } = await import("../agent/llm-provider.js");
  const { chayStream } = await import("../agent/stream-text-result.js");
  const tran = AbortSignal.timeout(TRAN_MOI_LAN_MS);
  const kq = await chayStream(
    (onError) =>
      streamText({
        model: resolveLanguageModel(),
        prompt,
        maxOutputTokens,
        maxRetries: 1,
        abortSignal: signal ? AbortSignal.any([signal, tran]) : tran,
        onError,
      }),
    (loi) => log.warn({ err: loi }, "streamText lỗi khi phân tích insight"),
  );
  if (signal?.aborted) throw new LoiDaDung();
  return kq.text.trim();
};
