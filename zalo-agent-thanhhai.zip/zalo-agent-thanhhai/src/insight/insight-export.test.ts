import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";
import type { DuLieuInsight } from "./insight-types.js";

let dataDir: string;
let exp: typeof import("./insight-export.js");

before(async () => {
  dataDir = setupTestEnv();
  exp = await import("./insight-export.js");
});

after(async () => {
  (await import("../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});

const d: DuLieuInsight = {
  taoLuc: "2026-09-25T00:00:00.000Z",
  thongKe: { soDoan: 1, soDoanHong: 0 },
  nhom: [{ ten: "Nhóm A", pk: "cong_dong", soTin: 10 }],
  y: [
    {
      loai: "noi_dau",
      chuDe: "cài VPS",
      moTa: "khó cài",
      trich: "mãi không được",
      nhom: "Nhóm A",
      pk: "cong_dong",
      ngay: "2026-09-20",
      tv: "TV001",
      chuDeGop: "Cài đặt",
    },
  ],
  chuDe: [{ ten: "Cài đặt", pk: "cong_dong", loai: "noi_dau", moTa: "m" }],
  faq: [{ pk: "cong_dong", cauHoi: "Cài thế nào?" }],
  coHoi: [{ pk: "cong_dong", ten: "Gói cài sẵn", moTa: "m", duaTren: "cài VPS" }],
  tomTat: [{ pk: "cong_dong", y: ["Điểm A"] }],
};

describe("xuatInsight", () => {
  it("Excel và Word là file ZIP OOXML hợp lệ, tên file theo ngày tạo", async () => {
    for (const dd of ["xlsx", "docx"] as const) {
      const f = await exp.xuatInsight(d, {}, dd);
      assert.equal(f.bytes.subarray(0, 2).toString("latin1"), "PK", dd);
      assert.equal(f.tenFile, `bao-cao-insight-2026-09-25.${dd}`);
    }
  });

  it("Markdown có đủ các mục chính", async () => {
    const md = (await exp.xuatInsight(d, {}, "md")).bytes.toString("utf8");
    for (const muc of ["Chỉ số chính", "Chủ đề nổi bật", "Câu hỏi lặp lại", "Cơ hội", "Dữ liệu chi tiết"]) {
      assert.ok(md.includes(muc), muc);
    }
  });
});
