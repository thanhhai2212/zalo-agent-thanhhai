import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let job: typeof import("./insight-job.js");
let cfg: typeof import("./insight-group-config.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  database = await import("../conversation/database.js");
  job = await import("./insight-job.js");
  cfg = await import("./insight-group-config.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  database.db.exec("DELETE FROM messages; DELETE FROM threads; DELETE FROM runtime_settings WHERE key = 'insight_group_config'");
  fs.rmSync(path.join(dataDir, "insight"), { recursive: true, force: true });
});

let phut = 0;
function them(threadId: string, ten: string, sid: string, sn: string, c: string) {
  database.db
    .prepare("INSERT OR IGNORE INTO threads (account_id, thread_id, thread_type, display_name) VALUES ('acc', ?, 1, ?)")
    .run(threadId, ten);
  const t = new Date(Date.parse("2026-09-20T00:00:00Z") + phut++ * 60_000).toISOString();
  database.db
    .prepare("INSERT INTO messages (account_id, thread_id, role, sender_id, sender_name, content, created_at) VALUES ('acc', ?, 'user', ?, ?, ?, ?)")
    .run(threadId, sid, sn, `${sn}: ${c}`, t);
}

/** Model giả: mỗi đoạn trả 1 ý, mang mã TV của dòng đầu tiên trong đoạn. */
function modelGia(ghi: string[], hongKhi?: (p: string) => boolean) {
  return async (p: string) => {
    ghi.push(p);
    if (!p.includes("TIN NHẮN:")) return JSON.stringify({ chu_de: [], faq: [], co_hoi: [], tom_tat: [] });
    if (hongKhi?.(p)) throw new Error("router sập");
    const tv = /(TV[0-9A-F]+) \(/.exec(p)?.[1] ?? "";
    return JSON.stringify([{ loai: "noi_dau", chu_de: "cài VPS", mo_ta: "m", trich: "t", tv, ngay: "2026-09-20" }]);
  };
}

describe("cập nhật tăng dần", () => {
  it("lần 2 chỉ gửi tin MỚI, giữ ý cũ, cộng dồn số tin, mã người gửi không đổi", async () => {
    them("g1", "Nhóm A", "u1", "An", "tin cũ đủ dài để không bị coi là rác");
    const ghi1: string[] = [];
    const d1 = await job.chayInsight(modelGia(ghi1));
    assert.equal(d1.cheDo, "toan_bo");
    assert.equal(d1.y.length, 1);

    them("g1", "Nhóm A", "u1", "An", "tin MỚI hôm nay cũng đủ dài nhé");
    const ghi2: string[] = [];
    const d2 = await job.chayInsight(modelGia(ghi2));
    const map2 = ghi2.filter((p) => p.includes("TIN NHẮN:"));
    assert.equal(map2.length, 1);
    assert.ok(map2[0]!.includes("tin MỚI") && !map2[0]!.includes("tin cũ"), "chỉ tin mới được gửi");
    assert.equal(d2.cheDo, "cap_nhat");
    assert.equal(d2.y.length, 2, "ý cũ + ý mới");
    assert.equal(d2.nhom[0]!.soTin, 2);
    assert.equal(d2.y[0]!.tv, d2.y[1]!.tv, "cùng một người -> cùng mã ẩn danh ở cả 2 lượt");
    assert.match(d2.y[0]!.tv, /^TV[0-9A-F]{6}$/);
  });

  it("không có tin mới: không gọi model lần nào, giữ nguyên kết quả gộp", async () => {
    them("g1", "Nhóm A", "u1", "An", "tin cũ đủ dài để không bị coi là rác");
    await job.chayInsight(modelGia([]));
    const ghi: string[] = [];
    const d = await job.chayInsight(modelGia(ghi));
    assert.equal(ghi.length, 0);
    assert.equal(d.y.length, 1);
  });

  it("đoạn hỏng: mốc không vượt qua nó, lượt sau làm lại đúng phần đó, không nhân đôi ý", async () => {
    them("g1", "Nhóm A", "u1", "An", "tin cũ đủ dài để không bị coi là rác");
    await job.chayInsight(modelGia([]));
    them("g1", "Nhóm A", "u1", "An", "tin mới sẽ gặp lúc router sập");
    const d2 = await job.chayInsight(modelGia([], (p) => p.includes("router sập")));
    assert.equal(d2.y.length, 1, "đoạn hỏng không thêm ý nào");
    const ghi3: string[] = [];
    const d3 = await job.chayInsight(modelGia(ghi3));
    assert.ok(ghi3.some((p) => p.includes("tin mới sẽ gặp")), "lượt sau làm lại đoạn hỏng");
    assert.equal(d3.y.length, 2);
  });

  it("bỏ chọn một nhóm thì ý của nhóm đó biến khỏi dashboard; 'toàn bộ' bỏ qua mốc cũ", async () => {
    them("g1", "Nhóm A", "u1", "An", "tin nhóm A đủ dài để không bị coi là rác");
    them("g2", "Nhóm B", "u2", "Bình", "tin nhóm B đủ dài để không bị coi là rác");
    await job.chayInsight(modelGia([]));
    cfg.datCauHinhNhom("g2", { boQua: true });
    const d = await job.chayInsight(modelGia([]));
    assert.deepEqual([...new Set(d.y.map((y) => y.nhom))], ["Nhóm A"]);
    const ghi: string[] = [];
    const dToanBo = await job.chayInsight(modelGia(ghi), undefined, { toanBo: true });
    assert.equal(dToanBo.cheDo, "toan_bo");
    assert.ok(ghi.some((p) => p.includes("tin nhóm A")), "chạy lại toàn bộ gửi cả tin cũ");
  });
});

describe("tự tăng tốc", () => {
  async function doSongSongToiDa(demDangChat: () => number): Promise<number> {
    for (let k = 0; k < 170; k++) them("g1", "Nhóm A", `u${k % 5}`, `Người ${k % 5}`, `tin số ${k} đủ dài để không bị coi là rác`);
    let dangChay = 0;
    let toiDa = 0;
    await job.chayInsight(
      async (p) => {
        if (!p.includes("TIN NHẮN:")) return "{}";
        dangChay++;
        toiDa = Math.max(toiDa, dangChay);
        await new Promise((r) => setTimeout(r, 30));
        dangChay--;
        return "[]";
      },
      undefined,
      { demDangChat },
    );
    return toiDa;
  }

  it("vắng người: chạy 2 đoạn cùng lúc", async () => {
    assert.equal(await doSongSongToiDa(() => 0), 2);
  });

  it("có người chat: chỉ 1 đoạn mỗi lúc", async () => {
    assert.equal(await doSongSongToiDa(() => 1), 1);
  });
});
