import { THREAD_DENY_ALL_TOOLS } from "../conversation/thread-permission-constants.js";
import { TOOL_KEYS } from "./tools/tool-registry.js";

/**
 * Áp override tool riêng theo THREAD (ma trận phân quyền theo liên hệ, trang
 * dashboard "Phân quyền Bot") lên account trước khi đưa vào `ToolScope` của
 * `tool-registry.ts`.
 *
 * Đây là phép HỢP (union) chứ không phải ghi đè: threadDisabledTools chỉ SIẾT
 * THÊM, không bao giờ mở lại tool mà account/agent đã tắt - đúng bất biến
 * "tool dùng được là phần KHÔNG BÊN NÀO tắt" đã có ở tool-registry.ts. Thread
 * là lớp thứ BA cùng chiều với agent/account, không phải lớp thay thế.
 */
export function applyThreadToolOverride<T extends { disabledTools: string[] }>(
  account: T,
  threadDisabledTools: string[],
): T {
  if (threadDisabledTools.length === 0) return account;
  const threadTools = threadDisabledTools.includes(THREAD_DENY_ALL_TOOLS)
    ? TOOL_KEYS
    : threadDisabledTools;
  const merged = new Set([...account.disabledTools, ...threadTools]);
  return { ...account, disabledTools: [...merged] };
}
