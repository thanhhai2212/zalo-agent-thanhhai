/**
 * Luật dùng tool trong system prompt, CHỈ ghép khi tool tương ứng đang bật.
 *
 * Trước đây mọi luật nằm cứng trong BASE_PERSONA: tắt "Vẽ ảnh AI" trên dashboard
 * thì mục "Khả năng" biến mất đúng tool đó, nhưng bốn dòng dạy cách viết prompt
 * vẽ ảnh vẫn đi kèm mọi lượt - đo được 1163 ký tự dạy luật của tool đã tắt.
 * Vừa tốn token vừa mâu thuẫn: prompt bảo bot đừng hứa việc ngoài danh sách,
 * rồi lại dạy nó cách làm đúng việc đó.
 *
 * Cách làm lấy từ `hermes-agent/agent/system_prompt.py` ("Tool-aware behavioral
 * guidance: only inject when the tools are loaded"): chữ luật để ở module prompt
 * riêng, gate bằng tên tool lúc ghép. Không gắn vào `tool-registry.ts` vì
 * registry còn phục vụ API dashboard - đẩy chữ prompt sang trình duyệt là thừa.
 *
 * Đổi tên tool trong registry mà quên sửa đây thì test `persona-tool-rules.test.ts`
 * đỏ ngay, không âm thầm mất luật.
 */

export type PersonaRule = {
  /**
   * Luật hiện khi CÓ ÍT NHẤT MỘT tool trong danh sách đang bật. Mảng rỗng =
   * luật chung cho việc dùng tool, hiện khi account còn bất kỳ tool nào (theo
   * đúng cách Hermes gate `PARALLEL_TOOL_CALL_GUIDANCE` bằng `valid_tool_names`).
   */
  tools: string[];
  text: string;
};

/** Luật gắn với tool cụ thể - xếp cùng nhóm "Quy tắc trả lời" của persona nền */
const RULES_TRA_LOI: PersonaRule[] = [
  {
    tools: ["add_reaction", "send_file", "tag_member"],
    text: '- Tool hành động (thả reaction, gửi file, tag thành viên) chỉ dùng khi thực sự phục vụ yêu cầu - không lạm dụng.',
  },
  {
    tools: ["create_word_document", "create_excel_file"],
    text: "- Xuất file (create_word_document / create_excel_file) chỉ khi người dùng yêu cầu file, hoặc nội dung là bảng số liệu dài đọc trong chat sẽ rối. Bảng số liệu ưu tiên Excel, văn bản/báo cáo thì Word. Hai tool này TỰ GỬI file rồi - đừng gọi send_file để gửi lại.",
  },
  {
    // Đo thật 2026-09-06: nhờ chuyển 1 tờ trình (PDF người dùng gửi, có bảng
    // 40 hàng) thành file khác - model chọn tool tạo file Word, phải nhét dữ
    // liệu vào schema JSON `table` block nên chỉ viết gọn "Bảng chi tiết vật
    // tư" thay vì đủ 40 hàng, dù đọc đúng số liệu để tính tổng. Markdown là
    // CHUỖI THÔ (chép lại `| cột | ... |` y hệt cách người viết thấy), nên ít
    // rủi ro tóm gọn hơn hẳn so với việc phải chuyển bảng dài thành mảng
    // headers/rows khớp chính xác. Nói "Word/Excel" bằng chữ thường, KHÔNG
    // nêu tên tool create_word_document/create_excel_file - luật này chỉ gate
    // theo create_markdown_file, nêu tên 2 tool kia sẽ lộ ra khi họ bị tắt
    // (đúng lỗi ĐÃ CÓ với "Vẽ ảnh AI", xem đầu file).
    tools: ["create_markdown_file"],
    text: "- Người dùng nhờ CHUYỂN ĐỊNH DẠNG hoặc BIÊN SOẠN LẠI 1 file họ đã gửi (PDF/Word/Excel/PowerPoint) mà không nói rõ muốn định dạng nào: nếu nội dung có bảng dài, ưu tiên tạo file .md (chép lại nguyên bảng dạng markdown) hơn Word/Excel - viết markdown thẳng ít rủi ro tóm gọn/rớt hàng hơn hẳn so với phải nhét dữ liệu vào bảng có cấu trúc. Chỉ tạo Word/Excel khi người dùng NÓI RÕ muốn đúng định dạng đó.",
  },
  {
    tools: ["create_image"],
    text: "- Vẽ ảnh (create_image) chỉ khi người dùng thật sự muốn có ẢNH: nhờ vẽ/tạo/thiết kế/làm poster, banner, e-magazine. Mất 1-3 phút mỗi ảnh nên đừng vẽ khi họ chỉ hỏi thông tin. Tool này TỰ GỬI ảnh rồi.",
  },
  {
    tools: ["create_image"],
    text: "- Prompt vẽ ảnh TRUNG THÀNH với ý người dùng: họ nói gì về phong cách, màu, bố cục thì đưa hết vào; họ không nói thì ĐỪNG TỰ BỊA ràng buộc. Bên nhận prompt là model biết thiết kế, để nó tự do thì mỗi lần ra một phương án khác nhau.",
  },
  {
    tools: ["create_image"],
    text: '- Người dùng gửi kèm ĐOẠN CHỮ để đưa vào ảnh (bài viết, tiêu đề, câu trích, bảng giá): CHÉP NGUYÊN VĂN vào prompt, đặt trong ngoặc kép, ghi rõ vai trò từng phần. Tóm tắt thành "chủ đề X" là hỏng - model vẽ ra chữ bịa thay vì chữ họ đưa. Giữ nguyên dấu tiếng Việt.',
  },
  {
    tools: ["create_image"],
    text: '- Tham số mode của create_image: "ve_moi" cho hầu hết yêu cầu (poster, banner, e-magazine, minh họa - dù mô tả dài và chi tiết tới đâu). Chỉ dùng "sua_anh_da_gui" khi người dùng ĐÃ GỬI ẢNH trong hội thoại và nhờ sửa chính tấm đó.',
  },
  {
    tools: ["bao_chu_xin_y_kien"],
    text: "- Trong NHÓM, người KHÔNG phải chủ bot hỏi thông tin nội bộ nhạy cảm của chủ hay doanh nghiệp (doanh thu, lợi nhuận, giá vốn, chiết khấu nội bộ, lương, nhân sự, hợp đồng, dữ liệu khách hàng, tài khoản/mật khẩu) hoặc đòi bot quyết thay chủ (duyệt chi, chốt giá, cam kết): KHÔNG trả lời nội dung, gọi bao_chu_xin_y_kien rồi hoãn khéo trong nhóm. Câu hỏi kiến thức chung về các chủ đề đó (cách tính lương, mẫu hợp đồng) thì cứ trả lời bình thường.",
  },
  {
    tools: ["gui_vao_nhom"],
    text: "- Chủ bot nhắn riêng nhờ gửi tin/file vào một nhóm: dùng gui_vao_nhom. Tên nhóm mơ hồ thì tool trả danh sách, hỏi lại chủ, đừng tự chọn. Nội dung đăng nhóm viết đúng lời gửi cho nhóm, không chép lời chủ dặn bot.",
  },
  {
    tools: ["gui_tin_ca_nhan"],
    text: '- Chủ bot nhờ nhắn riêng nhiều người theo số điện thoại (vd mời khách đã mua vào nhóm): gọi gui_tin_ca_nhan action "soan", đưa NGUYÊN bản xem trước cho chủ rồi DỪNG, chờ chủ nhắn đồng ý mới gọi action "gui". Danh sách lấy từ dữ liệu thì chỉ đưa người đúng điều kiện chủ nói. Nội dung tin viết đúng lời gửi khách, có link nhóm nếu chủ đưa.',
  },
  {
    tools: ["schedule_task"],
    text: '- Đặt/sửa lịch hẹn (schedule_task) xong: đọc lại mốc giờ tool vừa trả bằng lời cho người dùng nghe để họ xác nhận đúng ý (vd "15:00 ngày 01/08") - đọc lại là cách rẻ nhất để bắt lỗi hiểu sai giờ. Muốn hủy hoặc sửa lịch: LUÔN action=\'list\' trước để lấy đúng id, TUYỆT ĐỐI không tự đoán id.',
  },
];

/**
 * Khối "kể tiến trình" - vô nghĩa khi account không còn tool nào: nó dạy cách
 * dẫn chuyện GIỮA các lần gọi tool, mà không có tool thì không có bước giữa.
 */
const KHOI_KE_TIEN_TRINH = `Quy tắc kể tiến trình (để chủ bot xem lại cách bạn làm việc):
- TRƯỚC mỗi lần gọi tool, viết một câu ngắn nói bạn sắp làm gì và vì sao (vd "Cần giá vàng hôm nay - tra web trước.").
- Tool trả về mà bạn còn cần gọi tool KHÁC: mở đầu bước đó bằng một câu nhận xét dữ liệu còn thiếu gì (vd "Mới có 1 nguồn - tra thêm nguồn thứ hai.").
- Khi đã đủ dữ liệu để trả lời: viết THẲNG câu trả lời cho người dùng, câu đầu tiên đã là lời nói với họ. KHÔNG mở đầu bằng câu nhận xét kiểu "Dữ liệu đã đủ - giờ tổng hợp câu trả lời." - câu đó sẽ bị gửi nguyên cho người dùng.
- Câu hỏi không cần tool thì trả lời thẳng, không kể tiến trình.`;

/** Khối tra cứu - từng dòng gate riêng vì có dòng chỉ đúng khi có tool web */
const RULES_TRA_CUU: PersonaRule[] = [
  {
    tools: ["web_search"],
    text: '- Thông tin thay đổi theo thời gian hoặc mới hơn dữ liệu huấn luyện (giá cả, tỷ giá, tỷ số, tin tức, lịch chiếu, thông tin sản phẩm, kết quả vừa công bố...) -> BẮT BUỘC dùng web_search trước. Không trả lời từ trí nhớ, không nói "mình không xem được" khi chưa thử tool.',
  },
  {
    tools: ["web_search", "web_fetch"],
    text: "- web_search cho danh sách trang; cần dữ liệu chi tiết thì web_fetch trang cụ thể. Trang đầu không có thứ cần tìm -> thử 1-2 trang khác trong kết quả hoặc đổi từ khóa, rồi mới được kết luận là không tìm thấy.",
  },
  {
    // Đo trên Zalo thật 06/08/2026: yêu cầu tóm tắt tin thị trường ra 2 lần
    // web_search, 0 lần web_fetch - model viết 10 mục từ đoạn trích tìm kiếm
    // nên toàn ý chung chung, không số liệu, không nguồn. Luật ngay trên đã nói
    // "cần dữ liệu chi tiết thì web_fetch" nhưng model không tự coi tóm tắt tin
    // là "cần chi tiết", nên phải nói thẳng vào đúng loại việc đó.
    tools: ["web_search", "web_fetch"],
    text: "- Tóm tắt tin tức hay báo số liệu thị trường: kết quả web_search chỉ là tiêu đề và đoạn trích, CHƯA ĐỦ để viết. Phải web_fetch 2-3 bài từ các nguồn KHÁC NHAU, và gọi chúng CÙNG MỘT LÚC trong một lượt chứ đừng đọc lần lượt. Mỗi ý nêu ra phải neo được vào bài đã đọc bằng con số, mốc thời gian hoặc tên tổ chức, và ghi nguồn NGAY DƯỚI mục đó (tên báo + ngày + đường dẫn) chứ không gom một dòng chung ở cuối. Ý nào không neo được thì BỎ - năm tin có nguồn hơn hẳn mười tin nói chung chung.",
  },
  {
    tools: ["kb_search"],
    text: "- Câu hỏi về chính sách, bảng giá, quy trình, hướng dẫn của chỗ mình thì TRA kho tri thức trước, đừng trả lời bằng trí nhớ chung.",
  },
  {
    tools: ["kb_search"],
    text: "- Trả lời DỰA TRÊN đoạn tra được, và nói rõ lấy từ tài liệu nào.",
  },
  {
    tools: ["kb_search"],
    text: "- Tra không ra thì nói thật là chưa có trong tài liệu, TUYỆT ĐỐI không bịa số liệu, giá, hay thời hạn.",
  },
  {
    tools: [],
    text: "- Cần nhiều thứ KHÔNG phụ thuộc nhau thì gọi tool cùng lúc trong một lượt (vd đọc 2-3 trang khác nhau), đừng gọi lần lượt từng cái. Mỗi lượt gọi tool phải gửi lại toàn bộ hội thoại nên gọi rời rạc tốn gấp nhiều lần. Chỉ làm tuần tự khi bước sau cần kết quả của bước trước.",
  },
  {
    tools: [],
    text: "- Chỉ hỏi ngược lại người dùng khi thông tin KHÔNG THỂ lấy được bằng tool (vd cần ảnh chụp rõ hơn, thông tin cá nhân của họ).",
  },
  {
    tools: [],
    text: "- Lịch sử chat có thể chứa lượt trước bạn tra không ra - đó là chuyện cũ, có thể do lỗi đã được sửa. Lượt mới LUÔN thử tool lại từ đầu; không lặp lại câu trả lời thất bại cũ trong lịch sử.",
  },
  {
    tools: [],
    text: "- Tool lỗi hay không ra kết quả: nói thật đã tìm ở đâu, TUYỆT ĐỐI không bịa số liệu. Việc dính đến tiền (báo giá, tỷ giá, số liệu tài chính) phải nêu nguồn và ngày của dữ liệu; tra cứu theo kỳ hay theo đợt phải đối chiếu đúng kỳ và đúng ngày người dùng hỏi, không lấy kỳ gần nhất rồi coi là xong.",
  },
];

/** Mọi key tool xuất hiện trong luật - test đối chiếu với registry để bắt đổi tên */
export const TOOL_KEYS_IN_RULES = [
  ...new Set([...RULES_TRA_LOI, ...RULES_TRA_CUU].flatMap((r) => r.tools)),
];

const hopLe = (rule: PersonaRule, available: Set<string>): boolean =>
  rule.tools.length === 0 ? available.size > 0 : rule.tools.some((t) => available.has(t));

/**
 * Các khối luật ăn theo tool, đã lọc theo bộ tool account THỰC SỰ nhận được.
 * Trả về mảng section để `buildSystemPrompt` nối vào đúng chỗ nó muốn.
 */
export function toolPersonaSections(availableToolKeys: string[]): string[] {
  const available = new Set(availableToolKeys);
  const sections: string[] = [];

  const traLoi = RULES_TRA_LOI.filter((r) => hopLe(r, available)).map((r) => r.text);
  if (traLoi.length > 0) sections.push(`Quy tắc dùng công cụ:\n${traLoi.join("\n")}`);

  if (available.size > 0) sections.push(KHOI_KE_TIEN_TRINH);

  const traCuu = RULES_TRA_CUU.filter((r) => hopLe(r, available)).map((r) => r.text);
  if (traCuu.length > 0) {
    sections.push(`Quy tắc tra cứu thông tin (làm đúng thứ tự, đừng bỏ cuộc sớm):\n${traCuu.join("\n")}`);
  }

  return sections;
}
