import type { PromptMemory } from "./persona-prompt.js";

export type ThreadPrivacyTier = "normal" | "restricted";

/**
 * Áp chính sách riêng tư của liên hệ (ma trận phân quyền, trang dashboard
 * "Phân quyền Bot") lên dữ liệu đưa vào system prompt.
 *
 * `restricted` chặn toàn bộ fact bền vì bảng memories hiện chưa có nhãn phân
 * loại theo chủ đề. Summary vẫn được giữ vì nó chỉ thuộc đúng thread hiện tại,
 * không chảy dữ liệu từ người hoặc nhóm khác vào đây.
 *
 * Đây là lớp NHẮC (prompt) - lớp CHẶN CỨNG tương ứng nằm ở `save-memory-tool.ts`
 * (đọc thẳng `getThreadPrivacyTier`, không đi qua hàm này): "restricted" phải
 * vừa lọc được thứ ĐÃ nhớ khỏi ngữ cảnh, vừa khóa được việc nhớ THÊM - hai việc
 * khác nhau, không hàm nào một mình làm đủ cả hai.
 */
export function applyThreadPrivacyPolicy(
  memory: PromptMemory,
  tier: ThreadPrivacyTier,
): PromptMemory {
  if (tier === "normal") return memory;
  return { ...memory, facts: [], restricted: true };
}
