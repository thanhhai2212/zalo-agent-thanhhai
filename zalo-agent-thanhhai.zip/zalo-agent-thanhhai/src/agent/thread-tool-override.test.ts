import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { applyThreadToolOverride } from "./thread-tool-override.js";
import { TOOL_KEYS } from "./tools/tool-registry.js";

describe("applyThreadToolOverride", () => {
  it("không có override thread thì trả về account nguyên vẹn (không tạo object mới thừa)", () => {
    const account = { disabledTools: ["web_search"], other: "x" };
    const result = applyThreadToolOverride(account, []);
    assert.equal(result, account);
  });

  it("override thread CỘNG THÊM vào disabledTools của account - phép hợp, không phải ghi đè", () => {
    const account = { disabledTools: ["web_search"], other: "x" };
    const result = applyThreadToolOverride(account, ["create_image"]);
    assert.deepEqual(result.disabledTools.sort(), ["create_image", "web_search"]);
    assert.equal(result.other, "x", "field khác của account phải giữ nguyên");
  });

  it("override thread trùng tool đã tắt ở account thì không lặp trong danh sách", () => {
    const account = { disabledTools: ["web_search"] };
    const result = applyThreadToolOverride(account, ["web_search", "create_image"]);
    assert.deepEqual(result.disabledTools.sort(), ["create_image", "web_search"]);
  });

  it("KHÔNG bao giờ mở lại tool account đã tắt - override thread chỉ SIẾT thêm", () => {
    const account = { disabledTools: ["web_search", "send_file"] };
    const result = applyThreadToolOverride(account, []);
    assert.deepEqual(result.disabledTools.sort(), ["send_file", "web_search"]);
  });

  it("sentinel DB hỏng tắt toàn bộ tool theo hướng fail-closed", () => {
    const result = applyThreadToolOverride(
      { disabledTools: [] },
      ["__deny_all_thread_tools__"],
    );
    assert.deepEqual([...result.disabledTools].sort(), [...TOOL_KEYS].sort());
  });
});
