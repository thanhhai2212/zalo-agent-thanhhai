import type { Tool } from "ai";

/**
 * Bọc `execute` của mọi tool để đếm số lần ĐƯỢC GỌI trong một lần chạy model.
 *
 * Dùng để quyết định có được THỬ LẠI CẢ LƯỢT khi kết nối tới provider đứt giữa
 * chừng không: chưa tool nào chạy thì thử lại vô hại; đã có tool chạy (gửi
 * file, đặt lịch, đuổi thành viên...) thì chạy lại lượt là làm lại việc đó
 * hai lần - không được thử. Đếm MỌI tool chứ không chọn lọc "tool có tác dụng
 * phụ": danh sách đó đổi theo từng đợt thêm tool (kể cả tool MCP ngoài), bỏ
 * sót một cái là gửi trùng thật; còn đếm dư chỉ làm mất một lần thử lại.
 *
 * `khiBatDau`/`khiXong` còn dùng để TẠM DỪNG canh gác đứng im trong lúc tool
 * chạy (xem stream-idle-watchdog.ts).
 */
export function demLanGoiTool<T extends Record<string, Tool>>(
  tools: T,
  khiBatDau: () => void,
  khiXong: () => void = () => {},
): T {
  const ra: Record<string, Tool> = {};
  for (const [ten, t] of Object.entries(tools)) {
    const goc = t.execute;
    ra[ten] = goc
      ? ({
          ...t,
          execute: async (input: unknown, options: unknown) => {
            khiBatDau();
            try {
              return await (goc as (i: unknown, o: unknown) => unknown)(input, options);
            } finally {
              khiXong();
            }
          },
        } as Tool)
      : t;
  }
  return ra as T;
}
