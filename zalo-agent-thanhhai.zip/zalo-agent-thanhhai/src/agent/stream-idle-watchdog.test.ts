import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { MockLanguageModelV4 } from "ai/test";
import { ThreadType, type API } from "zca-js";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";
import { thanhKetQuaStream, type KetQuaGenerate } from "./streaming-model-test-helper.js";
import { LoiLuongDungIm, voiCanhGacDungIm } from "./stream-idle-watchdog.js";
import type { AccountConfig } from "../config/account-store.js";
import type { ParsedMessage } from "../zalo/zalo-message-parser.js";

const ngu = (ms: number) => new Promise((r) => setTimeout(r, ms));

describe("voiCanhGacDungIm", () => {
  it("không nhận mẩu dữ liệu nào thì cắt và ném LoiLuongDungIm", async () => {
    await assert.rejects(
      voiCanhGacDungIm(50, undefined, (signal) => new Promise((_, reject) => signal.addEventListener("abort", () => reject(new Error("aborted"))))),
      (e: unknown) => e instanceof LoiLuongDungIm && /stream stalled/.test(e.message),
    );
  });

  it("dữ liệu đổ về đều đặn thì KHÔNG cắt dù tổng thời gian vượt trần đứng im", async () => {
    const kq = await voiCanhGacDungIm(60, undefined, async (_signal, canh) => {
      for (let i = 0; i < 6; i++) {
        await ngu(25);
        canh.nhip();
      }
      return "xong";
    });
    assert.equal(kq, "xong");
  });

  it("TẠM DỪNG khi tool đang chạy: tool chạy lâu hơn trần đứng im vẫn không bị cắt", async () => {
    const kq = await voiCanhGacDungIm(50, undefined, async (signal, canh) => {
      canh.batDauTool();
      await ngu(200);
      assert.equal(signal.aborted, false, "không được cắt giữa lúc tool chạy");
      canh.xongTool();
      canh.nhip();
      return "tool xong";
    });
    assert.equal(kq, "tool xong");
  });

  it("tool xong mà model vẫn im thì canh gác chạy lại và cắt", async () => {
    await assert.rejects(
      voiCanhGacDungIm(50, undefined, async (signal, canh) => {
        canh.batDauTool();
        await ngu(100);
        canh.xongTool();
        await new Promise((_, reject) => signal.addEventListener("abort", () => reject(new Error("aborted"))));
      }),
      LoiLuongDungIm,
    );
  });

  it("caller tự hủy thì giữ lỗi gốc, không đổ cho đứng im", async () => {
    const ngoai = new AbortController();
    setTimeout(() => ngoai.abort(), 10);
    await assert.rejects(
      voiCanhGacDungIm(5000, ngoai.signal, (signal) => new Promise((_, reject) => signal.addEventListener("abort", () => reject(new Error("lỗi gốc"))))),
      /lỗi gốc/,
    );
  });
});

// ===== Tích hợp với vòng agent: model đứng im hoàn toàn ở lần gọi đầu =====

let dataDir: string;
let loop: typeof import("./agent-loop.js");

before(async () => {
  dataDir = setupTestEnv({ LLM_STREAM_IDLE_TIMEOUT_MS: "300" });
  loop = await import("./agent-loop.js");
});

after(async () => {
  (await import("../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});

const account: AccountConfig = {
  id: "acc-dung-im",
  label: "Test",
  enabled: true,
  agentId: "khong-co-agent-nay",
  allowlist: { mode: "all", userIds: [] },
  groupRequireMention: true,
  respondToGroups: true,
  groupPassiveListen: true,
  autoReactEnabled: false,
  autoReactIcon: "heart",
  typingIndicatorEnabled: false,
  disabledTools: [],
  ownerUserId: "",
  loai: "ca_nhan",
  coBotToken: false,
  autoKickFloodEnabled: false,
};

const tinNhan = (): ParsedMessage => ({
  accountId: account.id,
  threadId: "thread-dung-im",
  threadType: ThreadType.User,
  isGroup: false,
  senderId: "user-1",
  senderName: "Hải",
  text: "hôm nay ngày mấy",
  images: [],
  msgId: "m1",
  cliMsgId: "c1",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
});

const usage = { inputTokens: { total: 120, noCache: 120, cacheRead: 0, cacheWrite: 0 }, outputTokens: { total: 30, text: 30, reasoning: 0 } };
const traLoi = (text: string) => ({ content: [{ type: "text" as const, text }], finishReason: "stop" as const, usage, warnings: [] });
const goiTool = () => ({
  content: [{ type: "tool-call" as const, toolCallId: "call-1", toolName: "get_datetime", input: "{}" }],
  finishReason: "tool-calls" as const,
  usage,
  warnings: [],
});

/** Luồng không bao giờ gửi mẩu nào - chỉ đóng (báo lỗi) khi bị hủy, như fetch thật. */
function luongDungIm(signal?: AbortSignal) {
  return {
    stream: new ReadableStream({
      start(ctrl) {
        signal?.addEventListener("abort", () => ctrl.error(new Error("This operation was aborted")));
      },
    }),
  };
}

function dungModel(kichBan: ("dung_im" | "tra_loi" | "goi_tool")[]) {
  const dem = { lan: 0 };
  const model = new MockLanguageModelV4({
    doStream: async (options) => {
      const buoc = kichBan[Math.min(dem.lan, kichBan.length - 1)]!;
      dem.lan++;
      if (buoc === "dung_im") return luongDungIm(options.abortSignal) as never;
      return thanhKetQuaStream((buoc === "goi_tool" ? goiTool() : traLoi("trả lời sau khi nối lại")) as KetQuaGenerate);
    },
  });
  const chay = () => loop.runAgentTurn({ api: {} as API, account, batch: [tinNhan()], trace: [], resolveModel: () => model });
  return { dem, chay };
}

describe("vòng agent - model đứng im", () => {
  it("đứng im ở lần đầu, chưa tool nào chạy: cắt sớm rồi thử lại 1 lần, trả lời được", async () => {
    const t = Date.now();
    const { dem, chay } = dungModel(["dung_im", "tra_loi"]);
    const ket = await chay();
    assert.equal(ket.text, "trả lời sau khi nối lại");
    assert.equal(dem.lan, 2);
    assert.ok(Date.now() - t < 5000, "cắt theo trần đứng im, không chờ tới trần cả lượt");
  });

  it("đứng im mãi: thử lại đúng 1 lần rồi báo lỗi đứng im", async () => {
    const { dem, chay } = dungModel(["dung_im"]);
    await assert.rejects(chay(), /stream stalled/);
    assert.equal(dem.lan, 2);
  });

  it("đứng im SAU khi tool đã chạy: KHÔNG chạy lại cả lượt", async () => {
    const { dem, chay } = dungModel(["goi_tool", "dung_im"]);
    await assert.rejects(chay(), /stream stalled/);
    assert.equal(dem.lan, 2, "bước 1 gọi tool, bước 2 đứng im - không có lần thứ 3");
  });
});
