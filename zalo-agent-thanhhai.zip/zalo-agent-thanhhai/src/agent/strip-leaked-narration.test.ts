import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { boCauTuongThuatDau } from "./strip-leaked-narration.js";

const TRA_LOI = "Dạ anh Minh, Minh vừa kiểm tra ngay luồng chat riêng với bạn Bảo Võ.";

describe("boCauTuongThuatDau", () => {
  it("cắt đúng các câu tường thuật THẬT đã lọt ra Zalo (đo trên VPS 2026-09-26)", () => {
    const that = [
      "Đã kiểm tra luồng chat riêng với Bảo Võ và hệ thống tự động, dữ liệu đã đầy đủ để báo cáo và đưa phương án xử lý cho anh Minh.",
      "Đã đủ thông tin về WeKnora từ Tencent - tiến hành tổng hợp câu trả lời theo đúng cấu trúc.",
      "Đã gửi sticker xong, giờ soạn câu trả lời dí dỏm đáp lại anh Đạt.",
      "Dữ liệu từ Thông tư 88/2021/TT-BTC đã đầy đủ và chính xác - tiến hành tổng hợp câu trả lời cho bác Danh Van.",
      "Đã tạo xong file markdown, giờ tổng hợp các ý trọng tâm gửi cho anh An qua chat.",
      "Dữ liệu về BrowserAct đã đủ rõ từ tài liệu kỹ thuật và cộng đồng.",
    ];
    for (const c of that) {
      assert.equal(boCauTuongThuatDau(`${c}${TRA_LOI}`), TRA_LOI, `dính liền: ${c}`);
      assert.equal(boCauTuongThuatDau(`${c}\n\n${TRA_LOI}`), TRA_LOI, `xuống dòng: ${c}`);
    }
  });

  it("KHÔNG cắt câu trả lời thật", () => {
    const giu = [
      "Dạ, hồ sơ của anh đã đủ để nộp rồi ạ. Anh mang bản gốc tới là xong.",
      "Chào bạn, giờ trả lời nhanh câu hỏi của bạn nhé. Giá khoá học là 2 triệu.",
      "Giá vàng SJC hôm nay là 120 triệu/lượng. Tăng 500 nghìn so với hôm qua.",
      "Theo Thông tư 88/2021, hộ kinh doanh ghi sổ theo mẫu S1. Chi tiết như sau.",
    ];
    for (const c of giu) assert.equal(boCauTuongThuatDau(c), c, c);
  });

  it("tường thuật dính liền tiêu đề markdown: cắt đúng câu, giữ nguyên tiêu đề (ca thật)", () => {
    const bao = "# BÁO CÁO NGHIÊN CỨU CÁ HỀ\n\nNội dung chi tiết từng nguồn ở dưới.";
    const c = "Đã thu thập đầy đủ tài liệu từ WoRMS, FishBase và IUCN - tiến hành tổng hợp báo cáo chuyên sâu.";
    assert.equal(boCauTuongThuatDau(`${c}${bao}`), bao);
  });

  it("chỉ có mỗi câu tường thuật (không còn gì sau) thì giữ nguyên, không trả rỗng", () => {
    const c = "Dữ liệu đã đủ - giờ tổng hợp câu trả lời.";
    assert.equal(boCauTuongThuatDau(c), c);
  });
});
