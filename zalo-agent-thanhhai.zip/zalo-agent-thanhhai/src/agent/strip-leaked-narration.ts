/**
 * Cắt câu "kể tiến trình" lọt vào ĐẦU câu trả lời chốt.
 *
 * Persona dạy model viết một câu tường thuật trước/sau mỗi lần gọi tool (khối
 * "kể tiến trình" ở `persona-tool-rules.ts`, để chủ bot đọc trace). Câu đó chỉ
 * được nằm ở bước GIỮA, nhưng thỉnh thoảng model viết nó cả ở bước cuối rồi nối
 * thẳng câu trả lời - người nhận thấy kiểu "Dữ liệu đã đầy đủ để báo cáo cho
 * anh Minh.Dạ anh Minh, ...". Đo 2026-09-26 trên VPS: 13/1.160 câu trả lời có
 * dùng tool kể từ 19/9. Dặn trong prompt không đủ (luật đã có sẵn câu "TUYỆT
 * ĐỐI không kèm") nên chữa DETERMINISTIC ở đây.
 *
 * CỐ Ý hẹp: chỉ cắt khi câu đầu mang hình dạng tường thuật về CHÍNH VIỆC soạn
 * câu trả lời ("giờ tổng hợp câu trả lời", "dữ liệu đã đủ..."), không mở đầu
 * bằng lời xưng hô/chào, và sau nó còn nội dung thật. Cắt nhầm một câu trả lời
 * đúng tệ hơn để lọt một câu thừa.
 */

/** Tường thuật về việc SOẠN câu trả lời - gần như không bao giờ là lời mở đầu thật. */
const SAP_SOAN = /(giờ|tiến hành|bây giờ)\s+(soạn|tổng hợp|trả lời|phản hồi|trình bày|viết câu|báo cáo)/i;
/** Nhận xét độ đủ của dữ liệu đã thu thập. */
// KHÔNG dùng \b: \b của JS chỉ hiểu [A-Za-z0-9_], nên "đ", "ạ"... bị coi là
// ký tự không-phải-chữ và ranh giới từ quanh chúng không bao giờ khớp.
const DU_LIEU_DU = /(dữ liệu|thông tin|tài liệu|nguồn)[^.!?\n]{0,80}\sđã\s+(đủ|đầy đủ)|^đã\s+(đủ|thu thập (đủ|đầy đủ))(?=[\s,.!?]|$)/i;
/** Câu mở đầu bằng xưng hô/chào là lời nói với người dùng, không phải tường thuật. */
const XUNG_HO = /^(dạ|vâng|chào|xin chào|em|anh|chị|mình|bạn|cháu|con|hi|hello)(?=[\s,.!?]|$)/i;

const TOI_THIEU_PHAN_CON = 20;

export function boCauTuongThuatDau(text: string): string {
  const t = text.trimStart();
  // Câu đầu: tới dấu kết câu đầu tiên KHÔNG theo sau bởi chữ thường/chữ số (loại
  // "tencent.com", "1.5"). Model hay nối liền không cách - "...anh Minh.Dạ anh",
  // "...chuyên sâu.# BÁO CÁO" - nên chữ HOA hay "#" ngay sau dấu chấm vẫn là hết câu.
  // Đòi khoảng trắng/chữ HOA thôi thì ca "#" đi lố, cắt mất nửa tiêu đề (đo thật).
  const m = /^([^\n]{8,240}?[.!?])(?=[^\p{Ll}\d]|$)|^([^\n]{8,240})\n/u.exec(t);
  if (!m) return text;
  const cau = (m[1] ?? m[2])!.trim();
  if (XUNG_HO.test(cau)) return text;
  if (!SAP_SOAN.test(cau) && !DU_LIEU_DU.test(cau)) return text;
  const con = t.slice(m[0].length).trimStart();
  return con.length >= TOI_THIEU_PHAN_CON ? con : text;
}
