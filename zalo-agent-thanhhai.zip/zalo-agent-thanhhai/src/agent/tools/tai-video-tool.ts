import { tool } from "ai";
import { z } from "zod";

import { getTuning } from "../../config/runtime-tuning-settings.js";
import { createLogger } from "../../shared/logger.js";
import { layVideoQuaChuoi } from "../../video/chuoi-nguon-video.js";
import { guiVideoQuaZalo, LoiGuiVideo } from "../../video/gui-video-qua-zalo.js";
import { xepHangTaiVideo } from "../../video/hang-doi-tai-video.js";
import { kiemGioiHanVideo } from "../../video/kiem-gioi-han-video.js";
import { checkTaiVideoRateLimit, hoanSuatTaiVideo } from "../../video/tai-video-rate-limit.js";
import { kiemNguonVideo, timUrlTrongChu } from "../../video/whitelist-nguon-video.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import { TAI_VIDEO_DESCRIPTION } from "./tai-video-tool-description.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { ghiChuDaGuiVideoTaiVe } from "./sent-by-tool-note.js";
import type { ToolContext } from "./index.js";

const log = createLogger("tai-video");

/**
 * Tool tải video TikTok / Facebook / Instagram rồi gửi thẳng vào hội thoại.
 *
 * So sánh 2 repo cho thấy
 * đây là tính năng lớn upstream có mà local chưa, phần lõi (whitelist SSRF,
 * chạy yt-dlp có siết bảo mật, dò URL trước khi gửi) giữ NGUYÊN VẸN vì đó là
 * bảo mật đã trả giá qua nhiều vòng đo. Phần GỬI được đơn giản hóa: dùng lại
 * hạ tầng file-đính-kèm đã có sẵn của `create_video` thay vì tự dựng poster +
 * `sendVideo` như bản gốc - xem `gui-video-qua-zalo.ts`.
 *
 * THỨ TỰ KIỂM TRA cố ý xếp từ rẻ tới đắt, và cái nào chặn được sớm thì chặn:
 *
 *   1. whitelist domain   - 0 request, chặn SSRF
 *   2. trần theo giờ      - 0 request, chỉ đọc bộ nhớ
 *   3. hàng đợi           - chờ tới suất, chưa tốn gì
 *   4. đọc thông tin      - 1 request, có thời lượng
 *   5. trần thời lượng    - 0 request, CHẶN TRƯỚC KHI TẢI
 *   6. gửi                - tải byte + upload lên Zalo
 *
 * Đảo thứ tự 4 và 5 là mất hẳn điểm mạnh của thiết kế: video 2 tiếng vẫn bị từ
 * chối nhưng máy chủ đã tải xong rồi mới biết.
 */

const LOI_CAN_DANG_NHAP_CHO_MODEL =
  "Link này bắt đăng nhập mới xem được (story Facebook, bài trong nhóm/tài khoản kín, hoặc nội dung " +
  "Instagram hạn chế) nên bot không tải được - bot không có tài khoản mạng xã hội để xem. Nói rõ là " +
  "loại link này không tải được và gợi ý người dùng gửi link bài đăng hoặc reel công khai thay thế. " +
  "ĐỪNG bảo họ thử lại.";

const LOI_THIEU_CONG_CU =
  "Máy chủ chưa cài đủ công cụ để tải video (thiếu yt-dlp). Đây là lỗi cấu hình phía máy chủ, " +
  "KHÔNG phải do video. Báo người dùng là bot đang thiếu công cụ và cần người quản trị cài đặt, " +
  "đừng đổ cho video.";

/**
 * Ca TẠM THỜI: có nguồn hỏng kiểu thử-lại-được (TikTok trả trang chống bot, nguồn
 * 5xx). Đợi vài phút rồi thử lại thường ĐƯỢC. Câu này CỐ Ý dặn model đừng bảo
 * người dùng đổi dạng link: short link app và full link desktop cùng trỏ một
 * video, đổi qua lại vô ích - chuỗi nguồn đã tự resolve short link.
 */
const LOI_TAM_THOI =
  "Nguồn tải video đang chặn tạm thời (hay gặp: trang chặn máy tự động, hoặc lỗi mạng nhất thời). " +
  "Bảo người dùng CỨ THỬ LẠI sau vài phút, thường là được. Nói rõ đây là do NGUỒN chặn tạm thời chứ " +
  "KHÔNG phải link sai; ĐỪNG bảo họ gửi lại link hay đổi dạng link (link ngắn hay link đầy đủ đều như nhau).";

/**
 * Ca VĨNH VIỄN: không nguồn nào còn cửa thử lại - nhiều khả năng riêng tư/đã xóa.
 * Đừng hứa thử lại (vô ích), và vẫn đừng bảo đổi dạng link (không phải nguyên nhân).
 */
const LOI_VINH_VIEN =
  "Không tải được video này - nhiều khả năng video ở chế độ riêng tư hoặc đã bị xóa. Nói thật với " +
  "người dùng, ĐỪNG hứa thử lại sau và ĐỪNG bảo họ đổi dạng link (link ngắn hay đầy đủ đều như nhau).";

/**
 * Hai chỗ tool chạm ra ngoài. Thay được từ ngoài CHỈ để test.
 *
 * Cùng nếp `createImageTool(ctx, generate = generateImage)`. Không có seam này
 * thì test tool buộc phải gọi TikWM thật và chạy yt-dlp thật rồi gửi Zalo thật.
 */
export type PhuThuocTaiVideo = {
  layVideo: typeof layVideoQuaChuoi;
  guiVideo: typeof guiVideoQuaZalo;
};

const PHU_THUOC_THAT: PhuThuocTaiVideo = { layVideo: layVideoQuaChuoi, guiVideo: guiVideoQuaZalo };

export function createTaiVideoTool(ctx: ToolContext, phuThuoc: PhuThuocTaiVideo = PHU_THUOC_THAT) {
  const { api } = ctx;
  const { threadId, threadType } = ctx.message;
  const threadKey = `${ctx.account.id}:${threadId}`;

  return tool({
    description: TAI_VIDEO_DESCRIPTION,
    inputSchema: z.object({
      url: z.string().describe("Đường dẫn video TikTok, Facebook, Instagram hoặc YouTube (kể cả Shorts) người dùng gửi"),
    }),
    execute: async ({ url }) => {
      // Cửa 2 (recheck runtime) - Cửa 1 đã chặn tool này khỏi schema kênh bot
      // ở nang-luc-kenh-bot.ts (Zalo Bot API không có method gửi video).
      if (!api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);

      // Người dùng hiếm khi dán mỗi cái link. Bóc ở đây để luật whitelist luôn
      // chạy trên chuỗi đã chuẩn hóa, thay vì phụ thuộc model bóc đúng.
      const urlSach = timUrlTrongChu(url) ?? url.trim();

      const nguon = kiemNguonVideo(urlSach);
      if (!nguon.ok) return ketQuaLoi(nguon.loi);

      const rate = checkTaiVideoRateLimit(threadKey);
      if (!rate.ok) return ketQuaLoi(rate.reason);

      // Trần đếm số video ĐÃ GỬI, không đếm số lần thử. `checkTaiVideoRateLimit`
      // ghi nhận ngay lúc gọi, nên mọi đường thoát KHÔNG gửi được đều phải hoàn
      // lại - không thì nguồn sập một lúc là người dùng bị khóa cả giờ vì
      // những lần chưa nhận được gì.
      let daGui = false;
      try {
        return await xepHangTaiVideo(async () => {
          const ket = await phuThuoc.layVideo(nguon.url, nguon.nenTang, {
            soLanThu: getTuning("VIDEO_DOWNLOAD_SOURCE_RETRIES"),
            nghiMs: getTuning("VIDEO_DOWNLOAD_RETRY_DELAY_MS"),
          });

          if (!ket.ok) {
            log.warn({ url: nguon.url, nenTang: nguon.nenTang, daThu: ket.daThu }, "không lấy được video");
            // Ba câu KHÁC HẲN nhau, chọn theo cờ có kiểu chứ không theo chữ
            // trong `ket.loiChoLog` - chuỗi đó chở stderr của yt-dlp và thân
            // lỗi của TikWM, tức chữ do bên thứ ba sinh, không được chảy vào
            // câu model đọc.
            if (ket.loiCauHinh) return ketQuaLoi(LOI_THIEU_CONG_CU);
            if (ket.canDangNhap) return ketQuaLoi(LOI_CAN_DANG_NHAP_CHO_MODEL);
            return ketQuaLoi(ket.tamThoi ? LOI_TAM_THOI : LOI_VINH_VIEN);
          }

          const video = ket.video;
          const gioiHan = kiemGioiHanVideo(video, {
            thoiLuongToiDa: getTuning("VIDEO_DOWNLOAD_MAX_DURATION_MINUTES"),
            dungLuongToiDa: getTuning("VIDEO_DOWNLOAD_MAX_SIZE_MB"),
          });
          if (!gioiHan.ok) return ketQuaLoi(gioiHan.loi);

          // CÓ, lời gọi gửi này nằm TRONG suất của hàng đợi tải, và đó là CỐ
          // Ý: `guiVideoQuaZalo` có nhánh dự phòng tải-về-rồi-upload, tức tải
          // cả chục MB xuống rồi đẩy ngần ấy lên - đúng thứ nặng nhất trong cả
          // tool, nên phần nặng nhất phải chạy CÓ trần song song.
          const ketGui = await phuThuoc.guiVideo(
            { api, threadKey, threadId, threadType },
            video,
            // URL GỐC của người dùng, KHÔNG phải `video.videoUrl` của CDN: đường
            // dự phòng cuối để yt-dlp tự tải, mà yt-dlp phân tích trang
            // TikTok/Facebook chứ không phân tích được một link CDN.
            nguon.url,
            getTuning("VIDEO_DOWNLOAD_MAX_SIZE_MB") * 1024 * 1024,
          );
          daGui = true;

          ctx.ghiNhanDaGui?.(ghiChuDaGuiVideoTaiVe(nguon.nenTang));

          log.info(
            {
              nguon: video.nguon,
              nenTang: video.nenTang,
              giay: Math.round(video.durationMs / 1000),
              duongGui: ketGui.duong,
              bytes: ketGui.bytes,
            },
            "đã gửi video",
          );
          // KHÔNG nhắc tên tác giả ở đây. `tacGia` là TÊN HIỂN THỊ, chuỗi tự do
          // do người đăng tự đặt. Nhúng nó vào KẾT QUẢ TOOL - chỗ model tin
          // nhất - là đặt chữ của người lạ vào đúng chỗ dễ bị nghe theo nhất.
          return "Đã gửi video. Chỉ cần báo ngắn gọn là xong, đừng dán lại đường dẫn.";
        }, getTuning("VIDEO_DOWNLOAD_MAX_CONCURRENT"));
      } catch (err) {
        // Câu trả cho model KHÔNG nhúng `err.message`: có thể chứa đường dẫn
        // nội bộ hay chi tiết hạ tầng, mà model thì hay chép nguyên văn cho
        // người nhắn. Chi tiết vào log, câu chung cho model.
        log.error({ err, url: nguon.url }, "gửi video thất bại");

        if (err instanceof LoiGuiVideo && err.loiCauHinh) return ketQuaLoi(LOI_THIEU_CONG_CU);
        if (err instanceof LoiGuiVideo && err.quaNang) {
          const mb = err.soByte === null ? null : Math.round(err.soByte / 1024 / 1024);
          return ketQuaLoi(
            `Video này ${mb === null ? "vượt" : `nặng khoảng ${mb}MB, vượt`} giới hạn ` +
              `${getTuning("VIDEO_DOWNLOAD_MAX_SIZE_MB")}MB. Nói con số đó với người dùng và cho biết mức này ` +
              "chỉnh được ở trang Cấu hình.",
          );
        }
        return ketQuaLoi(
          "Gửi video thất bại. Nói thật với người dùng là không gửi được, đừng hứa gửi lại sau.",
        );
      } finally {
        if (!daGui) hoanSuatTaiVideo(threadKey);
      }
    },
  });
}
