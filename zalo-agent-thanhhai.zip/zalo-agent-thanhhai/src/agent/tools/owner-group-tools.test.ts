import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { ketQuaThanhCong, loiCuaTool } from "./tool-failure-result-test-helper.js";

/** gui_vao_nhom + bao_chu_xin_y_kien (2026-10-04). Import động sau setupTestEnv - CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let database: typeof import("../../conversation/database.js");
let threads: typeof import("../../conversation/thread-store.js");
let history: typeof import("../../conversation/history-store.js");
let guiNhom: typeof import("./gui-vao-nhom-tool.js");
let xinYKien: typeof import("./bao-chu-xin-y-kien-tool.js");

type Gui = { msg: unknown; threadId: string; type: number };
let daGui: Gui[] = [];

before(async () => {
  dataDir = setupTestEnv();
  database = await import("../../conversation/database.js");
  threads = await import("../../conversation/thread-store.js");
  history = await import("../../conversation/history-store.js");
  guiNhom = await import("./gui-vao-nhom-tool.js");
  xinYKien = await import("./bao-chu-xin-y-kien-tool.js");
  const nhom = (id: string, ten: string) => {
    threads.recordThreadActivity({ accountId: "acc", threadId: id, threadType: 1, displayName: "", lastSenderName: "x" });
    threads.setThreadDisplayName("acc", id, ten);
  };
  nhom("g-mkt", "Marketing Hạt Mộc");
  nhom("g-mkt2", "Marketing nội bộ");
  nhom("g-ban", "Bán hàng");
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  xinYKien._xoaSoXinYKien();
});

const api = {
  sendMessage: async (msg: unknown, threadId: string, type: number) => {
    daGui.push({ msg, threadId, type });
    return { message: { msgId: "777" } };
  },
};
const ctx = (o: { senderId?: string; isGroup?: boolean; threadId?: string; text?: string } = {}) =>
  ({
    api,
    account: { id: "acc", ownerUserId: "chu", disabledTools: [] },
    message: {
      threadId: o.threadId ?? "chu",
      threadType: o.isGroup ? 1 : 0,
      isGroup: o.isGroup ?? false,
      senderId: o.senderId ?? "chu",
      senderName: "Lan",
      text: o.text ?? "doanh thu tháng 9 bao nhiêu?",
    },
    batch: [],
  }) as never;
/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

describe("timNhom", () => {
  it("khớp id, khớp đúng tên, khớp một phần duy nhất (không phân biệt dấu)", () => {
    assert.deepEqual(guiNhom.timNhom("acc", "g-ban"), { ok: { threadId: "g-ban", ten: "Bán hàng" } });
    assert.deepEqual(guiNhom.timNhom("acc", "ban hang"), { ok: { threadId: "g-ban", ten: "Bán hàng" } });
    assert.deepEqual(guiNhom.timNhom("acc", "hat moc"), { ok: { threadId: "g-mkt", ten: "Marketing Hạt Mộc" } });
  });
  it("khớp nhiều hoặc không khớp thì trả danh sách, KHÔNG tự chọn", () => {
    const nhieu = guiNhom.timNhom("acc", "marketing");
    assert.ok("loi" in nhieu && /2 nhóm khớp/.test(nhieu.loi));
    assert.ok("loi" in guiNhom.timNhom("acc", "kế toán"));
  });
});

describe("gui_vao_nhom", () => {
  it("chủ nhắn riêng: gửi tin vào đúng nhóm và ghi history nhóm đó", async () => {
    const ra = await chay(guiNhom.createGuiVaoNhomTool(ctx()), { nhom: "bán hàng", noiDung: "Chiều nay họp lúc 3h nhé cả nhà" });
    assert.match(ketQuaThanhCong(ra), /Đã gửi tin vào nhóm "Bán hàng"/);
    assert.deepEqual(daGui[0], { msg: { msg: "Chiều nay họp lúc 3h nhé cả nhà" }, threadId: "g-ban", type: 1 });
    assert.equal(history.getRecentMessages("acc", "g-ban", 3).at(-1)?.content, "Chiều nay họp lúc 3h nhé cả nhà");
  });
  it("người khác, hoặc chủ nhưng đang ở trong nhóm, thì bị chặn và không gửi gì", async () => {
    assert.ok(loiCuaTool(await chay(guiNhom.createGuiVaoNhomTool(ctx({ senderId: "nguoi-la" })), { nhom: "bán hàng", noiDung: "x" })));
    assert.ok(loiCuaTool(await chay(guiNhom.createGuiVaoNhomTool(ctx({ isGroup: true, threadId: "g-mkt" })), { nhom: "bán hàng", noiDung: "x" })));
    assert.equal(daGui.length, 0);
  });
  it("tên nhóm mơ hồ thì trả lỗi kèm danh sách, không gửi", async () => {
    const ra = await chay(guiNhom.createGuiVaoNhomTool(ctx()), { nhom: "marketing", noiDung: "x" });
    assert.match(loiCuaTool(ra), /Marketing Hạt Mộc/);
    assert.equal(daGui.length, 0);
  });
  it("file không có trong danh sách bot đã tạo thì báo lỗi", async () => {
    const ra = await chay(guiNhom.createGuiVaoNhomTool(ctx()), { nhom: "bán hàng", tep: "khong-co.xlsx" });
    assert.match(loiCuaTool(ra), /Không tìm thấy file/);
  });
});

describe("bao_chu_xin_y_kien", () => {
  it("người trong nhóm hỏi chuyện nhạy cảm: nhắn riêng cho chủ kèm NGUYÊN VĂN tin gốc", async () => {
    const ra = await chay(xinYKien.createBaoChuXinYKienTool(ctx({ isGroup: true, threadId: "g-ban", senderId: "u-lan" })), { lyDo: "hỏi doanh thu" });
    assert.match(ketQuaThanhCong(ra), /Đã nhắn riêng/);
    assert.equal(daGui[0]!.threadId, "chu");
    assert.match(String((daGui[0]!.msg as { msg: string }).msg), /Nhóm "Bán hàng".*\n- Tin gốc: "doanh thu tháng 9 bao nhiêu\?"/);
  });
  it("cùng người trong 10 phút chỉ báo một lần", async () => {
    const t = xinYKien.createBaoChuXinYKienTool(ctx({ isGroup: true, threadId: "g-ban", senderId: "u-lan" }), () => 1000);
    await chay(t, { lyDo: "a" });
    const ra = await chay(t, { lyDo: "b" });
    assert.match(ketQuaThanhCong(ra), /không báo lại/);
    assert.equal(daGui.length, 1);
  });
  it("chính chủ hỏi, hoặc đang chat riêng, thì không báo", async () => {
    assert.ok(loiCuaTool(await chay(xinYKien.createBaoChuXinYKienTool(ctx({ isGroup: true, threadId: "g-ban", senderId: "chu" })), { lyDo: "x" })));
    assert.ok(loiCuaTool(await chay(xinYKien.createBaoChuXinYKienTool(ctx({ senderId: "u-lan", threadId: "u-lan" })), { lyDo: "x" })));
    assert.equal(daGui.length, 0);
  });
});
