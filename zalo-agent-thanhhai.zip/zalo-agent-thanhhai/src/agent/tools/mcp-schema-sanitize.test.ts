import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { locJsonSchemaMcp } from "./mcp-schema-sanitize.js";

/**
 * Ca thật báo lỗi 2026-09-24: gán server MCP Apify vào agent làm MỌI LƯỢT của
 * agent đó hỏng (không riêng lượt gọi tool Apify) - Gemini từ chối thẳng
 * `400 INVALID_ARGUMENT` vì input schema của actor "Facebook Groups Scraper"
 * mang khóa mở rộng riêng của Apify (`prefill`/`editor`/`enumTitles`/`$id`/
 * `schemaVersion`) mà Gemini không công nhận.
 */

describe("locJsonSchemaMcp - bỏ khóa lạ, giữ khóa chuẩn", () => {
  it("bỏ đúng 5 khóa đã đo được lỗi thật từ actor Apify, giữ nguyên type/properties/description", () => {
    const schemaThat = {
      $id: "https://apify.com/schema/facebook-groups-scraper",
      schemaVersion: 1,
      type: "object",
      description: "Input cho actor",
      properties: {
        groupUrl: {
          type: "string",
          editor: "textfield",
          prefill: "https://facebook.com/groups/...",
          description: "URL nhóm Facebook",
        },
        sortBy: {
          type: "string",
          enum: ["newest", "top"],
          enumTitles: ["Mới nhất", "Nổi bật"],
        },
      },
      required: ["groupUrl"],
    };

    const ra = locJsonSchemaMcp(schemaThat) as Record<string, unknown>;

    assert.ok(!("$id" in ra), "$id phải bị bỏ");
    assert.ok(!("schemaVersion" in ra), "schemaVersion phải bị bỏ");
    assert.equal(ra.type, "object");
    assert.equal(ra.description, "Input cho actor");
    assert.deepEqual(ra.required, ["groupUrl"]);

    const props = ra.properties as Record<string, Record<string, unknown>>;
    assert.ok(!("editor" in props.groupUrl!), "editor (khóa con) phải bị bỏ");
    assert.ok(!("prefill" in props.groupUrl!), "prefill (khóa con) phải bị bỏ");
    assert.equal(props.groupUrl!.type, "string");
    assert.equal(props.groupUrl!.description, "URL nhóm Facebook");

    assert.ok(!("enumTitles" in props.sortBy!), "enumTitles (khóa con) phải bị bỏ");
    assert.deepEqual(props.sortBy!.enum, ["newest", "top"]);
  });

  it("khóa an toàn lồng nhiều tầng (properties trong properties) vẫn được lọc đúng ở MỌI tầng", () => {
    const schema = {
      type: "object",
      properties: {
        bo_loc: {
          type: "object",
          $id: "#/nested",
          properties: {
            tu_ngay: { type: "string", editor: "datepicker" },
          },
        },
      },
    };
    const ra = locJsonSchemaMcp(schema) as any;
    assert.ok(!("$id" in ra.properties.bo_loc), "khóa lạ ở tầng 2 phải bị bỏ");
    assert.ok(!("editor" in ra.properties.bo_loc.properties.tu_ngay), "khóa lạ ở tầng 3 phải bị bỏ");
    assert.equal(ra.properties.bo_loc.properties.tu_ngay.type, "string");
  });

  it("additionalProperties dạng boolean giữ nguyên, không bị coi là schema con", () => {
    const ra = locJsonSchemaMcp({ type: "object", additionalProperties: false }) as any;
    assert.equal(ra.additionalProperties, false);
  });

  it("additionalProperties dạng OBJECT (schema con thật) vẫn được lọc đệ quy", () => {
    const ra = locJsonSchemaMcp({
      type: "object",
      additionalProperties: { type: "string", editor: "textfield" },
    }) as any;
    assert.equal(ra.additionalProperties.type, "string");
    assert.ok(!("editor" in ra.additionalProperties));
  });

  it("items là MỘT schema (không phải mảng) vẫn được lọc đúng", () => {
    const ra = locJsonSchemaMcp({
      type: "array",
      items: { type: "string", prefill: "abc" },
    }) as any;
    assert.equal(ra.items.type, "string");
    assert.ok(!("prefill" in ra.items));
  });

  it("schema KHÔNG có khóa lạ nào thì đi qua nguyên vẹn (không đổi gì oan)", () => {
    const sach = {
      type: "object",
      description: "Tìm kiếm",
      properties: { query: { type: "string", description: "Từ khóa" } },
      required: ["query"],
    };
    assert.deepEqual(locJsonSchemaMcp(sach), sach);
  });

  it("giá trị nguyên thủy (không phải object/array) đi qua nguyên vẹn - không phải mọi node đều là schema", () => {
    assert.equal(locJsonSchemaMcp("chuỗi"), "chuỗi");
    assert.equal(locJsonSchemaMcp(42), 42);
    assert.equal(locJsonSchemaMcp(true), true);
    assert.equal(locJsonSchemaMcp(null), null);
  });

  it("mảng enum/required KHÔNG bị đệ quy như schema - giữ nguyên phần tử chuỗi/số", () => {
    const ra = locJsonSchemaMcp({ type: "string", enum: ["a", "b", "c"] }) as any;
    assert.deepEqual(ra.enum, ["a", "b", "c"]);
  });

  it("độ sâu vượt trần (schema tự tham chiếu vòng lặp) thì tự dừng, không tràn ngăn xếp", () => {
    // Dựng thủ công một chuỗi lồng nhau sâu 25 tầng thay vì vòng lặp thật (vòng
    // lặp thật cần $ref runtime resolve, không dựng được bằng object trần) -
    // đủ để chứng minh trần độ sâu THẬT SỰ có tác dụng chặn.
    let sau: Record<string, unknown> = { type: "string" };
    for (let i = 0; i < 25; i++) {
      sau = { type: "object", properties: { con: sau } };
    }
    assert.doesNotThrow(() => locJsonSchemaMcp(sau));
  });
});
