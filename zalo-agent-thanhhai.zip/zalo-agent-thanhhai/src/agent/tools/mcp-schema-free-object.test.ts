import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { jsonSchema } from "ai";
import { doiObjectTuDoSangChuoi, khoiPhucObjectTuDo } from "./mcp-schema-free-object.js";
import { taoToolDefinitionMcp } from "./mcp-tool-definition.js";
import type { ToolContext } from "./tool-catalog-types.js";

/** Hình dạng THẬT của `call-actor` lấy từ Apify MCP 2026-10-06 (đo trên VPS) */
const CALL_ACTOR = {
  type: "object",
  properties: {
    actor: { type: "string", description: "Actor ID" },
    input: { type: "object", properties: {}, additionalProperties: {}, description: "The input JSON to pass to the Actor. Required." },
    waitSecs: { type: "number" },
  },
  required: ["actor", "input"],
};

describe("doiObjectTuDoSangChuoi", () => {
  it("ô object rỗng thành chuỗi JSON, giữ mô tả gốc; ô khác không đổi", () => {
    const { schema, duongDan } = doiObjectTuDoSangChuoi(CALL_ACTOR) as { schema: any; duongDan: string[][] };
    assert.deepEqual(duongDan, [["input"]]);
    assert.equal(schema.properties.input.type, "string");
    assert.match(schema.properties.input.description, /The input JSON to pass/);
    assert.match(schema.properties.input.description, /CHUỖI JSON/);
    assert.deepEqual(schema.properties.actor, CALL_ACTOR.properties.actor);
    assert.deepEqual(schema.required, ["actor", "input"]);
  });

  it("object CÓ thuộc tính khai báo giữ nguyên; gốc rỗng không bị đổi; ô lồng sâu vẫn bắt được", () => {
    const co = { type: "object", properties: { a: { type: "object", properties: { b: { type: "string" } } } } };
    assert.deepEqual(doiObjectTuDoSangChuoi(co).duongDan, []);
    assert.deepEqual(doiObjectTuDoSangChuoi({ type: "object", properties: {} }).duongDan, []);
    const long = { type: "object", properties: { cauHinh: { type: "object", properties: { them: { type: "object" } } } } };
    assert.deepEqual(doiObjectTuDoSangChuoi(long).duongDan, [["cauHinh", "them"]]);
  });
});

describe("khoiPhucObjectTuDo", () => {
  it("chuỗi JSON thành object, các trường khác giữ nguyên", () => {
    const ra = khoiPhucObjectTuDo({ actor: "a/b", input: '{"startUrls":[{"url":"https://x"}]}', waitSecs: 30 }, [["input"]]);
    assert.deepEqual(ra, { actor: "a/b", input: { startUrls: [{ url: "https://x" }] }, waitSecs: 30 });
  });

  it("không parse được / không phải object thì giữ nguyên chuỗi; đã là object thì không đụng", () => {
    assert.deepEqual(khoiPhucObjectTuDo({ input: "không phải json" }, [["input"]]), { input: "không phải json" });
    assert.deepEqual(khoiPhucObjectTuDo({ input: "[1,2]" }, [["input"]]), { input: "[1,2]" });
    assert.deepEqual(khoiPhucObjectTuDo({ input: { a: 1 } }, [["input"]]), { input: { a: 1 } });
  });

  it("ô lồng sâu được khôi phục", () => {
    assert.deepEqual(khoiPhucObjectTuDo({ cauHinh: { them: '{"k":1}' } }, [["cauHinh", "them"]]), { cauHinh: { them: { k: 1 } } });
  });
});

describe("taoToolDefinitionMcp - call-actor đầu-cuối", () => {
  it("model gửi input là chuỗi JSON (và reason thừa) -> server nhận object đúng, không có reason", async () => {
    let nhan: any;
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "Apify",
      toolTen: "call-actor",
      moTa: "Chạy Actor",
      aiTool: { inputSchema: jsonSchema(CALL_ACTOR as never), execute: async (a: unknown) => ((nhan = a), "ok") },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });
    const t = def.build({ api: {}, account: {}, agent: { id: "a" }, message: {}, batch: [] } as unknown as ToolContext) as any;
    assert.equal(t.inputSchema.jsonSchema.properties.input.type, "string");
    await t.execute({ actor: "apify/facebook-posts-scraper", input: '{"startUrls":[{"url":"https://fb.com/x"}]}', reason: "cào bài" }, {});
    assert.deepEqual(nhan, { actor: "apify/facebook-posts-scraper", input: { startUrls: [{ url: "https://fb.com/x" }] } });
  });
});
