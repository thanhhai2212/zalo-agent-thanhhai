import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let tools: typeof import("./ke-hoach-content-tools.js");
let render: typeof import("../../noi-dung/render-ke-hoach-content.js");
let rateLimit: typeof import("../../documents/document-rate-limit.js");

type DaGui = { ten: string; buf: Buffer };
let daGui: DaGui[] = [];

before(async () => {
  dataDir = setupTestEnv({ DOCUMENT_MAX_PER_HOUR: "5" });
  tools = await import("./ke-hoach-content-tools.js");
  render = await import("../../noi-dung/render-ke-hoach-content.js");
  rateLimit = await import("../../documents/document-rate-limit.js");
});
after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  rateLimit.resetDocumentRateLimit();
});

function ctx(nguoiGui = "chu") {
  return {
    api: {
      sendMessage: async (c: { attachments: string[] }) => {
        daGui.push({ ten: path.basename(c.attachments[0]!), buf: fs.readFileSync(c.attachments[0]!) });
        return {};
      },
    },
    account: { id: "acc-kh", disabledTools: [], ownerUserId: "chu" },
    message: { threadId: "t-kh", threadType: 1, senderId: nguoiGui },
    batch: [],
  } as never;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

const bai = (ngay: number, tru_cot: string) => ({
  ngay,
  kenh: "Facebook",
  dinh_dang: "carousel",
  tru_cot,
  tieu_de: `Bài ngày ${ngay}`,
  hook: "Bạn có biết cà phê rang hôm nay khác gì rang tuần trước?",
  y_chinh: "Bối cảnh, vấn đề, bước ngoặt, kết quả.",
  cta: "Nhắn tin để nhận thử",
});

const KE_HOACH = {
  tieu_de: "Kế hoạch content 30 ngày cà phê rang xay",
  muc_tieu: "Tăng inbox đặt hàng",
  khach_muc_tieu: "Người 25-40 tuổi uống cà phê tại nhà",
  thong_diep_chinh: "Rang hôm nay, giao trong 48h, kể rõ ngày rang và lô hàng",
  so_ngay: 30,
  ngay_bat_dau: "2026-10-05",
  tru_cot: [
    { ten: "Kiến thức", mo_ta: "Giáo dục về cà phê", ty_trong: 40 },
    { ten: "Câu chuyện", mo_ta: "Hành trình hạt cà phê", ty_trong: 35 },
    { ten: "Bán hàng", mo_ta: "Ưu đãi, đặt hàng", ty_trong: 25 },
  ],
  bai: [bai(1, "Kiến thức"), bai(3, "Câu chuyện"), bai(5, "Bán hàng"), bai(8, "Kiến thức"), bai(10, "Câu chuyện"), bai(12, "Kiến thức"), bai(15, "Bán hàng")],
};

describe("ngayThat", () => {
  it("gắn ngày thật và thứ từ ngày bắt đầu (không lệch múi giờ)", () => {
    assert.deepEqual(render.ngayThat("2026-10-05", 1), { ngay: "05/10/2026", thu: "Thứ hai" });
    assert.deepEqual(render.ngayThat("2026-10-05", 4), { ngay: "08/10/2026", thu: "Thứ năm" });
    assert.deepEqual(render.ngayThat("2026-12-30", 3), { ngay: "01/01/2027", thu: "Thứ sáu" });
  });
  it("không có ngày bắt đầu thì trả null", () => assert.equal(render.ngayThat(undefined, 1), null));
});

describe("huong_dan_ke_hoach_content", () => {
  it("có phần hỏi trước, trụ cột, hook/storytelling và quy tắc chỉ lập kế hoạch", async () => {
    const out = await chay(tools.createHuongDanKeHoachContentTool(ctx()), {});
    assert.match(out, /Hỏi trước khi làm/);
    assert.match(out, /trụ cột/);
    assert.match(out, /hook/);
    assert.match(out, /KHÔNG đăng bài/);
  });
});

describe("ke_hoach_content", () => {
  it("gửi MỘT file .xlsx có 3 sheet, ngày thật, và tỷ trọng thực tế", async () => {
    const out = await chay(tools.createKeHoachContentTool(ctx()), KE_HOACH);
    assert.equal(daGui.length, 1);
    assert.match(daGui[0]!.ten, /\.xlsx$/);
    const ExcelJS = (await import("exceljs")).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(daGui[0]!.buf as never);
    assert.deepEqual(wb.worksheets.map((w) => w.name), ["Lịch nội dung", "Trụ cột nội dung", "Tổng quan"]);
    const tat = (ws: import("exceljs").Worksheet) => {
      const ra: string[] = [];
      ws.eachRow((r) => r.eachCell((c) => ra.push(String(c.value ?? ""))));
      return ra.join("|");
    };
    const lich = tat(wb.getWorksheet("Lịch nội dung")!);
    assert.match(lich, /05\/10\/2026/);
    assert.match(lich, /Thứ hai/);
    assert.match(lich, /Chưa làm/);
    const tru = tat(wb.getWorksheet("Trụ cột nội dung")!);
    assert.match(tru, /Kiến thức\|Giáo dục về cà phê\|40%\|3\|43%/); // 3/7 bài
    assert.match(String(out), /7 bài trong 30 ngày/);
    assert.match(String(out), /KHÔNG dán lại/);
  });

  it("báo cảnh báo khi tỷ trọng thực tế lệch quá 8 điểm hoặc lịch dừng sớm, và luôn nhắc thay chuyện thật", async () => {
    const out = await chay(tools.createKeHoachContentTool(ctx()), {
      ...KE_HOACH,
      bai: [bai(1, "Kiến thức"), bai(2, "Kiến thức"), bai(3, "Kiến thức"), bai(4, "Kiến thức"), bai(5, "Câu chuyện"), bai(6, "Bán hàng"), bai(7, "Kiến thức")],
    });
    assert.match(String(out), /CẢNH BÁO phải nói thật/);
    assert.match(String(out), /trụ cột "Kiến thức" đề ra 40% nhưng thực tế 71%/);
    assert.ok(String(out).includes("bài cuối ở ngày 7/30"));
    assert.match(String(out), /khung, cần thay bằng trải nghiệm thật/);
    const ExcelJS = (await import("exceljs")).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(daGui[0]!.buf as never);
    let co = false;
    wb.getWorksheet("Tổng quan")!.eachRow((r) => r.eachCell((c) => { if (String(c.value ?? "").includes("đừng đăng chuyện không có thật")) co = true; }));
    assert.ok(co, "file phải luôn có lưu ý thay chuyện thật");
  });

  it("bài trỏ tới trụ cột không có thì TỪ CHỐI, chưa tạo file", async () => {
    const out = await chay(tools.createKeHoachContentTool(ctx()), {
      ...KE_HOACH,
      bai: [...KE_HOACH.bai.slice(0, 6), bai(20, "Trụ cột lạ")],
    });
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /Trụ cột lạ/);
    assert.equal(daGui.length, 0);
  });

  it("tỷ trọng trụ cột không cộng ~100% thì từ chối", async () => {
    const out = await chay(tools.createKeHoachContentTool(ctx()), {
      ...KE_HOACH,
      tru_cot: KE_HOACH.tru_cot.map((t) => ({ ...t, ty_trong: 10 })),
    });
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /100%/);
  });

  it("bài ngoài khoảng ngày hoặc trụ cột chưa có bài nào thì từ chối", async () => {
    const ngoai = await chay(tools.createKeHoachContentTool(ctx()), {
      ...KE_HOACH,
      so_ngay: 10,
      bai: [...KE_HOACH.bai.slice(0, 6), bai(15, "Bán hàng")],
    });
    assert.ok(loiCuaTool(ngoai));
    const thieu = await chay(tools.createKeHoachContentTool(ctx()), {
      ...KE_HOACH,
      bai: KE_HOACH.bai.filter((b) => b.tru_cot !== "Bán hàng").concat([bai(2, "Kiến thức"), bai(4, "Kiến thức")]),
    });
    assert.ok(loiCuaTool(thieu));
    assert.match(JSON.stringify(thieu), /Bán hàng/);
    assert.equal(daGui.length, 0);
  });

  it("schema chịu được chữ dài và ngày bắt đầu sai định dạng thì bị chặn", async () => {
    const t = tools.createKeHoachContentTool(ctx()) as any;
    const dai = "x".repeat(1200);
    assert.equal(
      t.inputSchema.safeParse({ ...KE_HOACH, bai: KE_HOACH.bai.map((b) => ({ ...b, y_chinh: dai })) }).success,
      true,
    );
    assert.equal(t.inputSchema.safeParse({ ...KE_HOACH, ngay_bat_dau: "05/10/2026" }).success, false);
  });


  it("NGƯỜI KHÁC trong nhóm (không phải chủ tài khoản) bị từ chối, không tạo/gửi gì", async () => {
    const out = await chay(tools.createKeHoachContentTool(ctx("nguoi-la") as never), KE_HOACH);
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /Chỉ chủ tài khoản/);
    assert.equal(daGui.length, 0);
    const guideOut = await chay(tools.createHuongDanKeHoachContentTool(ctx("nguoi-la")), {});
    assert.ok(loiCuaTool(guideOut), "hướng dẫn cũng chỉ dành cho chủ");
  });

  it("kênh Zalo Bot API (không có api) thì từ chối thay vì ném lỗi", async () => {
    const c = { ...(ctx() as any), api: null };
    const out = await chay(tools.createKeHoachContentTool(c as never), KE_HOACH);
    assert.ok(loiCuaTool(out));
  });
});
