import assert from "node:assert/strict";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";

let dataDir: string;
let tools: typeof import("./create-presentation-tool.js");
let rateLimit: typeof import("../../documents/document-rate-limit.js");
let zip: typeof import("../../shared/read-zip-entry.js");

type SentFile = { fileName: string; buffer: Buffer; caption: string; threadId: string };
let sent: SentFile[] = [];
let sendShouldFail = false;

before(async () => {
  dataDir = setupTestEnv({ DOCUMENT_MAX_PER_HOUR: "5", DOCUMENT_MAX_SLIDES: "10" });
  tools = await import("./create-presentation-tool.js");
  rateLimit = await import("../../documents/document-rate-limit.js");
  zip = await import("../../shared/read-zip-entry.js");
});

after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  sent = [];
  sendShouldFail = false;
  rateLimit.resetDocumentRateLimit();
});

function makeCtx() {
  return {
    api: {
      sendMessage: async (
        content: { msg: string; attachments: string[] },
        threadId: string,
      ) => {
        if (sendShouldFail) throw new Error("Zalo từ chối");
        const filePath = content.attachments[0]!;
        sent.push({
          fileName: path.basename(filePath),
          buffer: fs.readFileSync(filePath),
          caption: content.msg,
          threadId,
        });
        return {};
      },
    },
    account: { id: "acc-pptx", disabledTools: [] },
    message: { threadId: "t-pptx", threadType: 0 },
  } as never;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
const run = (toolInstance: unknown, input: unknown): Promise<string> =>
  (toolInstance as any).execute(input, {});

describe("create_powerpoint_file", () => {
  it("tạo file, gửi đúng thread, tên file sạch, và DẶN model đừng gửi lại", async () => {
    const result = await run(tools.createPowerpointFileTool(makeCtx()), {
      fileName: "Báo cáo quý 3",
      slides: [{ type: "title", title: "Báo cáo quý 3", subtitle: "Phòng Kinh doanh" }],
      caption: "File đây ạ",
    });

    assert.equal(sent.length, 1, "phải gửi đúng 1 file");
    assert.equal(sent[0]!.fileName, "Báo cáo quý 3.pptx", "tên file không được dính prefix random");
    assert.equal(sent[0]!.caption, "File đây ạ");
    assert.equal(sent[0]!.threadId, "t-pptx");
    assert.equal(sent[0]!.buffer.subarray(0, 2).toString(), "PK");

    const xml = zip.readZipEntryText(sent[0]!.buffer, "ppt/slides/slide1.xml");
    assert.ok(xml.includes("Báo cáo quý 3") && xml.includes("Phòng Kinh doanh"));
    assert.match(result, /KHÔNG gọi send_file/);
  });

  it("payload TỰ NHIÊN của model (đủ 6 loại slide) qua được inputSchema rồi tạo file", async () => {
    const toolInstance = tools.createPowerpointFileTool(makeCtx());
    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    const inputSchema = (toolInstance as any).inputSchema;
    const payload = {
      fileName: "deck",
      theme: "blue",
      slides: [
        { type: "title", title: "Tiêu đề" },
        { type: "section", title: "Phần 1" },
        { type: "bullets", heading: "Nội dung", items: ["Ý 1", "**Ý 2 đậm**"] },
        { type: "table", heading: "Số liệu", headers: ["A", "B"], rows: [["1", "2"]] },
        { type: "stat_highlight", stats: [{ value: "+42%", label: "tăng trưởng" }] },
        { type: "two_content", heading: "So sánh", left: ["Trái"], right: ["Phải"] },
      ],
    };

    const parsed = inputSchema.safeParse(payload);
    assert.equal(parsed.success, true, JSON.stringify(parsed.success ? "" : parsed.error?.issues));

    const result = await run(toolInstance, parsed.data);
    assert.equal(sent.length, 1);
    assert.match(result, /KHÔNG gọi send_file/);
  });

  it("xóa file tạm sau khi gửi xong - data/tmp không được để lại rác", async () => {
    await run(tools.createPowerpointFileTool(makeCtx()), {
      fileName: "x",
      slides: [{ type: "title", title: "x" }],
    });
    const tmpDir = path.join(dataDir, "tmp");
    const leftovers = fs.existsSync(tmpDir) ? fs.readdirSync(tmpDir) : [];
    assert.deepEqual(leftovers, [], "còn sót file/thư mục tạm");
  });

  it("vượt trần số slide -> trả thông báo, KHÔNG gửi file", async () => {
    const result = await run(tools.createPowerpointFileTool(makeCtx()), {
      fileName: "to",
      slides: Array.from({ length: 11 }, () => ({ type: "title" as const, title: "x" })),
    });
    assert.equal(sent.length, 0);
    assert.match(loiCuaTool(result), /11 slide.*trần 10/);
  });

  it("bảng lệch số cột trong 1 slide -> chặn kèm tên slide, không gửi", async () => {
    const result = await run(tools.createPowerpointFileTool(makeCtx()), {
      fileName: "lech",
      slides: [{ type: "table", heading: "Sai cột", headers: ["A", "B"], rows: [["x"]] }],
    });
    assert.equal(sent.length, 0);
    assert.match(loiCuaTool(result), /Sai cột.*dòng 1/);
  });

  it("đuôi file nguy hiểm bị ép về .pptx", async () => {
    await run(tools.createPowerpointFileTool(makeCtx()), {
      fileName: "../../hack.exe",
      slides: [{ type: "title", title: "x" }],
    });
    assert.equal(sent.length, 1);
    assert.ok(sent[0]!.fileName.endsWith(".pptx"), `tên thật: ${sent[0]!.fileName}`);
    assert.ok(!sent[0]!.fileName.includes(".."), `còn .. trong ${sent[0]!.fileName}`);
  });

  it("gửi lỗi -> trả câu cho model, không ném ra agent loop", async () => {
    sendShouldFail = true;
    const result = await run(tools.createPowerpointFileTool(makeCtx()), {
      fileName: "x",
      slides: [{ type: "title", title: "x" }],
    });
    assert.match(loiCuaTool(result), /Không tạo được file.*Zalo từ chối/);
    assert.match(loiCuaTool(result), /Nói thật với người dùng/);
  });

  it("hết suất trong giờ -> chặn, không gửi thêm", async () => {
    const ctx = makeCtx();
    const input = { fileName: "x", slides: [{ type: "title" as const, title: "x" }] };
    for (let i = 0; i < 5; i++) await run(tools.createPowerpointFileTool(ctx), input);
    assert.equal(sent.length, 5);

    const blocked = await run(tools.createPowerpointFileTool(ctx), input);
    assert.equal(sent.length, 5, "không được gửi file thứ 6");
    assert.match(loiCuaTool(blocked), /trần 5/);
  });
});
