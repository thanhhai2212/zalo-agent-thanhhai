import { isSidecarConfigured } from "../../config/runtime-vision-settings.js";
import { nguonCuaAgent } from "../../knowledge/kb-agent-binding.js";
import { coHuongDanNao, huongDanCuaAgent } from "../../knowledge/kb-huong-dan.js";
import { coNguonNao } from "../../knowledge/kb-source-queries.js";
import { createNapHuongDanTool } from "./nap-huong-dan-tool.js";
import { createDocYoutubeTool } from "./doc-youtube-tool.js";
import { createGetDatetimeTool } from "./get-datetime-tool.js";
import { createGetGroupInfoTool } from "./get-group-info-tool.js";
import { createKbSearchTool } from "./kb-search-tool.js";
import { createReadImageTool } from "./read-image-tool.js";
import { createSearchWikipediaTool } from "./search-wikipedia-tool.js";
import type { ToolDefinition } from "./tool-catalog-types.js";
import { createWebFetchTool } from "./web-fetch-tool.js";
import { createWebSearchTool } from "./web-search-tool.js";
import { createHuongDanKeHoachContentTool } from "./ke-hoach-content-tools.js";
import { createHuongDanDoLuongTool } from "./do-luong-tools.js";
import { createHuongDanAnhBaiDangTool } from "./anh-bai-dang-tools.js";
import { createHuongDanVietCaptionTool } from "./viet-caption-tools.js";
import { createHuongDanNghienCuuDoiThuTool } from "./nghien-cuu-doi-thu-tools.js";
import { createHuongDanSoanEmailTool } from "./soan-email-tools.js";

/**
 * Nhóm "read" của catalog tool - tra cứu, không tác động ra ngoài. Tách khỏi
 * `tool-catalog.ts` (đúng nếp tách theo NHÓM đã bàn ở phase 04) để không file
 * catalog nào vượt ngưỡng 200 dòng khi thêm tool mới.
 */
export const READ_TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    key: "get_datetime",
    label: "Ngày giờ hiện tại",
    description: "Cho bot biết chính xác ngày, giờ, thứ trong tuần theo múi giờ Việt Nam",
    group: "read",
    // Không khoe: người dùng tự xem giờ được, đưa vào danh sách năng lực chỉ
    // làm cả danh sách trông nghiệp dư. Model vẫn gọi tool này bình thường.
    keTrongKhaNang: false,
    build: () => createGetDatetimeTool(),
  },
  {
    key: "web_search",
    label: "Tìm kiếm web",
    description: "Tìm thông tin mới trên web theo chuỗi nguồn, DuckDuckGo luôn đứng cuối",
    group: "read",
    hasSettings: true,
    build: () => createWebSearchTool(),
  },
  {
    key: "web_fetch",
    label: "Đọc trang web",
    description: "Đọc nội dung 1 URL công khai (đã chặn IP nội bộ chống SSRF)",
    group: "read",
    hasSettings: true,
    build: () => createWebFetchTool(),
  },
  {
    key: "doc_youtube",
    label: "Đọc video YouTube",
    description: "Đọc lời thoại (qua phụ đề), tiêu đề và mô tả của video YouTube để tóm tắt hoặc trả lời câu hỏi về video",
    group: "read",
    build: () => createDocYoutubeTool(),
  },
  {
    key: "huong_dan_do_luong",
    label: "Hướng dẫn đo lường bài đăng",
    description: "Đọc quy trình đo lường bài đăng (lấy số liệu, nhập đúng, nhận định thận trọng, đề xuất) trước khi lập báo cáo",
    group: "read",
    // Hạ tầng cho bao_cao_do_luong, không phải năng lực để khoe riêng.
    keTrongKhaNang: false,
    build: (ctx) => createHuongDanDoLuongTool(ctx),
  },
  {
    key: "huong_dan_anh_bai_dang",
    label: "Hướng dẫn tạo ảnh bài đăng",
    description: "Đọc quy trình tạo ảnh bài đăng (tỉ lệ theo kênh, chữ trên ảnh, nhất quán thương hiệu, trung thực ảnh AI) trước khi vẽ",
    group: "read",
    // Hạ tầng cho tao_anh_bai_dang, không phải năng lực để khoe riêng.
    keTrongKhaNang: false,
    build: (ctx) => createHuongDanAnhBaiDangTool(ctx),
  },
  {
    key: "huong_dan_viet_caption",
    label: "Hướng dẫn viết caption",
    description: "Đọc quy trình viết caption từ lịch content (theo kênh, hashtag, CTA, trung thực) trước khi soạn",
    group: "read",
    // Hạ tầng cho viet_caption, không phải năng lực để khoe riêng.
    keTrongKhaNang: false,
    build: (ctx) => createHuongDanVietCaptionTool(ctx),
  },
  {
    key: "huong_dan_ke_hoach_content",
    label: "Hướng dẫn lập kế hoạch content",
    description: "Đọc quy trình lập kế hoạch content (hỏi gì, trụ cột, hook, storytelling, CTA) trước khi dựng lịch",
    group: "read",
    // Hạ tầng cho ke_hoach_content, không phải năng lực để khoe riêng.
    keTrongKhaNang: false,
    build: (ctx) => createHuongDanKeHoachContentTool(ctx),
  },
  {
    key: "huong_dan_nghien_cuu_doi_thu",
    label: "Hướng dẫn nghiên cứu đối thủ",
    description: "Đọc quy trình nghiên cứu đối thủ (hỏi gì, thu thập gì, xác minh nguồn, phân tích) trước khi làm báo cáo",
    group: "read",
    // Hạ tầng cho bao_cao_doi_thu, không phải năng lực để khoe riêng.
    keTrongKhaNang: false,
    build: (ctx) => createHuongDanNghienCuuDoiThuTool(ctx),
  },
  {
    key: "huong_dan_soan_email",
    label: "Hướng dẫn soạn email",
    description: "Đọc hướng dẫn soạn email công việc (hỏi gì, cấu trúc, giọng văn, bảng tự kiểm) trước khi soạn",
    group: "read",
    // Hạ tầng cho soan_email, không phải năng lực để khoe riêng.
    keTrongKhaNang: false,
    build: () => createHuongDanSoanEmailTool(),
  },
  {
    key: "read_image",
    label: "Nhìn kỹ ảnh",
    description:
      "Hỏi model đọc ảnh (sidecar) một câu cụ thể về ảnh đã nhận - đếm, đọc chữ nhỏ, soi chi tiết",
    group: "read",
    // Cấu hình đọc ảnh (chế độ vision + sidecar) nằm trong modal Settings của
    // chính dòng này - gom về một chỗ thay vì tách sang trang Providers
    hasSettings: true,
    available: () => isSidecarConfigured(),
    unavailableHint: "Bấm Settings để cấu hình model sidecar đọc ảnh",
    // Lượt theo lịch không có ảnh nào để mà nhìn kỹ lại
    runsInScheduledTurn: false,
    build: (ctx) => createReadImageTool(ctx),
  },
  {
    key: "get_group_info",
    label: "Thông tin nhóm",
    description: "Xem tên nhóm, số thành viên, danh sách thành viên của nhóm hiện tại",
    group: "read",
    build: (ctx) => createGetGroupInfoTool(ctx),
  },
  {
    key: "kb_search",
    label: "Tra kho tri thức",
    description: "Tra tài liệu do chủ bot nạp lên (chính sách, bảng giá, hướng dẫn)",
    group: "read",
    hasSettings: false,
    /**
     * Agent chưa gán nguồn nào thì tra cũng chỉ ra rỗng - bày tool luôn trả
     * rỗng chỉ dạy model gọi vô ích và tốn một step.
     *
     * `scope` KHÔNG truyền khi route `/api/tools` (catalog dashboard, không
     * có agent cụ thể - trang Tools phạm vi tài khoản) hỏi: khi đó câu hỏi
     * đúng tầm là "kho ĐÃ có nguồn
     * nào chưa" (`coNguonNao`), không phải "nguồn của agent nào".
     */
    available: (scope) => (scope ? nguonCuaAgent(scope.agent.id).length > 0 : coNguonNao()),
    unavailableHint:
      "Kho tri thức chưa có nguồn nào (nạp ở trang Kho tri thức), hoặc agent này chưa được gán nguồn - " +
      "gán ở khối Kho tri thức trên trang sửa agent.",
    // Lượt theo lịch đọc/hỏi kho tri thức vẫn hợp lý (vd nhắc lại chính sách
    // theo lịch) - KHÔNG loại khỏi runsInScheduledTurn như các tool tác động.
    build: (ctx) => createKbSearchTool(ctx),
  },
  {
    key: "nap_huong_dan",
    label: "Kỹ năng (skill)",
    description:
      "Đọc toàn văn một kỹ năng/quy trình chủ bot nạp ở trang Kỹ năng - model thấy tên + mô tả mỗi lượt, cần mới đọc cả bài",
    group: "read",
    hasSettings: false,
    // Hạ tầng cho các việc có quy trình riêng, không phải năng lực để khoe.
    keTrongKhaNang: false,
    // Như kb_search: không có hướng dẫn nào cho agent thì tool không vào schema.
    available: (scope) => (scope ? huongDanCuaAgent(scope.agent.id).length > 0 : coHuongDanNao()),
    unavailableHint:
      "Chưa có kỹ năng nào (trang Kỹ năng), hoặc agent này chưa được gán kỹ năng nào.",
    build: (ctx) => createNapHuongDanTool(ctx),
  },
  {
    key: "search_wikipedia",
    label: "Tra Wikipedia",
    description: "Tra cứu bài viết Wikipedia, ưu tiên tiếng Việt",
    group: "read",
    build: () => createSearchWikipediaTool(),
  },
];
