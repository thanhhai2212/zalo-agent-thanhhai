import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";

// nap-huong-dan-tool.ts bắc cầu tới database.ts (mở SQLite ở module scope) - phải dựng DB tạm TRƯỚC khi import.
let dataDir: string;
let moTaToolNapHuongDan: typeof import("./nap-huong-dan-tool.js")["moTaToolNapHuongDan"];
let database: typeof import("../../conversation/database.js");
before(async () => {
  dataDir = setupTestEnv();
  ({ moTaToolNapHuongDan } = await import("./nap-huong-dan-tool.js"));
  database = await import("../../conversation/database.js");
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

const h = (ten: string, bo: string, moTa = "") => ({ id: ten, ten, moTa, bo, trangThai: "san_sang" as const });

describe("moTaToolNapHuongDan", () => {
  it("một bộ thì không in tiêu đề bộ", () => {
    const s = moTaToolNapHuongDan([h("a", "Kit"), h("b", "Kit")]);
    assert.doesNotMatch(s, /\[Kit\]/);
    assert.match(s, /- "a"/);
  });

  it("nhiều bộ thì gom dòng dưới tiêu đề bộ, bộ rỗng gọi là Kỹ năng lẻ", () => {
    const s = moTaToolNapHuongDan([h("a", "Kit", "mô tả a"), h("b", ""), h("c", "Kit")]);
    const dong = s.split("\n");
    const iKit = dong.indexOf("[Kit]");
    const iLe = dong.indexOf("[Kỹ năng lẻ]");
    assert.ok(iKit >= 0 && iLe >= 0);
    assert.deepEqual(dong.slice(iKit + 1, iKit + 3), ['- "a": mô tả a', '- "c"']);
    assert.equal(dong[iLe + 1], '- "b"');
  });
});
