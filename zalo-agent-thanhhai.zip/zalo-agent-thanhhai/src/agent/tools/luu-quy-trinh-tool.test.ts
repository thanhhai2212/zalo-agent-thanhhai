import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { laKetQuaLoi } from "./tool-failure-result.js";
import type { ToolContext } from "./index.js";

let dataDir: string;
let database: typeof import("../../conversation/database.js");
let mod: typeof import("./luu-quy-trinh-tool.js");
let kb: typeof import("../../knowledge/kb-source-store.js");
let binding: typeof import("../../knowledge/kb-agent-binding.js");

before(async () => {
  dataDir = setupTestEnv();
  database = await import("../../conversation/database.js");
  mod = await import("./luu-quy-trinh-tool.js");
  kb = await import("../../knowledge/kb-source-store.js");
  binding = await import("../../knowledge/kb-agent-binding.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

const ctx = (senderId: string, isGroup = false): ToolContext =>
  ({
    agent: { id: "agent-1" },
    account: { id: "acc", ownerUserId: "chu-1" },
    message: { senderId, isGroup, threadId: "t1" },
    batch: [],
  }) as unknown as ToolContext;

const NOI_DUNG = `## Mục đích
Báo giá khóa học cho khách hỏi.
## Các bước
1. Hỏi khách học cho ai.
2. Gửi bảng giá tương ứng.
3. Mời vào nhóm.`;

const goi = (c: ToolContext, args: Record<string, unknown>) => (mod.createLuuQuyTrinhTool(c) as any).execute(args, {});

describe("luu_quy_trinh - hội thoại thành quy trình trong Kho tri thức", () => {
  it("người không phải chủ bot bị từ chối, kể cả trong chat riêng", async () => {
    assert.ok(laKetQuaLoi(await goi(ctx("nguoi-la"), { ten: "Báo giá", noiDung: NOI_DUNG })));
    assert.equal(kb.danhSachNguon().length, 0);
  });

  it("chủ bot lưu được (cả trong nhóm): tạo nguồn text có tiền tố, gán cho agent đang chạy", async () => {
    const kq = await goi(ctx("chu-1", true), { ten: "Báo giá khóa học", noiDung: NOI_DUNG, moTa: "Khách hỏi giá" });
    assert.match(String(kq), /Đã lưu "Quy trình: Báo giá khóa học"/);
    const nguon = kb.danhSachNguon();
    assert.equal(nguon.length, 1);
    assert.equal(nguon[0]!.loai, "text");
    assert.equal(nguon[0]!.noiDungGoc, NOI_DUNG);
    // Quy trình là hướng dẫn nạp theo nhu cầu: lần sau nap_huong_dan kể tên + mô tả
    assert.deepEqual([nguon[0]!.laHuongDan, nguon[0]!.moTa], [true, "Khách hỏi giá"]);
    assert.deepEqual(binding.nguonCuaAgent("agent-1"), [nguon[0]!.id]);
  });

  it("trùng tên thì từ chối và bảo hỏi lại; ghiDe=true thì thay bản cũ, không nhân đôi", async () => {
    const kq = await goi(ctx("chu-1"), { ten: "báo giá khóa học", noiDung: NOI_DUNG + "\n4. Chúc khách." });
    assert.ok(laKetQuaLoi(kq));
    assert.match(kq.loi, /Đã có quy trình/);
    assert.equal(kb.danhSachNguon().length, 1);
    await goi(ctx("chu-1"), { ten: "Báo giá khóa học", noiDung: NOI_DUNG + "\n4. Chúc khách.", ghiDe: true });
    const nguon = kb.danhSachNguon();
    assert.equal(nguon.length, 1);
    assert.match(nguon[0]!.noiDungGoc, /Chúc khách/);
    assert.deepEqual(binding.nguonCuaAgent("agent-1"), [nguon[0]!.id], "bản mới vẫn gán cho agent");
  });

  it("nội dung chứa API key bị chặn - quy trình đi vào câu trả lời cho mọi người", async () => {
    const kq = await goi(ctx("chu-1"), { ten: "Nối API", noiDung: NOI_DUNG + "\nDùng key " + "sk-" + "abcdefghijklmnopqrstuvwxyz123456 để gọi." });
    assert.ok(laKetQuaLoi(kq));
    assert.match(kq.loi, /API key/);
  });
});
