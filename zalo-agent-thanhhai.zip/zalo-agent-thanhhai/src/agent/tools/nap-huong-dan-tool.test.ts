import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { laKetQuaLoi } from "./tool-failure-result.js";
import type { ToolContext } from "./index.js";

let dataDir: string;
let database: typeof import("../../conversation/database.js");
let mod: typeof import("./nap-huong-dan-tool.js");
let store: typeof import("../../knowledge/kb-source-store.js");
let binding: typeof import("../../knowledge/kb-agent-binding.js");
let registry: typeof import("./tool-registry.js");

before(async () => {
  dataDir = setupTestEnv();
  database = await import("../../conversation/database.js");
  mod = await import("./nap-huong-dan-tool.js");
  store = await import("../../knowledge/kb-source-store.js");
  binding = await import("../../knowledge/kb-agent-binding.js");
  registry = await import("./tool-registry.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  for (const t of ["kb_sources", "kb_chunks", "kb_chunks_fts", "agent_kb_sources"]) database.db.exec(`DELETE FROM ${t}`);
});

const ctx = { agent: { id: "ag1" }, account: { id: "acc" }, message: { threadId: "t1" }, batch: [] } as unknown as ToolContext;
const goi = (args: Record<string, unknown>) => (mod.createNapHuongDanTool(ctx) as any).execute(args, {});
const t = (ten: string, noiDung: string, moTa = "") => store.taoNguon({ ten, loai: "text", noiDungGoc: noiDung, laHuongDan: true, moTa });

describe("nap_huong_dan", () => {
  it("mô tả tool kể tên + mô tả từng hướng dẫn của agent; mô tả quá dài bị cắt", () => {
    const a = t("Báo giá khóa học", "nội dung", "Khách hỏi giá");
    const b = t("Lên lịch học thử", "nội dung", "x".repeat(300));
    binding.datNguonChoAgent("ag1", [a.id, b.id]);
    const mo = (mod.createNapHuongDanTool(ctx) as any).description as string;
    assert.match(mo, /- "Báo giá khóa học": Khách hỏi giá/);
    assert.ok(mo.includes(`"Lên lịch học thử": ${"x".repeat(mod.TRAN_MO_TA_TRONG_TOOL)}\n`) || mo.endsWith(`"Lên lịch học thử": ${"x".repeat(mod.TRAN_MO_TA_TRONG_TOOL)}`));
    assert.ok(!mo.includes("x".repeat(mod.TRAN_MO_TA_TRONG_TOOL + 1)));
  });

  it("đọc theo tên (không phân biệt dấu/hoa thường) ra toàn văn kèm tiêu đề; không có thì liệt kê tên hiện có", async () => {
    const a = t("Báo giá khóa học", "## Bước 1\nHỏi học cho ai.");
    binding.datNguonChoAgent("ag1", [a.id]);
    const kq = await goi({ ten: "bao gia khoa hoc" });
    assert.equal(kq, "# Hướng dẫn: Báo giá khóa học\n\n## Bước 1\nHỏi học cho ai.");
    const loi = await goi({ ten: "không tồn tại" });
    assert.ok(laKetQuaLoi(loi));
    assert.match(loi.loi, /"Báo giá khóa học"/);
  });

  it("khớp một phần: duy nhất thì đọc, nhiều thì bắt gọi lại với tên đầy đủ", async () => {
    const a = t("Báo giá khóa AI", "A");
    const b = t("Báo giá khóa Zalo", "B");
    binding.datNguonChoAgent("ag1", [a.id, b.id]);
    assert.ok(laKetQuaLoi(await goi({ ten: "báo giá" })));
    assert.match(String(await goi({ ten: "khóa zalo" })), /\nB$/);
  });

  it("hướng dẫn của agent khác không đọc được; agent chưa có hướng dẫn thì tool không vào schema", async () => {
    const khac = t("Của agent khác", "bí mật");
    binding.datNguonChoAgent("ag2", [khac.id]);
    assert.ok(laKetQuaLoi(await goi({ ten: "Của agent khác" })));
    const def = registry.TOOL_DEFINITIONS.find((d) => d.key === "nap_huong_dan")!;
    assert.equal(def.available!({ agent: { id: "ag1" }, account: { disabledTools: [] } } as never), false);
    assert.equal(def.available!({ agent: { id: "ag2" }, account: { disabledTools: [] } } as never), true);
  });
});
