import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { ketQuaThanhCong, loiCuaTool } from "./tool-failure-result-test-helper.js";

/**
 * Tool tra Wikipedia - đúng nếp `web-tools-failure-marking.test.ts`: kiểm CẢ HAI CHIỀU,
 * hỏng phải đánh dấu `ketQuaLoi`, thành công phải là chuỗi trần. Không chạm mạng thật -
 * thay `globalThis.fetch`. (Bản này không có các tool tìm học thuật/lập trình.)
 */

let dataDir: string;
let database: typeof import("../../conversation/database.js");
let wikiTool: typeof import("./search-wikipedia-tool.js");

const fetchThat = globalThis.fetch;

before(async () => {
  dataDir = setupTestEnv();
  database = await import("../../conversation/database.js");
  wikiTool = await import("./search-wikipedia-tool.js");
});

after(() => {
  globalThis.fetch = fetchThat;
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (tool: unknown, input: unknown): Promise<unknown> => (tool as any).execute(input, {});

const datFetch = (body: unknown, ok = true, status = ok ? 200 : 500) => {
  globalThis.fetch = (async () =>
    new Response(typeof body === "string" ? body : JSON.stringify(body), {
      status,
      headers: { "content-type": "application/json" },
    })) as unknown as typeof fetch;
};

describe("search_wikipedia - đánh dấu đúng cả hai chiều", () => {
  it("không có kết quả ở cả tiếng Việt lẫn tiếng Anh -> nhánh HỎNG có đánh dấu", async () => {
    datFetch({ query: { search: [] } });
    const ra = await chay(wikiTool.createSearchWikipediaTool(), { query: "khong-ton-tai-xyz" });
    assert.match(loiCuaTool(ra), /Không tìm thấy bài viết/);
  });

  it("có kết quả -> chuỗi trần", async () => {
    datFetch({ query: { search: [{ title: "Hà Nội", snippet: "Thủ đô Việt Nam" }] } });
    const ra = await chay(wikiTool.createSearchWikipediaTool(), { query: "Ha Noi", lang: "vi" });
    assert.match(ketQuaThanhCong(ra), /Hà Nội/);
  });
});
