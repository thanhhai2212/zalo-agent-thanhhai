import { tool } from "ai";
import { z } from "zod";
import { safeFileName } from "../../documents/document-limits.js";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { HUONG_DAN_VIET_CAPTION } from "../../noi-dung/huong-dan-viet-caption.js";
import { canhBaoCaption, choCanDien, renderCaption } from "../../noi-dung/render-caption.js";
import { deliverFile, guard } from "./deliver-generated-file.js";
import type { ToolContext } from "./index.js";
import { chanKhongPhaiChu } from "./owner-action-gate.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Khâu 3 của hướng "Zalo Agent business" (2026-10-02): viết caption từ lịch content, xuất
 * file Word. Chỉ SOẠN, không đăng bài. Cảnh báo và danh sách chỗ cần điền do code phát hiện.
 */

export function createHuongDanVietCaptionTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Đọc quy trình viết caption từ lịch content (theo kênh, hashtag, CTA, trung thực). GỌI TRƯỚC khi viết caption bằng viet_caption.",
    inputSchema: z.object({}),
    execute: async () => chanKhongPhaiChu(ctx) ?? HUONG_DAN_VIET_CAPTION,
  });
}

// Giới hạn RỘNG có chủ ý (bài học từ bao_cao_doi_thu): model viết dài, schema chặt làm hỏng cả file.
const chuoi = (max = 1500) => z.string().min(1).max(max);

const baiSchema = z.object({
  ngay: chuoi(40).describe('Ngày đăng, vd "06/10/2026" (lấy từ lịch)'),
  kenh: chuoi(60),
  dinh_dang: chuoi(60),
  tieu_de: chuoi(300),
  caption: chuoi(4000).describe("Caption đầy đủ, đã gồm hook ở dòng đầu; KHÔNG chép hashtag/CTA vào đây"),
  hashtag: z.array(z.string().min(1).max(60)).max(15),
  cta: chuoi(300).describe("MỘT hành động rõ"),
  y_tuong_hinh: chuoi(1200).describe("Hình/cảnh cần chụp hoặc tạo; carousel thì ghi nội dung từng slide"),
});

export function createVietCaptionTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Dựng file Word chứa caption đầy đủ (kèm hashtag, CTA, gợi ý hình) cho các bài trong lịch content, gửi thành MỘT tin riêng. " +
      "Đọc huong_dan_viet_caption trước. Mỗi lần tối đa khoảng 12 bài, lịch dài thì chia theo tuần. Chỉ soạn, không đăng bài. " +
      "KHÔNG tự dựng trải nghiệm cá nhân, lời khách, giá, ưu đãi chưa được cung cấp: chỗ cần chi tiết riêng để [điền chuyện thật của bạn: ...].",
    inputSchema: z.object({
      tieu_de: chuoi(200).describe('Vd "Caption tuần 1 - Hạt Mộc"'),
      thuong_hieu: chuoi(200),
      bai: z.array(baiSchema).min(1).max(30),
      ten_file: z.string().max(80).optional(),
      caption: z.string().max(300).optional().describe("Lời nhắn ngắn gửi kèm file"),
    }),
    execute: ({ ten_file, caption, ...bo }) =>
      guard(async () => {
        const chan = chanKhongPhaiChu(ctx);
        if (chan) return chan;
                const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);
        const docx = await renderCaption(bo);
        const ten = safeFileName(ten_file || `caption ${bo.tieu_de}`.toLowerCase(), "docx");
        const gui = await deliverFile(ctx, ten, docx, caption);
        if (typeof gui !== "string") return gui;
        const canhBao = canhBaoCaption(bo);
        const dien = bo.bai.map((b) => ({ n: `${b.ngay} (${b.kenh})`, c: choCanDien(b) })).filter((x) => x.c.length);
        return [
          gui,
          `Đã soạn ${bo.bai.length} caption.`,
          dien.length ? `Bài còn chỗ cần người dùng điền: ${dien.map((x) => x.n).join(", ")}.` : "Không còn ô cần điền.",
          canhBao.length ? `CẢNH BÁO phải nói thật với người dùng: ${canhBao.join("; ")}.` : "",
          "Nhắc người dùng: đây là bản nháp, cần điền chuyện thật và rà soát giá/ưu đãi trước khi đăng.",
          "Bàn giao: tin ngắn nêu số bài, bài cần điền, cảnh báo, hỏi có muốn chỉnh giọng, rút ngắn hoặc tạo ảnh cho bài nào. KHÔNG dán lại cả caption vào chat.",
        ]
          .filter(Boolean)
          .join("\n");
      }),
  });
}
