import { tool } from "ai";
import { checkTextContentLimits, safeFileName } from "../../documents/document-limits.js";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { renderSoDo } from "../../so-do/render-so-do.js";
import { gomChu, kiemTraSoDo, soDoSchema } from "../../so-do/so-do-schema.js";
import { deliverFile, guard } from "./deliver-generated-file.js";
import type { ToolContext } from "./index.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Sơ đồ quy trình dạng file HTML (2026-10-08), cùng ngôn ngữ thiết kế với bộ sơ đồ workshop.
 * Chỉ nhận DỮ LIỆU: toàn bộ chữ đã thoát ký tự và mã chạy trong trang là cố định, nên đây không phải
 * đường chèn HTML/script như `create_html_file`. Không giới hạn chủ tài khoản (cùng mức rủi ro với
 * các tool tạo file khác, đã có trần số file theo giờ).
 */
export function createSoDoQuyTrinhTool(ctx: ToolContext) {
  return tool({
    description:
      "Vẽ SƠ ĐỒ QUY TRÌNH / workflow thành file HTML đẹp (mỗi bước là một thẻ: Bạn đưa, Bot làm, Trả về, Chốt chặn; có mũi tên, vòng lặp, bảng so sánh) gửi thành một tin riêng. " +
      "Điền dữ liệu, không viết HTML. Chỉ ghi điều có thật từ nguồn người dùng đưa hoặc từ công cụ đã tra; không bịa con số. 'chot_chan' chỉ cho điều do mã ép buộc, lời dặn AI để ở 'bot_lam'. Thường 4-7 bước.",
    inputSchema: soDoSchema,
    execute: ({ ten_file, caption, ...so_do }) =>
      guard(async () => {
        const loi = kiemTraSoDo({ ...so_do, ten_file, caption });
        if (loi) return ketQuaLoi(`Sơ đồ chưa hợp lý: ${loi} Sửa rồi gọi lại, CHƯA tạo file.`);
        const tran = checkTextContentLimits(gomChu({ ...so_do }));
        if (!tran.ok) return ketQuaLoi(tran.reason);
        const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);
        const html = renderSoDo({ ...so_do });
        const ten = safeFileName(ten_file || `so do ${so_do.tieu_de}`.toLowerCase(), "html");
        const gui = await deliverFile(ctx, ten, Buffer.from(html, "utf8"), caption);
        if (typeof gui !== "string") return gui;
        return [
          gui,
          `Đã dựng sơ đồ ${so_do.cac_buoc.length} ${so_do.song_song ? "luồng" : "bước"}.`,
          "Bàn giao: một tin ngắn nói sơ đồ nói về gì, và nhắc người dùng mở file bằng trình duyệt; nêu những con số/giả định cần họ tự kiểm lại. KHÔNG dán lại nội dung sơ đồ vào chat.",
        ].join("\n");
      }),
  });
}
