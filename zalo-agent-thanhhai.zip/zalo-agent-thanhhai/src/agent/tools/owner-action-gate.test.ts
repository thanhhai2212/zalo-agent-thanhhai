import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ThreadType } from "zca-js";
import type { AccountConfig } from "../../config/account-store.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";
import { chanKhongPhaiChu } from "./owner-action-gate.js";

/**
 * `chanKhongPhaiChu` khác `chanDocCheoThread` đúng MỘT chỗ: KHÔNG đòi chat
 * riêng - đây là bài test canh đúng khác biệt đó, vì lỡ tay thêm nhầm điều
 * kiện `isGroup` vào đây sẽ làm cả 10 tool quản trị nhóm vô dụng ngay trong
 * chính nhóm cần quản trị (lý do tách hàm thay vì tái dùng nguyên bản).
 */

const OWNER = "123456789012345678";
const account = (ownerUserId: string): AccountConfig => ({ id: "acc-1", ownerUserId }) as AccountConfig;

const msg = (overrides: Partial<ParsedMessage>): ParsedMessage =>
  ({
    accountId: "acc-1",
    threadId: "nhom-1",
    threadType: ThreadType.Group,
    isGroup: true,
    senderId: OWNER,
    senderName: "Chủ",
    text: "",
    images: [],
    msgId: "m0",
    cliMsgId: "c0",
    isSelf: false,
    mentionsMe: false,
    rawData: {},
    ...overrides,
  }) as ParsedMessage;

describe("chanKhongPhaiChu", () => {
  it("chưa cấu hình ownerUserId: chặn (fail-closed)", () => {
    const ra = chanKhongPhaiChu({ account: account(""), message: msg({}) });
    assert.ok(ra);
    assert.match(ra.loi, /chưa cấu hình/i);
  });

  it("senderId khác owner: chặn", () => {
    const ra = chanKhongPhaiChu({ account: account(OWNER), message: msg({ senderId: "nguoi-khac" }) });
    assert.ok(ra);
    assert.match(ra.loi, /chỉ chủ tài khoản/i);
  });

  it("đúng owner, ĐANG Ở TRONG NHÓM: KHÔNG chặn - khác chanDocCheoThread", () => {
    const ra = chanKhongPhaiChu({ account: account(OWNER), message: msg({ isGroup: true }) });
    assert.equal(ra, null);
  });

  it("đúng owner, chat riêng: cũng không chặn", () => {
    const ra = chanKhongPhaiChu({ account: account(OWNER), message: msg({ isGroup: false }) });
    assert.equal(ra, null);
  });
});
