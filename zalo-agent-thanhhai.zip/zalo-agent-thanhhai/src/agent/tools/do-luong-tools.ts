import { tool } from "ai";
import { z } from "zod";
import { safeFileName } from "../../documents/document-limits.js";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { HUONG_DAN_DO_LUONG } from "../../noi-dung/huong-dan-do-luong.js";
import { laDuLieuMau, renderBaoCaoDoLuong } from "../../noi-dung/render-bao-cao-do-luong.js";
import { phanTram, tinhDoLuong } from "../../noi-dung/tinh-do-luong.js";
import { deliverFile, guard } from "./deliver-generated-file.js";
import type { ToolContext } from "./index.js";
import { chanKhongPhaiChu } from "./owner-action-gate.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Khâu 5 của hướng "Zalo Agent business" (2026-10-02): đo lường bài đăng từ số liệu người dùng
 * cung cấp, xuất Excel. Mọi phép tính do code (tinh-do-luong.ts); model chỉ nhập số, viết nhận
 * định và đề xuất. Dữ liệu mẫu được đánh dấu ở mọi sheet, nhận ra cả từ tiêu đề "[MẪU]".
 */

export function createHuongDanDoLuongTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Đọc quy trình đo lường bài đăng (lấy số liệu, nhập đúng, nhận định thận trọng, đề xuất). GỌI TRƯỚC khi lập báo cáo bằng bao_cao_do_luong.",
    inputSchema: z.object({}),
    execute: async () => chanKhongPhaiChu(ctx) ?? HUONG_DAN_DO_LUONG,
  });
}

const chuoi = (max = 600) => z.string().min(1).max(max);
/** Số thiếu để null/bỏ trống, KHÔNG điền 0. */
const so = z.number().min(0).max(1e12).nullish();

const baiSchema = z.object({
  ngay: chuoi(40),
  kenh: chuoi(60),
  dinh_dang: chuoi(60),
  tru_cot: z.string().max(80).optional().describe("Lấy từ lịch content nếu có"),
  tieu_de: chuoi(300),
  tiep_can: so.describe("Lượt tiếp cận; thiếu thì bỏ trống"),
  luot_xem: so.describe("Lượt xem (video); thiếu thì bỏ trống"),
  thich: so,
  binh_luan: so,
  chia_se: so,
  luu: so,
  click: so,
  don: so.describe("Đơn hàng; thiếu thì bỏ trống, đừng điền 0"),
});

export function createBaoCaoDoLuongTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Lập báo cáo đo lường bài đăng thành file Excel gửi thành MỘT tin riêng: tỉ lệ tương tác, so sánh theo trụ cột/kênh/định dạng, bài nổi bật, cảnh báo mẫu ít. " +
      "Chỉ dùng số liệu người dùng cung cấp; số thiếu để trống, KHÔNG điền 0, không bịa số. Đọc huong_dan_do_luong trước. Máy tự tính, bạn chỉ nhập số và viết nhận định/đề xuất.",
    inputSchema: z.object({
      tieu_de: chuoi(200),
      ky_do: chuoi(120).describe('Vd "06/10 - 12/10/2026"'),
      nguon_so_lieu: chuoi(200).describe('Vd "file Excel người dùng gửi" / "người dùng nhập qua chat" / "dữ liệu mẫu"'),
      du_lieu_mau: z.boolean().optional().describe("true khi người dùng nói rõ đây là dữ liệu mẫu/thử nghiệm"),
      bai: z.array(baiSchema).min(1).max(200),
      nhan_dinh_ai: z.array(chuoi(800)).max(10).optional().describe("Điều số liệu gợi ý, thận trọng; mẫu ít thì không kết luận chắc"),
      de_xuat: z.array(chuoi(800)).max(10).optional().describe("Điều chỉnh lịch tuần sau, mỗi đề xuất nêu dựa trên con số nào"),
      gioi_han: z.array(chuoi(800)).max(10).optional().describe("Số thiếu, nền tính khác nhau, bài còn mới..."),
      ten_file: z.string().max(80).optional(),
      caption: z.string().max(300).optional(),
    }),
    execute: ({ ten_file, caption, tieu_de, ky_do, nguon_so_lieu, du_lieu_mau, bai, nhan_dinh_ai, de_xuat, gioi_han }) =>
      guard(async () => {
        const chan = chanKhongPhaiChu(ctx);
        if (chan) return chan;
                const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);
        const mau = laDuLieuMau(bai.map((b) => b.tieu_de), du_lieu_mau === true);
        const kq = tinhDoLuong(bai);
        const xlsx = await renderBaoCaoDoLuong(kq, {
          tieu_de,
          ky_do,
          nguon_so_lieu,
          du_lieu_mau: mau,
          nhan_dinh_ai: nhan_dinh_ai ?? [],
          de_xuat: de_xuat ?? [],
          gioi_han: gioi_han ?? [],
        });
        const ten = safeFileName(ten_file || `do luong ${tieu_de}`.toLowerCase(), "xlsx");
        const gui = await deliverFile(ctx, ten, xlsx, caption);
        if (typeof gui !== "string") return gui;
        return [
          gui,
          `Đã tính ${kq.tong.soBai} bài, tỉ lệ gộp ${phanTram(kq.tong.er)} (chỉ tham khảo, trộn hai nền tính; ${kq.tong.soBaiCoEr} bài đủ số liệu).`,
          mau ? "ĐÂY LÀ DỮ LIỆU MẪU: nói rõ với người dùng, file đã đánh dấu ở mọi sheet, không dùng để ra quyết định thật." : "",
          kq.canhBao.length ? `CẢNH BÁO phải nói thật với người dùng: ${kq.canhBao.join(" ")}` : "",
          "Khi nhận định: chỉ so sánh trong CÙNG nền tính (tiếp cận hoặc lượt xem), không xếp hạng trụ cột bằng tỉ lệ gộp.",
          "Bàn giao: tin ngắn nêu 2-3 điểm chính, cảnh báo, hỏi có muốn chỉnh lịch tuần sau theo đề xuất. KHÔNG dán lại cả bảng vào chat.",
        ]
          .filter(Boolean)
          .join("\n");
      }),
  });
}
