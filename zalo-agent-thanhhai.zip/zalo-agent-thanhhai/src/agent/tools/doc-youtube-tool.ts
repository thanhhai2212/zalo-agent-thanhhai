import { tool } from "ai";
import { z } from "zod";

import { getTuning } from "../../config/runtime-tuning-settings.js";
import { createLogger } from "../../shared/logger.js";
import { docYoutube, mmss, TRAN_KY_TU_LOI_THOAI } from "../../video/doc-youtube.js";
import { xepHangTaiVideo } from "../../video/hang-doi-tai-video.js";
import { kiemNguonVideo, timUrlTrongChu } from "../../video/whitelist-nguon-video.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { wrapUntrustedContent } from "./wrap-untrusted-content.js";

const log = createLogger("doc-youtube");

/**
 * Đọc nội dung (lời thoại qua phụ đề) một video YouTube để tóm tắt/trả lời câu
 * hỏi về video. Chỉ ĐỌC, không gửi gì - chạy được cả kênh Zalo Bot API và lượt
 * theo lịch. Dùng chung whitelist chống SSRF và hàng đợi yt-dlp của tải video.
 * Lời thoại là nội dung người lạ đăng nên bọc `wrapUntrustedContent`.
 */
export type PhuThuocDocYoutube = { doc: typeof docYoutube };

export function createDocYoutubeTool(phu: PhuThuocDocYoutube = { doc: docYoutube }) {
  return tool({
    description:
      "Đọc NỘI DUNG một video YouTube (lời thoại lấy từ phụ đề, kèm tiêu đề, kênh, mô tả) để tóm tắt hoặc trả lời câu hỏi về video. " +
      "Dùng khi người dùng gửi link YouTube và hỏi video nói gì - web_fetch KHÔNG đọc được lời thoại video. " +
      "Phụ đề tự động có thể sai chính tả; video không có phụ đề thì chỉ có tiêu đề và mô tả, nói thật với người dùng.",
    inputSchema: z.object({
      url: z.string().describe("Link video YouTube (youtube.com/watch, youtu.be, shorts...)"),
    }),
    execute: async ({ url }) => {
      const nguon = kiemNguonVideo(timUrlTrongChu(url) ?? url.trim());
      if (!nguon.ok) return ketQuaLoi(nguon.loi);
      if (nguon.nenTang !== "youtube") {
        return ketQuaLoi("Tool này chỉ đọc video YouTube. Link khác thì dùng web_fetch để đọc trang.");
      }
      const ket = await xepHangTaiVideo(() => phu.doc(nguon.url), getTuning("VIDEO_DOWNLOAD_MAX_CONCURRENT"));
      if (!ket.ok) {
        log.warn({ loi: ket.loi }, "Không đọc được video YouTube");
        return ketQuaLoi(
          ket.loiCauHinh
            ? "Máy chủ thiếu công cụ yt-dlp nên chưa đọc được video. Đây là lỗi cấu hình phía máy chủ, không phải do link."
            : "Không đọc được video này - có thể video riêng tư, bị xóa hoặc giới hạn độ tuổi. Nói thật với người dùng.",
        );
      }
      const t = ket.thongTin;
      const dau = [
        `Tiêu đề: ${t.tieuDe}`,
        `Kênh: ${t.kenh}`,
        `Thời lượng: ${mmss(t.giay)}`,
        t.moTa ? `Mô tả:\n${t.moTa}` : "",
      ].filter(Boolean);
      const than = ket.loiThoai
        ? `Lời thoại (${t.phuDe?.tuDong ? "phụ đề TỰ ĐỘNG, có thể sai chính tả" : "phụ đề của người đăng"}, mốc [phút:giây]):\n${ket.loiThoai}` +
          (ket.biCat ? `\n(Đã cắt ở ${TRAN_KY_TU_LOI_THOAI} ký tự - phần cuối video không có ở đây, nói rõ nếu người dùng hỏi phần cuối.)` : "")
        : `KHÔNG lấy được lời thoại: ${ket.loiPhuDe ?? "không rõ lý do"}. Chỉ trả lời được dựa trên tiêu đề và mô tả - nói rõ điều này.`;
      return wrapUntrustedContent(`${dau.join("\n")}\n\n${than}`, `YouTube: ${t.tieuDe}`);
    },
  });
}
