import type { Tool } from "ai";

/**
 * Tự nối lại khi server MCP ngoài đã QUÊN phiên (session) của bot.
 *
 * Streamable HTTP gắn mỗi client với một `mcp-session-id` do server cấp lúc
 * bắt tay. Server được quyền xóa phiên bất kỳ lúc nào (để lâu không dùng, hoặc
 * chính server khởi động lại/triển khai bản mới) và trả 404 kèm "Session not
 * found". `@ai-sdk/mcp` KHÔNG tự bắt tay lại (đọc source: nó chỉ ném lỗi kèm
 * câu "Create a new client ... to start a fresh session"), còn pool giữ client
 * cũ và trạng thái trên dashboard vẫn "Đã nối" - nên mọi lời gọi tool sau đó
 * đều hỏng cho tới khi restart tiến trình. Đã dính thật với Apify (2026-09-25).
 *
 * Thử lại MỘT lần với tool của client mới là an toàn: lỗi hết phiên bị server
 * từ chối ngay ở bước tra phiên, TRƯỚC khi tool kịp chạy, nên không có nguy cơ
 * chạy trùng một hành động.
 */
const HET_PHIEN_RE = /session/i;
const HET_PHIEN_CHI_TIET_RE = /(expired|not found|invalid|unknown|no valid)/i;

/**
 * Client đã bị ĐÓNG ("Attempted to send a request from a closed client", @ai-sdk/mcp).
 * Đo thật 2026-10-02: Apify báo "Đã nối" nhưng mọi lời gọi tool đều hỏng với câu này
 * - client trong cache đã đóng (server rớt kết nối, hoặc một lượt khác vừa nối lại và
 * đóng client cũ trong lúc lượt này còn cầm tool cũ). Yêu cầu bị từ chối ở phía mình
 * TRƯỚC khi gửi đi nên cũng thử lại an toàn, không chạy trùng hành động.
 */
const CLIENT_DA_DONG_RE = /closed client|client (is |was |has been )?closed/i;

export function laLoiHetPhienMcp(e: unknown): boolean {
  const msg = e instanceof Error ? e.message : String(e);
  if (CLIENT_DA_DONG_RE.test(msg)) return true;
  return HET_PHIEN_RE.test(msg) && HET_PHIEN_CHI_TIET_RE.test(msg);
}

export async function goiVoiPhucHoiPhien<T>(
  goi: (t: Tool) => Promise<T>,
  toolGoc: Tool,
  layToolMoi?: () => Promise<Tool | undefined>,
): Promise<T> {
  try {
    return await goi(toolGoc);
  } catch (e) {
    if (!layToolMoi || !laLoiHetPhienMcp(e)) throw e;
    const moi = await layToolMoi();
    if (!moi) throw e;
    return await goi(moi);
  }
}
