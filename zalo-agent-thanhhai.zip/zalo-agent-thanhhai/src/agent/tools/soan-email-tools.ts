import { tool } from "ai";
import { z } from "zod";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { safeFileName } from "../../documents/document-limits.js";
import { HUONG_DAN_SOAN_EMAIL } from "../../email-soan/huong-dan-soan-email.js";
import { choConTrong, renderEmailDocx } from "../../email-soan/render-email-docx.js";
import { deliverFile, guard } from "./deliver-generated-file.js";
import type { ToolContext } from "./index.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Hai tool soạn email công việc (2026-10-02, chủ bot yêu cầu "cách 2: tool nạp
 * hướng dẫn theo yêu cầu" + "email gửi thành một tin riêng dạng file Word").
 * Bot KHÔNG gửi email thật - chỉ dựng bản nháp để người dùng chép đi.
 */

/** Quá số này thì coi là chưa đủ thông tin (trừ khi người dùng xin bản mẫu). */
const TOI_DA_O_TRONG = 4;

/**
 * Người dùng CÓ nói muốn bản mẫu/khung để tự điền ở lượt này không. Cờ soan_mau do
 * model tự gắn nên không tin: đo thật 2026-10-02, Gemini tự đặt soan_mau=true để né
 * việc hỏi lại và dựng file 15 ô trống. Chỉ chấp nhận khi chính tin của người dùng
 * trong lượt hiện tại có chữ nói vậy.
 */
export function nguoiDungXinBanMau(ctx: Pick<ToolContext, "batch">): boolean {
  const chu = (ctx.batch ?? []).map((m) => m.text ?? "").join("\n").toLowerCase();
  return /(bản|file|email|thư|mail)\s+mẫu|mẫu\s+(trống|để|cho)|khung\s+(mẫu|trống)|template|tự\s+điền|điền\s+sau|chưa\s+có\s+(số\s+liệu|thông\s+tin)/.test(chu);
}

export function createHuongDanSoanEmailTool() {
  return tool({
    description:
      "Đọc hướng dẫn soạn email công việc (thông tin cần hỏi, cấu trúc, giọng văn, bảng tự kiểm). GỌI TRƯỚC khi soạn bằng soan_email.",
    inputSchema: z.object({}),
    execute: async () => HUONG_DAN_SOAN_EMAIL,
  });
}

export function createSoanEmailTool(ctx: ToolContext) {
  return tool({
    description:
      "Dựng email công việc thành file Word rồi gửi thành MỘT tin riêng (bản nháp, không gửi email thật). " +
      "Dùng khi người dùng nhờ soạn, viết, trả lời email. Đọc huong_dan_soan_email trước. " +
      "KHÔNG bịa tên, số liệu, ngày: chưa biết thì để trong ngoặc vuông, nhưng nếu thiếu người nhận hoặc mục tiêu/số liệu chính thì HỎI người dùng trước (một tin, đủ các câu cần thiết), đừng dựng file toàn ô trống.",
    inputSchema: z.object({
      tieu_de: z.string().min(3).max(200).describe("Tiêu đề email, khoảng 6-12 từ"),
      loi_chao: z.string().min(1).max(200).describe('Vd "Kính gửi anh Nam,"'),
      mo_dau: z.string().min(1).max(600).describe("Câu mở nêu mục đích, 1-2 câu"),
      than_bai: z
        .array(z.string().min(1).max(1500))
        .min(1)
        .max(8)
        .describe('Các đoạn thân bài; dòng bắt đầu bằng "- " thành gạch đầu dòng'),
      de_nghi: z.string().max(600).optional().describe("Lời đề nghị / kêu gọi hành động, kèm thời hạn nếu cần"),
      chu_ky: z
        .array(z.string().max(200))
        .min(1)
        .max(6)
        .describe('Dòng ký, vd ["Trân trọng,", "Nguyễn Văn A", "Trưởng phòng - Công ty X"]'),
      ten_file: z.string().max(80).optional().describe('Tên file, vd "email-xin-nghi-phep.docx"'),
      caption: z.string().max(300).optional().describe("Lời nhắn ngắn gửi kèm file"),
      soan_mau: z
        .boolean()
        .optional()
        .describe("true CHỈ khi người dùng NÓI RÕ trong tin nhắn muốn bản MẪU để tự điền. Không tự đặt true để né việc hỏi lại: hệ thống kiểm lời người dùng và vẫn từ chối. Mặc định false"),
    }),
    execute: ({ ten_file, caption, soan_mau, ...dacTa }) =>
      guard(async () => {
        // Chốt chặn CẤU TRÚC (không dựa vào model tự giác hỏi lại): mỗi model diễn giải
        // "thiếu thì hỏi" một kiểu - đo thật 2026-10-02, Gemini dựng luôn file toàn ô [ ]
        // còn Claude hỏi lại. Quá nhiều ô trống nghĩa là chưa đủ thông tin để soạn.
        const cho = choConTrong(dacTa);
        const duocXinMau = soan_mau === true && nguoiDungXinBanMau(ctx);
        if (!duocXinMau && (dacTa.tieu_de.includes("[") || cho.length > TOI_DA_O_TRONG)) {
          return ketQuaLoi(
            `Còn quá nhiều ô trống (${cho.length}: ${cho.slice(0, 6).join(", ")}) nên chưa đủ thông tin để soạn, CHƯA tạo file. ` +
              "Hãy hỏi người dùng MỘT tin gộp, đánh số từng câu cho ĐỦ (người nhận: tên và chức vụ; người ký; việc cần họ làm, mục đích và số liệu chính; thời hạn), " +
              "rồi gọi lại. Tiêu đề và lời chào không được để trong ngoặc vuông. Chỉ khi chính tin nhắn của người dùng nói rõ muốn bản mẫu để tự điền mới được dùng soan_mau=true; không tự quyết thay họ.",
          );
        }
        const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);
        const docx = await renderEmailDocx(dacTa);
        const ten = safeFileName(ten_file || `email ${dacTa.tieu_de}`.toLowerCase(), "docx");
        const gui = await deliverFile(ctx, ten, docx, caption);
        if (typeof gui !== "string") return gui;
        const trong = choConTrong(dacTa);
        return [
          gui,
          trong.length
            ? `Còn ${trong.length} ô cần người dùng điền: ${trong.join(", ")}. Nhắn họ điền trước khi gửi.`
            : "Không còn ô trống.",
          "Bàn giao: tin ngắn nêu các ô cần điền, điểm cần rà (pháp lý, cam kết) nếu có, hỏi có muốn đổi giọng hay độ dài. KHÔNG dán lại cả thư vào chat.",
        ].join("\n");
      }),
  });
}
