import { tool } from "ai";
import { z } from "zod";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { checkTextContentLimits, safeFileName } from "../../documents/document-limits.js";
import { bocTrangHtml, locHtmlAnToan } from "../../documents/html-sanitizer.js";
import { renderCsv } from "../../documents/render-csv.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { deliverFile, guard, type DeliverCtx } from "./deliver-generated-file.js";

/**
 * Bốn tool file văn bản thuần: .md, .html, .csv, .txt - dựng xong GỬI LUÔN,
 * cùng đường với 2 tool tài liệu Office (`deliver-generated-file.ts`).
 *
 * Vì sao TÁCH 4 tool thay vì một tool có tham số `format`: người dùng bật/tắt
 * được từng định dạng trên trang Tools, và mô tả riêng dạy model chính xác khi
 * nào dùng cái nào (markdown cho ghi chú/tài liệu kỹ thuật, csv cho dữ liệu đưa
 * vào Excel, html cho trang xem được trên trình duyệt).
 *
 * KHÁC 2 tool Office ở dạng đầu vào: .md/.txt/.html nhận CHUỖI THÔ vì model viết
 * markdown và HTML rất tự nhiên, gò vào schema khối sẽ mất code block, trích
 * dẫn, CSS. Đổi lại .html phải đi qua `locHtmlAnToan` - xem lý do ở đó.
 * .csv vẫn nhận BẢNG (headers + rows) vì csv vốn là bảng, và nhận chuỗi thô thì
 * không chặn được CSV injection ở tầng ô.
 */

type Ctx = DeliverCtx;

const KEY_TRAN = (ctx: Ctx): string => `${ctx.account.id}:${ctx.message.threadId}`;

const tenFile = (mo_ta: string) => z.string().min(1).describe(mo_ta);
const caption = () =>
  z.string().optional().describe("Lời nhắn ngắn gửi kèm file, viết như người thật nói");

export function createMarkdownFileTool(ctx: Ctx) {
  return tool({
    description:
      "Tạo file Markdown (.md) rồi gửi luôn cho người dùng. Dùng khi người dùng xin file .md, " +
      "hoặc khi nội dung là ghi chú/tài liệu kỹ thuật/README/checklist mà họ sẽ mở bằng công cụ khác. " +
      "Viết markdown đầy đủ: tiêu đề #, danh sách, bảng, khối code. Nội dung ngắn thì trả lời thẳng trong chat.",
    inputSchema: z.object({
      fileName: tenFile('Tên file, vd "ghi-chu-du-an.md"'),
      noiDung: z.string().min(1).describe("Toàn bộ nội dung markdown"),
      caption: caption(),
    }),
    execute: async ({ fileName, noiDung, caption }) =>
      guard(async () => {
        const limit = checkTextContentLimits(noiDung);
        if (!limit.ok) return ketQuaLoi(limit.reason);
        const rate = checkDocumentRateLimit(KEY_TRAN(ctx));
        if (!rate.ok) return ketQuaLoi(rate.reason);

        return deliverFile(
          ctx,
          safeFileName(fileName, "md"),
          Buffer.from(noiDung, "utf-8"),
          caption,
        );
      }),
  });
}

export function createPlainTextFileTool(ctx: Ctx) {
  return tool({
    description:
      "Tạo file văn bản thuần (.txt) rồi gửi luôn cho người dùng. Dùng khi người dùng xin file .txt, " +
      "hoặc cần nội dung không định dạng (danh sách thô, log, đoạn văn bản dài để dán sang chỗ khác).",
    inputSchema: z.object({
      fileName: tenFile('Tên file, vd "danh-sach.txt"'),
      noiDung: z.string().min(1).describe("Toàn bộ nội dung, xuống dòng bằng ký tự xuống dòng thật"),
      caption: caption(),
    }),
    execute: async ({ fileName, noiDung, caption }) =>
      guard(async () => {
        const limit = checkTextContentLimits(noiDung);
        if (!limit.ok) return ketQuaLoi(limit.reason);
        const rate = checkDocumentRateLimit(KEY_TRAN(ctx));
        if (!rate.ok) return ketQuaLoi(rate.reason);

        return deliverFile(
          ctx,
          safeFileName(fileName, "txt"),
          Buffer.from(noiDung, "utf-8"),
          caption,
        );
      }),
  });
}

export function createHtmlFileTool(ctx: Ctx) {
  return tool({
    description:
      "Tạo file HTML (.html) rồi gửi luôn cho người dùng. Dùng khi cần một trang xem được trên trình duyệt: " +
      "báo cáo có bảng biểu, trang giới thiệu, bản in đẹp. Viết HTML thường kèm CSS trong thẻ style. " +
      "LƯU Ý: mã chạy được (thẻ script, thuộc tính onclick, link javascript:) sẽ BỊ LOẠI BỎ vì lý do an toàn, " +
      "nên đừng dựa vào JavaScript - chỉ dùng HTML và CSS tĩnh.",
    inputSchema: z.object({
      fileName: tenFile('Tên file, vd "bao-cao-thang-7.html"'),
      noiDung: z
        .string()
        .min(1)
        .describe("Nội dung HTML. Gửi trọn trang hoặc chỉ phần thân, bot tự bọc khung nếu thiếu"),
      tieuDe: z.string().optional().describe("Tiêu đề trang, hiện trên tab trình duyệt"),
      caption: caption(),
    }),
    execute: async ({ fileName, noiDung, tieuDe, caption }) =>
      guard(async () => {
        const limit = checkTextContentLimits(noiDung);
        if (!limit.ok) return ketQuaLoi(limit.reason);
        const rate = checkDocumentRateLimit(KEY_TRAN(ctx));
        if (!rate.ok) return ketQuaLoi(rate.reason);

        const { html, daBo } = locHtmlAnToan(noiDung);
        const trang = bocTrangHtml(html, tieuDe ?? fileName);
        const ketQua = await deliverFile(
          ctx,
          safeFileName(fileName, "html"),
          Buffer.from(trang, "utf-8"),
          caption,
        );
        // Nói ra thay vì lọc im lặng: model biết mà không hứa với người dùng
        // những thứ tương tác mà file gửi đi không hề có.
        return daBo.length ? `${ketQua} Đã loại bỏ phần chạy được: ${daBo.join(", ")}.` : ketQua;
      }),
  });
}

export function createCsvFileTool(ctx: Ctx) {
  return tool({
    description:
      "Tạo file CSV (.csv) rồi gửi luôn cho người dùng. Dùng khi người dùng cần dữ liệu dạng bảng để nạp vào " +
      "Excel/Google Sheets hoặc phần mềm khác. Cần file có công thức tính sẵn và định dạng đẹp thì dùng " +
      "create_excel_file thay vì tool này.",
    inputSchema: z.object({
      fileName: tenFile('Tên file, vd "danh-sach-khach.csv"'),
      headers: z.array(z.string()).min(1).max(50).describe("Tên các cột, dòng đầu tiên của file"),
      rows: z
        .array(z.array(z.string()))
        .min(1)
        .describe("Các dòng dữ liệu, mỗi dòng phải đủ số ô bằng số cột"),
      caption: caption(),
    }),
    execute: async ({ fileName, headers, rows, caption }) =>
      guard(async () => {
        const lech = rows.findIndex((row) => row.length !== headers.length);
        if (lech >= 0) {
          return ketQuaLoi(
            `Dòng ${lech + 1} có ${rows[lech]!.length} ô nhưng bảng có ${headers.length} cột. Mọi dòng phải đủ số ô.`,
          );
        }

        const tongChu = [...headers, ...rows.flat()].join("");
        const limit = checkTextContentLimits(tongChu);
        if (!limit.ok) return ketQuaLoi(limit.reason);
        const rate = checkDocumentRateLimit(KEY_TRAN(ctx));
        if (!rate.ok) return ketQuaLoi(rate.reason);

        return deliverFile(ctx, safeFileName(fileName, "csv"), renderCsv({ headers, rows }), caption);
      }),
  });
}
