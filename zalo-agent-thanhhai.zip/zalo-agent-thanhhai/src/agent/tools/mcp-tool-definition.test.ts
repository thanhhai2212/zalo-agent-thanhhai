import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { jsonSchema } from "ai";
import { z } from "zod";
import { goiCoTimeout, taoToolDefinitionMcp, tenToolMcp, trichVanBanKetQuaMcp } from "./mcp-tool-definition.js";
import { laKetQuaLoi } from "./tool-failure-result.js";
import type { ToolContext } from "./tool-catalog-types.js";

describe("tenToolMcp - tên sạch thì KHÔNG hash", () => {
  it("server + tool đều sạch -> key gọn, không hậu tố hash", () => {
    assert.equal(tenToolMcp("Notion", "search_pages", "id1"), "mcp__notion__search_pages");
  });

  it("2 server SẠCH trùng tên (chuẩn hóa không đổi) -> CÙNG key, chấp nhận được ở V1", () => {
    const a = tenToolMcp("Notion", "search", "id1");
    const b = tenToolMcp("Notion", "search", "id2");
    assert.equal(a, b);
  });
});

describe("tenToolMcp - mất thông tin lúc chuẩn hóa thì PHẢI hash để chống trùng ÂM THẦM", () => {
  it("2 server tên khác nhau nhưng chuẩn hóa về CÙNG slug -> key KHÁC NHAU (nhờ hash theo serverId)", () => {
    const a = tenToolMcp("Notion!!!", "search", "id-a");
    const b = tenToolMcp("Notion???", "search", "id-b");
    assert.notEqual(a, b);
  });

  it("tên có dấu tiếng Việt (mất thông tin khi chuẩn hóa) vẫn ra key hợp lệ, có hash", () => {
    const key = tenToolMcp("Máy chủ của tôi", "tìm_kiếm", "id1");
    assert.match(key, /^mcp__/);
    assert.match(key, /_[0-9a-f]{8}$/);
  });

  it("toolTen do server ngoài đặt có ký tự lạ vẫn ra key hợp lệ charset model chấp nhận", () => {
    const key = tenToolMcp("ok", "tool with spaces!", "id1");
    assert.match(key, /^[A-Za-z0-9_]+$/);
  });
});

describe("tenToolMcp - key luôn <= 64 ký tự", () => {
  it("tên dài vượt trần thì cắt + hash, không ném lỗi", () => {
    const key = tenToolMcp("a".repeat(100), "b".repeat(100), "id1");
    assert.ok(key.length <= 64, `key dài ${key.length}: ${key}`);
    assert.match(key, /_[0-9a-f]{8}$/);
  });

  it("2 tool CÙNG serverId, tên dài trùng tiền tố khác đuôi -> key KHÁC NHAU sau khi cắt", () => {
    const a = tenToolMcp("srv", "x".repeat(80) + "AAA", "id1");
    const b = tenToolMcp("srv", "x".repeat(80) + "BBB", "id1");
    assert.notEqual(a, b);
  });
});

describe("trichVanBanKetQuaMcp", () => {
  it("chuỗi trần thì trả nguyên văn", () => {
    assert.equal(trichVanBanKetQuaMcp("xin chào"), "xin chào");
  });

  it("null/undefined hạ về chuỗi rỗng, KHÔNG rơi vào JSON.stringify(undefined)", () => {
    assert.equal(trichVanBanKetQuaMcp(null), "");
    assert.equal(trichVanBanKetQuaMcp(undefined), "");
  });

  it("dạng content block chuẩn MCP: nối các phần text lại", () => {
    const raw = { content: [{ type: "text", text: "phần 1" }, { type: "text", text: "phần 2" }] };
    assert.equal(trichVanBanKetQuaMcp(raw), "phần 1\nphần 2");
  });

  it("content block lẫn phần không phải text thì bỏ qua phần đó", () => {
    const raw = { content: [{ type: "text", text: "giữ" }, { type: "image", data: "abc" }] };
    assert.equal(trichVanBanKetQuaMcp(raw), "giữ");
  });

  it("JSON tùy ý (server không tuân thủ chuẩn) thì stringify, không đánh rơi dữ liệu", () => {
    assert.equal(trichVanBanKetQuaMcp({ so: 42 }), '{"so":42}');
  });
});

describe("goiCoTimeout", () => {
  it("xong trước hạn thì trả kết quả bình thường", async () => {
    const r = await goiCoTimeout(() => Promise.resolve("ok"), 1000);
    assert.equal(r, "ok");
  });

  it("quá hạn thì ném lỗi", async () => {
    await assert.rejects(
      goiCoTimeout(() => new Promise(() => {}), 20),
      /quá 20ms/,
    );
  });
});

function dungCtx(): ToolContext {
  return {
    api: {} as ToolContext["api"],
    account: {} as ToolContext["account"],
    agent: { id: "agent-1" } as ToolContext["agent"],
    message: {} as ToolContext["message"],
    batch: [],
  };
}

describe("taoToolDefinitionMcp - hai cửa default-deny", () => {
  it("available: chưa gán (kiemGan false) thì false", () => {
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "srv",
      toolTen: "tool1",
      moTa: "mô tả",
      aiTool: { inputSchema: z.object({}), execute: async () => "ok" },
      toolCallTimeoutMs: 1000,
      kiemGan: () => false,
    });
    assert.equal(def.available!({ agent: { id: "agent-1" } } as never), false);
  });

  it("available: scope rỗng (trang Tools hỏi không kèm agent) thì false - tool ngoài không có khái niệm hạ tầng chung", () => {
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "srv",
      toolTen: "tool1",
      moTa: "mô tả",
      aiTool: { inputSchema: z.object({}), execute: async () => "ok" },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });
    assert.equal(def.available!(undefined), false);
  });

  it("execute: cửa 2 recheck - quyền bị rút GIỮA lượt thì trả ketQuaLoi, KHÔNG ném", async () => {
    let coQuyen = true;
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "srv",
      toolTen: "tool1",
      moTa: "mô tả",
      aiTool: { inputSchema: z.object({}), execute: async () => "kết quả thật" },
      toolCallTimeoutMs: 1000,
      kiemGan: () => coQuyen,
    });
    coQuyen = false;
    const t = def.build(dungCtx());
    const kq = await (t as any).execute({}, {});
    assert.ok(laKetQuaLoi(kq));
  });

  it("execute: mất phiên mà nối lại không được -> câu lỗi nói rõ lỗi kết nối phía bot, không để câu thô 'Session not found'", async () => {
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "Apify",
      toolTen: "search-actors",
      moTa: "mô tả",
      aiTool: {
        inputSchema: z.object({}),
        execute: async () => {
          throw new Error('MCP HTTP Transport Error: POSTing to endpoint (HTTP 404): {"error":{"message":"Session not found"}}');
        },
      },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
      layToolMoi: async () => undefined,
    });
    const kq = await (def.build(dungCtx()) as any).execute({}, {});
    assert.ok(laKetQuaLoi(kq));
    const chu = JSON.stringify(kq);
    assert.match(chu, /Apify/);
    assert.match(chu, /lỗi kết nối phía bot/);
    assert.doesNotMatch(chu, /Session not found/);
  });

  it("execute: tool ngoài ném lỗi -> ketQuaLoi, không rơi ra agent loop", async () => {
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "srv",
      toolTen: "tool1",
      moTa: "mô tả",
      aiTool: {
        inputSchema: z.object({}),
        execute: async () => {
          throw new Error("server sập");
        },
      },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });
    const t = def.build(dungCtx());
    const kq = await (t as any).execute({}, {});
    assert.ok(laKetQuaLoi(kq));
  });

  it("execute: kết quả thành công được bọc wrapUntrustedContent (nội dung server ngoài không tin cậy)", async () => {
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "srv",
      toolTen: "tool1",
      moTa: "mô tả",
      aiTool: { inputSchema: z.object({}), execute: async () => "nội dung thật" },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });
    const t = def.build(dungCtx());
    const kq = await (t as any).execute({}, {});
    assert.equal(typeof kq, "string");
    assert.match(kq as string, /<noi_dung_ngoai/);
    assert.match(kq as string, /nội dung thật/);
  });

  it("runsInScheduledTurn=false, keTrongKhaNang=false - tool ngoài luôn xếp rủi ro cao nhất, không quảng cáo", () => {
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "srv",
      toolTen: "tool1",
      moTa: "mô tả",
      aiTool: { inputSchema: z.object({}), execute: async () => "ok" },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });
    assert.equal(def.runsInScheduledTurn, false);
    assert.equal(def.keTrongKhaNang, false);
    assert.equal(def.group, "action");
  });
});

describe("taoToolDefinitionMcp - lọc schema khóa lạ (bug thật 2026-09-24, Apify MCP)", () => {
  it("khóa mở rộng riêng của Apify (prefill/editor/enumTitles/$id/schemaVersion) bị lọc khỏi inputSchema gửi model", () => {
    // Đúng hình dạng THẬT của aiTool.inputSchema khi qua @ai-sdk/mcp (chế độ
    // "automatic" - LUÔN bọc jsonSchema(), không phải Zod như các test khác ở
    // trên dùng cho gọn). Test này phải dùng đúng hình dạng thật vì bug nằm ở
    // chính bước đọc `.jsonSchema`.
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "Apify",
      toolTen: "facebook-groups-scraper",
      moTa: "Cào bài viết trong nhóm Facebook",
      aiTool: {
        inputSchema: jsonSchema({
          $id: "https://apify.com/schema",
          schemaVersion: 1,
          type: "object",
          properties: {
            groupUrl: { type: "string", editor: "textfield", prefill: "https://facebook.com/groups/..." },
          },
        }),
        execute: async () => "ok",
      },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });

    const t = def.build(dungCtx()) as { inputSchema: { jsonSchema: Record<string, unknown> } };
    const schema = t.inputSchema.jsonSchema;

    assert.ok(!("$id" in schema), "$id phải bị lọc - đúng khóa Gemini từ chối thật");
    assert.ok(!("schemaVersion" in schema), "schemaVersion phải bị lọc");
    const props = schema.properties as Record<string, Record<string, unknown>>;
    assert.ok(!("editor" in props.groupUrl!), "editor (khóa con) phải bị lọc");
    assert.ok(!("prefill" in props.groupUrl!), "prefill (khóa con) phải bị lọc");
    assert.equal(props.groupUrl!.type, "string", "khóa chuẩn phải còn nguyên");
  });
});

describe("taoToolDefinitionMcp - server chỉ chủ bot (dữ liệu khách hàng)", () => {
  const dung = (chiChu: boolean) =>
    taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "thanhhai",
      toolTen: "danh_sach_don",
      moTa: "Đơn hàng",
      aiTool: { inputSchema: z.object({}), execute: async () => "SĐT khách" },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
      chiChuBot: () => chiChu,
    });
  const ctxVoi = (message: Partial<ToolContext["message"]>): ToolContext => ({
    ...dungCtx(),
    account: { ownerUserId: "chu-1" } as ToolContext["account"],
    message: message as ToolContext["message"],
  });

  it("schema: chỉ có khi chủ bot nhắn riêng; thiếu cờ là đóng", () => {
    const def = dung(true);
    assert.equal(def.available!({ agent: { id: "agent-1" } } as never), false);
    assert.equal(def.available!({ agent: { id: "agent-1" }, chuChatRieng: false } as never), false);
    assert.equal(def.available!({ agent: { id: "agent-1" }, chuChatRieng: true } as never), true);
    assert.equal(dung(false).available!({ agent: { id: "agent-1" } } as never), true, "server thường không bị ảnh hưởng");
  });

  it("execute: người khác hoặc chủ bot trong NHÓM bị từ chối, không gọi tool ngoài", async () => {
    const def = dung(true);
    for (const message of [
      { senderId: "nguoi-la", isGroup: false },
      { senderId: "chu-1", isGroup: true },
    ]) {
      const kq = await (def.build(ctxVoi(message)) as any).execute({}, {});
      assert.ok(laKetQuaLoi(kq), JSON.stringify(message));
    }
    const ok = await (def.build(ctxVoi({ senderId: "chu-1", isGroup: false })) as any).execute({}, {});
    assert.match(String(ok), /SĐT khách/);
  });
});

describe("taoToolDefinitionMcp - chủ bot dùng được cả trong nhóm (chuTrongNhom)", () => {
  const dung = (chuNhom: boolean) =>
    taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "Excalidraw",
      toolTen: "create_scene",
      moTa: "Vẽ",
      aiTool: { inputSchema: z.object({}), execute: async () => "đã vẽ" },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
      chiChuBot: () => true,
      chuTrongNhom: () => chuNhom,
    });
  const ctxNhom = (batch: { senderId: string }[]): ToolContext => ({
    ...dungCtx(),
    account: { ownerUserId: "chu-1" } as ToolContext["account"],
    message: { ...batch.at(-1), isGroup: true } as ToolContext["message"],
    batch: batch.map((m) => ({ ...m, isGroup: true })) as ToolContext["batch"],
  });

  it("schema: chỉ mở khi server cho phép VÀ lượt nhóm toàn tin của chủ bot", () => {
    const scope = (chuTrongNhom: boolean | undefined) => ({ agent: { id: "agent-1" }, chuChatRieng: false, chuTrongNhom }) as never;
    assert.equal(dung(true).available!(scope(true)), true);
    assert.equal(dung(true).available!(scope(false)), false, "lượt nhóm có tin người khác thì đóng");
    assert.equal(dung(true).available!(scope(undefined)), false, "thiếu cờ là đóng");
    assert.equal(dung(false).available!(scope(true)), false, "server chưa bật quyền trong nhóm thì đóng dù lượt đủ điều kiện");
  });

  it("execute: chủ bot một mình trong nhóm được gọi; có tin người khác chung lượt hoặc người khác gõ thì bị từ chối", async () => {
    const def = dung(true);
    const ok = await (def.build(ctxNhom([{ senderId: "chu-1" }])) as any).execute({}, {});
    assert.match(String(ok), /đã vẽ/);
    for (const batch of [
      [{ senderId: "nguoi-la" }, { senderId: "chu-1" }],
      [{ senderId: "chu-1" }, { senderId: "nguoi-la" }],
      [{ senderId: "nguoi-la" }],
    ]) {
      const kq = await (def.build(ctxNhom(batch)) as any).execute({}, {});
      assert.ok(laKetQuaLoi(kq), JSON.stringify(batch));
    }
  });

  it("server chưa bật quyền trong nhóm: chủ bot trong nhóm vẫn bị từ chối như cũ", async () => {
    const kq = await (dung(false).build(ctxNhom([{ senderId: "chu-1" }])) as any).execute({}, {});
    assert.ok(laKetQuaLoi(kq));
  });
});

describe("taoToolDefinitionMcp - bỏ tham số lạ router chèn vào", () => {
  it("tool không tham số: 'reason' do 9Router chèn bị bỏ trước khi gọi server", async () => {
    let nhan: unknown;
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "thanhhai",
      toolTen: "tong_quan",
      moTa: "Tổng quan",
      aiTool: {
        inputSchema: jsonSchema({ type: "object", properties: {}, additionalProperties: false }),
        execute: async (a: unknown) => ((nhan = a), "ok"),
      },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });
    await (def.build(dungCtx()) as any).execute({ reason: "xem số liệu" }, {});
    assert.deepEqual(nhan, {});
  });

  it("tool có tham số: giữ tham số khai báo, bỏ tham số lạ", async () => {
    let nhan: unknown;
    const def = taoToolDefinitionMcp({
      serverId: "s1",
      serverTen: "thanhhai",
      toolTen: "danh_sach_don",
      moTa: "Đơn",
      aiTool: {
        inputSchema: jsonSchema({ type: "object", properties: { status: { type: "string" } } }),
        execute: async (a: unknown) => ((nhan = a), "ok"),
      },
      toolCallTimeoutMs: 1000,
      kiemGan: () => true,
    });
    await (def.build(dungCtx()) as any).execute({ status: "paid", reason: "x" }, {});
    assert.deepEqual(nhan, { status: "paid" });
  });
});
