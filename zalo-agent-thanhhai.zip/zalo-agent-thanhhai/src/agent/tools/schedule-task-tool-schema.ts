import { z } from "zod";

/**
 * Lịch chạy - union RỜI theo `kind`, KHÔNG dùng `z.discriminatedUnion`: 'once'
 * có 2 dạng ({date,time} và {inMinutes}) cùng chia sẻ discriminant "once", mà
 * `z.discriminatedUnion` ném "Duplicate discriminator value" ở MỌI LẦN PARSE
 * khi có 2 nhánh trùng giá trị phân biệt - đã dính đúng lỗi này ở
 * `document-content-schema.ts`'s `spreadsheetCellSchema` (làm create_excel_file
 * chết 100% trên Zalo thật trong khi test vẫn xanh). Hình dạng khớp 1-1 với
 * `ScheduleInput` của `schedule-parser.ts` để truyền thẳng, không chuyển đổi.
 */
export const scheduleInputSchema = z
  .union([
    z.object({
      kind: z.literal("once"),
      date: z.string().describe('Ngày dạng YYYY-MM-DD theo giờ Việt Nam, vd "2026-08-01"'),
      time: z.string().describe('Giờ dạng HH:mm (24h) theo giờ Việt Nam, vd "15:00"'),
    }),
    z.object({
      kind: z.literal("once"),
      // Trần 525600 (1 năm) - thiếu trần này thì `new Date(now + inMinutes *
      // 60000)` ở schedule-parser.ts ném RangeError khi vượt biên Date; tool
      // có try/catch nhưng route POST /api/schedule (dùng chung schema này)
      // thì không, lỗi lọt thành 500 thay vì 400 có lý do rõ ràng.
      inMinutes: z.number().int().positive().max(525600).describe("Số phút kể từ bây giờ, vd 30 = 30 phút nữa"),
    }),
    z.object({
      kind: z.literal("every"),
      // Cùng trần 525600 (1 năm) với `inMinutes` ở trên - cùng đường vỡ:
      // `computeNextRun`/`computeEveryNext` (next-run.ts) cộng `steps * intervalMs`
      // vào `new Date(...)`, vượt biên Date ném RangeError. Route POST /api/schedule
      // dùng chung schema này, không có try/catch quanh createJob nên lỗi lọt
      // thành 500 thay vì 400 có lý do rõ ràng.
      minutes: z.number().int().positive().max(525600).describe("Lặp lại mỗi bấy nhiêu phút"),
    }),
    z.object({
      kind: z.literal("cron"),
      expr: z
        .string()
        .min(1)
        .describe('Biểu thức cron 5 trường theo giờ Việt Nam, vd "0 7 * * *" = 7h sáng mỗi ngày'),
    }),
  ])
  .describe(
    "Đúng 1 trong 4 dạng: once theo mốc giờ tuyệt đối (date+time), once tương đối (inMinutes), " +
      "every lặp theo phút, hoặc cron theo biểu thức cron - cả 4 đều hiểu theo giờ Việt Nam.",
  );

/**
 * Nhãn hiển thị trên dashboard/action list - không phải nội dung gửi đi.
 * Export để `schedule-routes.ts` (API dashboard, phase 05) dùng lại đúng
 * ngưỡng này thay vì khai một con số thứ hai dễ lệch.
 */
export const MAX_NAME_CHARS = 100;
/**
 * Trần ký tự payload - CHÍNH SÁCH tự đặt (không phải giới hạn của Zalo), đủ
 * rộng cho nhắc hẹn dài lẫn prompt agent chi tiết. Cùng độ lớn với
 * `MAX_PROMPT_CHARS` của `create-image-tool.ts` cho nhất quán trong catalog.
 */
export const MAX_PAYLOAD_CHARS = 4000;

/**
 * Hình dạng THẬT của input sau khi Zod parse xong - 4 nhánh theo `action`,
 * agent-actions.ts/test đều dùng type này để narrow theo action.
 */
export type ScheduleTaskInput =
  | { action: "create"; name: string; kind: "message" | "agent"; payload: string; schedule: ScheduleInput }
  | { action: "list" }
  | { action: "cancel"; id: string }
  | {
      action: "update";
      id: string;
      name?: string;
      payload?: string;
      schedule?: ScheduleInput;
    };
export type CreateScheduleTaskInput = Extract<ScheduleTaskInput, { action: "create" }>;
export type UpdateScheduleTaskInput = Extract<ScheduleTaskInput, { action: "update" }>;
type ScheduleInput = z.infer<typeof scheduleInputSchema>;

/**
 * KHÔNG được để `z.discriminatedUnion("action", [...])` làm SCHEMA GỐC của
 * tool - ca đã trả giá thật: 25/8/2026, agent `Trợ Lý Kế Toán Tài Chính` chạy
 * model Claude qua 9router (`cc/claude-sonnet-5`), Zalo thật gãy 100% mọi lượt
 * với lỗi `tools.24.custom.input_schema.type: Field required`, trong khi nút
 * "Test kết nối" trên dashboard vẫn xanh (route đó gọi `streamText` KHÔNG kèm
 * `tools`, nên không bao giờ đụng phải schema này). Tái hiện được tại chỗ:
 * `zodSchema(scheduleTaskInputSchema).jsonSchema` của discriminated union ra
 * `{"oneOf":[...]}` Ở GỐC, KHÔNG có field `type` - đúng ca Anthropic đòi hỏi.
 * Union RỜI (`z.union`, không discriminated) cũng dính y hệt, vì vấn đề nằm ở
 * CHỖ ĐẶT (làm schema gốc của tool) chứ không phải loại union nào.
 *
 * Sửa bằng cách PHẲNG HÓA: một `z.object` DUY NHẤT với mọi field khác `action`
 * đều optional, đúng luật bắt buộc-theo-action kiểm bằng `superRefine`, rồi
 * `transform` về lại đúng 4 nhánh discriminated union cho `execute()` narrow
 * như cũ - không đổi type ở phía dùng (`schedule-task-tool.ts`,
 * `schedule-task-actions.ts` không cần sửa). AI SDK bỏ qua `superRefine`/
 * `transform` khi tạo JSON Schema (chỉ đọc hình dạng object gốc), nên schema
 * gửi cho model vẫn đúng `type:"object"` - đã kiểm lại bằng chính lệnh tái
 * hiện lỗi ở trên.
 */
export const scheduleTaskInputSchema = z
  .object({
    action: z.enum(["create", "list", "cancel", "update"]).describe("Thao tác cần làm"),
    name: z
      .string()
      .min(1)
      .max(MAX_NAME_CHARS)
      .optional()
      .describe(
        "BẮT BUỘC khi action='create'. Nhãn ngắn để nhận ra lịch này trong action='list'. action='update': bỏ trống = giữ nguyên tên cũ.",
      ),
    kind: z
      .enum(["message", "agent"])
      .optional()
      .describe(
        "BẮT BUỘC khi action='create'. 'message' = gửi nguyên văn payload lúc tới giờ, không tốn lượt LLM. 'agent' = chạy 1 lượt agent có tool với payload là prompt.",
      ),
    payload: z
      .string()
      .min(1)
      .max(MAX_PAYLOAD_CHARS)
      .optional()
      .describe(
        "BẮT BUỘC khi action='create'. Nội dung gửi (kind='message') hoặc prompt cho lượt agent (kind='agent') - phải TỰ CHỨA đủ ngữ cảnh. action='update': bỏ trống = giữ nguyên nội dung cũ.",
      ),
    schedule: scheduleInputSchema
      .optional()
      .describe("BẮT BUỘC khi action='create'. action='update': bỏ trống = giữ nguyên lịch cũ."),
    id: z
      .string()
      .min(1)
      .optional()
      .describe("BẮT BUỘC khi action='cancel' hoặc action='update' - id lấy từ action='list', TUYỆT ĐỐI không tự đoán"),
  })
  .superRefine((data, ctx) => {
    if (data.action === "create") {
      if (!data.name) ctx.addIssue({ code: "custom", path: ["name"], message: "Bắt buộc khi action='create'" });
      if (!data.kind) ctx.addIssue({ code: "custom", path: ["kind"], message: "Bắt buộc khi action='create'" });
      if (!data.payload) ctx.addIssue({ code: "custom", path: ["payload"], message: "Bắt buộc khi action='create'" });
      if (!data.schedule) ctx.addIssue({ code: "custom", path: ["schedule"], message: "Bắt buộc khi action='create'" });
    } else if (data.action === "cancel" || data.action === "update") {
      if (!data.id) ctx.addIssue({ code: "custom", path: ["id"], message: "Bắt buộc khi action='cancel'/'update'" });
    }
  })
  .transform((data): ScheduleTaskInput => {
    switch (data.action) {
      case "create":
        return { action: "create", name: data.name!, kind: data.kind!, payload: data.payload!, schedule: data.schedule! };
      case "list":
        return { action: "list" };
      case "cancel":
        return { action: "cancel", id: data.id! };
      case "update":
        return { action: "update", id: data.id!, name: data.name, payload: data.payload, schedule: data.schedule };
    }
  });
