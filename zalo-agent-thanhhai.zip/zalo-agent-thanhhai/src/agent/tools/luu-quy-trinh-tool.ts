import { tool } from "ai";
import { z } from "zod";
import { datAgentChoNguon } from "../../knowledge/kb-agent-binding.js";
import { danhSachNguon, taoNguon, xoaNguon } from "../../knowledge/kb-source-store.js";
import { loaiBiMat } from "../../shared/secret-pattern-guard.js";
import type { ToolContext } from "./index.js";
import { chanKhongPhaiChu } from "./owner-action-gate.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Hội thoại -> quy trình dùng lại được (học "turn the conversation into a
 * skill" của Grok Bot, video Peter Yang 2026-10-09). Chủ bot vừa hướng dẫn bot
 * làm một việc qua vài lượt rồi nói "lưu cách làm này thành quy trình X": bot
 * tóm thành một tài liệu SOP, ghi vào Kho tri thức với tiền tố "Quy trình: ",
 * gán cho chính agent đang chạy. Lần sau ai hỏi tới, `kb_search` tự kéo ra -
 * không cần cơ chế skill riêng, không nhồi thêm vào persona.
 *
 * Chỉ chủ bot (`chanKhongPhaiChu`, dùng được cả trong nhóm): tài liệu này đi
 * vào câu trả lời cho MỌI người, nên người lạ không được quyền "dạy" bot.
 */
export const TIEN_TO_QUY_TRINH = "Quy trình: ";
/** Thư mục trên trang Kỹ năng cho các quy trình bot học từ hội thoại. */
export const BO_QUY_TRINH = "Quy trình bot đã học";

const MO_TA = [
  "Lưu CÁCH LÀM một việc mà chủ bot vừa hướng dẫn trong cuộc trò chuyện thành một quy trình dùng lại được",
  "(Kho tri thức, tiền tố \"Quy trình: \"). Lần sau có người hỏi việc đó, bạn tra kb_search là có.",
  "",
  "KHI NÀO: chủ bot nói \"lưu cách làm này\", \"lưu thành quy trình/skill/SOP\", \"nhớ cách làm này cho lần sau\".",
  "Không tự lưu khi chưa được bảo.",
  "",
  "NỘI DUNG: viết markdown theo các mục - Mục đích; Khi nào dùng; Các bước (đánh số, mỗi bước là hành động cụ thể,",
  "nêu tool nào nếu có); Lưu ý/điều tránh; Ví dụ đầu vào -> đầu ra (nếu cuộc trò chuyện có). Chỉ đúc kết từ điều chủ bot",
  "ĐÃ nói và ĐÃ làm trong cuộc trò chuyện này, không bịa thêm bước. Tiếng Việt có dấu. Không chép API key, mật khẩu,",
  "số điện thoại khách vào quy trình. Quy trình được đánh dấu \"hướng dẫn nạp theo nhu cầu\": lần sau bạn thấy tên + moTa",
  "trong tool nap_huong_dan và đọc được cả bài.",
].join("\n");

const tenNguon = (ten: string) => `${TIEN_TO_QUY_TRINH}${ten.trim()}`;

export function timQuyTrinh(ten: string) {
  const dich = tenNguon(ten).toLowerCase();
  return danhSachNguon().find((n) => n.ten.toLowerCase() === dich) ?? null;
}

export function createLuuQuyTrinhTool(ctx: ToolContext) {
  return tool({
    description: MO_TA,
    inputSchema: z.object({
      ten: z.string().trim().min(3).max(80).describe('Tên ngắn, dễ tìm, vd "Báo giá khóa học", "Trả lời khách hỏi ship"'),
      noiDung: z.string().min(80).max(20_000).describe("Toàn văn quy trình dạng markdown, theo các mục ở mô tả tool"),
      moTa: z
        .string()
        .trim()
        .max(160)
        .optional()
        .describe('MỘT câu nói quy trình này dùng khi nào, vd "Khách hỏi giá khóa học hoặc ưu đãi" - hiện trong danh sách của nap_huong_dan'),
      ghiDe: z
        .boolean()
        .optional()
        .describe("true khi chủ bot xác nhận THAY quy trình cũ cùng tên. Mặc định không ghi đè."),
    }),
    execute: async ({ ten, noiDung, moTa, ghiDe }) => {
      const chan = chanKhongPhaiChu(ctx);
      if (chan) return chan;
      const biMat = loaiBiMat(noiDung);
      if (biMat) return ketQuaLoi(`Nội dung có vẻ chứa ${biMat} - bỏ phần đó ra rồi lưu lại. Quy trình được đưa vào câu trả lời cho mọi người.`);
      const cu = timQuyTrinh(ten);
      if (cu && !ghiDe) {
        return ketQuaLoi(
          `Đã có quy trình tên "${ten}" (tạo ${cu.createdAt.slice(0, 10)}). Hỏi chủ bot muốn THAY bản cũ hay đặt tên khác; thay thì gọi lại với ghiDe=true.`,
        );
      }
      if (cu) xoaNguon(cu.id);
      const nguon = taoNguon({ ten: tenNguon(ten), loai: "text", noiDungGoc: noiDung.trim(), laHuongDan: true, moTa: moTa ?? "", boKyNang: cu?.boKyNang || BO_QUY_TRINH });
      datAgentChoNguon(nguon.id, [ctx.agent.id]);
      return (
        `Đã lưu "${nguon.ten}" vào Kho tri thức (${noiDung.length} ký tự)${cu ? ", thay bản cũ" : ""}. ` +
        "Hệ thống đang cắt đoạn, vài giây nữa tra được bằng kb_search. " +
        "Báo chủ bot: muốn agent khác cũng dùng thì gán thêm ở trang Kho tri thức."
      );
    },
  });
}
