import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let tools: typeof import("./viet-caption-tools.js");
let render: typeof import("../../noi-dung/render-caption.js");
let rateLimit: typeof import("../../documents/document-rate-limit.js");
let readZip: typeof import("../../shared/read-zip-entry.js");

type DaGui = { ten: string; buf: Buffer };
let daGui: DaGui[] = [];

before(async () => {
  dataDir = setupTestEnv({ DOCUMENT_MAX_PER_HOUR: "5" });
  tools = await import("./viet-caption-tools.js");
  render = await import("../../noi-dung/render-caption.js");
  rateLimit = await import("../../documents/document-rate-limit.js");
  readZip = await import("../../shared/read-zip-entry.js");
});
after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  rateLimit.resetDocumentRateLimit();
});

function ctx(nguoiGui = "chu") {
  return {
    api: {
      sendMessage: async (c: { attachments: string[] }) => {
        daGui.push({ ten: path.basename(c.attachments[0]!), buf: fs.readFileSync(c.attachments[0]!) });
        return {};
      },
    },
    account: { id: "acc-cap", disabledTools: [], ownerUserId: "chu" },
    message: { threadId: "t-cap", threadType: 1, senderId: nguoiGui },
    batch: [],
  } as never;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

const bai = (over: Record<string, unknown> = {}) => ({
  ngay: "06/10/2026",
  kenh: "Facebook",
  dinh_dang: "bài viết",
  tieu_de: "Cầu Đất ở đâu mà cà phê ngon vậy?",
  caption: "Nhiều người hỏi mình: Cầu Đất ở đâu?\n\nCầu Đất thuộc Đà Lạt, độ cao khoảng 1.500m.",
  hashtag: ["HatMoc", "CaPheCauDat", "#CaPheNguyenChat"],
  cta: "Bình luận nếu bạn đã từng uống cà phê Cầu Đất",
  y_tuong_hinh: "Ảnh vườn cà phê buổi sáng, ánh sáng tự nhiên",
  ...over,
});
const BO = { tieu_de: "Caption tuần 1 - Hạt Mộc", thuong_hieu: "Hạt Mộc", bai: [bai(), bai({ ngay: "07/10/2026", kenh: "TikTok", dinh_dang: "video ngắn", tieu_de: "Rang vừa khác rang đậm" })] };

describe("huong_dan_viet_caption", () => {
  it("có phần theo kênh, trung thực và quy tắc chỉ soạn", async () => {
    const out = await chay(tools.createHuongDanVietCaptionTool(ctx()), {});
    assert.match(out, /Facebook/);
    assert.match(out, /TikTok/);
    assert.match(out, /Trung thực/);
    assert.match(out, /KHÔNG đăng bài/);
  });
});

describe("viet_caption", () => {
  it("gửi MỘT file .docx có caption, hashtag chuẩn hóa, CTA và gợi ý hình", async () => {
    const out = await chay(tools.createVietCaptionTool(ctx()), BO);
    assert.equal(daGui.length, 1);
    assert.match(daGui[0]!.ten, /\.docx$/);
    const chu = readZip.readZipEntryText(daGui[0]!.buf, "word/document.xml").replace(/<[^>]+>/g, "");
    assert.ok(chu.includes("Cầu Đất ở đâu mà cà phê ngon vậy?"));
    assert.ok(chu.includes("#HatMoc #CaPheCauDat #CaPheNguyenChat"), "hashtag thiếu # phải được thêm, không nhân đôi");
    assert.ok(chu.includes("Gợi ý hình/cảnh:"));
    assert.ok(chu.includes("Cách dùng:"));
    assert.match(String(out), /Đã soạn 2 caption/);
    assert.match(String(out), /Không còn ô cần điền/);
    assert.match(String(out), /KHÔNG dán lại/);
  });

  it("liệt kê bài còn chỗ [điền chuyện thật], ghi vào file và vào kết quả", async () => {
    const out = await chay(tools.createVietCaptionTool(ctx()), {
      ...BO,
      bai: [bai({ caption: "Lần đầu lên vườn: [điền chuyện thật của bạn: điều bạn nhớ nhất]" })],
    });
    assert.match(String(out), /Bài còn chỗ cần người dùng điền: 06\/10\/2026 \(Facebook\)/);
    const chu = readZip.readZipEntryText(daGui[0]!.buf, "word/document.xml").replace(/<[^>]+>/g, "");
    assert.ok(chu.includes("Cần bạn điền trước khi đăng:"));
  });

  it("cảnh báo: TikTok quá 2200 ký tự, quá nhiều hashtag, thiếu hashtag, tuyên bố sức khỏe", async () => {
    const bo = {
      ...BO,
      bai: [
        bai({ kenh: "TikTok", caption: "x".repeat(2300) }),
        bai({ hashtag: Array.from({ length: 12 }, (_, i) => `h${i}`) }),
        bai({ hashtag: [] }),
        bai({ caption: "Cà phê này giúp giảm cân và tăng cường miễn dịch" }),
      ],
    };
    const w = render.canhBaoCaption(bo);
    assert.ok(w.some((x) => /vượt giới hạn 2200/.test(x)));
    assert.ok(w.some((x) => /12 hashtag/.test(x)));
    assert.ok(w.some((x) => /chưa có hashtag/.test(x)));
    assert.ok(w.some((x) => /tuyên bố sức khỏe/.test(x)));
    const out = await chay(tools.createVietCaptionTool(ctx()), bo);
    assert.match(String(out), /CẢNH BÁO phải nói thật/);
  });

  it("schema chịu caption dài và chặn quá 30 bài", async () => {
    const t = tools.createVietCaptionTool(ctx()) as any;
    assert.equal(t.inputSchema.safeParse({ ...BO, bai: [bai({ caption: "y".repeat(3500) })] }).success, true);
    assert.equal(t.inputSchema.safeParse({ ...BO, bai: Array.from({ length: 31 }, () => bai()) }).success, false);
  });


  it("NGƯỜI KHÁC trong nhóm (không phải chủ tài khoản) bị từ chối, không tạo/gửi gì", async () => {
    const out = await chay(tools.createVietCaptionTool(ctx("nguoi-la") as never), BO);
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /Chỉ chủ tài khoản/);
    assert.equal(daGui.length, 0);
    const guideOut = await chay(tools.createHuongDanVietCaptionTool(ctx("nguoi-la")), {});
    assert.ok(loiCuaTool(guideOut), "hướng dẫn cũng chỉ dành cho chủ");
  });

  it("kênh Zalo Bot API (không có api) thì từ chối thay vì ném lỗi", async () => {
    const c = { ...(ctx() as any), api: null };
    const out = await chay(tools.createVietCaptionTool(c as never), BO);
    assert.ok(loiCuaTool(out));
  });
});
