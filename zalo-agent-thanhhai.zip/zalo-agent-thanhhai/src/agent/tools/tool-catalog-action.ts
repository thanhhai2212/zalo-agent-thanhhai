import { getTuning } from "../../config/runtime-tuning-settings.js";
import { isImageGenConfigured } from "../../config/runtime-image-settings.js";
import { createAddReactionTool } from "./add-reaction-tool.js";
import { createExcelFileTool, createWordDocumentTool } from "./create-document-tools.js";
import { createPowerpointFileTool } from "./create-presentation-tool.js";
import { createBaoCaoDoLuongTool } from "./do-luong-tools.js";
import { createAnhBaiDangTool } from "./anh-bai-dang-tools.js";
import { createVietCaptionTool } from "./viet-caption-tools.js";
import { createKeHoachContentTool } from "./ke-hoach-content-tools.js";
import { createSoDoQuyTrinhTool } from "./so-do-quy-trinh-tool.js";
import { createBaoCaoDoiThuTool } from "./nghien-cuu-doi-thu-tools.js";
import { createSoanEmailTool } from "./soan-email-tools.js";
import {
  createCsvFileTool,
  createHtmlFileTool,
  createMarkdownFileTool,
  createPlainTextFileTool,
} from "./create-text-file-tools.js";
import { createPdfFileTool } from "./create-pdf-tool.js";
import { coTheInPdf } from "../../documents/chrome-finder.js";
import { createImageTool } from "./create-image-tool.js";
import { agentCoMusic, createMusicTool } from "./create-music-tool.js";
import { agentCoTts, createVoiceTool } from "./create-voice-tool.js";
import { createScheduleTaskTool } from "./schedule-task-tool.js";
import { createSaveMemoryTool } from "./save-memory-tool.js";
import { createLuuQuyTrinhTool } from "./luu-quy-trinh-tool.js";
import { createSendFileTool } from "./send-file-tool.js";
import { createTagMemberTool } from "./tag-member-tool.js";
import { createTaiMp3Tool } from "./tai-mp3-tool.js";
import { createTaiVideoTool } from "./tai-video-tool.js";
import { createGuiVaoNhomTool } from "./gui-vao-nhom-tool.js";
import { createOutreachTool } from "./outreach-tool.js";
import { createBaoChuXinYKienTool } from "./bao-chu-xin-y-kien-tool.js";
import type { ToolDefinition } from "./tool-catalog-types.js";

/**
 * Nhóm "action" của catalog tool - gửi/sửa thứ gì đó trên Zalo. Tách khỏi
 * `tool-catalog.ts` (đúng nếp tách theo NHÓM đã bàn ở phase 04) để không file
 * catalog nào vượt ngưỡng 200 dòng khi thêm tool mới.
 */
export const ACTION_TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    key: "add_reaction",
    label: "Thả cảm xúc",
    description: "Thả reaction (tim, like...) vào tin nhắn trong hội thoại",
    group: "action",
    // Không khoe: đây là phép lịch sự trong lúc trò chuyện, không phải việc ai
    // đó nhờ bot làm.
    keTrongKhaNang: false,
    // Lượt theo lịch không có tin thật nào (msgId rỗng) để mà thả reaction vào
    runsInScheduledTurn: false,
    build: (ctx) => createAddReactionTool(ctx),
  },
  {
    key: "send_file",
    label: "Gửi file",
    description: "Gửi file từ kho shared-files hoặc tải từ URL công khai rồi gửi",
    group: "action",
    // Gọi thẳng `enqueueSend` (rate-limiter THEO THREAD, không phải trần ngày)
    // để gửi - vào lượt theo lịch sẽ né hoàn toàn `SCHEDULER_MAX_PROACTIVE_PER_DAY`,
    // vì bộ đếm trần chỉ tăng ở đường `deliverProactively`/`reserveProactiveSlot`
    // của scheduler. Loại khỏi lượt theo lịch cho tới khi tool này đi qua đúng
    // đường đếm trần (đợt sau).
    runsInScheduledTurn: false,
    build: (ctx) => createSendFileTool(ctx),
  },
  {
    key: "create_word_document",
    label: "Tạo file Word",
    description: "Soạn nội dung thành file .docx (tiêu đề, đoạn văn, gạch đầu dòng, bảng) rồi gửi luôn",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua
    // enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createWordDocumentTool(ctx),
  },
  {
    key: "create_excel_file",
    label: "Tạo file Excel",
    description: "Soạn bảng số liệu thành file .xlsx có công thức tính sẵn rồi gửi luôn",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua
    // enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createExcelFileTool(ctx),
  },
  {
    key: "create_powerpoint_file",
    label: "Tạo file PowerPoint",
    description: "Soạn slide (tiêu đề, bullet, bảng, so sánh 2 cột) thành file .pptx rồi gửi luôn",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua
    // enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createPowerpointFileTool(ctx),
  },
  {
    key: "bao_cao_do_luong",
    label: "Báo cáo đo lường bài đăng",
    description: "Lập báo cáo đo lường từ số liệu người dùng cung cấp (tỉ lệ tương tác, so sánh theo trụ cột/kênh/định dạng, bài nổi bật, cảnh báo mẫu ít) thành file Excel gửi riêng một tin",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createBaoCaoDoLuongTool(ctx),
  },
  {
    key: "tao_anh_bai_dang",
    label: "Tạo bộ ảnh bài đăng",
    description: "Vẽ bộ ảnh bài đăng (tối đa 6) nhất quán phong cách thương hiệu, cắt đúng tỉ lệ từng kênh, gửi từng ảnh vào chat - mỗi ảnh 1-3 phút, tốn hạn mức vẽ ảnh",
    group: "action",
    // Gửi ảnh thẳng qua enqueueSend nhiều lần - né trần ngày của lịch hẹn, như create_image.
    runsInScheduledTurn: false,
    build: (ctx) => createAnhBaiDangTool(ctx),
  },
  {
    key: "viet_caption",
    label: "Viết caption từ lịch content",
    description: "Viết caption đầy đủ (hook, hashtag, CTA, gợi ý hình) cho các bài trong lịch content thành file Word gửi riêng một tin - chỉ soạn, bot không đăng bài",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createVietCaptionTool(ctx),
  },
  {
    key: "ke_hoach_content",
    label: "Kế hoạch content",
    description: "Lập kế hoạch content nhiều ngày (trụ cột, hook, storytelling, CTA, ngày thật) thành file Excel gửi riêng một tin - chỉ lập kế hoạch, bot không đăng bài",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createKeHoachContentTool(ctx),
  },
  {
    key: "tao_so_do_quy_trinh",
    label: "Sơ đồ quy trình",
    description: "Vẽ sơ đồ quy trình/workflow (thẻ từng bước: bạn đưa, bot làm, trả về, chốt chặn; mũi tên, vòng lặp, bảng so sánh) thành file HTML gửi riêng một tin",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createSoDoQuyTrinhTool(ctx),
  },
  {
    key: "bao_cao_doi_thu",
    label: "Báo cáo nghiên cứu đối thủ",
    description: "Dựng báo cáo nghiên cứu đối thủ (so sánh, điểm mạnh yếu, cơ hội, đề xuất, kèm nguồn và giới hạn dữ liệu) thành file Word gửi riêng một tin",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createBaoCaoDoiThuTool(ctx),
  },
  {
    key: "soan_email",
    label: "Soạn email công việc",
    description: "Soạn email công việc (đúng giọng, xưng hô, có ô trống chỗ chưa biết) thành file Word gửi riêng một tin - chỉ bản nháp, bot không gửi email thật",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createSoanEmailTool(ctx),
  },
  {
    key: "create_pdf_file",
    label: "Tạo file PDF",
    description: "Soạn nội dung thành file .pdf chuẩn văn bản Việt Nam (A4, Times New Roman 13pt) rồi gửi luôn",
    group: "action",
    // In bằng Chrome/Edge đã cài trên máy (puppeteer-core không kèm Chromium).
    // Kiểm mỗi lượt để cài Chrome xong là tool bật lên ngay, không cần restart.
    available: () => coTheInPdf(),
    unavailableHint:
      "Chưa tìm thấy Chrome hoặc Edge trên máy. Cài Chrome, hoặc đặt biến môi trường CHROME_PATH trỏ tới file chạy.",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua
    // enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createPdfFileTool(ctx),
  },
  {
    key: "create_markdown_file",
    label: "Tạo file Markdown",
    description: "Soạn nội dung thành file .md (ghi chú, tài liệu kỹ thuật, checklist) rồi gửi luôn",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua
    // enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createMarkdownFileTool(ctx),
  },
  {
    key: "create_html_file",
    label: "Tạo file HTML",
    description: "Soạn trang .html xem được trên trình duyệt rồi gửi luôn (mã chạy được bị loại bỏ)",
    group: "action",
    runsInScheduledTurn: false,
    build: (ctx) => createHtmlFileTool(ctx),
  },
  {
    key: "create_csv_file",
    label: "Tạo file CSV",
    description: "Soạn bảng dữ liệu thành file .csv để nạp vào Excel/Google Sheets rồi gửi luôn",
    group: "action",
    runsInScheduledTurn: false,
    build: (ctx) => createCsvFileTool(ctx),
  },
  {
    key: "create_text_file",
    label: "Tạo file văn bản",
    description: "Soạn nội dung thành file .txt không định dạng rồi gửi luôn",
    group: "action",
    runsInScheduledTurn: false,
    build: (ctx) => createPlainTextFileTool(ctx),
  },
  {
    key: "create_image",
    label: "Vẽ ảnh AI",
    description: "Vẽ ảnh mới hoặc sửa ảnh người dùng vừa gửi (đổi màu, xóa vật thể, đổi phong cách) rồi gửi luôn",
    group: "action",
    hasSettings: true,
    available: () => isImageGenConfigured(),
    unavailableHint: "Bấm Settings để cấu hình endpoint + model vẽ ảnh",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi 2 tin ("đang
    // vẽ..." rồi ảnh) thẳng qua enqueueSend, né trần ngày. Nặng nhất trong
    // nhóm 5 tool này: job every 5 phút + prompt "vẽ ảnh rồi [SILENT]" ra
    // hàng trăm tin chủ động/ngày mà trần không bao giờ chặn được.
    runsInScheduledTurn: false,
    build: (ctx) => createImageTool(ctx),
  },
  {
    key: "create_voice",
    label: "Tạo giọng nói (voice)",
    description: "Chuyển văn bản thành voice rồi gửi vào hội thoại (bong bóng nghe được)",
    group: "action",
    // Cấu hình TTS RIÊNG từng agent (trang Agents). Chỉ vào schema của agent khi
    // agent đó có đủ base URL + model + key TTS - scope không truyền (trang Tools
    // hỏi hạ tầng chung) thì coi là "được", badge thật do client tính theo agent.
    available: (scope) => (scope ? agentCoTts(scope.agent) : true),
    unavailableHint: "Cấu hình mục Giọng nói (TTS) cho agent này ở trang Agents",
    // Gửi thẳng qua enqueueSend (upload + sendVoice), né trần ngày - CÙNG nhóm
    // với create_image/send_file.
    runsInScheduledTurn: false,
    build: (ctx) => createVoiceTool(ctx),
  },
  {
    key: "create_music",
    label: "Tạo nhạc AI",
    description: "Sáng tác bài hát/bản nhạc từ mô tả (thể loại, chủ đề, lời) rồi gửi vào hội thoại dạng file",
    group: "action",
    // Cấu hình OpenRouter RIÊNG từng agent (trang Agents). Chỉ vào schema khi
    // agent đó có đủ model + key - cùng nếp create_voice/agentCoTts.
    available: (scope) => (scope ? agentCoMusic(scope.agent) : true),
    unavailableHint: "Cấu hình mục Tạo nhạc cho agent này ở trang Agents",
    // Gửi thẳng qua enqueueSend (câu báo + file), né trần ngày - cùng nhóm
    // create_image/create_voice.
    runsInScheduledTurn: false,
    build: (ctx) => createMusicTool(ctx),
  },
  {
    key: "tai_video",
    label: "Tải video TikTok/Facebook",
    description: "Tải video từ link TikTok, Facebook hoặc Instagram rồi gửi thẳng vào hội thoại",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua
    // enqueueSend (bên trong guiVideoQuaZalo), né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createTaiVideoTool(ctx),
  },
  {
    key: "tai_mp3",
    label: "Tải MP3",
    description: "Tải phần âm thanh của video YouTube/TikTok/Facebook/Instagram thành file MP3 rồi gửi vào hội thoại",
    group: "action",
    // Cùng lý do của tai_video: gửi thẳng qua enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createTaiMp3Tool(ctx),
  },
  {
    key: "tag_member",
    label: "Tag thành viên",
    description: "Nhắc tên (@mention) thành viên trong nhóm khi trả lời",
    group: "action",
    // Cùng lý do runsInScheduledTurn:false của send_file - gửi thẳng qua
    // enqueueSend, né trần ngày.
    runsInScheduledTurn: false,
    build: (ctx) => createTagMemberTool(ctx),
  },
  {
    key: "save_memory",
    label: "Ghi nhớ lâu dài",
    description: "Tự lưu fact về người dùng/nhóm để nhớ qua các phiên chat sau",
    group: "action",
    // Đường nội dung web đi vào trí nhớ vĩnh viễn là prompt injection thật, và
    // lượt theo lịch vốn không có phát ngôn nào của user để mà học
    runsInScheduledTurn: false,
    build: (ctx) => createSaveMemoryTool(ctx),
  },
  {
    key: "luu_quy_trinh",
    label: "Lưu cách làm thành quy trình",
    description: "Chủ bot bảo \"lưu cách làm này\" thì đúc kết cuộc trò chuyện thành quy trình trong Kho tri thức, lần sau kb_search tra ra",
    group: "action",
    // Chỉ chủ bot ra lệnh trong hội thoại thật; lượt theo lịch không có ai dạy gì để lưu
    runsInScheduledTurn: false,
    build: (ctx) => createLuuQuyTrinhTool(ctx),
  },
  {
    key: "gui_vao_nhom",
    label: "Gửi tin vào nhóm",
    description: "Chủ bot ra lệnh từ chat riêng để bot gửi tin/file đã tạo vào một nhóm bot đang tham gia",
    group: "action",
    // Năng lực riêng của chủ tài khoản - cùng lý do undo_message không khoe.
    keTrongKhaNang: false,
    // Gửi thẳng qua enqueueSend, và lượt theo lịch không có chủ nào đang ra lệnh.
    runsInScheduledTurn: false,
    build: (ctx) => createGuiVaoNhomTool(ctx),
  },
  {
    key: "gui_tin_ca_nhan",
    label: "Nhắn riêng theo số điện thoại",
    description: "Chủ bot ra lệnh từ chat riêng để bot nhắn riêng một danh sách khách theo số điện thoại (soạn, xem trước, chủ xác nhận rồi mới gửi chậm)",
    group: "action",
    keTrongKhaNang: false,
    // Lượt theo lịch không có chủ nào đang ra lệnh để xác nhận.
    runsInScheduledTurn: false,
    // Cửa 1: chỉ vào schema khi chính chủ bot nhắn riêng (cùng cờ với server MCP
    // "chỉ chủ bot"); người khác không biết tool này tồn tại. Cửa 2 trong execute.
    available: (scope) => scope?.chuChatRieng === true,
    build: (ctx) => createOutreachTool(ctx),
  },
  {
    key: "bao_chu_xin_y_kien",
    label: "Xin ý kiến chủ bot",
    description: "Người trong nhóm hỏi chuyện nội bộ nhạy cảm: bot hoãn trong nhóm và nhắn riêng xin ý kiến chủ",
    group: "action",
    keTrongKhaNang: false,
    // Lượt theo lịch không có người hỏi nào để mà xin ý kiến.
    runsInScheduledTurn: false,
    build: (ctx) => createBaoChuXinYKienTool(ctx),
  },
  {
    key: "schedule_task",
    label: "Lịch hẹn",
    description: "Đặt/xem/sửa/hủy lịch để bot tự nhắn lại đúng cuộc trò chuyện này ở một mốc giờ trong tương lai",
    group: "action",
    // Tắt cả tính năng lịch hẹn (vòng tick không chạy nữa) thì tool cũng biến
    // khỏi schema - đặt job mới lúc đó vô nghĩa, không có gì nhặt job lên chạy
    available: () => getTuning("SCHEDULER_ENABLED"),
    unavailableHint: 'Bật "Bật lịch hẹn" trong Cấu hình > Lịch hẹn để dùng tool này',
    // Luật số 1 của Hermes: job không được đẻ job
    runsInScheduledTurn: false,
    build: (ctx) => createScheduleTaskTool(ctx),
  },
];
