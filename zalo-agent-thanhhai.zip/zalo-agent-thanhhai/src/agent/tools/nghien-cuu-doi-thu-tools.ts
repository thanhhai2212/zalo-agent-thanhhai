import { tool } from "ai";
import { z } from "zod";
import { safeFileName } from "../../documents/document-limits.js";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { HUONG_DAN_NGHIEN_CUU_DOI_THU } from "../../noi-dung/huong-dan-nghien-cuu-doi-thu.js";
import { chinhDoTinCay, nguonHopLe, renderBaoCaoDoiThu } from "../../noi-dung/render-bao-cao-doi-thu.js";
import { deliverFile, guard } from "./deliver-generated-file.js";
import type { ToolContext } from "./index.js";
import { chanKhongPhaiChu } from "./owner-action-gate.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Khâu thử đầu tiên của hướng "Zalo Agent business" (2026-10-02): nghiên cứu đối thủ ra
 * báo cáo Word. Bot thu thập bằng web_search / web_fetch / Apify MCP rồi dựng báo cáo.
 * Chốt chặn CẤU TRÚC chống bịa: mỗi đối thủ phải có nguồn là địa chỉ web thật, và báo
 * cáo phải có phần giới hạn dữ liệu - không dựa vào việc model tự giác ghi nguồn.
 */

export function createHuongDanNghienCuuDoiThuTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Đọc quy trình nghiên cứu đối thủ (hỏi gì, thu thập gì, xác minh, phân tích). GỌI TRƯỚC khi nghiên cứu đối thủ hoặc soạn bao_cao_doi_thu.",
    inputSchema: z.object({}),
    execute: async () => chanKhongPhaiChu(ctx) ?? HUONG_DAN_NGHIEN_CUU_DOI_THU,
  });
}

// Giới hạn RỘNG có chủ ý: model nghiên cứu viết dài và xếp bảng theo cách riêng; schema chặt
// làm cả báo cáo (đã tốn 2-3 phút thu thập) bị từ chối vì một ô quá dài (đo thật 2026-10-02).
// Phần thừa được cắt khi dựng file (render-bao-cao-doi-thu.ts), không từ chối.
const chuoi = (max = 1500) => z.string().min(1).max(max);
const doiThuSchema = z.object({
  ten: chuoi(200),
  website: z.string().max(400).optional(),
  dinh_vi: chuoi(1200).describe("Họ làm gì, cho ai, khác biệt chính"),
  diem_manh: z.array(chuoi()).min(1).max(12),
  diem_yeu: z.array(chuoi()).min(1).max(12),
  nhan_dinh_ai: z
    .array(chuoi())
    .max(8)
    .optional()
    .describe("Đánh giá/ý kiến của BẠN không có nguồn trực tiếp (vd \"ít tương tác cộng đồng\"). diem_manh/diem_yeu CHỈ chứa điều có nguồn"),
  gia: z.string().max(1200).optional().describe("Giá/gói, ghi đúng con số và thời điểm đọc; chưa biết thì bỏ trống"),
  kenh: z.array(z.string().max(200)).max(15).optional(),
  thong_diep: z.string().max(1200).optional(),
  do_tin_cay: z.enum(["cao", "vua", "thap"]).describe("cao: nhiều nguồn mới; vua: 1-2 nguồn; thap: nguồn đơn lẻ hoặc cũ"),
  nguon: z.array(z.string().max(800)).min(1).max(15).describe("Địa chỉ web (http/https) đã đọc để có thông tin trên"),
});

export function createBaoCaoDoiThuTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Dựng báo cáo nghiên cứu đối thủ thành file Word rồi gửi thành MỘT tin riêng. Đọc huong_dan_nghien_cuu_doi_thu và thu thập dữ liệu thật trước. " +
      "Mỗi đối thủ phải có nguồn là địa chỉ web đã đọc; không bịa giá, số liệu. Phần giới hạn dữ liệu bắt buộc.",
    inputSchema: z.object({
      tieu_de: z.string().min(3).max(300),
      san_pham: z.string().min(1).max(1200).describe("Sản phẩm/dịch vụ của người dùng"),
      thi_truong: z.string().min(1).max(1200),
      tom_tat: z.array(chuoi()).min(1).max(12).describe("Các phát hiện chính"),
      doi_thu: z.array(doiThuSchema).min(1).max(12),
      bang_so_sanh: z
        .object({
          tieu_chi: z.array(z.string().max(200)).min(1).max(20).describe("Tên các CỘT tiêu chí (giá, kênh...), KHÔNG gồm tên đối thủ"),
          hang: z
            .array(z.object({ ten: z.string().max(200).describe("Tên đối thủ"), gia_tri: z.array(z.string().max(2000)).max(20).describe("Giá trị theo đúng thứ tự tieu_chi") }))
            .min(1)
            .max(15),
        })
        .optional(),
      co_hoi: z.array(chuoi()).min(1).max(12).describe("Khoảng trống, điều khách cần mà chưa ai làm tốt"),
      de_xuat: z.array(chuoi()).min(1).max(15).describe("Hành động cụ thể, ưu tiên theo dễ làm và tác động"),
      han_che_du_lieu: z.array(chuoi()).min(1).max(12).describe("Cái gì không lấy được hoặc chỉ là ước đoán"),
      ten_file: z.string().max(80).optional(),
      caption: z.string().max(300).optional(),
    }),
    execute: ({ ten_file, caption, ...bc }) =>
      guard(async () => {
        const chan = chanKhongPhaiChu(ctx);
        if (chan) return chan;
                const thieu = bc.doi_thu.filter((d) => !d.nguon.every(nguonHopLe));
        if (thieu.length) {
          return ketQuaLoi(
            `Nguồn của ${thieu.map((d) => d.ten).join(", ")} chưa phải địa chỉ web (http/https) hợp lệ. ` +
              "Mỗi đối thủ phải có địa chỉ trang đã đọc. Không đọc được thì bỏ thông tin đó hoặc ghi vào han_che_du_lieu, đừng bịa nguồn.",
          );
        }
        const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);
        // Hạ độ tin cậy lạc quan (xem chinhDoTinCay): "cao" cần >= 2 tên miền nguồn khác nhau.
        const daHa: string[] = [];
        bc.doi_thu = bc.doi_thu.map((d) => {
          const c = chinhDoTinCay(d);
          if (c.daHa) daHa.push(d.ten);
          return { ...d, do_tin_cay: c.muc };
        });
        const docx = await renderBaoCaoDoiThu(bc);
        const ten = safeFileName(ten_file || `bao cao doi thu ${bc.tieu_de}`.toLowerCase(), "docx");
        const gui = await deliverFile(ctx, ten, docx, caption);
        if (typeof gui !== "string") return gui;
        const thap = bc.doi_thu.filter((d) => d.do_tin_cay === "thap").map((d) => d.ten);
        return [
          gui,
          daHa.length ? `Đã tự hạ độ tin cậy từ Cao xuống Vừa vì chỉ có một tên miền nguồn: ${daHa.join(", ")}.` : "",
          thap.length ? `Dữ liệu độ tin cậy thấp: ${thap.join(", ")}. Nói rõ với người dùng.` : "Không có đối thủ nào độ tin cậy thấp.",
          "Bàn giao: tin ngắn nêu 2-3 phát hiện chính, điều chưa xác minh được, hỏi có muốn đào sâu hoặc lên kế hoạch content từ báo cáo. KHÔNG dán lại cả báo cáo vào chat.",
        ].join("\n");
      }),
  });
}
