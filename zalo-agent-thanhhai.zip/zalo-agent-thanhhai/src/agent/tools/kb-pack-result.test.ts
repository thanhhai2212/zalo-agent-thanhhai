import assert from "node:assert/strict";
import { describe, it } from "node:test";
// Module thuần (không env, không DB) - import tĩnh an toàn.
import { dongGoiTheoNganSach, KB_PACK_SEPARATOR } from "./kb-pack-result.js";

/**
 * Qua BA vòng rà soát -
 * giữ nguyên vẹn.
 */

/** Đoạn dài đúng `doDai` ký tự, tiền tố số để phân biệt từng đoạn khi kiểm nội dung. */
function doanCoDo(i: number, doDai: number): string {
  const nhan = `D${i}_`;
  return nhan + "x".repeat(Math.max(0, doDai - nhan.length));
}

describe("dongGoiTheoNganSach - ba nhánh", () => {
  it("đủ chỗ cho TẤT CẢ đoạn: nối nguyên vẹn, không nhãn nào", () => {
    const doan = [doanCoDo(0, 50), doanCoDo(1, 50), doanCoDo(2, 50)];
    const kq = dongGoiTheoNganSach(doan, 10_000);
    assert.equal(kq, doan.join(KB_PACK_SEPARATOR));
  });

  it("bỏ đoạn: đủ chỗ cho MỘT PHẦN, phần còn lại bị bỏ hẳn kèm nhãn ĐÚNG SỐ", () => {
    const doan = Array.from({ length: 5 }, (_, i) => doanCoDo(i, 1000));
    const kq = dongGoiTheoNganSach(doan, 2207);
    assert.ok(kq.includes(doan[0]!), "phải còn đoạn 0");
    assert.ok(kq.includes(doan[1]!), "phải còn đoạn 1");
    assert.ok(!kq.includes(doan[2]!), "đoạn 2 phải bị bỏ hẳn, không cắt cụt");
    assert.ok(!kq.includes(doan[3]!) && !kq.includes(doan[4]!), "đoạn 3, 4 cũng bị bỏ hẳn");
    assert.match(kq, /còn 3 đoạn nữa không đủ chỗ/, `phải báo ĐÚNG 3 đoạn còn lại, thực tế: ${JSON.stringify(kq)}`);
  });

  it("cắt đoạn đầu: ngay cả đoạn đầu cũng không vừa - cắt ở ranh giới khoảng trắng, không trả rỗng", () => {
    const doan = [doanCoDo(0, 5000)];
    const kq = dongGoiTheoNganSach(doan, 500);
    assert.ok(kq.length > 0, "không được trả rỗng");
    assert.match(kq, /đã rút gọn/, "phải ghi rõ đã rút gọn");
    assert.ok(!kq.includes(doan[0]!), "không được chứa nguyên văn đoạn gốc (phải bị cắt thật)");
    assert.doesNotMatch(kq, /còn \d+ đoạn/, `chỉ có ĐÚNG 1 đoạn, không được báo còn đoạn nào: ${JSON.stringify(kq)}`);
  });

  it("cắt đoạn đầu VÀ còn đoạn khác phía sau: PHẢI báo cả hai", () => {
    const doan = [doanCoDo(0, 5000), doanCoDo(1, 5000), doanCoDo(2, 5000)];
    const kq = dongGoiTheoNganSach(doan, 500);
    assert.match(kq, /đã rút gọn/, "đoạn đầu phải được ghi nhận đã cắt");
    assert.match(kq, /còn 2 đoạn nữa không đủ chỗ/, `phải báo còn ĐÚNG 2 đoạn (1 và 2), thực tế: ${JSON.stringify(kq)}`);
  });
});

describe("dongGoiTheoNganSach - chiều ÂM: đủ chỗ thì KHÔNG được có nhãn nào", () => {
  it("không nhãn 'còn N đoạn' khi mọi đoạn đều vừa", () => {
    const doan = [doanCoDo(0, 30), doanCoDo(1, 30)];
    const kq = dongGoiTheoNganSach(doan, 5000);
    assert.doesNotMatch(kq, /còn \d+ đoạn/);
  });

  it("không nhãn 'đã rút gọn' khi mọi đoạn đều vừa", () => {
    const doan = [doanCoDo(0, 30), doanCoDo(1, 30)];
    const kq = dongGoiTheoNganSach(doan, 5000);
    assert.doesNotMatch(kq, /đã rút gọn/);
  });
});

describe("dongGoiTheoNganSach - bất biến CỨNG: không bao giờ vượt ngân sách xin", () => {
  it("quét 31 cỡ đoạn x 201 mức trần (đúng quy mô đã đo) - luôn kq.length <= nganSachNoiDung", () => {
    const soDoan = 6;
    let soToHop = 0;
    for (let doDaiDoan = 20; doDaiDoan <= 620; doDaiDoan += 20) {
      const doan = Array.from({ length: soDoan }, (_, i) => doanCoDo(i, doDaiDoan));
      for (let tran = 300; tran <= 2300; tran += 10) {
        const kq = dongGoiTheoNganSach(doan, tran);
        soToHop++;
        assert.ok(kq.length <= tran, `doDaiDoan=${doDaiDoan} tran=${tran} -> dài ${kq.length} (vượt ${kq.length - tran})`);
      }
    }
    assert.ok(soToHop > 6000, `phải quét đủ nhiều tổ hợp, thực tế ${soToHop}`);
  });
});
