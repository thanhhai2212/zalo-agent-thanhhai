import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let tools: typeof import("./anh-bai-dang-tools.js");
let crop: typeof import("../../images/crop-ti-le.js");
let prompt: typeof import("../../noi-dung/dung-prompt-anh.js");
let rateLimit: typeof import("../../images/image-rate-limit.js");
let canvas: typeof import("@napi-rs/canvas");

type DaGui = { ten: string; buf: Buffer; caption: string };
let daGui: DaGui[] = [];
let prompts: string[] = [];
let loiVe: Error | null = null;

before(async () => {
  dataDir = setupTestEnv({ IMAGE_GEN_MAX_PER_HOUR: "3" });
  tools = await import("./anh-bai-dang-tools.js");
  crop = await import("../../images/crop-ti-le.js");
  prompt = await import("../../noi-dung/dung-prompt-anh.js");
  rateLimit = await import("../../images/image-rate-limit.js");
  canvas = await import("@napi-rs/canvas");
  (await import("../../config/runtime-image-settings.js")).updateImageSettings({
    baseUrl: "https://router.test",
    model: "cx/gpt-image-test",
    apiKey: "sk-test",
  });
});
after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  prompts = [];
  loiVe = null;
  rateLimit.resetImageRateLimit();
});

/** PNG thật cỡ w x h (để kiểm cắt tỉ lệ bằng cách giải mã lại). */
function png(w: number, h: number): Buffer {
  const c = canvas.createCanvas(w, h);
  const g = c.getContext("2d");
  g.fillStyle = "#c08040";
  g.fillRect(0, 0, w, h);
  return c.toBuffer("image/png");
}

/* eslint-disable @typescript-eslint/no-explicit-any */
const fakeGenerate: any = async (p: { prompt: string }) => {
  prompts.push(p.prompt);
  if (loiVe) throw loiVe;
  return { data: png(1536, 1024), ext: "png" };
};

function ctx(nguoiGui = "chu") {
  return {
    api: {
      sendMessage: async (c: { msg?: string; attachments?: string[] }) => {
        if (c.attachments?.[0]) {
          daGui.push({ ten: path.basename(c.attachments[0]), buf: fs.readFileSync(c.attachments[0]), caption: c.msg ?? "" });
        }
        return {};
      },
    },
    account: { id: "acc-anh", disabledTools: [], ownerUserId: "chu" },
    message: { threadId: "t-anh", threadType: 1, senderId: nguoiGui },
    batch: [],
  } as never;
}
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

const anh = (ten: string, ti_le: string, over: Record<string, unknown> = {}) => ({
  ten,
  tieu_de_bai: `Bài ${ten}`,
  ti_le,
  y_tuong: "Một tách cà phê phin đang nhỏ giọt bên cửa sổ buổi sáng",
  ...over,
});
const BO = {
  thuong_hieu: "Hạt Mộc",
  phong_cach: "ảnh chụp thực tế, ánh sáng tự nhiên, ấm áp, mộc mạc",
  mau_sac: "nâu cà phê, kem, xanh rêu",
  anh: [anh("a1", "1:1"), anh("a2", "9:16")],
};

async function kichThuoc(buf: Buffer): Promise<{ w: number; h: number }> {
  const img = await canvas.loadImage(buf);
  return { w: img.width, h: img.height };
}

describe("tinhVungCat", () => {
  it("cắt giữa về đúng tỉ lệ cho ảnh ngang và ảnh dọc", () => {
    assert.deepEqual(crop.tinhVungCat(1536, 1024, 1, 1), { x: 256, y: 0, w: 1024, h: 1024 });
    assert.deepEqual(crop.tinhVungCat(1536, 1024, 9, 16), { x: 480, y: 0, w: 576, h: 1024 });
    assert.deepEqual(crop.tinhVungCat(1000, 1000, 16, 9), { x: 0, y: 218, w: 1000, h: 563 });
  });
  it("ảnh đã đúng tỉ lệ thì không cắt lại", async () => {
    const kq = await crop.canTiLe(png(800, 800), "1:1");
    assert.equal(kq.daCat, false);
  });
});

describe("dungPromptAnh", () => {
  it("chèn phong cách thương hiệu, tỉ lệ, điều cấm; mặc định KHÔNG chữ", () => {
    const p = prompt.dungPromptAnh({ thuong_hieu: "Hạt Mộc", phong_cach: "mộc mạc", mau_sac: "nâu" }, { ti_le: "4:5", y_tuong: "tách cà phê" });
    assert.ok(p.includes('thương hiệu "Hạt Mộc"'));
    assert.ok(p.includes("mộc mạc"));
    assert.ok(p.includes("4:5"));
    assert.ok(p.includes("Không có chữ, không logo, không watermark"));
    assert.ok(p.includes("người nổi tiếng"));
  });
  it("có chữ trên ảnh thì chỉ đúng một dòng, có dấu chính xác", () => {
    const p = prompt.dungPromptAnh(
      { thuong_hieu: "Hạt Mộc", phong_cach: "x", mau_sac: "y", tranh: "ảnh quá tối" },
      { ti_le: "1:1", y_tuong: "z", chu_tren_anh: "RANG HÔM NAY" },
    );
    assert.ok(p.includes('chỉ có đúng dòng chữ "RANG HÔM NAY"'));
    assert.ok(p.includes("ảnh quá tối"));
    assert.ok(!p.includes("Không có chữ, không logo"));
  });
});

describe("huong_dan_anh_bai_dang", () => {
  it("có tỉ lệ theo kênh, chữ trên ảnh, trung thực ảnh AI và quy tắc không đăng bài", async () => {
    const out = await chay(tools.createHuongDanAnhBaiDangTool(ctx()), {});
    assert.match(out, /9:16/);
    assert.match(out, /sai dấu/);
    assert.match(out, /MINH HỌA/);
    assert.match(out, /không đăng bài/);
  });
});

describe("tao_anh_bai_dang", () => {
  it("vẽ cả bộ, mọi prompt có khối phong cách, cắt đúng tỉ lệ, gửi từng ảnh kèm lời nhắn", async () => {
    const out = await chay(tools.createAnhBaiDangTool(ctx(), fakeGenerate), BO);
    assert.equal(daGui.length, 2);
    assert.equal(prompts.length, 2);
    for (const p of prompts) assert.ok(p.includes("ảnh chụp thực tế, ánh sáng tự nhiên") && p.includes("nâu cà phê, kem, xanh rêu"));
    const a1 = daGui.find((g) => g.caption.startsWith("a1"))!;
    const a2 = daGui.find((g) => g.caption.startsWith("a2"))!;
    assert.deepEqual(await kichThuoc(a1.buf), { w: 1024, h: 1024 });
    const k2 = await kichThuoc(a2.buf);
    assert.ok(Math.abs(k2.w / k2.h - 9 / 16) < 0.01, `9:16, nhận ${k2.w}x${k2.h}`);
    assert.match(a1.ten, /\.jpg$/);
    assert.match(String(out), /Đã vẽ và GỬI 2\/2 ảnh/);
    assert.match(String(out), /minh họa/);
  });

  it("chạm trần ảnh mỗi giờ thì ảnh còn lại báo chưa vẽ, không lỗi cả bộ", async () => {
    const bo = { ...BO, anh: [anh("a1", "1:1"), anh("a2", "1:1"), anh("a3", "1:1"), anh("a4", "1:1"), anh("a5", "1:1")] };
    const out = await chay(tools.createAnhBaiDangTool(ctx(), fakeGenerate), bo);
    assert.equal(daGui.length, 3);
    assert.match(String(out), /Đã vẽ và GỬI 3\/5/);
    assert.match(String(out), /chưa vẽ vì chạm trần/);
  });

  it("một ảnh lỗi nhà cung cấp không làm mất ảnh khác, và báo thật", async () => {
    let n = 0;
    const gen: any = async (p: { prompt: string }) => {
      if (n++ === 0) throw new Error("hết quota");
      return fakeGenerate(p);
    };
    const out = await chay(tools.createAnhBaiDangTool(ctx(), gen), { ...BO, anh: [anh("loi", "1:1")] });
    assert.equal(daGui.length, 0);
    assert.match(String(out), /Đã vẽ và GỬI 0\/1/);
    assert.match(String(out), /vẽ thất bại \(hết quota\)/);
  });

  it("nhãn ảnh trùng nhau thì từ chối, chưa vẽ gì", async () => {
    const out = await chay(tools.createAnhBaiDangTool(ctx(), fakeGenerate), { ...BO, anh: [anh("x", "1:1"), anh("x", "9:16")] });
    assert.ok(loiCuaTool(out));
    assert.equal(prompts.length, 0);
  });

  it("schema: tối đa 6 ảnh, tỉ lệ lạ bị chặn, chữ trên ảnh quá dài bị chặn", async () => {
    const t = tools.createAnhBaiDangTool(ctx(), fakeGenerate) as any;
    assert.equal(t.inputSchema.safeParse({ ...BO, anh: Array.from({ length: 7 }, (_, i) => anh(`n${i}`, "1:1")) }).success, false);
    assert.equal(t.inputSchema.safeParse({ ...BO, anh: [anh("a", "3:2")] }).success, false);
    assert.equal(t.inputSchema.safeParse({ ...BO, anh: [anh("a", "1:1", { chu_tren_anh: "x".repeat(41) })] }).success, false);
    assert.equal(t.inputSchema.safeParse(BO).success, true);
  });


  it("NGƯỜI KHÁC trong nhóm (không phải chủ tài khoản) bị từ chối, không tạo/gửi gì", async () => {
    const out = await chay(tools.createAnhBaiDangTool(ctx("nguoi-la") as never, fakeGenerate), BO);
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /Chỉ chủ tài khoản/);
    assert.equal(daGui.length, 0);
    const guideOut = await chay(tools.createHuongDanAnhBaiDangTool(ctx("nguoi-la")), {});
    assert.ok(loiCuaTool(guideOut), "hướng dẫn cũng chỉ dành cho chủ");
  });

  it("kênh Zalo Bot API (không có api) thì từ chối thay vì ném lỗi", async () => {
    const c = { ...(ctx() as any), api: null };
    const out = await chay(tools.createAnhBaiDangTool(c as never, fakeGenerate), BO);
    assert.ok(loiCuaTool(out));
  });
});
