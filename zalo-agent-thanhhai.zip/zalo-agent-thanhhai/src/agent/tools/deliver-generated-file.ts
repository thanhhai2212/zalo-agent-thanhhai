import { luuFileDaTao } from "../../second-brain/generated-file-store.js";
import { createLogger } from "../../shared/logger.js";
import { withNamedTempFile } from "../../shared/temp-file-store.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import type { ToolContext } from "./index.js";
import { ketQuaLoi, type KetQuaLoiTool } from "./tool-failure-result.js";
import { guiFileKemCaption } from "./send-attachment-with-caption.js";
import { ghiChuDaGuiFile } from "./sent-by-tool-note.js";

/**
 * Đường GỬI dùng chung cho mọi tool tự dựng file (.docx, .xlsx, .md, .html,
 * .csv, .txt).
 *
 * Tách khỏi `create-document-tools.ts` khi thêm nhóm file văn bản thuần: hai
 * file tool cùng cần y hệt bộ ba "ghi temp -> gửi kèm caption -> ghi vào
 * history", mà đó đúng là chỗ `send-attachment-with-caption.ts` đã dặn - lưới
 * an toàn phải nằm ở MỘT chỗ, rải ra nhiều nơi thì sớm muộn có nơi bị bỏ quên.
 * Ở đây "bỏ quên" nghĩa là file gửi rồi nhưng biến mất khỏi dashboard và khỏi
 * trí nhớ của chính bot ở lượt sau (thiếu `ghiNhanDaGui`).
 */

const log = createLogger("deliver-file");

export const DELIVERED_NOTE =
  "Đã tạo và GỬI file cho người dùng rồi. KHÔNG gọi send_file để gửi lại file này.";

export type DeliverCtx = Pick<ToolContext, "api" | "account" | "message" | "ghiNhanDaGui">;

/** Dựng buffer -> gửi kèm caption -> xóa file tạm. Trả câu cho model đọc. */
export async function deliverFile(
  ctx: DeliverCtx,
  fileName: string,
  data: Buffer,
  caption: string | undefined,
  /** false cho file KHÔNG phải bot soạn (vd MP3 tải từ YouTube) - không đưa vào second brain. */
  luuBanSao = true,
): Promise<string | KetQuaLoiTool> {
  // Cửa 2 (recheck runtime) - Cửa 1 đã chặn mọi tool tạo file khỏi schema kênh
  // bot ở nang-luc-kenh-bot.ts (Zalo Bot API không có method gửi tài liệu).
  if (!ctx.api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);
  const threadKey = `${ctx.account.id}:${ctx.message.threadId}`;
  await withNamedTempFile(fileName, data, (filePath) =>
    guiFileKemCaption(
      ctx.api!,
      threadKey,
      ctx.message.threadId,
      ctx.message.threadType,
      filePath,
      caption,
    ),
  );
  // Giữ bản sao cho second brain (Notion / Kho tri thức) - trước đây file bị
  // xóa ngay sau khi gửi, nội dung mất vĩnh viễn. Lưu hỏng không làm hỏng gửi.
  if (luuBanSao) luuFileDaTao({ accountId: ctx.account.id, threadId: ctx.message.threadId, fileName, data });
  // Vào history: tin này KHÔNG đi qua `deliverChatReply` nên không ai ghi hộ.
  // Thiếu nó thì dashboard không thấy, và lượt sau bot không nhớ đã gửi file.
  ctx.ghiNhanDaGui?.(ghiChuDaGuiFile(fileName, caption));
  log.info(
    { accountId: ctx.account.id, threadId: ctx.message.threadId, fileName, bytes: data.length },
    "Đã gửi file tự tạo",
  );
  return `${DELIVERED_NOTE} (tên file: ${fileName}, ${Math.round(data.length / 1024)} KB)`;
}

/** Gói mọi nhánh lỗi thành câu cho model đọc - không throw ra agent loop */
export async function guard(
  work: () => Promise<string | KetQuaLoiTool>,
): Promise<string | KetQuaLoiTool> {
  try {
    return await work();
  } catch (err) {
    const reason = err instanceof Error ? err.message : String(err);
    log.warn({ err }, "Tạo/gửi file thất bại");
    return ketQuaLoi(
      `Không tạo được file (${reason}). Nói thật với người dùng và trả lời nội dung trực tiếp trong chat.`,
    );
  }
}
