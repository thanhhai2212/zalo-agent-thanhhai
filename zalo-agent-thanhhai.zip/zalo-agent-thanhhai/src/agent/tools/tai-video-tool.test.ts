import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import type { KetQuaChuoi } from "../../video/chuoi-nguon-video.js";
import type { KetQuaGui } from "../../video/gui-video-qua-zalo.js";
import type { ThongTinVideo } from "../../video/thong-tin-video.js";
import { loiCuaTool, ketQuaThanhCong } from "./tool-failure-result-test-helper.js";
import type { AgentProfile } from "../../config/agent-store.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";

/**
 * `fakeAgentProfile` VÀ `LoiGuiVideo` (giá trị, không phải type) đều PHẢI vào
 * qua `await import()` động trong `before()`, không phải import tĩnh ở đây:
 * `LoiGuiVideo` bắc cầu qua `gui-video-qua-zalo.ts` -> `send-attachment-with-caption.ts`
 * -> `rate-limiter.ts` -> `runtime-tuning-settings.ts` -> `env.ts`/`database.ts`.
 * Import tĩnh nạp `env.ts` (đọc `process.env` MỘT LẦN) TRƯỚC khi `before()` kịp
 * gọi `setupTestEnv()` - đúng bẫy CLAUDE.md đã ghi, và đã dính thật ở đây: mọi
 * `getTuning("VIDEO_DOWNLOAD_MAX_PER_HOUR")` âm thầm đọc mặc định 15 thay vì
 * "2" test override, nên trần "chạm trần thì KHÔNG gọi layVideo" không bao giờ chặn.
 */

/**
 * `tai_video`: TikTok/Facebook/Instagram. `layVideo`/`guiVideo` tiêm được từ
 * ngoài - test không gọi TikWM thật, không chạy yt-dlp thật, không gửi Zalo
 * thật (đúng nếp `create-video-tool.test.ts`/`PhuThuocTaiVideo`).
 */

let dataDir: string;
let toolModule: typeof import("./tai-video-tool.js");
let rateLimit: typeof import("../../video/tai-video-rate-limit.js");
let database: typeof import("../../conversation/database.js");
let fakeAgentProfile: typeof import("../../shared/fake-agent-profile.js").fakeAgentProfile;
let LoiGuiVideo: typeof import("../../video/gui-video-qua-zalo.js").LoiGuiVideo;
type ToolContext = import("./tool-registry.js").ToolContext;

let ghiNhan: string[] = [];
let layVideoGoi: { url: string }[] = [];
let guiVideoGoi: { nguon: ThongTinVideo; urlGoc: string; tranByte: number }[] = [];
let layVideoKetQua: KetQuaChuoi = { ok: true, video: videoOk() };
let guiVideoKetQua: (() => Promise<KetQuaGui>) | null = null;

function videoOk(): ThongTinVideo {
  return {
    videoUrl: "https://cdn.test/x.mp4",
    durationMs: 20_000,
    fileSize: 1_000_000,
    tacGia: "nguoi_dung",
    nguon: "tikwm",
    nenTang: "tiktok",
  };
}

before(async () => {
  dataDir = setupTestEnv({
    VIDEO_DOWNLOAD_MAX_PER_HOUR: "2",
    VIDEO_DOWNLOAD_MAX_DURATION_MINUTES: "30",
    VIDEO_DOWNLOAD_MAX_SIZE_MB: "100",
    VIDEO_DOWNLOAD_MAX_CONCURRENT: "2",
    VIDEO_DOWNLOAD_SOURCE_RETRIES: "1",
    VIDEO_DOWNLOAD_RETRY_DELAY_MS: "1000",
  });
  toolModule = await import("./tai-video-tool.js");
  rateLimit = await import("../../video/tai-video-rate-limit.js");
  database = await import("../../conversation/database.js");
  fakeAgentProfile = (await import("../../shared/fake-agent-profile.js")).fakeAgentProfile;
  LoiGuiVideo = (await import("../../video/gui-video-qua-zalo.js")).LoiGuiVideo;
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  ghiNhan = [];
  layVideoGoi = [];
  guiVideoGoi = [];
  layVideoKetQua = { ok: true, video: videoOk() };
  guiVideoKetQua = null;
  rateLimit.resetTaiVideoRateLimit();
});

const message: ParsedMessage = {
  accountId: "acc-v",
  threadId: "t-v",
  threadType: 0,
  isGroup: false,
  senderId: "u1",
  senderName: "Hải",
  text: "tải hộ video này",
  images: [],
  msgId: "m1",
  cliMsgId: "c1",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
};

function makeCtx(agent: AgentProfile = fakeAgentProfile({})): ToolContext {
  return {
    api: {} as never,
    account: { id: "acc-v", disabledTools: [] } as never,
    agent,
    message,
    batch: [message],
    ghiNhanDaGui: (noiDung: string) => ghiNhan.push(noiDung),
  } as ToolContext;
}

const phuThuoc: import("./tai-video-tool.js").PhuThuocTaiVideo = {
  layVideo: async (url) => {
    layVideoGoi.push({ url });
    return layVideoKetQua;
  },
  guiVideo: async (_dich, video, urlGoc, tranByte) => {
    guiVideoGoi.push({ nguon: video, urlGoc, tranByte });
    if (guiVideoKetQua) return guiVideoKetQua();
    return { duong: "url", bytes: 123 };
  },
};

/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (input: unknown, ctx: ToolContext = makeCtx()): Promise<unknown> =>
  (toolModule.createTaiVideoTool(ctx, phuThuoc) as any).execute(input, {});

describe("tai_video - whitelist chặn TRƯỚC khi gọi mạng", () => {
  it("link Threads bị chặn ngay, không gọi layVideo", async () => {
    const ra = await chay({ url: "https://www.threads.com/@a/post/1" });
    assert.match(loiCuaTool(ra), /TikTok, Facebook, Instagram và YouTube/);
    assert.equal(layVideoGoi.length, 0);
  });

  it("link YouTube (kể cả Shorts) được CHẤP NHẬN - gọi layVideo với nenTang youtube (2026-09-24)", async () => {
    await chay({ url: "https://youtube.com/shorts/3BADYADlqWs?si=AvisLaqmf5Y25MVc" });
    assert.equal(layVideoGoi.length, 1);
    assert.equal(layVideoGoi[0]!.url, "https://youtube.com/shorts/3BADYADlqWs?si=AvisLaqmf5Y25MVc");
  });

  it("bóc URL nằm giữa câu trước khi kiểm whitelist", async () => {
    await chay({ url: "tải hộ https://www.tiktok.com/@a/video/1 nhé" });
    assert.equal(layVideoGoi.length, 1);
    assert.equal(layVideoGoi[0]!.url, "https://www.tiktok.com/@a/video/1");
  });
});

describe("tai_video - trần theo giờ", () => {
  it("chạm trần thì KHÔNG gọi layVideo", async () => {
    await chay({ url: "https://www.tiktok.com/@a/video/1" });
    await chay({ url: "https://www.tiktok.com/@a/video/2" });
    layVideoGoi = [];

    const ra = await chay({ url: "https://www.tiktok.com/@a/video/3" });
    assert.match(loiCuaTool(ra), /trần 2/);
    assert.equal(layVideoGoi.length, 0);
  });

  it("nguồn hỏng thì HOÀN suất - không khóa người dùng vì lần chưa nhận được gì", async () => {
    layVideoKetQua = { ok: false, loiChoLog: "hỏng", daThu: [], loiCauHinh: false, canDangNhap: false, tamThoi: false };
    await chay({ url: "https://www.tiktok.com/@a/video/1" }); // hỏng, phải hoàn
    await chay({ url: "https://www.tiktok.com/@a/video/2" }); // hỏng, phải hoàn
    layVideoKetQua = { ok: true, video: videoOk() };
    // Trần là 2 - nếu 2 lần hỏng ở trên KHÔNG hoàn suất thì lần này sẽ bị chặn.
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/3" });
    assert.equal(layVideoGoi.length, 3, "cả 3 lần đều phải gọi tới layVideo - suất không bị khóa oan");
    ketQuaThanhCong(ra);
  });

  it("gửi thành công thì KHÔNG hoàn suất - suất phải bị trừ thật", async () => {
    await chay({ url: "https://www.tiktok.com/@a/video/1" });
    await chay({ url: "https://www.tiktok.com/@a/video/2" });
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/3" });
    assert.match(loiCuaTool(ra), /trần 2/, "2 lần THÀNH CÔNG phải tính vào trần thật");
  });
});

describe("tai_video - phân loại lỗi nguồn theo cờ có kiểu, không theo chữ", () => {
  it("loiCauHinh -> câu THIẾU CÔNG CỤ, không đổ oan cho video", async () => {
    layVideoKetQua = {
      ok: false,
      loiChoLog: "No module named yt_dlp",
      daThu: [],
      loiCauHinh: true,
      canDangNhap: false,
      tamThoi: false,
    };
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    assert.match(loiCuaTool(ra), /thiếu công cụ|chưa cài đủ công cụ/i);
    assert.doesNotMatch(loiCuaTool(ra), /No module named/, "chữ thô của bên thứ ba không được lọt vào câu model đọc");
  });

  it("canDangNhap -> câu CẦN ĐĂNG NHẬP, dặn đừng thử lại", async () => {
    layVideoKetQua = {
      ok: false,
      loiChoLog: "login.php",
      daThu: [],
      loiCauHinh: false,
      canDangNhap: true,
      tamThoi: false,
    };
    const ra = await chay({ url: "https://www.facebook.com/watch/?v=1" });
    assert.match(loiCuaTool(ra), /đăng nhập/i);
    assert.match(loiCuaTool(ra), /ĐỪNG bảo họ thử lại/);
  });

  it("tamThoi:true -> câu THỬ LẠI SAU", async () => {
    layVideoKetQua = {
      ok: false,
      loiChoLog: "chống bot",
      daThu: [],
      loiCauHinh: false,
      canDangNhap: false,
      tamThoi: true,
    };
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    assert.match(loiCuaTool(ra), /thử lại sau/i);
  });

  it("tamThoi:false -> câu VĨNH VIỄN, không hứa thử lại", async () => {
    layVideoKetQua = {
      ok: false,
      loiChoLog: "private",
      daThu: [],
      loiCauHinh: false,
      canDangNhap: false,
      tamThoi: false,
    };
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    assert.match(loiCuaTool(ra), /riêng tư hoặc đã bị xóa/);
    assert.match(loiCuaTool(ra), /ĐỪNG hứa thử lại/);
  });
});

describe("tai_video - trần thời lượng/dung lượng chặn TRƯỚC khi gửi", () => {
  it("video quá dài thì KHÔNG gọi guiVideo", async () => {
    layVideoKetQua = { ok: true, video: { ...videoOk(), durationMs: 60 * 60_000 } };
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    assert.match(loiCuaTool(ra), /30 phút/);
    assert.equal(guiVideoGoi.length, 0);
  });
});

describe("tai_video - lỗi ở tầng gửi (LoiGuiVideo)", () => {
  it("quaNang -> nói đúng số MB và trần chỉnh được ở đâu", async () => {
    guiVideoKetQua = async () => {
      throw new LoiGuiVideo("nặng quá", { quaNang: true, soByte: 150 * 1024 * 1024 });
    };
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    assert.match(loiCuaTool(ra), /150MB/);
    assert.match(loiCuaTool(ra), /100MB/);
  });

  it("loiCauHinh ở tầng gửi -> vẫn ra đúng câu THIẾU CÔNG CỤ", async () => {
    guiVideoKetQua = async () => {
      throw new LoiGuiVideo("thiếu yt-dlp", { loiCauHinh: true });
    };
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    assert.match(loiCuaTool(ra), /thiếu công cụ|chưa cài đủ công cụ/i);
  });

  it("lỗi lạ khác -> câu chung, KHÔNG lộ err.message ra ngoài", async () => {
    guiVideoKetQua = async () => {
      throw new Error("ECONNRESET tại /internal/secret/path");
    };
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    assert.doesNotMatch(loiCuaTool(ra), /ECONNRESET|secret/);
    assert.match(loiCuaTool(ra), /Gửi video thất bại/);
  });

  it("gửi hỏng thì HOÀN suất", async () => {
    guiVideoKetQua = async () => {
      throw new Error("hỏng");
    };
    await chay({ url: "https://www.tiktok.com/@a/video/1" });
    await chay({ url: "https://www.tiktok.com/@a/video/2" });
    guiVideoKetQua = null;
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/3" });
    ketQuaThanhCong(ra);
  });
});

describe("tai_video - thành công", () => {
  it("gọi guiVideo với URL GỐC (đã whitelist) chứ không phải chuỗi thô người dùng gõ", async () => {
    await chay({ url: "  https://www.tiktok.com/@a/video/1  " });
    assert.equal(guiVideoGoi[0]!.urlGoc, "https://www.tiktok.com/@a/video/1");
  });

  it("ghi lịch sử kèm nền tảng, KHÔNG trả đường dẫn cho model chép lại", async () => {
    const ra = await chay({ url: "https://www.tiktok.com/@a/video/1" });
    const text = ketQuaThanhCong(ra);
    assert.doesNotMatch(text, /https?:\/\//);
    assert.equal(ghiNhan.length, 1);
    assert.match(ghiNhan[0]!, /tiktok/);
  });
});
