import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import type { KetQuaChuoi } from "../../video/chuoi-nguon-video.js";
import type { KetQuaTaiMp3 } from "../../video/tai-mp3.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let toolModule: typeof import("./tai-mp3-tool.js");
let rateLimit: typeof import("../../video/tai-video-rate-limit.js");
let database: typeof import("../../conversation/database.js");
let fakeAgentProfile: typeof import("../../shared/fake-agent-profile.js").fakeAgentProfile;
type ToolContext = import("./tool-registry.js").ToolContext;

let layVideoKq: KetQuaChuoi;
let taiKq: KetQuaTaiMp3;
let goi: { lay: number; tai: number; gui: { ten: string; bytes: number }[] };

before(async () => {
  dataDir = setupTestEnv({
    VIDEO_DOWNLOAD_MAX_PER_HOUR: "2",
    AUDIO_DOWNLOAD_MAX_DURATION_MINUTES: "60",
    VIDEO_DOWNLOAD_MAX_SIZE_MB: "100",
    VIDEO_DOWNLOAD_MAX_CONCURRENT: "2",
    VIDEO_DOWNLOAD_SOURCE_RETRIES: "1",
    VIDEO_DOWNLOAD_RETRY_DELAY_MS: "1000",
  });
  toolModule = await import("./tai-mp3-tool.js");
  rateLimit = await import("../../video/tai-video-rate-limit.js");
  database = await import("../../conversation/database.js");
  fakeAgentProfile = (await import("../../shared/fake-agent-profile.js")).fakeAgentProfile;
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

const video = (phut: number) => ({
  videoUrl: "",
  durationMs: phut * 60_000,
  fileSize: null,
  tacGia: "kenh",
  nguon: "yt-dlp" as const,
  nenTang: "youtube" as const,
});

beforeEach(() => {
  rateLimit.resetTaiVideoRateLimit();
  layVideoKq = { ok: true, video: video(4) };
  taiKq = { ok: true, byte: Buffer.from("ID3") };
  goi = { lay: 0, tai: 0, gui: [] };
});

const message: ParsedMessage = {
  accountId: "acc-a",
  threadId: "t-a",
  threadType: 0,
  isGroup: false,
  senderId: "u1",
  senderName: "Hải",
  text: "tải mp3",
  images: [],
  msgId: "m1",
  cliMsgId: "c1",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
};

const chay = (url: string): Promise<unknown> => {
  const ctx = {
    api: {} as never,
    account: { id: "acc-a", disabledTools: [] } as never,
    agent: fakeAgentProfile({}),
    message,
    batch: [message],
  } as ToolContext;
  const t = toolModule.createTaiMp3Tool(ctx, {
    layVideo: async () => (goi.lay++, layVideoKq),
    taiMp3: async () => (goi.tai++, taiKq),
    gui: async (_c, ten, byte) => (goi.gui.push({ ten, bytes: byte.length }), "Đã tạo và GỬI file"),
  });
  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  return (t as any).execute({ url }, {});
};

const URL_YT = "https://youtube.com/watch?v=3f2X_gIJ_u4&si=5x6jzcdq2MElG__Z";

describe("tai_mp3", () => {
  it("link YouTube hợp lệ: đọc thông tin, tải, gửi file .mp3 đặt tên theo id video", async () => {
    const ra = await chay(`hãy tải file mp3 của link này ${URL_YT}`);
    assert.equal(ra, "Đã tạo và GỬI file");
    assert.deepEqual(goi.gui, [{ ten: "am-thanh-youtube-3f2X_gIJ_u4.mp3", bytes: 3 }]);
  });

  it("link ngoài whitelist bị chặn trước khi gọi mạng", async () => {
    assert.ok(loiCuaTool(await chay("https://example.com/a.mp3")));
    assert.equal(goi.lay, 0);
  });

  it("bài dài hơn trần bị từ chối TRƯỚC khi tải, có nói số phút", async () => {
    layVideoKq = { ok: true, video: video(95) };
    assert.match(loiCuaTool(await chay(URL_YT)), /95 phút.*60 phút/);
    assert.equal(goi.tai, 0);
  });

  it("thiếu yt-dlp/ffmpeg -> báo lỗi cấu hình máy chủ, không đổ cho link", async () => {
    taiKq = { ok: false, loi: "x", loiCauHinh: true };
    assert.match(loiCuaTool(await chay(URL_YT)), /thiếu yt-dlp hoặc ffmpeg/);
  });

  it("tải hỏng thì HOÀN suất: 2 lần hỏng vẫn còn suất cho lần thứ 3 (trần 2/giờ)", async () => {
    taiKq = { ok: false, loi: "hỏng" };
    await chay(URL_YT);
    await chay(URL_YT);
    taiKq = { ok: true, byte: Buffer.from("ID3") };
    assert.equal(await chay(URL_YT), "Đã tạo và GỬI file");
  });
});
