import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { ThreadType } from "zca-js";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";
import type { AccountConfig } from "../../config/account-store.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";

/**
 * Chỉ đo phần MỚI THÊM (chặn lưu chuỗi trông như OTP) - `save-memory-tool.ts`
 * chạm DB qua `saveMemoryFact` nên phải theo đúng bẫy `setupTestEnv()` TRƯỚC
 * import động, không thì mở nhầm `data/zalo-agent.db` thật.
 */

let dataDir: string;
let saveMemoryTool: typeof import("./save-memory-tool.js");
let database: typeof import("../../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  saveMemoryTool = await import("./save-memory-tool.js");
  database = await import("../../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

const account: AccountConfig = { id: "acc-1", ownerUserId: "" } as AccountConfig;
const message: ParsedMessage = {
  accountId: "acc-1",
  threadId: "dm-1",
  threadType: ThreadType.User,
  isGroup: false,
  senderId: "u-hai",
  senderName: "Hải",
  text: "",
  images: [],
  msgId: "m0",
  cliMsgId: "c0",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
} as ParsedMessage;

/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (input: unknown): Promise<unknown> =>
  (saveMemoryTool.createSaveMemoryTool({ account, message } as any) as any).execute(input, {});

describe("save_memory - chặn OTP", () => {
  it("action=them, content trông như OTP: từ chối, KHÔNG lưu vào trí nhớ", async () => {
    const ra = await chay({ action: "them", content: "Mã OTP của em là 483920", about: "sender" });
    assert.match(loiCuaTool(ra), /OTP/i);
  });

  it("action=sua, content mới trông như OTP: cũng từ chối", async () => {
    // Ghi một fact bình thường trước để có gì đó mà "sửa"
    await chay({ action: "them", content: "Anh Hải thích cà phê đen", about: "sender" });
    const ra = await chay({
      action: "sua",
      doan_chu: "cà phê đen",
      content: "mã xác nhận 998877",
      about: "sender",
    });
    assert.match(loiCuaTool(ra), /OTP/i);
  });

  it("API key và số CCCD: từ chối, nói rõ loại (ca thật 2026-09-28)", async () => {
    const key = await chay({ action: "them", content: `API Key OpenRouter của anh Minh: sk-or-v1-${"ab12".repeat(10)}`, about: "sender" });
    assert.match(loiCuaTool(key), /API key/);
    const cccd = await chay({ action: "them", content: "Số CCCD của anh Minh: 012345678901", about: "sender" });
    assert.match(loiCuaTool(cccd), /CCCD/);
  });

  it("content bình thường không liên quan OTP: vẫn lưu được như cũ", async () => {
    const ra = await chay({ action: "them", content: "Chị Lan thích trà sữa trân châu", about: "sender" });
    assert.equal(typeof ra, "string");
    assert.match(ra as string, /Đã ghi nhớ/);
  });
});

describe("save_memory - chặn khi thread ở privacy tier 'restricted' (ma trận phân quyền)", () => {
  it("action=them bị chặn CỨNG khi thread đang restricted - không lưu, không phụ thuộc model có để ý luật riêng tư hay không", async () => {
    const { setThreadPrivacyTier, recordThreadActivity } = await import("../../conversation/thread-store.js");
    recordThreadActivity({
      accountId: "acc-1",
      threadId: "dm-restricted",
      threadType: 0,
      displayName: "Hải",
      lastSenderName: "Hải",
    });
    setThreadPrivacyTier("acc-1", "dm-restricted", "restricted");

    const msgRestricted = { ...message, threadId: "dm-restricted" };
    const ra = (await (saveMemoryTool.createSaveMemoryTool({ account, message: msgRestricted } as any) as any)
      .execute({ action: "them", content: "Chuyện nhạy cảm cần nhớ", about: "sender" }, {})) as unknown;
    assert.match(loiCuaTool(ra), /riêng tư hạn chế/);
  });

  it("thread bình thường (privacy tier mặc định) không bị chặn", async () => {
    const ra = await chay({ action: "them", content: "Anh Nam thích nghe nhạc EDM", about: "sender" });
    assert.match(ra as string, /Đã ghi nhớ/);
  });
});
