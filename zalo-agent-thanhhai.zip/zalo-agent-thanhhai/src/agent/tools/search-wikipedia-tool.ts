import { tool } from "ai";
import { z } from "zod";
import { searchWikipedia } from "../../shared/research-providers/wikipedia-search.js";
import { formatResearchResults } from "../../shared/research-providers/research-result.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { wrapUntrustedContent } from "./wrap-untrusted-content.js";

export function createSearchWikipediaTool() {
  return tool({
    description:
      "Tra cứu Wikipedia (API công khai, không cần key). lang=auto ưu tiên tiếng Việt, ghé thêm tiếng Anh nếu ít kết quả.",
    inputSchema: z.object({
      query: z.string().min(1).max(300).describe("Từ khóa tra cứu"),
      lang: z.enum(["auto", "vi", "en"]).optional().describe("Mặc định auto"),
      count: z.number().int().min(1).max(12).optional().describe("Số kết quả, mặc định 6"),
    }),
    execute: async ({ query, lang, count }) => {
      let results;
      try {
        results = await searchWikipedia(query, { count: count ?? 6, lang: lang ?? "auto" });
      } catch {
        return ketQuaLoi("Wikipedia đang lỗi hoặc không phản hồi. Thử lại sau.");
      }
      if (results.length === 0) return ketQuaLoi("Không tìm thấy bài viết nào khớp trên Wikipedia.");
      return wrapUntrustedContent(
        formatResearchResults(`Kết quả Wikipedia cho: "${query}"`, results),
        `Wikipedia: ${query}`,
      );
    },
  });
}
