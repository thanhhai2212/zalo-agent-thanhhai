/**
 * Lọc ký tự HIỂN-THỊ-RỖNG (ASCII smuggling) khỏi văn bản.
 *
 * Dải chính: Unicode Tags (U+E0000-U+E007F) - kênh Riley Goodside (01/2024):
 * mỗi mã ánh xạ 1-1 sang một ký tự ASCII in được, RENDER RA RỖNG ở mọi trình
 * duyệt/terminal/editor - người vận hành xem tài liệu trên dashboard không
 * thấy gì - nhưng tokenizer của model vẫn đọc ra chữ, nên một chỉ thị giấu
 * trong dải này vẫn tới được model nguyên vẹn.
 *
 * Bốn ký tự lẻ bổ sung, cùng họ "operator không thấy gì trên dashboard":
 *   - U+3164 HANGUL FILLER, U+115F HANGUL CHOSEONG FILLER, U+1160 HANGUL
 *     JUNGSEONG FILLER, U+FFA0 HALFWIDTH HANGUL FILLER: BỐN filler của thuật
 *     toán ghép âm tiết Hangul cũ - không xuất hiện trong văn bản Hàn hiện
 *     đại (chữ Hàn THƯỜNG dùng âm tiết đã ghép sẵn, không dùng filler).
 *   - U+2800 BRAILLE PATTERN BLANK: đây là DẤU CÁCH của chữ Braille (không
 *     phải "mẫu rỗng vô nghĩa") - vẫn lọc vì nó hiện ra rỗng trên dashboard
 *     và là kênh smuggling đã biết, nhưng cái giá thật là xoá nó làm CÁC TỪ
 *     BRAILLE DÍNH VÀO NHAU (mất dấu cách giữa từ).
 *
 * KHÔNG lọc U+1D41D MATHEMATICAL BOLD SMALL D: đổi NGHĨA khi nằm trong công
 * thức toán (`𝐝x/𝐝t` đạo hàm thành `x/t` phép chia bình thường) - không phải
 * làm nhiễu như ASCII smuggling. Lọc một mã lẻ giữa 1024 mã của khối
 * U+1D400-U+1D7FF cũng không phải một bộ lọc thật - kẻ tấn công chỉ cần đổi
 * sang mã khác trong cùng khối.
 *
 * CHỈ lọc đúng các dải/mã trên, KHÔNG lọc `\p{Cf}` toàn cục hay chạy NFKC: một
 * bộ lọc rộng hơn phá emoji ghép ZWJ, ZWNJ (chữ trong tiếng Ba Tư/Ấn), và biến
 * thể Unicode hợp lệ khác. Đánh đổi DUY NHẤT của dải Tags là cờ vùng con (Anh,
 * Scotland, Wales dùng Tags để mã hoá mã vùng) - không liên quan tới bot
 * tiếng Việt.
 *
 * Module THUẦN: 0 import, không env, không DB.
 */

const KY_TU_AN_RE = /[\u{E0000}-\u{E007F}ㅤᅟᅠﾠ⠀]/gu;

/** Lọc ký tự hiển-thị-rỗng khỏi `text`. Không tìm thấy thì trả về CHÍNH `text` (không sao chép thừa). */
export function locKyTuAn(text: string): string {
  return KY_TU_AN_RE.test(text) ? text.replace(KY_TU_AN_RE, "") : text;
}
