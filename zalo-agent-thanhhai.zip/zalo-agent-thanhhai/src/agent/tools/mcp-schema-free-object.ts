/**
 * Tham số kiểu "ô nhập tự do" (`{type:"object", properties:{}}`) của tool MCP
 * ngoài - điển hình `input` của `call-actor` bên Apify, nơi mỗi Actor có hình
 * dạng đầu vào riêng nên server không thể khai trước.
 *
 * Bẫy đã dính thật (2026-10-06): 9Router thấy object KHÔNG có thuộc tính thì
 * tự gán cho nó một trường BẮT BUỘC `reason` (Gemini không nhận object rỗng).
 * Model chỉ phát được đúng `{"reason": "..."}` vào `input`, không có chỗ để gửi
 * `startUrls` - cả 3 lần gọi `apify/facebook-posts-scraper` đều hỏng "input
 * validation failed", và bot kết luận "Facebook chặn" khi chưa chạy được công
 * cụ cào nào.
 *
 * Né bằng cách đổi các ô đó thành CHUỖI JSON trước khi gửi model (router chỉ
 * chèn vào object, không đụng chuỗi), rồi tự `JSON.parse` ngược lại trước khi
 * gọi server. Chỉ đổi object THIẾU thuộc tính; object có thuộc tính khai báo
 * giữ nguyên.
 */

const GOI_Y_JSON = 'Viết dưới dạng CHUỖI JSON của một object, ví dụ {"startUrls":[{"url":"https://..."}]}.';

export type DuongDan = string[];

function laObjectThuan(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function laOObjectTuDo(s: Record<string, unknown>): boolean {
  if (s.type !== "object") return false;
  const p = s.properties;
  return p === undefined || (laObjectThuan(p) && Object.keys(p).length === 0);
}

/**
 * Trả schema mới + danh sách đường dẫn (qua `properties`) tới các ô đã đổi.
 * Schema GỐC (cấp cao nhất) không bao giờ bị đổi: object rỗng ở gốc là chuyện
 * khác (router chèn `reason`, bỏ ở `locThamSo`).
 */
export function doiObjectTuDoSangChuoi(schema: unknown): { schema: unknown; duongDan: DuongDan[] } {
  const duongDan: DuongDan[] = [];
  const duyet = (node: unknown, ganDay: DuongDan, doSau: number): unknown => {
    if (!laObjectThuan(node) || doSau > 20) return node;
    const props = node.properties;
    if (!laObjectThuan(props)) return node;
    const moi: Record<string, unknown> = {};
    for (const [ten, con] of Object.entries(props)) {
      if (laObjectThuan(con) && laOObjectTuDo(con)) {
        duongDan.push([...ganDay, ten]);
        const moTa = typeof con.description === "string" && con.description ? `${con.description} ` : "";
        moi[ten] = { type: "string", description: `${moTa}${GOI_Y_JSON}` };
      } else {
        moi[ten] = duyet(con, [...ganDay, ten], doSau + 1);
      }
    }
    return { ...node, properties: moi };
  };
  return { schema: duyet(schema, [], 0), duongDan };
}

/** Đổi ngược các ô chuỗi JSON thành object. Không parse được thì giữ nguyên để server báo lỗi rõ. */
export function khoiPhucObjectTuDo(args: unknown, duongDan: DuongDan[]): unknown {
  if (!laObjectThuan(args) || duongDan.length === 0) return args;
  const ra = structuredClone(args) as Record<string, unknown>;
  for (const dd of duongDan) {
    let cha: Record<string, unknown> = ra;
    for (const khoa of dd.slice(0, -1)) {
      const tiep = cha[khoa];
      if (!laObjectThuan(tiep)) {
        cha = {};
        break;
      }
      cha = tiep;
    }
    const khoaCuoi = dd[dd.length - 1]!;
    const gia = cha[khoaCuoi];
    if (typeof gia !== "string") continue;
    try {
      const parse = JSON.parse(gia) as unknown;
      if (laObjectThuan(parse)) cha[khoaCuoi] = parse;
    } catch {
      // giữ nguyên chuỗi - server ngoài sẽ báo "input không hợp lệ" kèm lý do
    }
  }
  return ra;
}
