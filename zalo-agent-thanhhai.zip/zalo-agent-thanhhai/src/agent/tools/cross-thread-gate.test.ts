import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ThreadType } from "zca-js";
import { chanDocCheoThread } from "./cross-thread-gate.js";
import { laKetQuaLoi } from "./tool-failure-result.js";
import type { AccountConfig } from "../../config/account-store.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";

const OWNER = "123456789012345678";
const NGUOI_KHAC = "999999999999999999";

const account = (ownerUserId: string): AccountConfig => ({ id: "acc-1", ownerUserId }) as AccountConfig;

const message = (over: Partial<ParsedMessage>): ParsedMessage =>
  ({
    accountId: "acc-1",
    threadId: "t-1",
    threadType: ThreadType.User,
    isGroup: false,
    senderId: OWNER,
    senderName: "Nguyễn Văn A",
    text: "",
    images: [],
    msgId: "m0",
    cliMsgId: "c0",
    isSelf: false,
    mentionsMe: false,
    rawData: {},
    ...over,
  }) as ParsedMessage;

describe("chanDocCheoThread - fail-closed khi chưa cấu hình", () => {
  it("ownerUserId rỗng: chặn TẤT CẢ, kể cả chính người gửi trùng chuỗi rỗng", () => {
    const ket = chanDocCheoThread({ account: account(""), message: message({ senderId: "" }) });
    assert.ok(laKetQuaLoi(ket));
    assert.match(ket!.loi, /chưa cấu hình|Chưa cấu hình/i);
  });
});

describe("chanDocCheoThread - đủ 3 điều kiện mới cho qua", () => {
  it("đúng chủ, đúng chat riêng: CHO QUA (trả null)", () => {
    const ket = chanDocCheoThread({ account: account(OWNER), message: message({ isGroup: false, senderId: OWNER }) });
    assert.equal(ket, null);
  });

  it("đúng chủ nhưng đang ở TRONG NHÓM: chặn - dù senderId khớp", () => {
    const ket = chanDocCheoThread({
      account: account(OWNER),
      message: message({ isGroup: true, threadType: ThreadType.Group, senderId: OWNER }),
    });
    assert.ok(laKetQuaLoi(ket));
    assert.match(ket!.loi, /chat riêng/);
  });

  it("chat riêng nhưng SAI người: chặn - không suy diễn qua tên hiển thị", () => {
    const ket = chanDocCheoThread({
      account: account(OWNER),
      message: message({ isGroup: false, senderId: NGUOI_KHAC, senderName: "Nguyễn Văn A" }),
    });
    assert.ok(laKetQuaLoi(ket));
    assert.match(ket!.loi, /Chỉ chủ tài khoản/);
  });

  it("thành viên nhóm gõ đúng câu gọi tool trong NHÓM vẫn bị chặn dù trùng senderId với chủ ở account khác", () => {
    // Ca thực tế: kẻ tấn công không cần biết OWNER là ai - chỉ cần đang ở nhóm
    // là đủ bị chặn bởi điều kiện isGroup, không bao giờ chạm tới so senderId.
    const ket = chanDocCheoThread({
      account: account(OWNER),
      message: message({ isGroup: true, threadType: ThreadType.Group, senderId: NGUOI_KHAC }),
    });
    assert.ok(laKetQuaLoi(ket));
  });
});
