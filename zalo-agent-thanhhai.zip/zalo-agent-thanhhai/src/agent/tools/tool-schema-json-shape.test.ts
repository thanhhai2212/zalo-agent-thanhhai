import assert from "node:assert/strict";
import { zodSchema } from "ai";
import { after, describe, it } from "node:test";
import { fakeAgentProfile } from "../../shared/fake-agent-profile.js";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";

/**
 * Chặn LẠI đúng lớp lỗi đã trả giá 2 lần: schema Zod có UNION Ở GỐC (không
 * phải lồng trong 1 field) khiến AI SDK sinh JSON Schema thiếu `type` ở gốc -
 * Anthropic (và có thể nhà cung cấp khác) từ chối THẲNG với lỗi dạng
 * `tools.N.custom.input_schema.type: Field required`. Route /api/agents/test
 * KHÔNG gửi `tools` nên không bao giờ bắt được ca này - phải test tận đây.
 *
 * Ca 1 (`document-content-schema.ts`, `spreadsheetCellSchema`): discriminator
 * trùng giá trị, ném lỗi MỌI LẦN PARSE.
 * Ca 2 (2026-08-31, `schedule-task-tool-schema.ts`): `z.discriminatedUnion`
 * làm schema GỐC của tool, JSON Schema ra `{"oneOf":[...]}` không `type` -
 * agent `Trợ Lý Kế Toán Tài Chính` (model Claude qua 9router) gãy 100% mọi
 * lượt trên Zalo thật trong khi dashboard "Test kết nối" vẫn xanh.
 *
 * Test này build MỌI tool trong catalog (kể cả tool chưa đủ hạ tầng - build()
 * chỉ dựng closure + schema, không chạm mạng) rồi soi JSON Schema thật mà AI
 * SDK sẽ gửi cho provider.
 */

// Top-level await: phải import XONG rồi mới sinh được từng it() theo tool
// key thật - describe()/it() ở dưới chạy NGAY lúc file được nạp, còn
// before() thì chạy sau, không kịp cho vòng lặp sinh test.
const dataDir = setupTestEnv();
const registry = await import("./tool-registry.js");

after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});

const message: ParsedMessage = {
  accountId: "acc-schema",
  threadId: "t-schema",
  threadType: 0,
  isGroup: false,
  senderId: "u1",
  senderName: "Hải",
  text: "x",
  images: [],
  msgId: "m1",
  cliMsgId: "c1",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
};

describe("mọi tool: JSON Schema GỐC phải có type (không union/discriminatedUnion trần)", () => {
  for (const def of registry.TOOL_DEFINITIONS) {
    it(`${def.key}`, () => {
      const ctx = {
        api: {} as never,
        account: { id: "acc-schema", disabledTools: [] } as never,
        agent: fakeAgentProfile(),
        message,
        batch: [message],
      } as never;

      const built = def.build(ctx) as { inputSchema?: unknown };
      // Vài tool không nhận tham số (vd get_datetime) - vẫn hợp lệ, chỉ cần
      // có mặt input schema thì phải đúng hình dạng.
      if (!built.inputSchema) return;

      const schema = zodSchema(built.inputSchema as Parameters<typeof zodSchema>[0]);
      assert.equal(
        schema.jsonSchema.type,
        "object",
        `Tool "${def.key}" có JSON Schema gốc thiếu type:"object" (rất có thể do union/discriminatedUnion nằm ngay ở gốc schema) - đúng lớp lỗi đã làm schedule_task/create_excel_file chết trên Zalo thật dù test khác vẫn xanh.`,
      );
    });
  }
});
