import { tool } from "ai";
import { luuFileDaTao } from "../../second-brain/generated-file-store.js";
import { z } from "zod";
import { generateMusic, isMusicConfigured, type MusicConfig } from "../../music/music-generation-client.js";
import { checkMusicRateLimit } from "../../music/music-rate-limit.js";
import { enqueueSend } from "../../middleware/rate-limiter.js";
import { withNamedTempFile } from "../../shared/temp-file-store.js";
import { createLogger } from "../../shared/logger.js";
import type { AgentProfile } from "../../config/agent-store.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import type { ToolContext } from "./index.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { guiFileKemCaption } from "./send-attachment-with-caption.js";
import { ghiChuDaGuiChu, ghiChuDaGuiNhac } from "./sent-by-tool-note.js";

const log = createLogger("create-music");

/**
 * Tool sáng tác nhạc bằng AI (cấu hình RIÊNG từng agent, 2 nhà cung cấp - xem
 * `music-generation-client.ts`) rồi gửi vào hội thoại dạng FILE ĐÍNH KÈM
 * (không phải bong bóng voice - bài hát dài hợp trình phát file hơn).
 *
 * Nhắn báo trước khi tạo: đo thật trên OpenRouter Playground ~40-60 giây/bài
 * (google-ai-studio chưa đo thật, để chung câu báo vì cùng bậc thời gian).
 * Gửi thẳng qua enqueueSend (như create_image) nên `runsInScheduledTurn:false`
 * và phải `ghiNhanDaGui` để tin vào history + trí nhớ của bot.
 *
 * `generate` tiêm được để test không chạm mạng, không tốn tiền thật ($0,08/bài).
 */

const MAX_PROMPT_CHARS = 4000;
const DELIVERED_NOTE = "Đã tạo và GỬI bài hát cho người dùng rồi. KHÔNG gọi send_file để gửi lại.";
const TIN_DANG_TAO = "Đang tạo nhạc, đợi khoảng 1 phút nhé...";

/** Cấu hình tạo nhạc riêng của agent (Pick từ AgentProfile). `ttsApiKey` cần
 * kèm theo vì nhánh "google-ai-studio" DÙNG CHUNG bộ key với TTS, không có
 * cột key riêng - xem `music-generation-client.ts`. */
type MusicConfigCuaAgent = Pick<
  AgentProfile,
  "musicProvider" | "musicModel" | "musicVoice" | "musicFormat" | "musicApiKey" | "ttsApiKey"
>;

export function musicConfigCua(agent: MusicConfigCuaAgent): MusicConfig {
  const provider = agent.musicProvider || "openrouter";
  return {
    provider,
    model: agent.musicModel,
    voice: agent.musicVoice,
    format: agent.musicFormat,
    apiKey: provider === "google-ai-studio" ? (agent.ttsApiKey ?? "") : (agent.musicApiKey ?? ""),
  };
}

/**
 * Agent này đã cấu hình đủ để tool vào schema chưa (khác nhau theo nhà cung
 * cấp). Nhận Pick RIÊNG (không phải `MusicConfigCuaAgent` đầy đủ) vì
 * `ToolScope.agent` (`tool-registry.ts`) không mang `musicVoice`/`musicFormat`
 * - 2 field đó không ảnh hưởng "đã cấu hình đủ chưa", chỉ `isMusicConfigured`
 * mới cần.
 */
export function agentCoMusic(agent: Pick<AgentProfile, "musicProvider" | "musicModel" | "musicApiKey" | "ttsApiKey">): boolean {
  const provider = agent.musicProvider || "openrouter";
  return isMusicConfigured({
    provider,
    model: agent.musicModel,
    apiKey: provider === "google-ai-studio" ? (agent.ttsApiKey ?? "") : (agent.musicApiKey ?? ""),
  });
}

export function createMusicTool(ctx: ToolContext, generate = generateMusic) {
  const agent = ctx.agent;
  return tool({
    description:
      "Sáng tác một bài hát/bản nhạc bằng AI từ mô tả (thể loại, chủ đề, không khí, lời nếu có) rồi gửi vào hội thoại dạng file audio. Có thể tạo bài hát ĐẦY ĐỦ dài vài phút (verse/chorus/bridge, tự viết lời) nếu người dùng mô tả càng chi tiết càng tốt - nêu rõ mốc thời gian nếu muốn kiểm soát cấu trúc bài hát. Dùng khi người dùng yêu cầu 'sáng tác nhạc', 'tạo bài hát', 'làm nhạc nền', 'viết một bài hát về...'.",
    inputSchema: z.object({
      prompt: z
        .string()
        .min(1)
        .max(MAX_PROMPT_CHARS)
        .describe("Mô tả chi tiết bài hát cần tạo: thể loại, chủ đề, không khí, và lời bài hát nếu người dùng có yêu cầu"),
      caption: z.string().optional().describe("Lời nhắn gửi kèm file (tùy chọn)"),
    }),
    execute: async ({ prompt, caption }) => {
      if (!ctx.api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);
      const api = ctx.api;
      if (!agentCoMusic(agent)) {
        return ketQuaLoi(
          agent.musicProvider === "google-ai-studio"
            ? "Agent này chưa cấu hình tạo nhạc qua Google AI Studio (thiếu API key - mục này DÙNG CHUNG key với Giọng nói/TTS). Nói cho người dùng biết cần vào trang Agents, mở agent này, nhập API key ở mục Giọng nói (TTS)."
            : "Agent này chưa cấu hình tạo nhạc (thiếu model hoặc API key OpenRouter). Nói cho người dùng biết cần vào trang Agents, mở agent này, nhập cấu hình mục Tạo nhạc.",
        );
      }

      const threadKey = `${ctx.account.id}:${ctx.message.threadId}`;
      const rate = checkMusicRateLimit(threadKey);
      if (!rate.ok) return ketQuaLoi(rate.reason);

      // Chỉ báo sau khi chắc chắn sẽ tạo thật (đã qua cửa cấu hình + trần)
      await enqueueSend(threadKey, () =>
        api.sendMessage({ msg: TIN_DANG_TAO }, ctx.message.threadId, ctx.message.threadType),
      )
        .then(() => {
          ctx.ghiNhanDaGui?.(ghiChuDaGuiChu(TIN_DANG_TAO));
        })
        .catch(() => {
          // Báo trước hỏng không được làm chết cả lượt tạo nhạc
        });

      let music;
      try {
        music = await generate(prompt, musicConfigCua(agent));
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err);
        log.warn({ err }, "Tạo nhạc thất bại");
        return ketQuaLoi(`Tạo nhạc thất bại (${reason}). Nói thật với người dùng, đừng hứa gửi nhạc sau.`);
      }

      try {
        const fileName = `nhac-${Date.now()}.${music.ext}`;
        await withNamedTempFile(fileName, music.data, (filePath) =>
          guiFileKemCaption(api, threadKey, ctx.message.threadId, ctx.message.threadType, filePath, caption),
        );
        // Bản sao cho second brain (Notion) - trước đây chỉ file tài liệu mới được giữ.
        luuFileDaTao({ accountId: ctx.account.id, threadId: ctx.message.threadId, fileName: fileName, data: music.data });
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err);
        return ketQuaLoi(`Gửi file nhạc lên Zalo thất bại (${reason}). Nói thật với người dùng.`);
      }

      ctx.ghiNhanDaGui?.(ghiChuDaGuiNhac(prompt, caption));
      log.info(
        {
          accountId: ctx.account.id,
          threadId: ctx.message.threadId,
          kb: Math.round(music.data.length / 1024),
          ext: music.ext,
        },
        "Đã gửi nhạc tự tạo",
      );
      return `${DELIVERED_NOTE} (${Math.round(music.data.length / 1024)} KB)`;
    },
  });
}
