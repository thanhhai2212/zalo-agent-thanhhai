import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import type { API } from "zca-js";
import { fakeAgentProfile } from "../../shared/fake-agent-profile.js";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";

// Kéo theo env + DB nên phải setupTestEnv trước, import động sau
let dataDir: string;
let registry: typeof import("./tool-registry.js");
let visionStore: typeof import("../../config/runtime-vision-settings.js");
let imageStore: typeof import("../../config/runtime-image-settings.js");
let tuning: typeof import("../../config/runtime-tuning-settings.js");

before(async () => {
  dataDir = setupTestEnv();
  registry = await import("./tool-registry.js");
  visionStore = await import("../../config/runtime-vision-settings.js");
  imageStore = await import("../../config/runtime-image-settings.js");
  tuning = await import("../../config/runtime-tuning-settings.js");
});

after(async () => {
  const { closeDatabase } = await import("../../conversation/database.js");
  closeDatabase();
  cleanupTestEnv(dataDir);
});

/**
 * build() không gọi API lúc dựng schema nên stub rỗng là đủ.
 *
 * Hai danh sách tắt RỜI NHAU vì đó chính là thứ cần kiểm: `disabledTools` là
 * chính sách của nick Zalo, `agentDisabled` là năng lực của agent, và tool dùng
 * được là phần không bên nào tắt.
 */
function makeContext(
  disabledTools: string[],
  agentDisabled: string[] = [],
  ttsConfigured = false,
  musicConfigured = false,
  videoConfigured = false,
) {
  return {
    api: {} as API,
    account: {
      id: "acc-test",
      label: "Test",
      enabled: true,
      agentId: "agent-test",
      allowlist: { mode: "all" as const, userIds: [] },
      groupRequireMention: true,
      respondToGroups: true,
      groupPassiveListen: true,
      autoReactEnabled: true,
      autoReactIcon: "heart",
      typingIndicatorEnabled: true,
      disabledTools,
      ownerUserId: "",
      loai: "ca_nhan" as const,
      coBotToken: false,
      autoKickFloodEnabled: false,
    },
    // Dùng fixture chung thay vì chép literal: thêm trường mới vào AgentProfile
    // thì chỉ sửa một chỗ, và không có file nào âm thầm thiếu trường.
    // `ttsConfigured`/`musicConfigured`/`videoConfigured` bật cấu hình RIÊNG
    // của agent để create_voice/create_music/create_video thoát gate available
    // (mặc định tắt -> cả ba nằm trong GATED_TOOLS).
    agent: fakeAgentProfile({
      disabledTools: agentDisabled,
      ...(ttsConfigured
        ? { ttsBaseUrl: "https://tts.test", ttsModel: "tts-1", ttsApiKey: "sk-tts" }
        : {}),
      ...(musicConfigured ? { musicModel: "google/lyria-3-pro-preview", musicApiKey: "sk-or-x" } : {}),
      ...(videoConfigured ? { videoModel: "bytedance/seedance-2.0-mini", videoApiKey: "sk-or-x" } : {}),
    }),
    message: { threadId: "t-1", threadType: 0 } as never,
    batch: [],
  };
}

function unconfigureSidecar(): void {
  visionStore.updateVisionSettings({ sidecarBaseUrl: "", sidecarModel: "", sidecarApiKey: "" });
}

function configureSidecar(): void {
  visionStore.updateVisionSettings({
    sidecarBaseUrl: "https://gemini.test/v1beta/openai",
    sidecarModel: "gemini-3.5-flash-lite",
    sidecarApiKey: "AIza-x",
  });
}

/** Các tool chỉ vào schema khi hạ tầng riêng của chúng đã sẵn sàng
 * (create_voice/create_music/create_video gate theo cấu hình RIÊNG của agent;
 * kb_search gate theo agent đã được gán nguồn Kho tri thức chưa - rỗng trong
 * mọi test ở file này) */
const GATED_TOOLS = [
  "read_image",
  "create_image",
  "create_voice",
  "create_music",
  "kb_search",
  // Như kb_search: agent chưa được gán hướng dẫn nào thì không vào schema.
  "nap_huong_dan",
  // Chỉ vào schema khi chính chủ bot nhắn riêng - ngữ cảnh test là tin người lạ.
  "gui_tin_ca_nhan",
];

function configureImageGen(): void {
  imageStore.updateImageSettings({
    baseUrl: "https://router.test",
    model: "cx/gpt-5.5-image",
    apiKey: "sk-x",
  });
}

describe("tool-registry", () => {
  it("mặc định (không tắt gì) build đủ catalog TRỪ các tool chưa có hạ tầng", () => {
    unconfigureSidecar();
    imageStore.clearImageSettings();
    const tools = registry.buildAgentTools(makeContext([]));
    const expected = registry.TOOL_KEYS.filter((k) => !GATED_TOOLS.includes(k));
    assert.deepEqual(Object.keys(tools).sort(), expected.sort());
    // Các tool cốt lõi phải có mặt - đổi key là model "mất trí nhớ" về tool
    for (const key of ["get_datetime", "web_search", "web_fetch", "add_reaction", "send_file"]) {
      assert.ok(tools[key], `thiếu tool ${key}`);
    }
  });

  it("read_image chỉ vào schema khi sidecar đã cấu hình (kiểm mỗi lượt, không cần restart)", () => {
    configureSidecar();
    assert.ok(registry.buildAgentTools(makeContext([])).read_image, "có sidecar phải có tool");
    unconfigureSidecar();
    assert.equal(registry.buildAgentTools(makeContext([])).read_image, undefined);
  });

  it("read_image bị tắt per account thì kể cả có sidecar cũng không vào schema", () => {
    configureSidecar();
    const tools = registry.buildAgentTools(makeContext(["read_image"]));
    assert.equal(tools.read_image, undefined);
    unconfigureSidecar();
  });

  it("tool bị tắt biến mất khỏi schema - model không biết nó tồn tại", () => {
    const tools = registry.buildAgentTools(makeContext(["web_search", "send_file"]));
    assert.equal(tools.web_search, undefined);
    assert.equal(tools.send_file, undefined);
    assert.ok(tools.get_datetime, "tool không tắt vẫn phải còn");
  });

  it("create_image chỉ vào schema khi đã cấu hình endpoint vẽ ảnh", () => {
    imageStore.clearImageSettings();
    assert.equal(registry.buildAgentTools(makeContext([])).create_image, undefined);
    configureImageGen();
    assert.ok(registry.buildAgentTools(makeContext([])).create_image, "có cấu hình phải có tool");
    imageStore.clearImageSettings();
  });

  it("create_image bị tắt per account thì kể cả đã cấu hình cũng không vào schema", () => {
    configureImageGen();
    assert.equal(registry.buildAgentTools(makeContext(["create_image"])).create_image, undefined);
    imageStore.clearImageSettings();
  });

  it("schedule_task chỉ vào schema khi SCHEDULER_ENABLED bật (kiểm mỗi lượt, không cần restart)", () => {
    assert.ok(registry.buildAgentTools(makeContext([])).schedule_task, "mặc định SCHEDULER_ENABLED=true phải có tool");
    tuning.setTuning("SCHEDULER_ENABLED", false);
    assert.equal(registry.buildAgentTools(makeContext([])).schedule_task, undefined, "tắt cờ thì tool phải biến mất");
    tuning.setTuning("SCHEDULER_ENABLED", null);
  });

  it("key lạ trong disabledTools không làm crash, không ảnh hưởng tool khác", () => {
    unconfigureSidecar();
    imageStore.clearImageSettings();
    const tools = registry.buildAgentTools(makeContext(["khong-ton-tai"]));
    // 2 tool có điều kiện vắng vì chưa cấu hình, phần còn lại đủ
    assert.equal(Object.keys(tools).length, registry.TOOL_KEYS.length - GATED_TOOLS.length);
  });

  // ===== Hai lớp lọc: agent khai năng lực, account áp chính sách =====
  // Bất biến: tool dùng được là phần KHÔNG BÊN NÀO tắt. Không bên nào bật ngược
  // lại được bên kia - nhờ vậy thêm một agent mới không bao giờ nới rộng được
  // quyền của một nick, kể cả khi agent đó được tạo cẩu thả.

  it("agent tắt tool thì mất, dù account bật", () => {
    const tools = registry.buildAgentTools(makeContext([], ["web_search"]));
    assert.equal(tools.web_search, undefined, "agent tắt phải thắng");
    assert.ok(tools.web_fetch, "tool agent không tắt vẫn phải còn");
  });

  it("account tắt tool thì mất, dù agent bật", () => {
    const tools = registry.buildAgentTools(makeContext(["web_search"], []));
    assert.equal(tools.web_search, undefined, "account tắt phải thắng");
  });

  it("cả hai cùng tắt một tool cũng chỉ mất một lần, không lỗi", () => {
    const tools = registry.buildAgentTools(makeContext(["web_search"], ["web_search"]));
    assert.equal(tools.web_search, undefined);
    assert.ok(tools.get_datetime, "phần còn lại không bị ảnh hưởng");
  });

  it("hai bên tắt hai tool KHÁC nhau thì mất cả hai - đây là phép giao, không phải ghi đè", () => {
    unconfigureSidecar();
    imageStore.clearImageSettings();
    const tools = registry.buildAgentTools(makeContext(["send_file"], ["web_search"]));
    assert.equal(tools.send_file, undefined, "account tắt send_file");
    assert.equal(tools.web_search, undefined, "agent tắt web_search");
    // Chứng minh không phải "bên này ghi đè bên kia": nếu ghi đè thì một trong
    // hai tool trên sẽ còn sống.
    assert.equal(
      Object.keys(tools).length,
      registry.TOOL_KEYS.length - GATED_TOOLS.length - 2,
      "phải mất ĐÚNG 2 tool",
    );
  });

  it("không bên nào tắt thì đủ bộ - đối chứng cho 4 ca trên", () => {
    unconfigureSidecar();
    imageStore.clearImageSettings();
    const tools = registry.buildAgentTools(makeContext([], []));
    assert.equal(Object.keys(tools).length, registry.TOOL_KEYS.length - GATED_TOOLS.length);
  });

  it("key lạ trong danh sách tắt của AGENT cũng không làm crash", () => {
    unconfigureSidecar();
    imageStore.clearImageSettings();
    const tools = registry.buildAgentTools(makeContext([], ["khong-ton-tai-2"]));
    assert.equal(Object.keys(tools).length, registry.TOOL_KEYS.length - GATED_TOOLS.length);
  });

  // 29 tool bị loại khỏi lượt theo lịch, 4 nhóm lý do (xem tool-catalog-types.ts):
  // thiếu hạ tầng cho lượt cô lập (add_reaction, read_image, save_memory,
  // luu_quy_trinh, schedule_task), gửi thẳng qua enqueueSend nên né được trần ngày
  // (send_file, send_sticker, 3 tool Office (Word/Excel/PowerPoint), PowerPoint thiết kế, PDF, 4
  // tool file văn bản thuần, create_image, create_voice, create_music,
  // create_video, tai_video, tag_member), không có chủ tài khoản nào đang chat
  // để mà ra lệnh (undo_message), và 10 tool quản trị nhóm cùng lý do
  // (kick/chuyển quyền/duyệt thành viên...).
  const TOOL_LOAI_KHOI_LICH = [
    "add_reaction",
    "read_image",
    "save_memory",
    "luu_quy_trinh",
    "schedule_task",
    "send_file",
    "create_word_document",
    "create_excel_file",
    "create_powerpoint_file",
    "soan_email",
    "bao_cao_doi_thu",
    "ke_hoach_content",
    "tao_so_do_quy_trinh",
    "viet_caption",
    "tao_anh_bai_dang",
    "bao_cao_do_luong",
    "create_pdf_file",
    "create_markdown_file",







    "create_html_file",
    "create_csv_file",
    "create_text_file",
    "create_image",
    "create_voice",
    "create_music",
    "tai_video",
    "tai_mp3",
    "tag_member",
    "gui_vao_nhom",
    "gui_tin_ca_nhan",
    "bao_chu_xin_y_kien",
  ];

  it("isolated:true (lượt theo lịch) loại đủ 28 tool kể cả khi hạ tầng/cấu hình đã sẵn sàng", () => {
    // Cấu hình sidecar + vẽ ảnh + TTS + nhạc + video TRƯỚC để chứng minh các
    // tool đó bị loại vì runsInScheduledTurn, không phải vì thiếu cấu hình -
    // nếu không thì test không phân biệt được vắng do isolated hay do chưa sẵn sàng.
    configureSidecar();
    configureImageGen();
    const tools = registry.buildAgentTools({ ...makeContext([], [], true, true, true), isolated: true });
    for (const key of TOOL_LOAI_KHOI_LICH) {
      assert.equal(tools[key], undefined, `lượt theo lịch không được có tool ${key}`);
    }
    // Tool KHÔNG bị loại (vd get_datetime, web_search) vẫn phải còn nguyên
    assert.ok(tools.get_datetime, "tool không liên quan tới isolated vẫn phải có mặt");
    assert.ok(tools.web_search, "web_search không nằm trong danh sách loại");
    unconfigureSidecar();
    imageStore.clearImageSettings();
  });

  it("isolated không truyền (mặc định) hoặc false thì đủ cả 28 tool - hành vi lượt tin nhắn không đổi", () => {
    configureSidecar();
    configureImageGen();
    const macDinh = registry.buildAgentTools(makeContext([], [], true, true, true));
    const roFalse = registry.buildAgentTools({ ...makeContext([], [], true, true, true), isolated: false });
    for (const tools of [macDinh, roFalse]) {
      // create_designed_slides cần PPT Master trên máy chủ - không dựng được ở máy test.
      for (const key of TOOL_LOAI_KHOI_LICH.filter((k) => k !== "gui_tin_ca_nhan")) {
        assert.ok(tools[key], `${key} phải còn khi không cô lập (đã cấu hình đủ hạ tầng)`);
      }
    }
    unconfigureSidecar();
    imageStore.clearImageSettings();
  });

  it("runsInScheduledTurn khai đúng false cho đúng 29 tool, còn lại mặc định undefined (coi như true)", () => {
    const bịLoại = registry.TOOL_DEFINITIONS.filter((t) => t.runsInScheduledTurn === false).map((t) => t.key);
    assert.deepEqual(bịLoại.sort(), [...TOOL_LOAI_KHOI_LICH].sort());
  });

  it("catalog: key duy nhất, đủ metadata cho UI, nhóm hợp lệ", () => {
    const keys = registry.TOOL_DEFINITIONS.map((t) => t.key);
    assert.equal(new Set(keys).size, keys.length, "key tool phải duy nhất");
    for (const def of registry.TOOL_DEFINITIONS) {
      assert.ok(def.label && def.description, `tool ${def.key} thiếu label/description cho UI`);
      assert.ok(["read", "action"].includes(def.group));
    }
  });
});
