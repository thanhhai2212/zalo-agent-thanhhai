/**
 * Lọc JSON Schema của tool MCP NGOÀI trước khi gửi cho model - bẫy đã dính
 * thật (2026-09-24): Apify actor "Facebook Groups Scraper" khai input schema
 * có các khóa MỞ RỘNG riêng của Apify (`prefill`, `editor`, `enumTitles`,
 * `$id`, `schemaVersion` - dùng để dựng form nhập liệu trên web Apify), hợp lệ
 * theo quy ước của họ nhưng KHÔNG nằm trong tập khóa Gemini công nhận.
 *
 * Hậu quả đo thật, nặng hơn một tool lỗi đơn lẻ: Gemini (qua router
 * openai-compatible) từ chối THẲNG CẢ REQUEST với `400 INVALID_ARGUMENT` ngay
 * khi danh sách tool gửi kèm MANG THEO một tool có schema lạ - dù model CHƯA
 * HỀ gọi tool đó. Vì mọi lượt của agent đều gửi kèm TOÀN BỘ schema tool đang
 * bật, một server MCP có schema không sạch làm HỎNG MỌI LƯỢT của agent đó,
 * kể cả những câu hỏi không liên quan gì tới MCP.
 *
 * Hướng ĐÃ CÂN NHẮC và BÁC: liệt kê (blocklist) đúng 5 khóa đã đo được lỗi.
 * Không đủ an toàn - server MCP khác (hoặc actor Apify khác) có thể mang theo
 * khóa lạ KHÁC mà chưa ai đo được, tái diễn đúng sự cố này. Chọn ALLOWLIST
 * (chỉ giữ khóa ĐÃ BIẾT an toàn) - khớp triết lý mặc định-từ-chối đã dùng
 * xuyên suốt repo (Cửa 1/Cửa 2 của mọi tool, whitelist domain video...).
 */

/** Khóa JSON Schema được coi là AN TOÀN với Gemini/OpenAI function-calling */
const KHOA_AN_TOAN = new Set([
  "type",
  "description",
  "properties",
  "items",
  "required",
  "enum",
  "additionalProperties",
  "format",
  "default",
  "minimum",
  "maximum",
  "minLength",
  "maxLength",
  "minItems",
  "maxItems",
  "pattern",
  "nullable",
]);

/** Khóa mà GIÁ TRỊ của nó là một schema con (hoặc mảng schema con) - phải đệ quy vào */
const KHOA_CO_SCHEMA_CON = new Set(["items", "additionalProperties"]);

function laObjectThuan(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/**
 * Lọc đệ quy MỘT node schema. Đệ quy CÓ TRẦN ĐỘ SÂU (20) chứ không đệ quy vô
 * hạn - JSON Schema hợp lệ không bao giờ sâu tới mức đó, còn schema server
 * ngoài cố tình dựng vòng lặp tham chiếu (`$ref` trỏ ngược) sẽ tự dừng ở đây
 * thay vì tràn ngăn xếp.
 */
export function locJsonSchemaMcp(node: unknown, doSau = 0): unknown {
  if (doSau > 20) return undefined;
  if (Array.isArray(node)) return node.map((n) => locJsonSchemaMcp(n, doSau + 1));
  if (!laObjectThuan(node)) return node;

  const ra: Record<string, unknown> = {};
  for (const [khoa, gia] of Object.entries(node)) {
    if (!KHOA_AN_TOAN.has(khoa)) continue; // bỏ hẳn khóa lạ - đúng tinh thần allowlist
    if (khoa === "properties" && laObjectThuan(gia)) {
      const props: Record<string, unknown> = {};
      for (const [ten, schemaCon] of Object.entries(gia)) {
        props[ten] = locJsonSchemaMcp(schemaCon, doSau + 1);
      }
      ra[khoa] = props;
    } else if (KHOA_CO_SCHEMA_CON.has(khoa) && (laObjectThuan(gia) || Array.isArray(gia))) {
      // `items`/`additionalProperties` có thể là schema (object) HOẶC boolean
      // (`additionalProperties: false`) - chỉ đệ quy khi thật sự là schema.
      ra[khoa] = locJsonSchemaMcp(gia, doSau + 1);
    } else {
      ra[khoa] = gia;
    }
  }
  return ra;
}
