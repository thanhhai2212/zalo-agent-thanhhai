import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { Tool } from "ai";
import { goiVoiPhucHoiPhien, laLoiHetPhienMcp } from "./mcp-session-retry.js";

const toolA = { name: "A" } as unknown as Tool;
const toolB = { name: "B" } as unknown as Tool;

describe("laLoiHetPhienMcp", () => {
  it("nhận đúng các câu hết phiên thật (Apify, @ai-sdk/mcp)", () => {
    assert.ok(laLoiHetPhienMcp(new Error("Session not found")));
    assert.ok(laLoiHetPhienMcp(new Error("Bad Request: Session ID not found")));
    assert.ok(laLoiHetPhienMcp(new Error("HTTP 404. The MCP session expired. Create a new client")));
    assert.ok(laLoiHetPhienMcp(new Error("No valid session ID provided")));
  });

  it("nhận client đã đóng (đo thật với Apify 2026-10-02)", () => {
    assert.equal(laLoiHetPhienMcp(new Error("Attempted to send a request from a closed client")), true);
  });

  it("lỗi khác KHÔNG bị coi là hết phiên", () => {
    assert.ok(!laLoiHetPhienMcp(new Error("server sập")));
    assert.ok(!laLoiHetPhienMcp(new Error("quá 60000ms")));
    assert.ok(!laLoiHetPhienMcp(new Error("Actor not found")));
  });
});

describe("goiVoiPhucHoiPhien", () => {
  it("hết phiên thì lấy tool mới và thử lại ĐÚNG một lần", async () => {
    const daGoi: Tool[] = [];
    let soLanLay = 0;
    const kq = await goiVoiPhucHoiPhien(
      async (t) => {
        daGoi.push(t);
        if (t === toolA) throw new Error("Session not found");
        return "ok";
      },
      toolA,
      async () => {
        soLanLay++;
        return toolB;
      },
    );
    assert.equal(kq, "ok");
    assert.deepEqual(daGoi, [toolA, toolB]);
    assert.equal(soLanLay, 1);
  });

  it("lỗi không phải hết phiên thì ném luôn, không nối lại", async () => {
    let soLanLay = 0;
    await assert.rejects(
      goiVoiPhucHoiPhien(
        async () => {
          throw new Error("server sập");
        },
        toolA,
        async () => {
          soLanLay++;
          return toolB;
        },
      ),
      /server sập/,
    );
    assert.equal(soLanLay, 0);
  });

  it("nối lại không ra tool thì ném lỗi GỐC", async () => {
    await assert.rejects(
      goiVoiPhucHoiPhien(
        async () => {
          throw new Error("Session not found");
        },
        toolA,
        async () => undefined,
      ),
      /Session not found/,
    );
  });

  it("client mới vẫn hết phiên thì dừng sau 1 lần thử lại, không lặp vô hạn", async () => {
    let soLanGoi = 0;
    await assert.rejects(
      goiVoiPhucHoiPhien(
        async () => {
          soLanGoi++;
          throw new Error("Session not found");
        },
        toolA,
        async () => toolB,
      ),
    );
    assert.equal(soLanGoi, 2);
  });
});
