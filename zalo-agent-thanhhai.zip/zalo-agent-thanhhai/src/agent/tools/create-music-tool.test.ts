import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { fakeAgentProfile } from "../../shared/fake-agent-profile.js";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool, ketQuaThanhCong } from "./tool-failure-result-test-helper.js";
import type { AgentProfile } from "../../config/agent-store.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";
import type { GeneratedMusic } from "../../music/music-generation-client.js";

/**
 * create_music: đọc cấu hình tạo nhạc RIÊNG của agent (ctx.agent). Mock
 * `generate` - không chạm mạng, không tốn tiền thật ($0,08/bài).
 */

let dataDir: string;
let toolModule: typeof import("./create-music-tool.js");
let rateLimit: typeof import("../../music/music-rate-limit.js");
let database: typeof import("../../conversation/database.js");
type ToolContext = import("./tool-registry.js").ToolContext;

type Event =
  | { kind: "generate"; prompt: string }
  | { kind: "file"; fileName: string; buffer: Buffer; caption: string }
  | { kind: "text"; msg: string };
let events: Event[] = [];
let ghiNhan: string[] = [];
let generateError: Error | null = null;

before(async () => {
  dataDir = setupTestEnv({ MUSIC_GEN_MAX_PER_HOUR: "2" });
  toolModule = await import("./create-music-tool.js");
  rateLimit = await import("../../music/music-rate-limit.js");
  database = await import("../../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  events = [];
  ghiNhan = [];
  generateError = null;
  rateLimit.resetMusicRateLimit();
});

const fakeGenerate = async (prompt: string): Promise<GeneratedMusic> => {
  events.push({ kind: "generate", prompt });
  if (generateError) throw generateError;
  return { data: Buffer.from([1, 2, 3, 4, 5]), ext: "wav" };
};

const message: ParsedMessage = {
  accountId: "acc-m",
  threadId: "t-m",
  threadType: 0,
  isGroup: false,
  senderId: "u1",
  senderName: "Hải",
  text: "sáng tác giúp",
  images: [],
  msgId: "m1",
  cliMsgId: "c1",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
};

function makeCtx(agent: AgentProfile): ToolContext {
  return {
    api: {
      sendMessage: async (content: { msg: string; attachments?: string[] }) => {
        const attachment = content.attachments?.[0];
        if (attachment) {
          events.push({
            kind: "file",
            fileName: path.basename(attachment),
            buffer: fs.readFileSync(attachment),
            caption: content.msg,
          });
        } else {
          events.push({ kind: "text", msg: content.msg });
        }
        return {};
      },
    } as never,
    account: { id: "acc-m", disabledTools: [] } as never,
    agent,
    message,
    batch: [message],
    ghiNhanDaGui: (noiDung: string) => ghiNhan.push(noiDung),
  } as ToolContext;
}

const MUSIC_OK = {
  musicProvider: "openrouter",
  musicModel: "google/lyria-3-pro-preview",
  musicApiKey: "sk-or-x",
};

/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (agent: AgentProfile, input: unknown): Promise<unknown> =>
  (toolModule.createMusicTool(makeCtx(agent), fakeGenerate) as any).execute(input, {});

describe("agentCoMusic - gate", () => {
  it("thiếu model hoặc key (openrouter) -> false", () => {
    assert.equal(toolModule.agentCoMusic(fakeAgentProfile({ musicApiKey: "k" })), false);
    assert.equal(toolModule.agentCoMusic(fakeAgentProfile({ musicModel: "google/lyria-3-pro-preview" })), false);
  });
  it("đủ model + key -> true, KHÔNG cần voice/format (có mặc định)", () => {
    assert.equal(toolModule.agentCoMusic(fakeAgentProfile(MUSIC_OK)), true);
  });

  it("google-ai-studio: chưa có ttsApiKey -> false dù có musicApiKey riêng (không dùng cột đó nữa)", () => {
    assert.equal(
      toolModule.agentCoMusic(fakeAgentProfile({ musicProvider: "google-ai-studio", musicApiKey: "sk-or-x" })),
      false,
    );
  });
  it("google-ai-studio: có ttsApiKey (dùng chung với TTS) -> true, KHÔNG cần musicModel (có mặc định lyria-3.5)", () => {
    assert.equal(
      toolModule.agentCoMusic(fakeAgentProfile({ musicProvider: "google-ai-studio", ttsApiKey: "AIzaS-key" })),
      true,
    );
  });
});

describe("create_music - các nhánh", () => {
  it("agent chưa cấu hình tạo nhạc -> HỎNG có đánh dấu, không gọi generate", async () => {
    const ra = await chay(fakeAgentProfile({}), { prompt: "một bản lo-fi" });
    assert.match(loiCuaTool(ra), /chưa cấu hình tạo nhạc/i);
    assert.equal(events.length, 0);
  });

  it("google-ai-studio chưa cấu hình -> báo rõ dùng chung key với TTS, không nhắc OpenRouter", async () => {
    const ra = await chay(fakeAgentProfile({ musicProvider: "google-ai-studio" }), { prompt: "một bản lo-fi" });
    assert.match(loiCuaTool(ra), /Giọng nói.*TTS/i);
    assert.equal(events.length, 0);
  });

  it("google-ai-studio đã có ttsApiKey (dùng chung với TTS) -> tạo được, không cần musicApiKey riêng", async () => {
    const ra = await chay(
      fakeAgentProfile({ musicProvider: "google-ai-studio", ttsApiKey: "AIzaS-key" }),
      { prompt: "một bản đồng quê vui tươi" },
    );
    ketQuaThanhCong(ra);
    assert.deepEqual(
      events.map((e) => e.kind),
      ["text", "generate", "file"],
    );
  });

  it("chạm trần thì KHÔNG gọi generate và KHÔNG nhắn báo trước", async () => {
    await chay(fakeAgentProfile(MUSIC_OK), { prompt: "1" });
    await chay(fakeAgentProfile(MUSIC_OK), { prompt: "2" });
    events = [];

    const ra = await chay(fakeAgentProfile(MUSIC_OK), { prompt: "3" });
    assert.deepEqual(events, [], "chạm trần mà vẫn nhắn 'đang tạo' là hứa lèo");
    assert.match(loiCuaTool(ra), /trần 2/);
  });

  it("tạo nhạc lỗi -> HỎNG có đánh dấu, không gửi gì lên Zalo", async () => {
    generateError = new Error("401 sai key");
    const ra = await chay(fakeAgentProfile(MUSIC_OK), { prompt: "một bản lo-fi" });
    assert.match(loiCuaTool(ra), /Tạo nhạc thất bại/);
    assert.equal(events.filter((e) => e.kind === "file").length, 0);
  });

  it("thành công -> báo trước rồi gửi file, chuỗi trần, có ghiNhanDaGui", async () => {
    const ra = await chay(fakeAgentProfile(MUSIC_OK), { prompt: "một bản đồng quê vui tươi" });
    const text = ketQuaThanhCong(ra);
    assert.match(text, /GỬI bài hát/);
    assert.deepEqual(
      events.map((e) => e.kind),
      ["text", "generate", "file"],
      "phải báo trước KHI generate mất ~1 phút, không phải sau",
    );
    const file = events.find((e) => e.kind === "file") as { fileName: string; buffer: Buffer };
    assert.match(file.fileName, /nhac-.*\.wav$/);
    assert.deepEqual(file.buffer, Buffer.from([1, 2, 3, 4, 5]));
    // báo trước + file: BẮT BUỘC ghi vào history để bot nhớ đã gửi
    assert.equal(ghiNhan.length, 2);
    assert.match(ghiNhan[1]!, /đã gửi bài hát/);
  });

  it("có caption -> file gửi kèm đúng caption, ghi chú kèm caption", async () => {
    const ra = await chay(fakeAgentProfile(MUSIC_OK), { prompt: "nội dung", caption: "Bài hát tặng bạn nhé" });
    ketQuaThanhCong(ra);
    const file = events.find((e) => e.kind === "file") as { caption: string };
    assert.equal(file.caption, "Bài hát tặng bạn nhé");
    assert.match(ghiNhan[1]!, /Bài hát tặng bạn nhé/);
  });
});
