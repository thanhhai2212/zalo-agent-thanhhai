import { tool } from "ai";
import { z } from "zod";
import { docThanHuongDan, huongDanCuaAgent, type HuongDanTomTat } from "../../knowledge/kb-huong-dan.js";
import { noiDungKyNang, TOI_DA_TEP_MOI_LAN } from "../../knowledge/skill-parts.js";
import { layNguon } from "../../knowledge/kb-source-store.js";
import { boDauTiengViet } from "../../shared/bo-dau-tieng-viet.js";
import type { ToolContext } from "./index.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * `nap_huong_dan`: đọc toàn văn một hướng dẫn/quy trình chủ bot đã nạp vào Kho
 * tri thức và đánh dấu "nạp theo nhu cầu" (xem `kb-huong-dan.ts`). Danh sách
 * tên + mô tả một dòng nằm NGAY TRONG mô tả tool, dựng lại mỗi lượt theo agent
 * - model nhìn danh sách ngắn là biết có hướng dẫn cho việc đang làm, gọi rồi
 * mới tốn token cho toàn văn. Khác `kb_search` (tìm đoạn theo từ khóa): ở đây
 * là cả bài, đúng thứ tự, để làm theo từng bước.
 */

export const TRAN_MO_TA_TRONG_TOOL = 120;

export function moTaToolNapHuongDan(ds: HuongDanTomTat[]): string {
  const motDong = (h: HuongDanTomTat) => `- "${h.ten}"${h.moTa ? `: ${h.moTa.slice(0, TRAN_MO_TA_TRONG_TOOL)}` : ""}`;
  // Nhiều bộ thì đặt tiêu đề bộ trước nhóm dòng - model dễ thấy cả bộ liên quan tới việc đang làm.
  const cacBo = [...new Set(ds.map((h) => h.bo))];
  const dong = cacBo.length <= 1 ? ds.map(motDong) : cacBo.flatMap((b) => [`[${b || "Kỹ năng lẻ"}]`, ...ds.filter((h) => h.bo === b).map(motDong)]);
  return [
    "Đọc TOÀN VĂN một kỹ năng (skill)/quy trình chủ bot đã nạp, để làm theo từng bước. GỌI TRƯỚC khi bắt tay vào việc",
    "nếu việc người dùng yêu cầu khớp một kỹ năng dưới đây (đọc rồi mới làm, không đoán quy trình). Kỹ năng dài trả phần chính",
    "kèm danh sách tài liệu kèm - mở tài liệu nào thì gọi lại với tep. Kỹ năng có sẵn:",
    ...dong,
  ].join("\n");
}

function khopTen(ten: string, h: HuongDanTomTat): boolean {
  const q = boDauTiengViet(ten).toLowerCase().trim();
  return h.id === ten.trim() || boDauTiengViet(h.ten).toLowerCase() === q;
}

export function createNapHuongDanTool(ctx: ToolContext) {
  const ds = huongDanCuaAgent(ctx.agent.id);
  return tool({
    description: moTaToolNapHuongDan(ds),
    inputSchema: z.object({
      ten: z.string().min(1).max(200).describe("Tên hướng dẫn đúng như trong danh sách"),
      tep: z
        .array(z.string().min(1).max(300))
        .max(TOI_DA_TEP_MOI_LAN)
        .optional()
        .describe("Đường dẫn tài liệu kèm cần đọc (lấy từ danh sách lần gọi trước). Bỏ trống để đọc phần chính."),
    }),
    execute: async ({ ten, tep }) => {
      // Đọc LẠI danh sách lúc gọi (không dùng bản chụp lúc dựng tool): hướng
      // dẫn bị xóa/gỡ khỏi agent giữa lượt thì không đọc được nữa.
      const hienCo = huongDanCuaAgent(ctx.agent.id);
      let khop = hienCo.filter((h) => khopTen(ten, h));
      if (khop.length === 0) {
        const q = boDauTiengViet(ten).toLowerCase().trim();
        khop = hienCo.filter((h) => boDauTiengViet(h.ten).toLowerCase().includes(q));
      }
      if (khop.length === 0) {
        return ketQuaLoi(`Không có hướng dẫn tên "${ten}". Hiện có: ${hienCo.map((h) => `"${h.ten}"`).join(", ") || "(không có)"}.`);
      }
      if (khop.length > 1) {
        return ketQuaLoi(`Nhiều hướng dẫn khớp "${ten}": ${khop.map((h) => `"${h.ten}"`).join(", ")} - gọi lại với tên đầy đủ.`);
      }
      const nguon = layNguon(khop[0]!.id);
      if (!nguon) return ketQuaLoi("Hướng dẫn vừa bị xóa.");
      try {
        const than = docThanHuongDan(nguon);
        if (!than) return ketQuaLoi(`Hướng dẫn "${nguon.ten}" chưa có nội dung (file chưa xử lý xong hoặc rỗng).`);
        const kq = noiDungKyNang(nguon.ten, than, tep);
        return kq.ok ? kq.text : ketQuaLoi(kq.loi);
      } catch (err) {
        return ketQuaLoi(`Không đọc được hướng dẫn "${nguon.ten}": ${err instanceof Error ? err.message : String(err)}`);
      }
    },
  });
}
