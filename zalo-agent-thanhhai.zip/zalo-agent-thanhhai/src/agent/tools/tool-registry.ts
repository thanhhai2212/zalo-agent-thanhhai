import type { Tool } from "ai";
import type { AccountConfig } from "../../config/account-store.js";
import type { AgentProfile } from "../../config/agent-store.js";
import { toolChayDuocTrenBot } from "../../zalo-bot/nang-luc-kenh-bot.js";
import { layToolMcpChoAgent } from "./mcp-tool-provider.js";
import { TOOL_DEFINITIONS, type ToolContext, type ToolDefinition } from "./tool-catalog.js";

/**
 * Logic lọc + dựng tool cho 1 lượt agent. Hình dạng dữ liệu (type + catalog
 * `TOOL_DEFINITIONS`) nằm ở `tool-catalog.ts` - tách ra để file này không vượt
 * ngưỡng 200 dòng. Re-export lại để mọi nơi import từ "tool-registry.js" (hoặc
 * gián tiếp qua "index.js") như cũ, không phải sửa call site nào khác.
 */
export { TOOL_DEFINITIONS, TOOL_KEYS, type ToolContext, type ToolDefinition, type ToolGroup } from "./tool-catalog.js";

/**
 * Hai lớp cùng quyết định một tool có được cấp hay không.
 *
 * - `agent` khai NĂNG LỰC: agent này biết làm những việc gì.
 * - `account` áp CHÍNH SÁCH: nick Zalo này được phép làm gì.
 *
 * Cả hai đều lưu danh sách TẮT, và kết quả là phần KHÔNG bên nào tắt. Không bên
 * nào bật ngược lại được bên kia - nhờ vậy thêm một agent mới không bao giờ nới
 * rộng được quyền của một nick, kể cả khi agent đó được tạo cẩu thả.
 */
export type ToolScope = {
  // tts*/music*/video* để `available(scope)` của tool tạo nội dung quyết theo
  // cấu hình RIÊNG của agent - tool chỉ vào schema khi agent đó đã cấu hình
  agent: Pick<
    AgentProfile,
    | "id"
    | "disabledTools"
    | "ttsProvider"
    | "ttsBaseUrl"
    | "ttsModel"
    | "ttsVoice"
    | "ttsApiKey"
    | "ttsVbeeAppId"
    | "musicProvider"
    | "musicModel"
    | "musicApiKey"
    | "videoProvider"
    | "videoModel"
    | "videoApiKey"
  >;
  account: Pick<AccountConfig, "disabledTools" | "loai">;
  /**
   * Lượt này do CHÍNH chủ bot nhắn RIÊNG (không phải nhóm). Server MCP bật "chỉ
   * chủ bot" chỉ đưa tool vào schema khi cờ này đúng - thiếu = false (đóng).
   */
  chuChatRieng?: boolean;
  /**
   * Lượt trong NHÓM mà TẤT CẢ tin của lượt đều do chủ bot gửi. Đòi cả batch (không chỉ tin cuối) vì
   * lượt nhóm gộp tin của nhiều người: một tin của người lạ nằm chung lượt có thể chứa câu lệnh dụ
   * model gọi tool trong khi tin cuối là của chủ bot.
   */
  chuTrongNhom?: boolean;
};

/**
 * Bộ tool đưa vào lượt agent, đã bỏ tool agent tắt, tool account tắt trên
 * dashboard, và (với lượt theo lịch) tool có `runsInScheduledTurn: false`.
 * Tool bị tắt không xuất hiện trong schema -> model không biết nó tồn tại,
 * không tốn token mô tả, không thể bị prompt injection dụ gọi.
 */
export function buildAgentTools(ctx: ToolContext): Record<string, Tool> {
  const tools: Record<string, Tool> = {};
  const laChu = Boolean(ctx.account.ownerUserId) && ctx.message.senderId === ctx.account.ownerUserId;
  const chuChatRieng = laChu && !ctx.message.isGroup;
  const chuTrongNhom = laChu && ctx.message.isGroup && ctx.batch.every((m) => m.senderId === ctx.account.ownerUserId);
  for (const def of listAvailableTools(
    { agent: ctx.agent, account: ctx.account, chuChatRieng, chuTrongNhom },
    { isolated: ctx.isolated },
  )) {
    tools[def.key] = def.build(ctx);
  }
  return tools;
}

/**
 * Tool agent THỰC SỰ nhận được trong lượt này. Dùng chung bộ lọc với
 * `buildAgentTools` (chính nó gọi hàm này) vì system prompt cũng cần danh sách
 * để trả lời câu "bạn làm được gì" - hai nơi tự lọc riêng là sớm muộn cũng
 * lệch, và lệch nghĩa là bot hứa một tool mà model không hề nhận được.
 *
 * Nhận nguyên cụm `scope` thay vì hai tham số rời: thêm lớp lọc mới sau này chỉ
 * phải sửa type, không phải sờ lại từng call site. Và để cụm là BẮT BUỘC (không
 * optional) nên quên truyền `agent` là lỗi biên dịch, không phải lỗi âm thầm
 * cấp thừa tool.
 *
 * `context.isolated` mặc định false: CẢ `buildAgentTools` LẪN `buildSystemPrompt`
 * (persona-prompt.ts) đều truyền `isolated` THẬT xuống đây - lượt theo lịch
 * (isolated:true) phải thấy ĐÚNG danh sách tool đã lọc ở CẢ 2 nơi, không chỉ
 * ở schema gửi model. Lệch nhau nghĩa là persona hứa 1 tool mà model không hề
 * nhận được (đúng lỗi persona-prompt.test.ts đang canh bằng bất biến riêng).
 */
export function listAvailableTools(
  scope: ToolScope,
  context: { isolated?: boolean } = {},
): ToolDefinition[] {
  // Gộp hai danh sách TẮT thành một tập: tool nằm trong tập là bị loại, bất kể
  // bên nào tắt nó. Đây chính là phép giao của hai tập BẬT, viết theo chiều
  // danh sách tắt cho khớp cách lưu ở DB.
  const disabled = new Set([...scope.agent.disabledTools, ...scope.account.disabledTools]);
  // Tool NGOÀI (MCP) - danh sách ĐỘNG theo agent, không nằm trong
  // TOOL_DEFINITIONS tĩnh. Nguồn đã tự lọc theo server ĐÃ GÁN cho agent này
  // (`mcpToolDefinitions`), nên gộp thẳng vào đây rồi đi qua CÙNG vòng lọc
  // available/disabled/isolated bên dưới như mọi tool nội bộ khác.
  const tatCa = [...TOOL_DEFINITIONS, ...layToolMcpChoAgent(scope.agent.id)];
  return tatCa.filter((def) => {
    if (disabled.has(def.key)) return false;
    if (context.isolated && def.runsInScheduledTurn === false) return false;
    // Cửa 1 (schema): kênh bot (Zalo Bot API) không có method cho các tool cần
    // zca-js - chặn NGAY ĐÂY để model không hứa việc nó không làm nổi. Cửa 2
    // (recheck runtime, `ctx.api` null) nằm trong chính `execute` của từng
    // tool - xem `nang-luc-kenh-bot.ts`.
    if (scope.account.loai === "bot" && !toolChayDuocTrenBot(def.key)) return false;
    // Kiểm mỗi lượt: cấu hình từ dashboard ăn ngay không cần restart. Truyền
    // `scope` để tool có cấu hình RIÊNG theo agent (vd TTS) tự quyết được -
    // tool global (sidecar, vẽ ảnh) bỏ qua tham số này.
    return !def.available || def.available(scope);
  });
}
