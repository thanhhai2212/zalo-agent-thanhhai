import fs from "node:fs";
import path from "node:path";
import { tool } from "ai";
import { ThreadType } from "zca-js";
import { z } from "zod";
import { dataDir } from "../../config/env.js";
import { db } from "../../conversation/database.js";
import { appendMessage } from "../../conversation/history-store.js";
import { appendSentMsgId } from "../../conversation/message-recall-store.js";
import { chuanHoaTimKiem } from "../../conversation/sender-lookup-store.js";
import { listThreadsForAccount } from "../../conversation/thread-store.js";
import { enqueueSend } from "../../middleware/rate-limiter.js";
import { withNamedTempFile } from "../../shared/temp-file-store.js";
import { waitForCliMsgId } from "../../zalo/self-echo-registry.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import { chanDocCheoThread } from "./cross-thread-gate.js";
import type { ToolContext } from "./index.js";
import { guiFileKemCaption } from "./send-attachment-with-caption.js";
import { ghiChuDaGuiFile } from "./sent-by-tool-note.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Chủ bot ra lệnh từ CHAT RIÊNG để bot gửi tin/file vào một NHÓM khác
 * (2026-10-04, học từ `[POST_TO_GROUP]` của Heo-Agent nhưng làm thành tool).
 *
 * Khác Heo ở 3 chỗ an toàn:
 * - Gate `chanDocCheoThread`: chỉ chủ tài khoản, chỉ trong chat riêng. Heo bóc
 *   thẻ từ MỌI câu trả lời, kể cả câu trả lời cho người lạ trong nhóm.
 * - Không đoán nhóm: tên khớp 0 hoặc nhiều nhóm thì trả danh sách để hỏi lại.
 *   Heo gửi vào nhóm ĐẦU TIÊN khi không khớp tên.
 * - Chỉ gửi vào nhóm bot đã có trong danh sách hội thoại (bot đang tham gia).
 *
 * Tin chữ ghi vào history nhóm đích kèm `sent_msg_ids` (qua tiếng vọng) nên
 * `undo_message` thu hồi được như tin trả lời thường.
 */

export type NhomTimDuoc = { threadId: string; ten: string };

export function timNhom(accountId: string, nhom: string): { ok: NhomTimDuoc } | { loi: string } {
  const ds = listThreadsForAccount(accountId)
    .filter((t) => t.threadType === ThreadType.Group)
    .map((t) => ({ threadId: t.threadId, ten: t.displayName || t.threadId }));
  const q = nhom.trim();
  const theoId = ds.find((g) => g.threadId === q);
  if (theoId) return { ok: theoId };
  const n = chuanHoaTimKiem(q);
  const dungTen = ds.filter((g) => chuanHoaTimKiem(g.ten) === n);
  if (dungTen.length === 1) return { ok: dungTen[0]! };
  const chua = ds.filter((g) => chuanHoaTimKiem(g.ten).includes(n));
  if (chua.length === 1) return { ok: chua[0]! };
  const goiY = (chua.length ? chua : ds).slice(0, 12).map((g) => `- ${g.ten} (id ${g.threadId})`).join("\n");
  return {
    loi: chua.length
      ? `Có ${chua.length} nhóm khớp "${nhom}", hỏi lại chủ bot muốn gửi nhóm nào:\n${goiY}`
      : `Không thấy nhóm nào tên "${nhom}" trong các nhóm bot đang tham gia. Một số nhóm hiện có:\n${goiY || "(chưa có nhóm nào)"}`,
  };
}

type FileGanDay = { fileName: string; relPath: string };

/** File bot đã tạo gần đây (mọi cuộc chat của tài khoản này) khớp tên. */
export function timFileDaTao(accountId: string, ten: string): FileGanDay | null {
  const rows = db
    .prepare("SELECT file_name, rel_path FROM generated_files WHERE account_id = ? ORDER BY id DESC LIMIT 100")
    .all(accountId) as { file_name: string; rel_path: string }[];
  const n = chuanHoaTimKiem(ten);
  const r = rows.find((x) => chuanHoaTimKiem(x.file_name) === n) ?? rows.find((x) => chuanHoaTimKiem(x.file_name).includes(n));
  return r ? { fileName: r.file_name, relPath: r.rel_path } : null;
}

const trichMsgId = (res: unknown): string | undefined => {
  const id = (res as { message?: { msgId?: unknown } } | null)?.message?.msgId;
  return id === undefined || id === null ? undefined : String(id);
};

export function createGuiVaoNhomTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được, chỉ trong chat riêng. Gửi một tin nhắn và/hoặc một file BOT ĐÃ TẠO vào một NHÓM Zalo " +
      "bot đang tham gia, theo lệnh của chủ (vd 'gửi vào nhóm Marketing là chiều nay họp lúc 3h', 'gửi file kế hoạch vừa làm vào nhóm X'). " +
      "Viết nội dung đúng lời sẽ đăng trong nhóm, không kèm lời nói với chủ. Tên nhóm khớp nhiều hoặc không khớp thì tool trả danh sách: hỏi lại chủ, đừng tự chọn.",
    inputSchema: z.object({
      nhom: z.string().min(1).max(200).describe("Tên nhóm (hoặc id nhóm) cần gửi"),
      noiDung: z.string().max(4000).optional().describe("Tin nhắn đăng vào nhóm; kèm file thì đây là lời nhắn đi cùng file"),
      tep: z.string().max(200).optional().describe("Tên file bot đã tạo trước đó cần gửi kèm (vd 'ke hoach content thang 10.xlsx')"),
    }),
    execute: async ({ nhom, noiDung, tep }) => {
      const chan = chanDocCheoThread(ctx);
      if (chan) return chan;
      if (!ctx.api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);
      const api = ctx.api;
      const loiNhan = noiDung?.trim();
      if (!loiNhan && !tep) return ketQuaLoi("Thiếu nội dung: cần noiDung hoặc tep.");

      const tim = timNhom(ctx.account.id, nhom);
      if ("loi" in tim) return ketQuaLoi(tim.loi);
      const { threadId: gid, ten } = tim.ok;
      const threadKey = `${ctx.account.id}:${gid}`;

      try {
        if (tep) {
          const f = timFileDaTao(ctx.account.id, tep);
          if (!f) return ketQuaLoi(`Không tìm thấy file bot đã tạo tên "${tep}". Hỏi lại chủ đúng tên file, hoặc tạo file trước rồi gửi.`);
          const data = fs.readFileSync(path.join(dataDir, f.relPath));
          await withNamedTempFile(f.fileName, data, (p) => guiFileKemCaption(api, threadKey, gid, ThreadType.Group, p, loiNhan));
          appendMessage(ctx.account.id, gid, { role: "assistant", content: ghiChuDaGuiFile(f.fileName, loiNhan) });
          return `Đã gửi file "${f.fileName}"${loiNhan ? " kèm lời nhắn" : ""} vào nhóm "${ten}". Báo chủ ngắn gọn là đã gửi.`;
        }
        const res = await enqueueSend(threadKey, () => api.sendMessage({ msg: loiNhan! }, gid, ThreadType.Group));
        const rowId = appendMessage(ctx.account.id, gid, { role: "assistant", content: loiNhan! });
        const msgId = trichMsgId(res);
        if (msgId) {
          void waitForCliMsgId(ctx.account.id, msgId).then((cli) => {
            if (cli) appendSentMsgId(rowId, msgId, cli);
          });
        }
        return `Đã gửi tin vào nhóm "${ten}" (id ${gid}). Báo chủ ngắn gọn là đã gửi; muốn gỡ thì dùng undo_message với threadId ${gid}.`;
      } catch (err) {
        return ketQuaLoi(`Gửi vào nhóm "${ten}" thất bại: ${err instanceof Error ? err.message : String(err)}`);
      }
    },
  });
}
