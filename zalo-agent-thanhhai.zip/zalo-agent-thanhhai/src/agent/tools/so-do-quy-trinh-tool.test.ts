import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let tools: typeof import("./so-do-quy-trinh-tool.js");
let render: typeof import("../../so-do/render-so-do.js");
let rateLimit: typeof import("../../documents/document-rate-limit.js");

type DaGui = { ten: string; buf: Buffer };
let daGui: DaGui[] = [];

before(async () => {
  dataDir = setupTestEnv({ DOCUMENT_MAX_PER_HOUR: "3" });
  tools = await import("./so-do-quy-trinh-tool.js");
  render = await import("../../so-do/render-so-do.js");
  rateLimit = await import("../../documents/document-rate-limit.js");
});
after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  rateLimit.resetDocumentRateLimit();
});

function ctx() {
  return {
    api: {
      sendMessage: async (c: { attachments: string[] }) => {
        daGui.push({ ten: path.basename(c.attachments[0]!), buf: fs.readFileSync(c.attachments[0]!) });
        return {};
      },
    },
    account: { id: "acc-sd", disabledTools: [], ownerUserId: "chu" },
    message: { threadId: "t-sd", threadType: 1, senderId: "nguoi-la" },
    batch: [],
  } as never;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

const buoc = (ten: string) => ({ ten, bot_lam: ["Làm việc A"], chot_chan: ["Trần 20 tệp"] });
const SO_DO = {
  tieu_de: "Từ ảnh ra Excel",
  gioi_thieu: "Bốn bước đi từ ảnh chụp tới bảng tính.",
  nguoi_khoi_dong: "Bạn gửi ảnh cho bot",
  cac_buoc: [buoc("Nhận ảnh"), buoc("Đọc chữ"), buoc("Dựng bảng"), buoc("Gửi file")],
};

describe("renderSoDo", () => {
  it("thoát ký tự mọi chữ của model, không để lọt thẻ hay thuộc tính", () => {
    const xau = '<script>alert(1)</script>"><img src=x onerror=alert(2)>';
    const html = render.renderSoDo({
      ...SO_DO,
      tieu_de: xau,
      cac_buoc: [{ ten: xau, bot_lam: [xau], nhan_thu: xau, nhan_nho: xau }, buoc("B")],
      nguyen_tac: [{ tieu_de: xau, noi_dung: xau }],
      cong_cu: [{ ten: xau, ghi_chu: xau }],
      chan_trang: xau,
    });
    assert.ok(!html.includes("<img"), "không được có thẻ img từ model");
    assert.equal((html.match(/<script/g) ?? []).length, 1, "chỉ còn đúng 1 thẻ script cố định");
    assert.ok(html.includes("&lt;script&gt;alert(1)"));
  });

  it("thuộc tính số do code tính, không phải chuỗi của model", () => {
    const html = render.renderSoDo({
      ...SO_DO,
      vong_lap: { tu_buoc: 3, den_buoc: 4, noi_dung: "Quay lại" },
    });
    assert.ok(html.includes('data-n="4"'));
    assert.ok(html.includes('data-loop="3,4"'));
    assert.ok(html.includes('data-parallel="0"'));
  });

  it("6 bước chia 3 thẻ một hàng", () => {
    const html = render.renderSoDo({ ...SO_DO, cac_buoc: Array.from({ length: 6 }, (_, i) => buoc(`B${i}`)) });
    assert.ok(html.includes("repeat(3,1fr)"));
  });
});

describe("so_do_quy_trinh tool", () => {
  it("gửi file .html và trả hướng dẫn bàn giao", async () => {
    const kq = await chay(tools.createSoDoQuyTrinhTool(ctx()), SO_DO);
    assert.equal(daGui.length, 1);
    assert.ok(daGui[0]!.ten.endsWith(".html"));
    assert.ok(daGui[0]!.buf.toString("utf8").includes("Từ ảnh ra Excel"));
    assert.match(String(kq), /Đã dựng sơ đồ 4 bước/);
  });

  it("từ chối vòng lặp nối bước ở hàng trên, không gửi file", async () => {
    const kq = await chay(tools.createSoDoQuyTrinhTool(ctx()), {
      ...SO_DO,
      cac_buoc: Array.from({ length: 6 }, (_, i) => buoc(`B${i}`)),
      vong_lap: { tu_buoc: 6, den_buoc: 1, noi_dung: "Quay lại" },
    });
    assert.ok(loiCuaTool(kq));
    assert.match(String(loiCuaTool(kq)), /HÀNG CUỐI/);
    assert.equal(daGui.length, 0);
  });

  it("từ chối vòng lặp cùng song_song", async () => {
    const kq = await chay(tools.createSoDoQuyTrinhTool(ctx()), {
      ...SO_DO,
      song_song: true,
      vong_lap: { tu_buoc: 3, den_buoc: 4, noi_dung: "x" },
    });
    assert.ok(loiCuaTool(kq));
    assert.equal(daGui.length, 0);
  });

  it("chạm trần số file theo giờ thì từ chối", async () => {
    const t = tools.createSoDoQuyTrinhTool(ctx());
    for (let i = 0; i < 3; i++) await chay(t, SO_DO);
    const kq = await chay(t, SO_DO);
    assert.ok(loiCuaTool(kq));
    assert.equal(daGui.length, 3);
  });
});
