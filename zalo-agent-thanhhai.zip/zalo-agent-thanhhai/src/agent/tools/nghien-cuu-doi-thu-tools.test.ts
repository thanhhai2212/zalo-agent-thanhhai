import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let tools: typeof import("./nghien-cuu-doi-thu-tools.js");
let rateLimit: typeof import("../../documents/document-rate-limit.js");
let readZip: typeof import("../../shared/read-zip-entry.js");

type DaGui = { ten: string; buf: Buffer };
let daGui: DaGui[] = [];

before(async () => {
  dataDir = setupTestEnv({ DOCUMENT_MAX_PER_HOUR: "5" });
  tools = await import("./nghien-cuu-doi-thu-tools.js");
  rateLimit = await import("../../documents/document-rate-limit.js");
  readZip = await import("../../shared/read-zip-entry.js");
});
after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  rateLimit.resetDocumentRateLimit();
});

function ctx(nguoiGui = "chu") {
  return {
    api: {
      sendMessage: async (c: { attachments: string[] }) => {
        daGui.push({ ten: path.basename(c.attachments[0]!), buf: fs.readFileSync(c.attachments[0]!) });
        return {};
      },
    },
    account: { id: "acc-dt", disabledTools: [], ownerUserId: "chu" },
    message: { threadId: "t-dt", threadType: 1, senderId: nguoiGui },
    batch: [],
  } as never;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

const BAO_CAO = {
  tieu_de: "Nghiên cứu đối thủ ngành cà phê rang xay Đà Lạt",
  san_pham: "Cà phê rang xay nguyên chất, bán online",
  thi_truong: "Toàn quốc, kênh online",
  tom_tat: ["Phần lớn đối thủ cạnh tranh bằng giá.", "Ít ai kể câu chuyện vùng trồng."],
  doi_thu: [
    {
      ten: "Cà phê A",
      website: "https://example.com/a",
      dinh_vi: "Cà phê giá rẻ, giao nhanh",
      diem_manh: ["Giá thấp", "Giao 24h"],
      diem_yeu: ["Ít thông tin nguồn gốc"],
      gia: "Từ 120.000đ/500g (đọc ngày 02/10)",
      kenh: ["Website", "Facebook"],
      thong_diep: "Rẻ mà ngon",
      do_tin_cay: "vua",
      nguon: ["https://example.com/a/gia", "https://www.facebook.com/example-a"],
    },
    {
      ten: "Cà phê B",
      dinh_vi: "Cà phê đặc sản cao cấp",
      diem_manh: ["Thương hiệu mạnh"],
      diem_yeu: ["Giá cao"],
      do_tin_cay: "thap",
      nguon: ["https://example.com/b"],
    },
  ],
  bang_so_sanh: {
    tieu_chi: ["Giá", "Kênh"],
    hang: [
      { ten: "Cà phê A", gia_tri: ["120k", "Web, FB"] },
      { ten: "Cà phê B", gia_tri: ["260k"] },
    ],
  },
  co_hoi: ["Kể chuyện vùng trồng và người nông dân"],
  de_xuat: ["Làm 4 video ngắn về hành trình hạt cà phê"],
  han_che_du_lieu: ["Không lấy được số liệu bán hàng của đối thủ B"],
};

describe("huong_dan_nghien_cuu_doi_thu", () => {
  it("có đủ các phần: hỏi trước, chỉ dữ liệu công khai, xác minh nguồn, giới hạn dữ liệu", async () => {
    const out = await chay(tools.createHuongDanNghienCuuDoiThuTool(ctx()), {});
    assert.match(out, /Hỏi trước khi làm/);
    assert.match(out, /CÔNG KHAI/);
    assert.match(out, /NGUỒN/);
    assert.match(out, /GIỚI HẠN DỮ LIỆU/);
    assert.match(out, /bao_cao_doi_thu/);
  });
});

describe("bao_cao_doi_thu", () => {
  it("gửi MỘT file .docx có đối thủ, bảng so sánh, nguồn và phần giới hạn dữ liệu", async () => {
    const out = await chay(tools.createBaoCaoDoiThuTool(ctx()), BAO_CAO);
    assert.equal(daGui.length, 1);
    assert.match(daGui[0]!.ten, /\.docx$/);
    const xml = readZip.readZipEntryText(daGui[0]!.buf, "word/document.xml");
    assert.match(xml, /Cà phê A/);
    assert.match(xml, /Bảng so sánh/);
    assert.match(xml, /example\.com\/a\/gia/);
    assert.match(xml, /Giới hạn dữ liệu/);
    assert.match(xml, /chưa rõ/); // ô thiếu trong bảng không để trống
    assert.match(String(out), /độ tin cậy thấp: Cà phê B/);
    assert.match(String(out), /KHÔNG dán lại/);
  });

  it("nhận định của AI nằm mục riêng, có câu cảnh báo cần kiểm chứng và lời nhắc cách đọc báo cáo", async () => {
    await chay(tools.createBaoCaoDoiThuTool(ctx()), {
      ...BAO_CAO,
      doi_thu: [{ ...BAO_CAO.doi_thu[0]!, nhan_dinh_ai: ["Ít tương tác với cộng đồng yêu cà phê"] }],
    });
    const chu = readZip.readZipEntryText(daGui[0]!.buf, "word/document.xml").replace(/<[^>]+>/g, "");
    assert.ok(chu.includes("Nhận định của AI (không có nguồn trực tiếp, cần kiểm chứng)"));
    assert.match(chu, /Ít tương tác với cộng đồng/);
    assert.match(chu, /Cách đọc báo cáo/);
  });

  it("chấm \"cao\" mà chỉ có MỘT tên miền nguồn thì tự hạ xuống \"vừa\" và báo lại", async () => {
    const out = await chay(tools.createBaoCaoDoiThuTool(ctx()), {
      ...BAO_CAO,
      doi_thu: [{ ...BAO_CAO.doi_thu[0]!, do_tin_cay: "cao", nguon: ["https://example.com/a", "https://example.com/b"] }],
    });
    assert.match(String(out), /tự hạ độ tin cậy từ Cao xuống Vừa.*Cà phê A/);
    const xml = readZip.readZipEntryText(daGui[0]!.buf, "word/document.xml");
    const chu = xml.replace(/<[^>]+>/g, "");
    assert.match(chu, /Độ tin cậy dữ liệu: Vừa/);
    assert.doesNotMatch(chu, /Độ tin cậy dữ liệu: Cao/);
  });

  it("hai tên miền khác nhau thì giữ nguyên \"cao\"", async () => {
    const out = await chay(tools.createBaoCaoDoiThuTool(ctx()), {
      ...BAO_CAO,
      doi_thu: [{ ...BAO_CAO.doi_thu[0]!, do_tin_cay: "cao", nguon: ["https://a.com/x", "https://www.b.com/y"] }],
    });
    assert.doesNotMatch(String(out), /tự hạ độ tin cậy/);
  });

  it("schema chịu được kiểu viết dài và bảng nhiều cột của model (không từ chối cả báo cáo vì một ô dài)", async () => {
    const dai = "x".repeat(900);
    const t = tools.createBaoCaoDoiThuTool(ctx()) as any;
    const kq = t.inputSchema.safeParse({
      ...BAO_CAO,
      doi_thu: [{ ...BAO_CAO.doi_thu[0]!, diem_manh: [dai], dinh_vi: dai }],
      bang_so_sanh: {
        tieu_chi: ["a", "b", "c", "d", "e", "f", "g", "h", "i"],
        hang: [{ ten: "A", gia_tri: [dai, "2", "3", "4", "5", "6", "7", "8", "9"] }],
      },
    });
    assert.equal(kq.success, true, JSON.stringify(kq.error?.issues ?? []));
    await chay(t, {
      ...BAO_CAO,
      bang_so_sanh: { tieu_chi: ["a", "b", "c", "d", "e", "f", "g", "h", "i"], hang: [{ ten: "A", gia_tri: ["1", "2"] }] },
    });
    assert.equal(daGui.length, 1, "bảng 9 cột phải được cắt về 7 tiêu chí, không làm hỏng file");
  });

  it("nguồn không phải địa chỉ web (chữ trơn) thì TỪ CHỐI, không tạo file", async () => {
    const out = await chay(tools.createBaoCaoDoiThuTool(ctx()), {
      ...BAO_CAO,
      doi_thu: [{ ...BAO_CAO.doi_thu[0]!, nguon: ["theo báo chí địa phương"] }],
    });
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /đừng bịa nguồn/);
    assert.equal(daGui.length, 0);
  });

  it("giao thức lạ (javascript:, file:) cũng không được coi là nguồn hợp lệ", async () => {
    const out = await chay(tools.createBaoCaoDoiThuTool(ctx()), {
      ...BAO_CAO,
      doi_thu: [{ ...BAO_CAO.doi_thu[0]!, nguon: ["file:///etc/passwd"] }],
    });
    assert.ok(loiCuaTool(out));
    assert.equal(daGui.length, 0);
  });


  it("NGƯỜI KHÁC trong nhóm (không phải chủ tài khoản) bị từ chối, không tạo/gửi gì", async () => {
    const out = await chay(tools.createBaoCaoDoiThuTool(ctx("nguoi-la") as never), BAO_CAO);
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /Chỉ chủ tài khoản/);
    assert.equal(daGui.length, 0);
    const guideOut = await chay(tools.createHuongDanNghienCuuDoiThuTool(ctx("nguoi-la")), {});
    assert.ok(loiCuaTool(guideOut), "hướng dẫn cũng chỉ dành cho chủ");
  });

  it("kênh Zalo Bot API (không có api) thì từ chối thay vì ném lỗi", async () => {
    const c = { ...(ctx() as any), api: null };
    const out = await chay(tools.createBaoCaoDoiThuTool(c as never), BAO_CAO);
    assert.ok(loiCuaTool(out));
  });
});
