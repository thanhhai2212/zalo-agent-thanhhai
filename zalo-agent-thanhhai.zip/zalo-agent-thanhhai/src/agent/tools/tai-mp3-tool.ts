import { tool } from "ai";
import { z } from "zod";

import { getTuning } from "../../config/runtime-tuning-settings.js";
import { createLogger } from "../../shared/logger.js";
import { layVideoQuaChuoi } from "../../video/chuoi-nguon-video.js";
import { xepHangTaiVideo } from "../../video/hang-doi-tai-video.js";
import { taiMp3, tenFileMp3 } from "../../video/tai-mp3.js";
import { checkTaiVideoRateLimit, hoanSuatTaiVideo } from "../../video/tai-video-rate-limit.js";
import { kiemNguonVideo, timUrlTrongChu } from "../../video/whitelist-nguon-video.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import { deliverFile } from "./deliver-generated-file.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import type { ToolContext } from "./index.js";

const log = createLogger("tai-mp3");

/**
 * Tool tải ÂM THANH (MP3) từ link YouTube/TikTok/Facebook/Instagram rồi gửi file
 * vào hội thoại. Dùng lại nguyên hạ tầng của `tai_video`: whitelist chống SSRF,
 * trần theo giờ (CHUNG với tải video - cùng là tải nội dung từ mạng về một nick
 * Zalo cá nhân), hàng đợi giới hạn số tiến trình yt-dlp, và bước ĐỌC THÔNG TIN
 * trước để từ chối bài quá dài khi chưa tải byte nào.
 *
 * Tách tool riêng thay vì thêm tham số vào `tai_video`: "tải video" và "tải
 * nhạc" là hai ý khác nhau trong câu người dùng, gộp chung dễ làm model gửi
 * nhầm video khi người ta chỉ xin file nghe.
 */

const LOI_THIEU_CONG_CU =
  "Máy chủ chưa cài đủ công cụ để tải âm thanh (thiếu yt-dlp hoặc ffmpeg). Đây là lỗi cấu hình phía " +
  "máy chủ, KHÔNG phải do link. Báo người dùng là bot đang thiếu công cụ và cần người quản trị cài đặt.";

export type PhuThuocTaiMp3Tool = {
  layVideo: typeof layVideoQuaChuoi;
  taiMp3: typeof taiMp3;
  gui: typeof deliverFile;
};
const PHU_THUOC_THAT: PhuThuocTaiMp3Tool = { layVideo: layVideoQuaChuoi, taiMp3, gui: deliverFile };

export function createTaiMp3Tool(ctx: ToolContext, phuThuoc: PhuThuocTaiMp3Tool = PHU_THUOC_THAT) {
  const threadKey = `${ctx.account.id}:${ctx.message.threadId}`;
  return tool({
    description:
      "Tải PHẦN ÂM THANH của video YouTube (hoặc TikTok, Facebook, Instagram) thành file MP3 rồi GỬI THẲNG " +
      "vào cuộc trò chuyện. Dùng khi người dùng xin file mp3/nhạc/âm thanh của một link; xin VIDEO thì dùng tai_video. " +
      "Tool tự gửi file, KHÔNG trả đường dẫn - gọi xong chỉ cần báo ngắn gọn là đã gửi.",
    inputSchema: z.object({
      url: z.string().describe("Link video người dùng gửi (YouTube, TikTok, Facebook hoặc Instagram)"),
    }),
    execute: async ({ url }) => {
      // Cửa 2 - Cửa 1 đã chặn tool khỏi schema kênh bot (nang-luc-kenh-bot.ts).
      if (!ctx.api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);

      const nguon = kiemNguonVideo(timUrlTrongChu(url) ?? url.trim());
      if (!nguon.ok) return ketQuaLoi(nguon.loi);

      const rate = checkTaiVideoRateLimit(threadKey);
      if (!rate.ok) return ketQuaLoi(rate.reason);

      // Trần đếm số file ĐÃ GỬI - mọi đường thoát không gửi được phải hoàn suất.
      let daGui = false;
      try {
        return await xepHangTaiVideo(async () => {
          const info = await phuThuoc.layVideo(nguon.url, nguon.nenTang, {
            soLanThu: getTuning("VIDEO_DOWNLOAD_SOURCE_RETRIES"),
            nghiMs: getTuning("VIDEO_DOWNLOAD_RETRY_DELAY_MS"),
          });
          if (!info.ok) {
            if (info.loiCauHinh) return ketQuaLoi(LOI_THIEU_CONG_CU);
            return ketQuaLoi(
              info.canDangNhap
                ? "Link này bắt đăng nhập mới xem được nên bot không tải được. Nói rõ với người dùng, đừng bảo thử lại."
                : info.tamThoi
                  ? "Nguồn đang chặn tạm thời. Bảo người dùng thử lại sau vài phút, KHÔNG phải do link sai."
                  : "Không lấy được nội dung link này - nhiều khả năng video riêng tư hoặc đã bị xóa. Nói thật, đừng hứa thử lại.",
            );
          }

          // Chặn bài quá dài TRƯỚC khi tải byte nào.
          const phutToiDa = getTuning("AUDIO_DOWNLOAD_MAX_DURATION_MINUTES");
          const phut = Math.ceil(info.video.durationMs / 60_000);
          if (phut > phutToiDa) {
            return ketQuaLoi(
              `Video dài khoảng ${phut} phút, vượt giới hạn tải âm thanh ${phutToiDa} phút. Nói hai con số đó ` +
                "với người dùng và cho biết mức này chỉnh được ở trang Cấu hình.",
            );
          }

          const tranByte = getTuning("VIDEO_DOWNLOAD_MAX_SIZE_MB") * 1024 * 1024;
          const ket = await phuThuoc.taiMp3(nguon.url, tranByte);
          if (!ket.ok) {
            log.warn({ url: nguon.url, loi: ket.loi }, "không tải được mp3");
            if (ket.loiCauHinh) return ketQuaLoi(LOI_THIEU_CONG_CU);
            if (ket.quaNang) {
              return ketQuaLoi(
                `File âm thanh vượt giới hạn ${getTuning("VIDEO_DOWNLOAD_MAX_SIZE_MB")}MB. Nói con số đó với người dùng.`,
              );
            }
            return ketQuaLoi("Tải âm thanh thất bại. Nói thật với người dùng là không tải được, đừng hứa gửi lại sau.");
          }

          const kq = await phuThuoc.gui(ctx, tenFileMp3(nguon.url, nguon.nenTang), ket.byte, undefined, false);
          daGui = typeof kq === "string";
          log.info({ nenTang: nguon.nenTang, phut, bytes: ket.byte.length }, "đã gửi mp3");
          return kq;
        }, getTuning("VIDEO_DOWNLOAD_MAX_CONCURRENT"));
      } catch (err) {
        log.error({ err, url: nguon.url }, "tải mp3 thất bại");
        return ketQuaLoi("Gửi file âm thanh thất bại. Nói thật với người dùng là không gửi được.");
      } finally {
        if (!daGui) hoanSuatTaiVideo(threadKey);
      }
    },
  });
}
