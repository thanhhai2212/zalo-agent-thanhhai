import { tool } from "ai";
import { z } from "zod";
import {
  documentBlockSchema,
  type DocumentBlock,
} from "../../documents/document-content-schema.js";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { checkDocumentLimits, safeFileName } from "../../documents/document-limits.js";
import { renderPdf } from "../../documents/render-pdf.js";
import { PDF_THEME_NAMES } from "../../documents/pdf-themes.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { deliverFile, guard, type DeliverCtx } from "./deliver-generated-file.js";

/**
 * Tool tạo file .pdf rồi GỬI LUÔN - in bằng Chrome đã cài trên máy.
 *
 * Dùng CHUNG `documentBlockSchema` với `create_word_document`, cố ý: cùng một
 * nội dung xuất được cả .docx lẫn .pdf mà model không phải học schema thứ hai,
 * và mọi trần kiểm sẵn có (`checkDocumentLimits`, rate limit theo giờ) áp được
 * nguyên vẹn.
 *
 * Vì sao KHÔNG nhận HTML thô như tool .html: PDF đi qua một trình duyệt THẬT,
 * nên đây là bề mặt tấn công lớn nhất trong repo. Nhận dữ liệu rồi tự dựng HTML
 * theo mẫu cố định thì không có chữ nào của model chạm tới trình duyệt dưới dạng
 * mã - đúng ràng buộc "tool chỉ nhận dữ liệu" của CLAUDE.md. Trang render cũng
 * đã TẮT JavaScript (xem `render-pdf.ts`).
 */

type Ctx = DeliverCtx;

export function createPdfFileTool(ctx: Ctx, render = renderPdf) {
  return tool({
    description:
      "Tạo file PDF (.pdf) trình bày đẹp kiểu báo cáo hiện đại rồi gửi luôn cho người dùng: tiêu đề có màu, " +
      "mục có vạch nhấn, bảng đầu màu và sọc xen kẽ, dãn dòng thoáng dễ đọc trên điện thoại. " +
      "Dùng khi người dùng xin file PDF, hoặc khi tài liệu cần GIỮ NGUYÊN bố cục lúc in và không cần sửa lại " +
      "(báo cáo, đề xuất, hướng dẫn, tài liệu gửi khách). Cần file sửa được thì dùng create_word_document. " +
      "Bôi **đậm** những cụm QUAN TRỌNG trong đoạn văn - chúng sẽ được tô nền vàng nổi bật, nên đừng bôi tràn lan. " +
      "Chia nội dung thành nhiều heading và đoạn ngắn thay vì một khối chữ dài. " +
      "Bảng dài tự chia trang và lặp lại hàng tiêu đề. Nội dung ngắn thì trả lời thẳng trong chat, đừng tạo file.",
    inputSchema: z.object({
      fileName: z.string().min(1).describe('Tên file, vd "bao-cao-thang-8.pdf"'),
      title: z.string().optional().describe("Tiêu đề lớn ở đầu tài liệu"),
      tone: z
        .enum(PDF_THEME_NAMES)
        .optional()
        .describe(
          "Tông màu hợp nội dung: navy (trang trọng, mặc định) · blue (tài chính, báo giá) · " +
            "green (tăng trưởng, nông nghiệp, môi trường) · burgundy (rủi ro, pháp lý, sự cố) · " +
            "slate (kỹ thuật, vận hành) · teal (y tế, giáo dục, dịch vụ)",
        ),
      blocks: z
        .array(documentBlockSchema)
        .min(1)
        .describe("Nội dung theo thứ tự: heading, paragraph, bullets, table, two_columns"),
      caption: z
        .string()
        .optional()
        .describe("Lời nhắn ngắn gửi kèm file, viết như người thật nói"),
    }),
    execute: async ({ fileName, title, tone, blocks, caption }) =>
      guard(async () => {
        const limit = checkDocumentLimits(blocks as DocumentBlock[]);
        if (!limit.ok) return ketQuaLoi(limit.reason);

        const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);

        const data = await render(blocks as DocumentBlock[], { title, tone });
        return deliverFile(ctx, safeFileName(fileName, "pdf"), data, caption);
      }),
  });
}
