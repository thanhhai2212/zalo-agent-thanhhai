import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let tools: typeof import("./do-luong-tools.js");
let tinh: typeof import("../../noi-dung/tinh-do-luong.js");
let rateLimit: typeof import("../../documents/document-rate-limit.js");

type DaGui = { ten: string; buf: Buffer };
let daGui: DaGui[] = [];

before(async () => {
  dataDir = setupTestEnv({ DOCUMENT_MAX_PER_HOUR: "5" });
  tools = await import("./do-luong-tools.js");
  tinh = await import("../../noi-dung/tinh-do-luong.js");
  rateLimit = await import("../../documents/document-rate-limit.js");
});
after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  rateLimit.resetDocumentRateLimit();
});

function ctx(nguoiGui = "chu") {
  return {
    api: {
      sendMessage: async (c: { attachments: string[] }) => {
        daGui.push({ ten: path.basename(c.attachments[0]!), buf: fs.readFileSync(c.attachments[0]!) });
        return {};
      },
    },
    account: { id: "acc-dl", disabledTools: [], ownerUserId: "chu" },
    message: { threadId: "t-dl", threadType: 1, senderId: nguoiGui },
    batch: [],
  } as never;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

const bai = (i: number, over: Record<string, unknown> = {}) => ({
  ngay: `0${i}/10/2026`,
  kenh: "Facebook",
  dinh_dang: "carousel",
  tru_cot: "Kiến thức",
  tieu_de: `Bài ${i}`,
  tiep_can: 1000,
  thich: 40,
  binh_luan: 5,
  chia_se: 3,
  luu: 2,
  ...over,
});
const NAM_BAI = [bai(1), bai(2, { kenh: "TikTok", dinh_dang: "video ngắn", tru_cot: "Hậu trường", tiep_can: null, luot_xem: 2000, thich: 300, binh_luan: 20, chia_se: 30, luu: 50 }), bai(3), bai(4, { tru_cot: "Bán hàng", thich: 10, binh_luan: 0, chia_se: 0, luu: 0 }), bai(5, { tru_cot: "Bán hàng", thich: 8, binh_luan: 1, chia_se: 0, luu: 1 })];
const GOC = { tieu_de: "Đo lường tuần 1", ky_do: "06/10 - 12/10/2026", nguon_so_lieu: "file Excel người dùng gửi", bai: NAM_BAI };

describe("tinhBai / tinhDoLuong", () => {
  it("tỉ lệ tương tác = tổng tương tác / số tiếp cận; thiếu tiếp cận thì dùng lượt xem", () => {
    const a = tinh.tinhBai(NAM_BAI[0] as any);
    assert.equal(a.tuongTac, 50);
    assert.equal(a.er, 50 / 1000);
    assert.equal(a.loaiNen, "tiếp cận");
    const b = tinh.tinhBai(NAM_BAI[1] as any);
    assert.equal(b.loaiNen, "lượt xem");
    assert.equal(b.er, 400 / 2000);
  });

  it("thiếu số KHÔNG bị coi là 0: không có nền hoặc không có tương tác thì er là null", () => {
    assert.equal(tinh.tinhBai({ ngay: "1", kenh: "k", dinh_dang: "d", tieu_de: "t", thich: 10 }).er, null);
    assert.equal(tinh.tinhBai({ ngay: "1", kenh: "k", dinh_dang: "d", tieu_de: "t", tiep_can: 100 }).er, null);
    assert.equal(tinh.tinhBai({ ngay: "1", kenh: "k", dinh_dang: "d", tieu_de: "t", tiep_can: 100, thich: 0 }).er, 0);
    assert.equal(tinh.tinhBai({ ngay: "1", kenh: "k", dinh_dang: "d", tieu_de: "t", click: 0, don: 3 }).chuyenDoi, null);
  });

  it("gom nhóm TÁCH THEO NỀN, không có tỉ lệ gộp; nhóm ít mẫu được đánh dấu", () => {
    const kq = tinh.tinhDoLuong(NAM_BAI as any);
    const banHang = kq.nhom.find((n) => n.loai === "Trụ cột" && n.ten === "Bán hàng")!;
    assert.equal(banHang.soBai, 2);
    assert.equal(banHang.tiepCan.er, (10 + 8 + 1 + 1) / 2000);
    assert.equal(banHang.luotXem.er, null, "nhóm không có bài tính lượt xem thì không có tỉ lệ đó");
    assert.match(banHang.doTinCay, /Mẫu ít/);
    const fb = kq.nhom.find((n) => n.loai === "Kênh" && n.ten === "Facebook")!;
    assert.equal(fb.soBai, 4);
    assert.equal(fb.tiepCan.n, 4);
    assert.match(fb.doTinCay, /Đủ mẫu/);
    assert.ok(kq.canhBao.some((c) => /TÁCH THEO NỀN/.test(c)));
  });

  it("trụ cột nhiều bài TikTok không 'thắng' chỉ vì tính trên lượt xem: hai tỉ lệ nằm riêng", () => {
    const kq = tinh.tinhDoLuong([
      bai(1, { tru_cot: "A", tiep_can: null, luot_xem: 1000, thich: 200, binh_luan: 0, chia_se: 0, luu: 0 }),
      bai(2, { tru_cot: "A", tiep_can: null, luot_xem: 1000, thich: 200, binh_luan: 0, chia_se: 0, luu: 0 }),
      bai(3, { tru_cot: "A", tiep_can: null, luot_xem: 1000, thich: 200, binh_luan: 0, chia_se: 0, luu: 0 }),
      bai(4, { tru_cot: "B", tiep_can: 1000, thich: 30, binh_luan: 0, chia_se: 0, luu: 0 }),
      bai(5, { tru_cot: "B", tiep_can: 1000, thich: 30, binh_luan: 0, chia_se: 0, luu: 0 }),
      bai(6, { tru_cot: "B", tiep_can: 1000, thich: 30, binh_luan: 0, chia_se: 0, luu: 0 }),
    ] as any);
    const a = kq.nhom.find((n) => n.loai === "Trụ cột" && n.ten === "A")!;
    const bb = kq.nhom.find((n) => n.loai === "Trụ cột" && n.ten === "B")!;
    assert.equal(a.luotXem.er, 0.2);
    assert.equal(a.tiepCan.er, null);
    assert.equal(bb.tiepCan.er, 0.03);
    assert.equal(bb.luotXem.er, null);
  });

  it("ít hơn 5 bài thì cảnh báo không rút ra quy luật; nổi bật chỉ chia đôi khi dưới 6 bài và theo từng nền", () => {
    const kq = tinh.tinhDoLuong([bai(1), bai(2)] as any);
    assert.ok(kq.canhBao.some((c) => /quá ít/.test(c)));
    assert.equal(kq.noiBat.length, 1);
    assert.equal(kq.noiBat[0]!.nen, "tiếp cận");
    assert.equal(kq.noiBat[0]!.top.length, 1);
    assert.equal(kq.noiBat[0]!.bottom.length, 1);
  });
});

describe("laDuLieuMau", () => {
  it("nhận ra từ tiêu đề [MẪU] (từ một nửa số bài) hoặc từ cờ model", async () => {
    const r = await import("../../noi-dung/render-bao-cao-do-luong.js");
    assert.equal(r.laDuLieuMau(["[MẪU] a", "[mẫu] b", "c"], false), true);
    assert.equal(r.laDuLieuMau(["[MẪU] a", "b", "c"], false), false);
    assert.equal(r.laDuLieuMau(["a"], true), true);
  });
});

describe("huong_dan_do_luong", () => {
  it("dặn bỏ trống số thiếu (không điền 0), không bịa, thận trọng khi mẫu ít", async () => {
    const out = await chay(tools.createHuongDanDoLuongTool(ctx()), {});
    assert.match(out, /BỎ TRỐNG \(null\)/);
    assert.match(out, /không điền 0/);
    assert.match(out, /dưới 5 bài/);
  });
});

describe("bao_cao_do_luong", () => {
  async function doc(buf: Buffer) {
    const ExcelJS = (await import("exceljs")).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buf as never);
    const tat = (ten: string) => {
      const ra: string[] = [];
      wb.getWorksheet(ten)!.eachRow((r) => r.eachCell((c) => ra.push(String(c.value ?? ""))));
      return ra.join("|");
    };
    return { wb, tat };
  }

  it("gửi MỘT file .xlsx 5 sheet; tỉ lệ do code tính; ô thiếu ghi 'chưa có'", async () => {
    const out = await chay(tools.createBaoCaoDoLuongTool(ctx()), {
      ...GOC,
      bai: [...NAM_BAI, bai(6, { tiep_can: null, luot_xem: null })],
      nhan_dinh_ai: ["Video TikTok có vẻ tương tác cao hơn"],
      de_xuat: ["Tăng video hậu trường ở tuần 2"],
      gioi_han: ["Bài 6 thiếu số tiếp cận"],
    });
    assert.equal(daGui.length, 1);
    const { wb, tat } = await doc(daGui[0]!.buf);
    assert.deepEqual(wb.worksheets.map((w) => w.name), ["Tổng quan", "Theo bài", "Theo nhóm", "Bài nổi bật", "Nhận định và đề xuất"]);
    assert.ok(tat("Theo bài").includes("5.0%"), "bài 1: 50/1000");
    assert.ok(tat("Theo bài").includes("chưa có"));
    assert.ok(tat("Nhận định và đề xuất").includes("Nhận định của AI (cần kiểm chứng)"));
    assert.ok(!tat("Tổng quan").includes("DỮ LIỆU MẪU"));
    assert.match(String(out), /Đã tính 6 bài/);
    assert.match(String(out), /KHÔNG dán lại/);
  });

  it("dữ liệu mẫu (tiêu đề [MẪU]) được đánh dấu ở MỌI sheet và báo cho model", async () => {
    const out = await chay(tools.createBaoCaoDoLuongTool(ctx()), {
      ...GOC,
      bai: NAM_BAI.map((b) => ({ ...b, tieu_de: `[MẪU] ${b.tieu_de}` })),
    });
    const { wb, tat } = await doc(daGui[0]!.buf);
    for (const ws of wb.worksheets) assert.ok(tat(ws.name).includes("DỮ LIỆU MẪU, KHÔNG PHẢN ÁNH THỰC TẾ"), `sheet ${ws.name} thiếu biểu ngữ mẫu`);
    assert.match(String(out), /ĐÂY LÀ DỮ LIỆU MẪU/);
  });

  it("ít bài thì cảnh báo mẫu ít được ghi vào file và trả cho model", async () => {
    const out = await chay(tools.createBaoCaoDoLuongTool(ctx()), { ...GOC, bai: [bai(1), bai(2)] });
    const { tat } = await doc(daGui[0]!.buf);
    assert.ok(tat("Tổng quan").includes("quá ít để rút ra quy luật"));
    assert.match(String(out), /CẢNH BÁO phải nói thật/);
  });

  it("schema: số âm bị chặn, số thiếu (null/bỏ trống) được nhận, quá 200 bài bị chặn", async () => {
    const t = tools.createBaoCaoDoLuongTool(ctx()) as any;
    assert.equal(t.inputSchema.safeParse({ ...GOC, bai: [bai(1, { thich: -1 })] }).success, false);
    assert.equal(t.inputSchema.safeParse({ ...GOC, bai: [bai(1, { tiep_can: null, luot_xem: undefined })] }).success, true);
    assert.equal(t.inputSchema.safeParse({ ...GOC, bai: Array.from({ length: 201 }, (_, i) => bai(i)) }).success, false);
  });


  it("NGƯỜI KHÁC trong nhóm (không phải chủ tài khoản) bị từ chối, không tạo/gửi gì", async () => {
    const out = await chay(tools.createBaoCaoDoLuongTool(ctx("nguoi-la") as never), GOC);
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /Chỉ chủ tài khoản/);
    assert.equal(daGui.length, 0);
    const guideOut = await chay(tools.createHuongDanDoLuongTool(ctx("nguoi-la")), {});
    assert.ok(loiCuaTool(guideOut), "hướng dẫn cũng chỉ dành cho chủ");
  });

  it("kênh Zalo Bot API (không có api) thì từ chối thay vì ném lỗi", async () => {
    const c = { ...(ctx() as any), api: null };
    const out = await chay(tools.createBaoCaoDoLuongTool(c as never), GOC);
    assert.ok(loiCuaTool(out));
  });
});
