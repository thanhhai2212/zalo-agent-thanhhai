import { tool } from "ai";
import { z } from "zod";
import { isImageGenConfigured } from "../../config/runtime-image-settings.js";
import { generateImage } from "../../images/image-generation-client.js";
import { canTiLe, TI_LE_ANH, type TiLeAnh } from "../../images/crop-ti-le.js";
import { checkImageRateLimit } from "../../images/image-rate-limit.js";
import { dungPromptAnh } from "../../noi-dung/dung-prompt-anh.js";
import { HUONG_DAN_ANH_BAI_DANG } from "../../noi-dung/huong-dan-anh-bai-dang.js";
import { enqueueSend } from "../../middleware/rate-limiter.js";
import { luuFileDaTao } from "../../second-brain/generated-file-store.js";
import { createLogger } from "../../shared/logger.js";
import { withNamedTempFile } from "../../shared/temp-file-store.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import { veVoiMotLanThuLai } from "./draw-image-with-one-retry.js";
import type { ToolContext } from "./index.js";
import { guiFileKemCaption } from "./send-attachment-with-caption.js";
import { ghiChuDaGuiAnh, ghiChuDaGuiChu } from "./sent-by-tool-note.js";
import { chanKhongPhaiChu } from "./owner-action-gate.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Khâu 4 của hướng "Zalo Agent business" (2026-10-02): tạo BỘ ảnh bài đăng. Phong cách thương
 * hiệu, quy tắc chữ trên ảnh và điều cấm do code chèn vào mọi ảnh (cả bộ nhất quán); ảnh được cắt
 * về đúng tỉ lệ kênh vì model bỏ qua tham số kích thước. Vẽ 2 ảnh cùng lúc, gửi từng ảnh khi xong.
 */

const log = createLogger("anh-bai-dang");
const TOI_DA_ANH = 6;
const SONG_SONG = 2;

export function createHuongDanAnhBaiDangTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Đọc quy trình tạo ảnh bài đăng (tỉ lệ theo kênh, chữ trên ảnh, nhất quán thương hiệu, trung thực ảnh AI). GỌI TRƯỚC khi vẽ bằng tao_anh_bai_dang.",
    inputSchema: z.object({}),
    execute: async () => chanKhongPhaiChu(ctx) ?? HUONG_DAN_ANH_BAI_DANG,
  });
}

const chuoi = (max = 800) => z.string().min(1).max(max);

const anhSchema = z.object({
  ten: chuoi(80).describe('Nhãn ảnh, duy nhất trong bộ, vd "06-10-facebook-cau-dat"'),
  tieu_de_bai: chuoi(200).describe("Tiêu đề bài mà ảnh này thuộc về (dùng làm lời nhắn gửi kèm)"),
  ti_le: z.enum(Object.keys(TI_LE_ANH) as [TiLeAnh, ...TiLeAnh[]]).describe("1:1, 4:5, 9:16 hoặc 16:9 theo kênh"),
  y_tuong: chuoi(1200).describe("Cảnh cụ thể: chủ thể, bối cảnh, hành động, góc máy, ánh sáng. Một ý chính mỗi ảnh"),
  chu_tren_anh: z.string().max(40).optional().describe("Chữ DUY NHẤT trên ảnh, tối đa 4-6 từ; mặc định bỏ trống = không chữ"),
});

type KetQuaAnh = { ten: string; ok: boolean; ghiChu: string };

export function createAnhBaiDangTool(ctx: ToolContext, generate = generateImage) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Vẽ một BỘ ảnh bài đăng (tối đa 6) nhất quán phong cách thương hiệu, cắt đúng tỉ lệ kênh, gửi từng ảnh vào chat. Mỗi ảnh khoảng 1-3 phút. " +
      "Đọc huong_dan_anh_bai_dang trước và hỏi phong cách/màu nếu chưa biết. Ảnh AI là ảnh minh họa: không giả làm ảnh sản phẩm hay người thật.",
    inputSchema: z.object({
      thuong_hieu: chuoi(100),
      phong_cach: chuoi(500).describe('Phong cách thị giác chung, vd "ảnh chụp thực tế, ánh sáng tự nhiên buổi sáng, ấm áp, mộc mạc"'),
      mau_sac: chuoi(200).describe('Bảng màu chủ đạo, vd "nâu cà phê, kem, xanh rêu"'),
      tranh: z.string().max(300).optional().describe("Điều cần tránh riêng của thương hiệu"),
      anh: z.array(anhSchema).min(1).max(TOI_DA_ANH),
    }),
    execute: async ({ thuong_hieu, phong_cach, mau_sac, tranh, anh }) => {
      const chan = chanKhongPhaiChu(ctx);
      if (chan) return chan;
      if (!ctx.api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);
      const api = ctx.api;
      if (!isImageGenConfigured()) {
        return ketQuaLoi("Tool vẽ ảnh chưa cấu hình (thiếu base URL, model hoặc API key). Nói thật với người dùng là chưa vẽ được.");
      }
      if (new Set(anh.map((a) => a.ten)).size !== anh.length) return ketQuaLoi("Nhãn (ten) của các ảnh bị trùng nhau, đặt lại cho duy nhất rồi gọi lại.");

      const threadKey = `${ctx.account.id}:${ctx.message.threadId}`;
      const baoTruoc = `Đang vẽ bộ ${anh.length} ảnh bài đăng, khoảng ${Math.ceil(anh.length / SONG_SONG) * 2}-${Math.ceil(anh.length / SONG_SONG) * 3} phút, mình gửi từng ảnh khi xong nhé...`;
      await enqueueSend(threadKey, () => api.sendMessage({ msg: baoTruoc }, ctx.message.threadId, ctx.message.threadType))
        .then(() => ctx.ghiNhanDaGui?.(ghiChuDaGuiChu(baoTruoc)))
        .catch(() => {});

      const pc = { thuong_hieu, phong_cach, mau_sac, tranh };
      const ketQua: KetQuaAnh[] = new Array(anh.length);
      let tiep = 0;

      async function lamMotAnh(i: number): Promise<void> {
        const a = anh[i]!;
        const rate = checkImageRateLimit(threadKey);
        if (!rate.ok) {
          ketQua[i] = { ten: a.ten, ok: false, ghiChu: "chưa vẽ vì chạm trần ảnh mỗi giờ" };
          return;
        }
        try {
          const prompt = dungPromptAnh(pc, a);
          const goc = await veVoiMotLanThuLai((p) => generate(p), { prompt }, () => {});
          let data = goc.data;
          let ext: string = goc.ext;
          let ghiChu = "";
          try {
            const cat = await canTiLe(goc.data, a.ti_le);
            if (cat.daCat) {
              data = cat.data;
              ext = cat.ext;
              ghiChu = `đã cắt về ${a.ti_le}`;
            }
          } catch (e) {
            ghiChu = `không cắt được về ${a.ti_le}, giữ ảnh gốc`;
            log.warn({ err: e }, "Cắt tỉ lệ ảnh thất bại");
          }
          const fileName = `anh-${a.ten.replace(/[^\p{L}\p{N}-]+/gu, "-").slice(0, 60)}-${Date.now()}.${ext}`;
          const loiNhan = `${a.ten} (${a.ti_le}): ${a.tieu_de_bai}`;
          await withNamedTempFile(fileName, data, (filePath) =>
            guiFileKemCaption(api, threadKey, ctx.message.threadId, ctx.message.threadType, filePath, loiNhan),
          );
          luuFileDaTao({ accountId: ctx.account.id, threadId: ctx.message.threadId, fileName, data });
          ctx.ghiNhanDaGui?.(ghiChuDaGuiAnh(1, loiNhan));
          ketQua[i] = { ten: a.ten, ok: true, ghiChu };
        } catch (err) {
          const lyDo = err instanceof Error ? err.message : String(err);
          log.warn({ err }, "Vẽ ảnh bài đăng thất bại");
          ketQua[i] = { ten: a.ten, ok: false, ghiChu: `vẽ thất bại (${lyDo.slice(0, 120)})` };
        }
      }

      await Promise.all(
        Array.from({ length: Math.min(SONG_SONG, anh.length) }, async () => {
          while (tiep < anh.length) await lamMotAnh(tiep++);
        }),
      );

      const xong = ketQua.filter((k) => k.ok);
      const loi = ketQua.filter((k) => !k.ok);
      return [
        `Đã vẽ và GỬI ${xong.length}/${anh.length} ảnh cho người dùng. KHÔNG gọi send_file để gửi lại.`,
        xong.length ? `Ảnh xong: ${xong.map((k) => k.ten + (k.ghiChu ? ` (${k.ghiChu})` : "")).join(", ")}.` : "",
        loi.length ? `Ảnh CHƯA có: ${loi.map((k) => `${k.ten} - ${k.ghiChu}`).join("; ")}. Nói thật với người dùng, đừng hứa gửi sau.` : "",
        "Bàn giao: tin ngắn nêu ảnh xong/lỗi, nhắc đây là ảnh AI minh họa (không giả làm ảnh sản phẩm/người thật), chữ dài/giá/số điện thoại nên thêm sau bằng Canva, hỏi có muốn vẽ lại hoặc chỉnh ảnh nào.",
      ]
        .filter(Boolean)
        .join("\n");
    },
  });
}
