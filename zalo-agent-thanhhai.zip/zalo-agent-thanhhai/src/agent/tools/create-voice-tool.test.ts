import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { fakeAgentProfile } from "../../shared/fake-agent-profile.js";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { ketQuaThanhCong, loiCuaTool } from "./tool-failure-result-test-helper.js";
import { agentCoTts } from "./create-voice-tool.js";
import type { AgentProfile } from "../../config/agent-store.js";
import type { ParsedMessage } from "../../zalo/zalo-message-parser.js";
import type { GeneratedVoice } from "../../voice/tts-client.js";

/**
 * create_voice: đọc TTS RIÊNG của agent (ctx.agent). Kiểm 4 nhánh + luôn
 * `ghiNhanDaGui` khi thành công. Mock `generate` + `api.sendMessage` - không
 * chạm mạng, không đụng Zalo thật.
 *
 * Gửi qua `guiFileKemCaption` (file đính kèm), KHÔNG còn qua `sendVoice` (bong
 * bóng voice native) - đổi sau khi phát hiện voice gửi cộng đồng lớn (996
 * người) bị kẹt loading vĩnh viễn ở máy người nhận, xem comment ở
 * `create-voice-tool.ts`. `guiFileKemCaption` tự ghi file tạm ra đĩa rồi gọi
 * `sendMessage({attachments:[filePath]})` - không còn `uploadAttachment`/
 * `sendVoice` riêng để mock.
 */

let dataDir: string;
let toolModule: typeof import("./create-voice-tool.js");
let database: typeof import("../../conversation/database.js");
type ToolContext = import("./tool-registry.js").ToolContext;

type Event =
  | { kind: "generate"; text: string }
  | { kind: "file"; fileName: string; buffer: Buffer; caption: string }
  | { kind: "text"; msg: string };
let events: Event[] = [];
let ghiNhan: string[] = [];
let generateError: Error | null = null;
let sendMessageError: Error | null = null;
let capturedArgs: unknown[] = [];

before(async () => {
  dataDir = setupTestEnv();
  toolModule = await import("./create-voice-tool.js");
  database = await import("../../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  events = [];
  ghiNhan = [];
  generateError = null;
  sendMessageError = null;
  capturedArgs = [];
});

const fakeGenerate = async (
  text: string,
  cfg: unknown,
  fetchImpl: unknown,
  speakers: unknown,
): Promise<GeneratedVoice> => {
  events.push({ kind: "generate", text });
  capturedArgs = [cfg, speakers];
  if (generateError) throw generateError;
  return { data: Buffer.from([1, 2, 3, 4, 5]), ext: "mp3" };
};

const message: ParsedMessage = {
  accountId: "acc-v",
  threadId: "t-v",
  threadType: 0,
  isGroup: false,
  senderId: "u1",
  senderName: "Hải",
  text: "đọc giúp",
  images: [],
  msgId: "m1",
  cliMsgId: "c1",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
};

function makeCtx(agent: AgentProfile): ToolContext {
  return {
    api: {
      sendMessage: async (content: { msg: string; attachments?: string[] }) => {
        if (sendMessageError) throw sendMessageError;
        const attachment = content.attachments?.[0];
        if (attachment) {
          events.push({
            kind: "file",
            fileName: path.basename(attachment),
            buffer: fs.readFileSync(attachment),
            caption: content.msg,
          });
        } else {
          events.push({ kind: "text", msg: content.msg });
        }
        return {};
      },
    } as never,
    account: { id: "acc-v", disabledTools: [] } as never,
    agent,
    message,
    batch: [message],
    ghiNhanDaGui: (noiDung: string) => ghiNhan.push(noiDung),
  } as ToolContext;
}

const TTS_OK = { ttsBaseUrl: "https://router.test", ttsModel: "tts-1", ttsApiKey: "sk-tts" };

/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (agent: AgentProfile, input: unknown): Promise<unknown> =>
  (toolModule.createVoiceTool(makeCtx(agent), fakeGenerate) as any).execute(input, {});

describe("agentCoTts - gate", () => {
  it("openai-compatible: thiếu base URL/model/key -> false", () => {
    assert.equal(agentCoTts(fakeAgentProfile({ ttsModel: "tts-1", ttsApiKey: "k" })), false);
    assert.equal(agentCoTts(fakeAgentProfile(TTS_OK)), true);
  });

  it("elevenlabs: cần voice_id (KHÔNG cần base URL/model) - khác hẳn openai-compatible", () => {
    assert.equal(
      agentCoTts(fakeAgentProfile({ ttsProvider: "elevenlabs", ttsApiKey: "el-key" })),
      false,
      "chưa có voice_id thì chưa đủ",
    );
    assert.equal(
      agentCoTts(fakeAgentProfile({ ttsProvider: "elevenlabs", ttsApiKey: "el-key", ttsVoice: "pNInz6obpgDQGcFmaJgB" })),
      true,
      "có voice_id + key là đủ, KHÔNG cần ttsBaseUrl/ttsModel",
    );
  });

  it("vbee: cần voiceCode + App-Id (KHÔNG cần base URL/model) - khác hẳn openai-compatible", () => {
    assert.equal(
      agentCoTts(fakeAgentProfile({ ttsProvider: "vbee", ttsApiKey: "vbee-token", ttsVoice: "hn_female_ngochuyen_full_48k-fhg" })),
      false,
      "thiếu App-Id thì chưa đủ dù có voiceCode + key",
    );
    assert.equal(
      agentCoTts(
        fakeAgentProfile({
          ttsProvider: "vbee",
          ttsApiKey: "vbee-token",
          ttsVoice: "hn_female_ngochuyen_full_48k-fhg",
          ttsVbeeAppId: "app-1",
        }),
      ),
      true,
      "có voiceCode + App-Id + key là đủ, KHÔNG cần ttsBaseUrl/ttsModel",
    );
  });

  it("google-ai-studio: cần model + key (KHÔNG cần voice, có default) - khác hẳn openai-compatible", () => {
    assert.equal(
      agentCoTts(fakeAgentProfile({ ttsProvider: "google-ai-studio", ttsApiKey: "gai-key" })),
      false,
      "thiếu model thì chưa đủ dù có key",
    );
    assert.equal(
      agentCoTts(
        fakeAgentProfile({ ttsProvider: "google-ai-studio", ttsApiKey: "gai-key", ttsModel: "gemini-2.5-flash-preview-tts" }),
      ),
      true,
      "có model + key là đủ, KHÔNG cần ttsVoice/ttsBaseUrl",
    );
  });
});

describe("create_voice - 4 nhánh", () => {
  it("agent chưa cấu hình TTS -> HỎNG có đánh dấu, không gọi generate", async () => {
    const ra = await chay(fakeAgentProfile({}), { text: "xin chào" });
    assert.match(loiCuaTool(ra), /chưa cấu hình tạo voice/i);
    assert.equal(events.length, 0);
  });

  it("TTS lỗi -> HỎNG có đánh dấu, không gửi gì lên Zalo", async () => {
    generateError = new Error("401 sai key");
    const ra = await chay(fakeAgentProfile(TTS_OK), { text: "xin chào" });
    assert.match(loiCuaTool(ra), /Tạo voice thất bại/);
    assert.ok(!events.some((e) => e.kind === "file"));
  });

  it("gửi file lên Zalo thất bại -> nhánh gửi HỎNG có đánh dấu", async () => {
    sendMessageError = new Error("socket hang up");
    const ra = await chay(fakeAgentProfile(TTS_OK), { text: "xin chào" });
    assert.match(loiCuaTool(ra), /Gửi voice lên Zalo thất bại/);
  });

  it("thành công -> gửi voice dạng FILE ĐÍNH KÈM (không phải sendVoice), chuỗi trần, có ghiNhanDaGui", async () => {
    const ra = await chay(fakeAgentProfile(TTS_OK), { text: "Xin chào mọi người" });
    const text = ketQuaThanhCong(ra);
    assert.match(text, /GỬI voice/);
    assert.deepEqual(
      events.map((e) => e.kind),
      ["generate", "file"],
    );
    const file = events.find((e) => e.kind === "file") as { fileName: string; buffer: Buffer };
    assert.match(file.fileName, /voice-.*\.mp3$/);
    assert.deepEqual(file.buffer, Buffer.from([1, 2, 3, 4, 5]));
    // BẮT BUỘC ghi vào history để bot nhớ đã gửi voice
    assert.equal(ghiNhan.length, 1);
    assert.match(ghiNhan[0]!, /đã gửi voice/);
  });

  it("có caption -> file gửi kèm đúng caption, ghi chú kèm caption", async () => {
    const ra = await chay(fakeAgentProfile(TTS_OK), { text: "nội dung", caption: "Đây là voice nhé" });
    ketQuaThanhCong(ra);
    const file = events.find((e) => e.kind === "file") as { caption: string };
    assert.equal(file.caption, "Đây là voice nhé");
    assert.match(ghiNhan[0]!, /Đây là voice nhé/);
  });
});

const GOOGLE_TTS_OK = { ttsProvider: "google-ai-studio", ttsModel: "gemini-2.5-flash-preview-tts", ttsApiKey: "gai-key" };

describe("create_voice - đổi giọng theo lượt + multi-speaker (chỉ google-ai-studio)", () => {
  it("agent KHÔNG dùng google-ai-studio + có truyền voice -> HỎNG có đánh dấu, không gọi generate", async () => {
    const ra = await chay(fakeAgentProfile(TTS_OK), { text: "xin chào", voice: "Puck" });
    assert.match(loiCuaTool(ra), /chỉ dùng được khi agent cấu hình.*Google AI Studio/i);
    assert.equal(events.length, 0);
  });

  it("agent KHÔNG dùng google-ai-studio + có truyền speakers -> HỎNG có đánh dấu, không gọi generate", async () => {
    const ra = await chay(fakeAgentProfile(TTS_OK), {
      text: "Joe: hi Jane: hi",
      speakers: [
        { speaker: "Joe", voice: "Kore" },
        { speaker: "Jane", voice: "Puck" },
      ],
    });
    assert.match(loiCuaTool(ra), /chỉ dùng được khi agent cấu hình.*Google AI Studio/i);
    assert.equal(events.length, 0);
  });

  it("agent google-ai-studio + không truyền voice/speakers -> vẫn chạy bình thường như cũ, không đổi cfg.voice", async () => {
    const ra = await chay(fakeAgentProfile({ ...GOOGLE_TTS_OK, ttsVoice: "Kore" }), { text: "xin chào" });
    ketQuaThanhCong(ra);
    const [cfg, speakers] = capturedArgs as [{ voice: string }, unknown];
    assert.equal(cfg.voice, "Kore", "giữ nguyên giọng mặc định đã cấu hình sẵn cho agent");
    assert.equal(speakers, undefined);
  });

  it("agent google-ai-studio + truyền voice -> ĐÈ lên giọng mặc định cho đúng lượt này", async () => {
    const ra = await chay(fakeAgentProfile({ ...GOOGLE_TTS_OK, ttsVoice: "Kore" }), { text: "xin chào", voice: "Puck" });
    ketQuaThanhCong(ra);
    const [cfg] = capturedArgs as [{ voice: string }];
    assert.equal(cfg.voice, "Puck", "voice truyền vào lượt này phải thắng giọng mặc định");
  });

  it("agent google-ai-studio + truyền speakers (2 người) -> chuyển thẳng xuống generate() làm multi-speaker", async () => {
    const ra = await chay(fakeAgentProfile(GOOGLE_TTS_OK), {
      text: "Joe: Hows it going today Jane? Jane: Not too bad, how about you?",
      speakers: [
        { speaker: "Joe", voice: "Kore" },
        { speaker: "Jane", voice: "Puck" },
      ],
    });
    ketQuaThanhCong(ra);
    const [, speakers] = capturedArgs as [unknown, { speaker: string; voice: string }[]];
    assert.deepEqual(speakers, [
      { speaker: "Joe", voice: "Kore" },
      { speaker: "Jane", voice: "Puck" },
    ]);
  });
});
