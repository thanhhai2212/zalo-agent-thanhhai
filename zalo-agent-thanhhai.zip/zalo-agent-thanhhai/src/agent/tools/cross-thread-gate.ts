import type { ToolContext } from "./index.js";
import { ketQuaLoi, type KetQuaLoiTool } from "./tool-failure-result.js";

/**
 * Chốt chặn cho nhóm tool ĐỌC CHÉO THREAD (list_threads, read_thread) - năng
 * lực cho phép một lượt đang chạy đọc được nội dung của THREAD KHÁC, việc mà
 * mọi tool khác trong repo này không làm.
 *
 * Đủ CẢ BA điều kiện mới cho qua:
 *
 * 1. Đã cấu hình `account.ownerUserId` trên dashboard (rỗng = FAIL-CLOSED,
 *    không đoán bừa - từng thấy hai UID khác nhau cùng trùng tên hiển thị
 *    trong DB thật, chứng minh không thể suy UID chủ từ tên hiển thị).
 * 2. Lượt đang chạy nằm trong CHAT RIÊNG, không phải nhóm. Mở ở nhóm thì bất
 *    kỳ ai trong nhóm đó cũng gõ được câu gọi tool, dù `senderId` của HỌ không
 *    khớp - chặn theo isGroup trước cả khi so sánh senderId.
 * 3. `senderId` của tin đang xử lý khớp ĐÚNG `ownerUserId`. So sánh trực tiếp,
 *    không suy diễn qua tên hiển thị hay lịch sử.
 *
 * Đặt gate ở TOOL, không phải ở allowlist toàn account: allowlist chặn cả
 * account, còn ở đây chỉ muốn khóa riêng NĂNG LỰC đọc chéo - thành viên nhóm
 * vẫn được bot phục vụ bình thường cho mọi việc khác.
 */
export function chanDocCheoThread(ctx: Pick<ToolContext, "account" | "message">): KetQuaLoiTool | null {
  if (!ctx.account.ownerUserId) {
    return ketQuaLoi(
      "Chưa cấu hình UID chủ tài khoản trên dashboard (trang Accounts) nên tool này bị khóa. Nói cho người dùng biết cần vào dashboard cấu hình trước.",
    );
  }
  if (ctx.message.isGroup) {
    return ketQuaLoi("Tool này chỉ dùng được trong chat riêng với chủ tài khoản, không dùng được trong nhóm.");
  }
  if (ctx.message.senderId !== ctx.account.ownerUserId) {
    return ketQuaLoi("Chỉ chủ tài khoản mới dùng được tool này.");
  }
  return null;
}
