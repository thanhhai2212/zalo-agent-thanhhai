import { tool } from "ai";
import { z } from "zod";
import {
  presentationSlideSchema,
  type PresentationSlide,
} from "../../documents/document-content-schema.js";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { checkPresentationLimits, safeFileName } from "../../documents/document-limits.js";
import { renderPptx } from "../../documents/render-pptx.js";
import { PDF_THEME_NAMES } from "../../documents/pdf-themes.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { deliverFile, guard, type DeliverCtx } from "./deliver-generated-file.js";

/**
 * Tool tạo file PowerPoint (.pptx) rồi GỬI LUÔN - dựng bằng `pptxgenjs`
 * (thuần JS/TS, không phụ thuộc native hay Python).
 *
 * Quyết định 2026-09-17: người dùng hỏi tích hợp repo Python "PPTMaster" (AI
 * coding-agent tool chạy trong Claude Code/Cursor, không phải library gọi
 * được) - bị đánh giá không ổn định/không an toàn vì đi ngược "100%
 * Node.js/TypeScript" và phải lồng thêm 1 tầng LLM riêng không kiểm soát được.
 * Tool này là hướng thay thế: nhận DỮ LIỆU slide qua schema, không nhận code.
 *
 * Slide chỉ có 4 loại (title/bullets/table/two_content, xem
 * `document-content-schema.ts`) - đủ cho phần lớn slide thuyết trình mà không
 * bắt model học API shape/text-box thủ công của pptxgenjs.
 */

type Ctx = DeliverCtx;

export function createPowerpointFileTool(ctx: Ctx) {
  return tool({
    description:
      "Tạo file PowerPoint (.pptx) từ danh sách slide rồi gửi luôn cho người dùng. " +
      'Slide đầu nên là type "title" (tiêu đề mở đầu, có thể kèm subtitle). "bullets" cho nội dung chính ' +
      "(tối đa 8 dòng/slide - nhiều ý hơn thì tách thêm slide, đừng nhồi chữ nhỏ). " +
      '"table" cho số liệu chi tiết. "stat_highlight" cho 1-3 con số ấn tượng cỡ lớn kèm chú thích ngắn ' +
      "(KPI, số liệu tác động - đừng nhét số to vào bullet thường, dùng loại này để số nổi bật hẳn lên). " +
      '"two_content" cho so sánh 2 vế (trước/sau, ưu/nhược, phương án A/B). "section" để tách chương/phần ' +
      "trong bài dài (chỉ 1 dòng tiêu đề ngắn, nền màu đậm) - dùng khi bài có nhiều chủ đề con rõ rệt, " +
      "không phải slide nào cũng cần. " +
      "Bôi **đậm** cụm quan trọng trong dòng bullet để nhấn. " +
      "File có đánh số trang tự động ở các slide nội dung, không cần tự ghi số trang vào chữ. " +
      "Nội dung ngắn thì trả lời thẳng trong chat, đừng tạo file.",
    inputSchema: z.object({
      fileName: z.string().min(1).describe('Tên file, vd "bao-cao-quy-3.pptx"'),
      theme: z
        .enum(PDF_THEME_NAMES)
        .optional()
        .describe(
          "Tông màu hợp nội dung: navy (trang trọng, mặc định) · blue (tài chính, báo giá) · " +
            "green (tăng trưởng, nông nghiệp, môi trường) · burgundy (rủi ro, pháp lý, sự cố) · " +
            "slate (kỹ thuật, vận hành) · teal (y tế, giáo dục, dịch vụ)",
        ),
      slides: z
        .array(presentationSlideSchema)
        .min(1)
        .describe("Danh sách slide theo đúng thứ tự sẽ xuất hiện trong file"),
      caption: z.string().optional().describe("Lời nhắn gửi kèm file"),
    }),
    execute: ({ fileName, theme, slides, caption }) =>
      guard(async () => {
        const limit = checkPresentationLimits(slides as PresentationSlide[]);
        if (!limit.ok) return ketQuaLoi(limit.reason);

        const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);

        const data = await renderPptx(slides as PresentationSlide[], { theme });
        return deliverFile(ctx, safeFileName(fileName, "pptx"), data, caption);
      }),
  });
}
