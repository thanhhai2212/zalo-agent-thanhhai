import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../../shared/test-env-setup.js";
import { loiCuaTool } from "./tool-failure-result-test-helper.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let tools: typeof import("./soan-email-tools.js");
let rateLimit: typeof import("../../documents/document-rate-limit.js");
let readZip: typeof import("../../shared/read-zip-entry.js");

type DaGui = { ten: string; buf: Buffer };
let daGui: DaGui[] = [];

before(async () => {
  dataDir = setupTestEnv({ DOCUMENT_MAX_PER_HOUR: "5" });
  tools = await import("./soan-email-tools.js");
  rateLimit = await import("../../documents/document-rate-limit.js");
  readZip = await import("../../shared/read-zip-entry.js");
});
after(async () => {
  (await import("../../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  daGui = [];
  rateLimit.resetDocumentRateLimit();
});

function ctx(batch: unknown[] = []) {
  return {
    api: {
      sendMessage: async (c: { attachments: string[] }) => {
        daGui.push({ ten: path.basename(c.attachments[0]!), buf: fs.readFileSync(c.attachments[0]!) });
        return {};
      },
    },
    account: { id: "acc-em", disabledTools: [] },
    message: { threadId: "t-em", threadType: 0 },
    batch,
  } as never;
}
/* eslint-disable @typescript-eslint/no-explicit-any */
const chay = (t: unknown, input: unknown) => (t as any).execute(input, {});

const EMAIL = {
  tieu_de: "Đề nghị phê duyệt ngân sách quý 4",
  loi_chao: "Kính gửi anh Nam,",
  mo_dau: "Em xin gửi anh đề xuất ngân sách quý 4 của phòng để anh xem xét.",
  than_bai: ["Tổng đề xuất là [số tiền], tăng so với quý 3.", "- Truyền thông: [số tiền]", "- Đào tạo: [số tiền]"],
  de_nghi: "Mong anh phản hồi trước [ngày] để em kịp hoàn tất.",
  chu_ky: ["Trân trọng,", "Lan", "Chuyên viên - Phòng Kế hoạch"],
};

describe("huong_dan_soan_email", () => {
  it("trả hướng dẫn có đủ phần hỏi lại, quy trình và bàn giao", async () => {
    const out = await chay(tools.createHuongDanSoanEmailTool(), {});
    assert.match(out, /đánh số từng câu/);
    assert.match(out, /soan_email/);
    assert.match(out, /KHÔNG tự gửi email/);
  });
});

describe("soan_email", () => {
  it("gửi MỘT file .docx có tiêu đề + nội dung, và liệt kê các ô còn trống", async () => {
    const out = await chay(tools.createSoanEmailTool(ctx()), EMAIL);
    assert.equal(daGui.length, 1);
    assert.match(daGui[0]!.ten, /\.docx$/);
    const xml = readZip.readZipEntryText(daGui[0]!.buf, "word/document.xml");
    assert.match(xml, /Đề nghị phê duyệt ngân sách quý 4/);
    assert.match(xml, /Kính gửi anh Nam/);
    assert.match(xml, /Chuyên viên - Phòng Kế hoạch/);
    assert.match(String(out), /\[số tiền\]/);
    assert.match(String(out), /\[ngày\]/);
    assert.match(String(out), /KHÔNG dán lại/);
  });

  it("không còn ô trống thì báo rõ", async () => {
    const out = await chay(tools.createSoanEmailTool(ctx()), {
      ...EMAIL,
      than_bai: ["Tổng đề xuất là 120 triệu."],
      de_nghi: "Mong anh phản hồi trước thứ Sáu.",
    });
    assert.match(String(out), /Không còn ô trống/);
  });

  it("toàn ô trống (thiếu thông tin) thì TỪ CHỐI, chưa tạo file, bảo model hỏi người dùng", async () => {
    const out = await chay(tools.createSoanEmailTool(ctx()), {
      tieu_de: "[Đề xuất] Duyệt ngân sách Quý 4/[Năm] - [Tên bộ phận]",
      loi_chao: "Kính gửi [Tên sếp],",
      mo_dau: "Em gửi [chức danh] đề xuất ngân sách [số tiền] cho [mục đích].",
      than_bai: ["Chi tiết gồm [hạng mục 1], [hạng mục 2]."],
      chu_ky: ["Trân trọng,", "[Họ tên]"],
    });
    assert.ok(loiCuaTool(out));
    assert.match(JSON.stringify(out), /MỘT tin gộp/);
    assert.equal(daGui.length, 0);
  });

  it("tiêu đề để trong ngoặc vuông thì từ chối dù ít ô trống", async () => {
    const out = await chay(tools.createSoanEmailTool(ctx()), { ...EMAIL, tieu_de: "Duyệt ngân sách [Quý]" });
    assert.ok(loiCuaTool(out));
    assert.equal(daGui.length, 0);
  });

  it("soan_mau=true KHI người dùng nói rõ muốn bản mẫu thì cho nhiều ô trống", async () => {
    await chay(tools.createSoanEmailTool(ctx([{ text: "soạn giúp mình bản mẫu email xin duyệt ngân sách để mình tự điền" }])), {
      tieu_de: "Mẫu email xin duyệt ngân sách",
      loi_chao: "Kính gửi [Tên sếp],",
      mo_dau: "Em gửi [chức danh] đề xuất ngân sách [số tiền] cho [mục đích].",
      than_bai: ["Chi tiết gồm [hạng mục 1], [hạng mục 2]."],
      chu_ky: ["Trân trọng,", "[Họ tên]"],
      soan_mau: true,
    });
    assert.equal(daGui.length, 1);
  });

  it("model TỰ đặt soan_mau=true mà người dùng không nói gì về bản mẫu thì VẪN từ chối", async () => {
    const out = await chay(tools.createSoanEmailTool(ctx([{ text: "soạn email xin sếp duyệt ngân sách quý 4" }])), {
      tieu_de: "Mẫu email xin duyệt ngân sách",
      loi_chao: "Kính gửi [Tên sếp],",
      mo_dau: "Em gửi [chức danh] đề xuất ngân sách [số tiền] cho [mục đích].",
      than_bai: ["Chi tiết gồm [hạng mục 1], [hạng mục 2]."],
      chu_ky: ["Trân trọng,", "[Họ tên]"],
      soan_mau: true,
    });
    assert.ok(loiCuaTool(out));
    assert.equal(daGui.length, 0);
  });

  it("chạm trần số file/giờ thì báo lỗi có dấu hiệu, không gửi", async () => {
    const t = tools.createSoanEmailTool(ctx());
    for (let i = 0; i < 5; i++) await chay(t, EMAIL);
    daGui = [];
    const out = await chay(t, EMAIL);
    assert.ok(loiCuaTool(out));
    assert.equal(daGui.length, 0);
  });

  it("kênh Zalo Bot API (không có api) thì từ chối thay vì ném lỗi", async () => {
    const c = { ...(ctx() as any), api: null };
    const out = await chay(tools.createSoanEmailTool(c as never), EMAIL);
    assert.ok(loiCuaTool(out));
  });
});
