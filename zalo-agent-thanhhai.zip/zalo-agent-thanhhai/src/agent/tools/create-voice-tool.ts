import { tool } from "ai";
import { luuFileDaTao } from "../../second-brain/generated-file-store.js";
import { z } from "zod";
import { GOOGLE_TTS_VOICES, generateSpeech, isTtsConfigured, type TtsConfig } from "../../voice/tts-client.js";
import type { AgentProfile } from "../../config/agent-store.js";
import { createLogger } from "../../shared/logger.js";
import { withNamedTempFile } from "../../shared/temp-file-store.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import type { ToolContext } from "./index.js";
import { ketQuaLoi } from "./tool-failure-result.js";
import { guiFileKemCaption } from "./send-attachment-with-caption.js";
import { ghiChuDaGuiVoice } from "./sent-by-tool-note.js";

const log = createLogger("create-voice");

/** Trần độ dài văn bản đọc - audio dài vừa chậm vừa nặng, và Zalo giới hạn file */
const MAX_TEXT_CHARS = 3000;

const DELIVERED_NOTE = "Đã tạo và GỬI voice cho người dùng rồi. KHÔNG gọi send_file để gửi lại.";

/**
 * Tính từ mô tả từng giọng - NGUYÊN VĂN từ doc chính thức
 * (`ai.google.dev/gemini-api/docs/speech-generation`), dịch sang tiếng Việt.
 * KHÔNG có nhãn giới tính chính thức nào cho 30 giọng này - cố tình KHÔNG bịa
 * bảng nam/nữ, để model tự suy đoán hợp lý từ chính tên gọi (đa số là tên
 * thần thoại/tên sao, có gợi ý giới tính tự nhiên qua kiến thức nền của model)
 * khi người dùng xin "giọng nam"/"giọng nữ" - xem thêm docstring `tts-client.ts`.
 */
const MO_TA_GIONG_GOOGLE =
  "30 giọng Gemini TTS (tên - phong cách): Zephyr-trong sáng, Puck-vui tươi, Charon-điềm đạm, " +
  "Kore-chắc chắn, Fenrir-sôi nổi, Leda-trẻ trung, Orus-chắc chắn, Aoede-nhẹ nhàng, " +
  "Callirrhoe-thoải mái, Autonoe-trong sáng, Enceladus-hơi thở nhẹ, Iapetus-rõ ràng, " +
  "Umbriel-thoải mái, Algieba-mượt mà, Despina-mượt mà, Erinome-rõ ràng, Algenib-khàn trầm, " +
  "Rasalgethi-điềm đạm, Laomedeia-vui tươi, Achernar-nhẹ êm, Alnilam-chắc chắn, Schedar-đều đặn, " +
  "Gacrux-chín chắn, Pulcherrima-dứt khoát, Achird-thân thiện, Zubenelgenubi-đời thường, " +
  "Vindemiatrix-dịu dàng, Sadachbia-sôi động, Sadaltager-am hiểu, Sulafat-ấm áp. " +
  "KHÔNG có nhãn nam/nữ chính thức - tự suy đoán giới tính hợp lý từ tên gọi khi cần.";

/** Cấu hình TTS riêng của agent (Pick từ AgentProfile) */
type TtsConfigCuaAgent = Pick<
  AgentProfile,
  "ttsProvider" | "ttsBaseUrl" | "ttsModel" | "ttsVoice" | "ttsFormat" | "ttsApiKey" | "ttsVbeeAppId"
>;

function ttsConfigCua(agent: TtsConfigCuaAgent): TtsConfig {
  return {
    provider: agent.ttsProvider,
    baseUrl: agent.ttsBaseUrl,
    model: agent.ttsModel,
    voice: agent.ttsVoice,
    format: agent.ttsFormat,
    apiKey: agent.ttsApiKey ?? "",
    appId: agent.ttsVbeeAppId,
  };
}

/** Agent này đã cấu hình TTS đủ để tool vào schema chưa - openai-compatible cần
 * base URL + model, elevenlabs cần voice_id, vbee cần voiceCode + App-Id; cả ba
 * đều cần key. Chỉ nhận field cần cho gate - khớp đúng phần scope mang theo
 * trong ToolScope. */
export function agentCoTts(
  agent: Pick<AgentProfile, "ttsProvider" | "ttsBaseUrl" | "ttsModel" | "ttsVoice" | "ttsApiKey" | "ttsVbeeAppId">,
): boolean {
  return isTtsConfigured({
    provider: agent.ttsProvider,
    baseUrl: agent.ttsBaseUrl,
    model: agent.ttsModel,
    voice: agent.ttsVoice,
    apiKey: agent.ttsApiKey ?? "",
    appId: agent.ttsVbeeAppId,
  });
}

/**
 * Chuyển văn bản thành giọng nói (voice) rồi gửi vào hội thoại Zalo dạng FILE
 * ĐÍNH KÈM (không phải bong bóng voice native qua `sendVoice`). TTS + giọng
 * cấu hình RIÊNG cho agent này ở trang Agents.
 *
 * Đổi từ `sendVoice` (bong bóng voice, link do Zalo host) sang file đính kèm
 * sau khi đo thật: voice gửi vào cộng đồng lớn (996 người) bị kẹt ở icon
 * loading vĩnh viễn ở máy người khác trong khi cùng nội dung gửi 1-1/nhóm nhỏ
 * nghe được bình thường - nghi do link CDN của `sendVoice` có hạn dùng ngắn,
 * không đủ thời gian đồng bộ tới hết quy mô lớn. File đính kèm dùng lại đúng
 * hạ tầng đã ổn định của `create_video`/`send_file` (`guiFileKemCaption`),
 * đánh đổi mất trải nghiệm bong bóng nghe trực tiếp để đổi lấy độ tin cậy.
 *
 * Gửi thẳng qua enqueueSend (như create_image) nên `runsInScheduledTurn:false`
 * và phải `ghiNhanDaGui` để tin voice vào history + trí nhớ của bot.
 */
export function createVoiceTool(ctx: ToolContext, generate = generateSpeech) {
  const agent = ctx.agent;
  return tool({
    description:
      "Chuyển văn bản thành giọng nói (voice) rồi gửi vào hội thoại. Dùng khi người dùng yêu cầu 'đọc', 'chuyển sang voice', 'gửi voice', 'thu âm giúp'. Giọng đọc cấu hình riêng cho agent này - tham số voice/speakers bên dưới CHỈ có tác dụng khi agent dùng nhà cung cấp Google AI Studio, agent khác thì bỏ qua và luôn dùng giọng đã cấu hình sẵn.",
    inputSchema: z.object({
      text: z
        .string()
        .min(1)
        .max(MAX_TEXT_CHARS)
        .describe(
          "Nội dung cần đọc. Khi dùng `speakers` (hội thoại nhiều người), PHẢI viết theo từng dòng 'TênNgười: câu nói', tên phải khớp CHÍNH XÁC với `speaker` trong `speakers`.",
        ),
      caption: z.string().optional().describe("Lời nhắn chữ gửi kèm (tùy chọn)"),
      voice: z
        .enum(GOOGLE_TTS_VOICES)
        .optional()
        .describe(
          `Đổi giọng CHO ĐÚNG LƯỢT NÀY (vd người dùng xin giọng nam/nữ/phong cách khác) - để trống thì dùng giọng mặc định đã cấu hình sẵn cho agent. Bỏ qua nếu có 'speakers'. ${MO_TA_GIONG_GOOGLE}`,
        ),
      speakers: z
        .array(
          z.object({
            speaker: z.string().min(1).max(50).describe("Tên nhân vật - PHẢI khớp CHÍNH XÁC tên dùng trong `text`"),
            voice: z.enum(GOOGLE_TTS_VOICES),
          }),
        )
        .length(2)
        .optional()
        .describe(
          `Dùng khi cần tạo hội thoại/podcast ĐÚNG 2 người nói (mỗi người 1 giọng riêng) - vd 'tạo podcast 2 người bàn về X', 'làm hội thoại 1 nam 1 nữ nói về Y'. Bỏ trống cho lượt đọc 1 giọng bình thường. ${MO_TA_GIONG_GOOGLE}`,
        ),
    }),
    execute: async ({ text, caption, voice, speakers }) => {
      if (!ctx.api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);
      const api = ctx.api;
      if (!agentCoTts(agent)) {
        return ketQuaLoi(
          "Agent này chưa cấu hình tạo voice (thiếu base URL, model hoặc API key TTS). Nói cho người dùng biết cần vào trang Agents, mở agent này, nhập cấu hình mục Giọng nói (TTS).",
        );
      }
      if ((voice || speakers) && agent.ttsProvider !== "google-ai-studio") {
        return ketQuaLoi(
          "Đổi giọng theo lượt và hội thoại nhiều người (speakers) chỉ dùng được khi agent cấu hình nhà cung cấp TTS là Google AI Studio. Cứ đọc bằng giọng mặc định hiện tại, hoặc nói cho người dùng biết cần đổi nhà cung cấp TTS trước.",
        );
      }

      const threadKey = `${ctx.account.id}:${ctx.message.threadId}`;
      const cfg = ttsConfigCua(agent);
      if (voice) cfg.voice = voice;

      let ket;
      try {
        ket = await generate(text, cfg, undefined, speakers);
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err);
        return ketQuaLoi(`Tạo voice thất bại (${reason}). Nói thật với người dùng, đừng hứa gửi voice sau.`);
      }

      try {
        const fileName = `voice-${Date.now()}.${ket.ext}`;
        await withNamedTempFile(fileName, ket.data, (filePath) =>
          guiFileKemCaption(api, threadKey, ctx.message.threadId, ctx.message.threadType, filePath, caption),
        );
        // Bản sao cho second brain (Notion) - trước đây chỉ file tài liệu mới được giữ.
        luuFileDaTao({ accountId: ctx.account.id, threadId: ctx.message.threadId, fileName: fileName, data: ket.data });
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err);
        return ketQuaLoi(`Gửi voice lên Zalo thất bại (${reason}). Nói thật với người dùng.`);
      }

      ctx.ghiNhanDaGui?.(ghiChuDaGuiVoice(text, caption));
      log.info(
        { accountId: ctx.account.id, threadId: ctx.message.threadId, kb: Math.round(ket.data.length / 1024), ext: ket.ext, multiSpeaker: Boolean(speakers) },
        "Đã gửi voice",
      );
      return `${DELIVERED_NOTE} (${Math.round(ket.data.length / 1024)} KB)`;
    },
  });
}
