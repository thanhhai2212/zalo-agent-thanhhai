import { tool } from "ai";
import { z } from "zod";
import { safeFileName } from "../../documents/document-limits.js";
import { checkDocumentRateLimit } from "../../documents/document-rate-limit.js";
import { HUONG_DAN_KE_HOACH_CONTENT } from "../../noi-dung/huong-dan-ke-hoach-content.js";
import { canhBaoKeHoach, kiemTraKeHoach, renderKeHoachContent } from "../../noi-dung/render-ke-hoach-content.js";
import { deliverFile, guard } from "./deliver-generated-file.js";
import type { ToolContext } from "./index.js";
import { chanKhongPhaiChu } from "./owner-action-gate.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Khâu thứ hai của hướng "Zalo Agent business" (2026-10-02): lập kế hoạch content (lịch
 * nhiều ngày, xuất Excel), nối tiếp báo cáo đối thủ. Chỉ LẬP KẾ HOẠCH - bot không đăng bài.
 * Ngày thật, thứ và tỷ trọng thực tế do code tính; công cụ từ chối khi lịch tự mâu thuẫn
 * (bài trỏ trụ cột không có, tỷ trọng không cộng ~100%, ngày ngoài khoảng).
 */

export function createHuongDanKeHoachContentTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Đọc quy trình lập kế hoạch content (hỏi gì, trụ cột, hook, storytelling, CTA). GỌI TRƯỚC khi lập kế hoạch bằng ke_hoach_content.",
    inputSchema: z.object({}),
    execute: async () => chanKhongPhaiChu(ctx) ?? HUONG_DAN_KE_HOACH_CONTENT,
  });
}

// Giới hạn RỘNG có chủ ý (bài học từ bao_cao_doi_thu): model viết dài, schema chặt làm hỏng cả kế hoạch.
const chuoi = (max = 1500) => z.string().min(1).max(max);

const truCotSchema = z.object({
  ten: chuoi(80),
  mo_ta: chuoi(600),
  ty_trong: z.number().min(0).max(100).describe("Phần trăm số bài; cộng tất cả trụ cột khoảng 100"),
});

const baiSchema = z.object({
  ngay: z.number().int().min(1).max(90).describe("Ngày thứ mấy của kế hoạch (1 = ngày đầu)"),
  kenh: chuoi(60),
  dinh_dang: chuoi(60).describe("bài viết / ảnh đơn / carousel / video ngắn / story / livestream..."),
  tru_cot: chuoi(80).describe("PHẢI trùng tên một trụ cột trong tru_cot"),
  tieu_de: chuoi(300),
  hook: chuoi(500).describe("Câu mở 1-2 dòng khiến người xem dừng lại"),
  y_chinh: chuoi(1500).describe("Dàn ý ngắn, theo storytelling hoặc PAS; video thì ghi ý từng cảnh"),
  cta: chuoi(300).describe("MỘT hành động rõ"),
});

export function createKeHoachContentTool(ctx: ToolContext) {
  return tool({
    description:
      "CHỈ CHỦ TÀI KHOẢN dùng được. Dựng kế hoạch content (lịch nhiều ngày) thành file Excel gửi thành MỘT tin riêng. Đọc huong_dan_ke_hoach_content trước và HỎI người dùng mục tiêu, kênh, tần suất nếu chưa rõ. " +
      "Chỉ lập kế hoạch, không đăng bài. Không bịa số liệu, ưu đãi, đánh giá khách, và KHÔNG tự dựng trải nghiệm cá nhân của chủ thương hiệu (kỷ niệm, lời thoại, mốc ra mắt): chỗ cần chi tiết riêng để [điền chuyện thật của bạn: ...]. Phủ đủ số ngày yêu cầu.",
    inputSchema: z.object({
      tieu_de: chuoi(200),
      muc_tieu: chuoi(500),
      khach_muc_tieu: chuoi(600),
      thong_diep_chinh: chuoi(500).describe("Một câu, khác biệt với đối thủ"),
      giong_thuong_hieu: z.string().max(400).optional(),
      so_ngay: z.number().int().min(7).max(90).describe("Độ dài kế hoạch, thường 30"),
      ngay_bat_dau: z
        .string()
        .regex(/^\d{4}-\d{2}-\d{2}$/)
        .optional()
        .describe("YYYY-MM-DD, có thì lịch hiện ngày thật và thứ"),
      tru_cot: z.array(truCotSchema).min(2).max(7),
      bai: z.array(baiSchema).min(7).max(120),
      ghi_chu: z.array(chuoi(600)).max(8).optional(),
      ten_file: z.string().max(80).optional(),
      caption: z.string().max(300).optional(),
    }),
    execute: ({ ten_file, caption, ...kh }) =>
      guard(async () => {
        const chan = chanKhongPhaiChu(ctx);
        if (chan) return chan;
                const loi = kiemTraKeHoach(kh);
        if (loi) return ketQuaLoi(`Kế hoạch chưa hợp lý: ${loi} Sửa rồi gọi lại, CHƯA tạo file.`);
        const rate = checkDocumentRateLimit(`${ctx.account.id}:${ctx.message.threadId}`);
        if (!rate.ok) return ketQuaLoi(rate.reason);
        const xlsx = await renderKeHoachContent(kh);
        const ten = safeFileName(ten_file || `ke hoach content ${kh.tieu_de}`.toLowerCase(), "xlsx");
        const gui = await deliverFile(ctx, ten, xlsx, caption);
        if (typeof gui !== "string") return gui;
        const canhBao = canhBaoKeHoach(kh);
        const banHang = kh.bai.filter((b) => /bán|ưu đãi|khuyến mãi|sale/i.test(b.tru_cot)).length;
        return [
          gui,
          `Đã dựng ${kh.bai.length} bài trong ${kh.so_ngay} ngày, ${kh.tru_cot.length} trụ cột.`,
          canhBao.length ? `CẢNH BÁO phải nói thật với người dùng trong tin bàn giao: ${canhBao.join("; ")}.` : "",
          "Nhắc người dùng: các bài kể chuyện cá nhân chỉ là khung, cần thay bằng trải nghiệm thật của họ trước khi đăng.",
          banHang / kh.bai.length > 0.3 ? "Lưu ý: bài bán hàng vượt 30%, nói với người dùng và đề xuất cân lại." : "",
          "Bàn giao: tin ngắn nêu thông điệp chính, tỷ trọng các trụ cột, 2-3 bài nổi bật, hỏi có muốn viết chi tiết bài nào hoặc lên kịch bản video từ lịch. KHÔNG dán lại cả lịch vào chat.",
        ]
          .filter(Boolean)
          .join("\n");
      }),
  });
}
