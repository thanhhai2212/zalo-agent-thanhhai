import type { ToolContext } from "./index.js";
import { ketQuaLoi, type KetQuaLoiTool } from "./tool-failure-result.js";

/**
 * Chốt chặn cho nhóm tool QUẢN TRỊ NHÓM (kick, transfer owner, duyệt thành
 * viên, đổi tên/avatar, ghim thông báo...) - khác `chanDocCheoThread`
 * (`cross-thread-gate.ts`) đúng MỘT chỗ: KHÔNG đòi chat riêng.
 *
 * Lý do tách hàm thay vì thêm cờ vào `chanDocCheoThread`: hai nhóm tool có
 * ngữ cảnh dùng khác hẳn nhau. `list_threads`/`read_thread`/`undo_message` là
 * năng lực ĐỌC/SỬA CHÉO THREAD - chủ ngồi ở DM ra lệnh cho một thread khác,
 * nên bắt buộc DM để chặn thành viên nhóm gõ trúng câu lệnh cũng kích hoạt
 * được. Còn quản trị nhóm thì việc THẬT xảy ra ngay tại nhóm đang cần xử lý -
 * chủ tài khoản đang ở trong chính nhóm đó gõ "kick thằng này" là kịch bản
 * chính, bắt DM sẽ làm tool này vô dụng cho đúng việc nó sinh ra để làm.
 *
 * Vẫn giữ đủ 2 lớp fail-closed như `chanDocCheoThread`: chưa cấu hình
 * `ownerUserId` thì khóa (không đoán), và so `senderId` trực tiếp - không suy
 * qua tên hiển thị.
 */
export function chanKhongPhaiChu(ctx: Pick<ToolContext, "account" | "message">): KetQuaLoiTool | null {
  if (!ctx.account.ownerUserId) {
    return ketQuaLoi(
      "Chưa cấu hình UID chủ tài khoản trên dashboard (trang Accounts) nên tool này bị khóa. Nói cho người dùng biết cần vào dashboard cấu hình trước.",
    );
  }
  if (ctx.message.senderId !== ctx.account.ownerUserId) {
    return ketQuaLoi("Chỉ chủ tài khoản mới dùng được tool này.");
  }
  return null;
}
