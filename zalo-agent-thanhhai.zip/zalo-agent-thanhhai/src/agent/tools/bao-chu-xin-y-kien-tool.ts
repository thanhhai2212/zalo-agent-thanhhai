import { tool } from "ai";
import { z } from "zod";
import { getThreadDisplayName } from "../../conversation/thread-store.js";
import { guiChoChuQuaZalo } from "../../zalo/send-to-owner.js";
import { LOI_TOOL_KHONG_CHAY_TREN_BOT } from "../../zalo-bot/nang-luc-kenh-bot.js";
import type { ToolContext } from "./index.js";
import { ketQuaLoi } from "./tool-failure-result.js";

/**
 * Người trong NHÓM (không phải chủ bot) hỏi chuyện nội bộ nhạy cảm hoặc đòi bot
 * quyết thay chủ: bot hoãn khéo trong nhóm và nhắn riêng xin ý kiến chủ
 * (2026-10-04, học từ `[PRIVATE_ALERT_BOSS]` của Heo-Agent).
 *
 * Model quyết định khi nào gọi (luật ở `persona-tool-rules.ts`) - danh sách từ
 * khóa cứng kiểu Heo ("tiền", "quỹ"...) báo nhầm liên tục trong nhóm đông người.
 * Tin gửi chủ trích NGUYÊN VĂN tin gốc (lấy từ `ctx.message`, không phải lời
 * model kể lại) để chủ tự đánh giá. Mỗi người trong mỗi nhóm báo tối đa một lần
 * mỗi 10 phút: tin người lạ có thể soạn để dụ bot nhắn chủ liên tục.
 */

const CHO_MS = 10 * 60_000;
const daBao = new Map<string, number>();

const trich = (s: string, max: number) => {
  const t = s.replace(/\s+/g, " ").trim();
  return t.length > max ? `${t.slice(0, max - 3)}...` : t;
};

export function noiDungXinYKien(o: { tenNhom: string; nguoi: string; tinGoc: string; lyDo: string }): string {
  return [
    `[Xin ý kiến] Nhóm "${o.tenNhom}": ${o.nguoi} hỏi chuyện cần anh/chị duyệt.`,
    `- Tin gốc: "${trich(o.tinGoc, 400)}"`,
    `- Bot nhận định: ${trich(o.lyDo, 200)}`,
    "Bot đã hoãn trong nhóm, chưa trả lời nội dung. Anh/chị trả lời ngay đây để bot biết cách xử lý.",
  ].join("\n");
}

export function createBaoChuXinYKienTool(ctx: ToolContext, now: () => number = Date.now) {
  return tool({
    description:
      "Dùng trong NHÓM khi một người (không phải chủ bot) hỏi thông tin nội bộ nhạy cảm của chủ/doanh nghiệp hoặc đòi bot quyết thay chủ. " +
      "Tool nhắn riêng cho chủ bot kèm nguyên văn tin. Sau khi gọi: hoãn lịch sự trong nhóm (đang xin ý kiến, sẽ phản hồi sau), KHÔNG tiết lộ nội dung.",
    inputSchema: z.object({
      lyDo: z.string().min(1).max(300).describe('Vì sao cần chủ duyệt, một câu ngắn (vd "hỏi doanh thu tháng 9 của cửa hàng")'),
    }),
    execute: async ({ lyDo }) => {
      if (!ctx.api) return ketQuaLoi(LOI_TOOL_KHONG_CHAY_TREN_BOT);
      const chu = ctx.account.ownerUserId;
      if (!chu) return ketQuaLoi("Chưa cấu hình UID chủ tài khoản nên không báo được. Cứ hoãn lịch sự trong nhóm.");
      if (!ctx.message.isGroup) return ketQuaLoi("Tool này chỉ dùng trong nhóm.");
      if (ctx.message.senderId === chu) return ketQuaLoi("Người đang hỏi chính là chủ bot, không cần xin ý kiến - trả lời bình thường.");

      const khoa = `${ctx.account.id}:${ctx.message.threadId}:${ctx.message.senderId}`;
      const t = now();
      const truoc = daBao.get(khoa);
      if (truoc !== undefined && t - truoc < CHO_MS) {
        return "Đã báo chủ về người này trong 10 phút qua, không báo lại. Chỉ cần hoãn lịch sự trong nhóm.";
      }
      try {
        await guiChoChuQuaZalo(ctx.api)(
          ctx.account,
          noiDungXinYKien({
            tenNhom: getThreadDisplayName(ctx.account.id, ctx.message.threadId) || ctx.message.threadId,
            nguoi: ctx.message.senderName || "Một thành viên",
            tinGoc: ctx.message.text,
            lyDo,
          }),
        );
        daBao.set(khoa, t);
        return "Đã nhắn riêng xin ý kiến chủ bot. Giờ trả lời trong nhóm 1-2 câu: đang xin ý kiến anh/chị phụ trách, sẽ phản hồi sau. KHÔNG nêu nội dung đã hỏi.";
      } catch (err) {
        return ketQuaLoi(`Không nhắn được cho chủ: ${err instanceof Error ? err.message : String(err)}. Vẫn hoãn lịch sự trong nhóm.`);
      }
    },
  });
}

/** Chỉ dùng trong test. */
export function _xoaSoXinYKien(): void {
  daBao.clear();
}
