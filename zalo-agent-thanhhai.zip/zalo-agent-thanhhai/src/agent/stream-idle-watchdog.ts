/**
 * Canh gác LUỒNG TRẢ VỀ ĐỨNG IM: không nhận thêm mẩu dữ liệu nào (chữ, suy luận,
 * tham số tool...) trong `ms` thì cắt lần gọi model đó.
 *
 * Ca thật 2026-09-25 (09:16 và 09:32, cùng một chat): hai lượt treo đủ trần
 * 15 phút mà không tool nào chạy, không lỗi nào - 9Router không ghi request vì
 * nó chưa bao giờ hoàn tất. Model đang dùng trả ~400 token/giây (lượt tạo Excel
 * 26.583 token xong trong 67 giây), nên 15 phút không phải "viết dài" mà là đứng
 * im thật. Bot chỉ có trần TỔNG của cả lượt, không có cách nhận ra đứng im - người
 * nhắn phải chờ đủ 15 phút mới nhận câu báo lỗi. 9Router có canh gác riêng nhưng
 * rộng (200 giây chờ chữ đầu, 6 phút đứng im) và chỉ đo byte phía trên của nó.
 *
 * Viết dài hợp lệ (tạo file lớn) KHÔNG bị cắt nhầm: dữ liệu vẫn đổ về liên tục,
 * mỗi mẩu gia hạn lại đồng hồ.
 */

export class LoiLuongDungIm extends Error {
  constructor(ms: number) {
    // Chữ "stalled" để `laDutKetNoi()` nhận ra và cho thử lại 1 lần.
    super(`stream stalled: không nhận dữ liệu nào từ model trong ${Math.round(ms / 1000)} giây`);
    this.name = "LoiLuongDungIm";
  }
}

export type CanhGac = {
  /** Gọi mỗi khi nhận mẩu dữ liệu mới từ model (truyền vào `onChunk`). */
  nhip: () => void;
  /** Tool bắt đầu chạy: TẠM DỪNG canh gác - lúc tool chạy (vẽ ảnh tới 10 phút,
   *  tải video...) model không gửi gì về, đó không phải đứng im. */
  batDauTool: () => void;
  /** Tool xong: hết tool nào đang chạy thì canh lại từ đầu. */
  xongTool: () => void;
};

/**
 * Chạy `chay` với một tín hiệu hủy tự kích khi đứng im quá `ms`. Đứng im thì
 * ném `LoiLuongDungIm` thay cho lỗi hủy chung chung của SDK; bị caller hủy
 * (`ngoai`) thì để nguyên lỗi gốc.
 */
export async function voiCanhGacDungIm<T>(
  ms: number,
  ngoai: AbortSignal | undefined,
  chay: (signal: AbortSignal, canh: CanhGac) => Promise<T>,
): Promise<T> {
  const dk = new AbortController();
  let hen: ReturnType<typeof setTimeout> | undefined;
  let daCat = false;
  let soToolDangChay = 0;
  const huyHen = () => {
    if (hen) clearTimeout(hen);
    hen = undefined;
  };
  const nhip = () => {
    huyHen();
    if (soToolDangChay > 0) return;
    hen = setTimeout(() => {
      daCat = true;
      dk.abort(new LoiLuongDungIm(ms));
    }, ms);
  };
  const canh: CanhGac = {
    nhip,
    batDauTool: () => {
      soToolDangChay++;
      huyHen();
    },
    xongTool: () => {
      soToolDangChay = Math.max(0, soToolDangChay - 1);
      nhip();
    },
  };
  nhip();
  const signal = ngoai ? AbortSignal.any([ngoai, dk.signal]) : dk.signal;
  try {
    return await chay(signal, canh);
  } catch (e) {
    if (daCat && !ngoai?.aborted) throw new LoiLuongDungIm(ms);
    throw e;
  } finally {
    huyHen();
  }
}
