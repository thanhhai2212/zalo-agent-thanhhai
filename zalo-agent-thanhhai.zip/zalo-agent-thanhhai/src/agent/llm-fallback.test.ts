import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { APICallError } from "ai";
import { MockLanguageModelV4 } from "ai/test";
import { ThreadType, type API } from "zca-js";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";
import { thanhKetQuaStream } from "./streaming-model-test-helper.js";
import type { AccountConfig } from "../config/account-store.js";
import type { ParsedMessage } from "../zalo/zalo-message-parser.js";
import { chuoiModelCuaLuot, datLaiModelNghiChoTest, ghiModelHong, nenDoiModel, viTriBatDau } from "./llm-fallback.js";

/** Mọi module chạm env/DB vào qua `await import()` SAU setupTestEnv - xem CLAUDE.md "Bẫy khi viết test". */

let dataDir: string;
let loop: typeof import("./agent-loop.js");
let llm: typeof import("../config/runtime-llm-settings.js");

before(async () => {
  dataDir = setupTestEnv();
  loop = await import("./agent-loop.js");
  llm = await import("../config/runtime-llm-settings.js");
});
after(async () => {
  (await import("../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => datLaiModelNghiChoTest());

describe("chuỗi model dự phòng (thuần)", () => {
  it("model chính đứng đầu, bỏ trùng; model hết lượt nghỉ 10 phút, lỗi thoáng qua thì không", () => {
    const chuoi = chuoiModelCuaLuot("ag/gemini", ["ag/claude", " ag/gemini ", "", "ag/gpt"]);
    assert.deepEqual(chuoi, ["ag/gemini", "ag/claude", "ag/gpt"]);
    assert.equal(viTriBatDau(chuoi, 0), 0);

    ghiModelHong("ag/gemini", "transient", 0);
    assert.equal(viTriBatDau(chuoi, 0), 0);
    ghiModelHong("ag/gemini", "rate_limit", 0);
    assert.equal(viTriBatDau(chuoi, 60_000), 1);
    assert.equal(viTriBatDau(chuoi, 11 * 60_000), 0);

    ghiModelHong("ag/claude", "auth", 0);
    ghiModelHong("ag/gpt", "auth", 0);
    assert.equal(viTriBatDau(chuoi, 60_000), 0, "mọi model đều nghỉ thì về model chính");

    assert.equal(nenDoiModel("cau_hinh"), false);
    assert.equal(nenDoiModel("context_overflow"), false);
    assert.equal(nenDoiModel("rate_limit"), true);
  });

  it("lưu cấu hình: mỗi dòng một model, bỏ trống/trùng, mảng rỗng là xóa", () => {
    llm.updateLlmSettings({ fallbackModels: ["ag/claude-sonnet-4-6", "  ", "ag/claude-sonnet-4-6", "ag/gpt"] });
    assert.deepEqual(llm.getEffectiveLlmSettings().fallbackModels, ["ag/claude-sonnet-4-6", "ag/gpt"]);
    llm.updateLlmSettings({ model: "x" });
    assert.deepEqual(llm.getEffectiveLlmSettings().fallbackModels, ["ag/claude-sonnet-4-6", "ag/gpt"], "không gửi thì giữ nguyên");
    llm.updateLlmSettings({ fallbackModels: [] });
    assert.deepEqual(llm.getEffectiveLlmSettings().fallbackModels, []);
  });
});

const account: AccountConfig = {
  id: "acc-fb",
  label: "Test",
  enabled: true,
  agentId: "khong-co-agent-nay",
  allowlist: { mode: "all", userIds: [] },
  groupRequireMention: true,
  respondToGroups: true,
  groupPassiveListen: true,
  autoReactEnabled: false,
  autoReactIcon: "heart",
  typingIndicatorEnabled: false,
  disabledTools: [],
  ownerUserId: "",
  loai: "ca_nhan" as const,
  coBotToken: false,
  autoKickFloodEnabled: false,
};

const tin = (): ParsedMessage => ({
  accountId: account.id,
  threadId: "t-fb",
  threadType: ThreadType.User,
  isGroup: false,
  senderId: "u1",
  senderName: "Hải",
  text: "chào",
  images: [],
  msgId: "m1",
  cliMsgId: "c1",
  isSelf: false,
  mentionsMe: false,
  rawData: {},
});

const usage = { inputTokens: { total: 50, noCache: 50, cacheRead: 0, cacheWrite: 0 }, outputTokens: { total: 5, text: 5, reasoning: 0 } };
const loi403 = () =>
  new APICallError({ message: "Forbidden", url: "http://router/v1", requestBodyValues: {}, statusCode: 403, responseBody: "Forbidden" });

/** Model chính luôn 403; model dự phòng trả lời. Đếm lần gọi theo tên model. */
async function chay(): Promise<{ text: string; goi: string[] }> {
  const goi: string[] = [];
  const dung = (ten: string, hong: boolean) =>
    new MockLanguageModelV4({
      doStream: async () => {
        goi.push(ten);
        if (hong) throw loi403();
        return thanhKetQuaStream({ content: [{ type: "text", text: `trả lời từ ${ten}` }], finishReason: "stop", usage, warnings: [] });
      },
    });
  const ket = await loop.runAgentTurn({
    api: {} as API,
    account,
    batch: [tin()],
    trace: [],
    resolveModel: (_agent, _thread, modelThay) => dung(modelThay ?? "chinh", !modelThay),
  });
  return { text: ket.text, goi };
}

describe("runAgentTurn - model dự phòng", () => {
  it("model chính bị từ chối thì chạy lại bằng model dự phòng; lượt sau đi thẳng model dự phòng", async () => {
    llm.updateLlmSettings({ provider: "openai-compatible", baseUrl: "http://router/v1", model: "chinh", apiKey: "k", fallbackModels: ["ag/claude-sonnet-4-6"] });
    const a = await chay();
    assert.deepEqual(a.goi, ["chinh", "ag/claude-sonnet-4-6"]);
    assert.match(a.text, /ag\/claude-sonnet-4-6/);

    const b = await chay();
    assert.deepEqual(b.goi, ["ag/claude-sonnet-4-6"], "model chính đang nghỉ 10 phút");
  });

  it("cuộc chat có model riêng: chạy model đó trước, lỗi thì về model của agent; chat khác không đổi", async () => {
    datLaiModelNghiChoTest();
    llm.updateLlmSettings({ provider: "openai-compatible", baseUrl: "http://router/v1", model: "chinh", apiKey: "k", fallbackModels: [] });
    const { recordThreadActivity, setThreadPermissions } = await import("../conversation/thread-store.js");
    recordThreadActivity({ accountId: account.id, threadId: "t-fb", threadType: 0, displayName: "Chủ bot", lastSenderName: "Hải" });
    setThreadPermissions({ accountId: account.id, threadId: "t-fb", botEnabled: true, mentionOverride: null, disabledTools: [], privacyTier: "normal", modelOverride: "ag/claude-sonnet-4-6" });

    const goi: string[] = [];
    const chayVoi = (hong: string[]) =>
      loop.runAgentTurn({
        api: {} as API,
        account,
        batch: [tin()],
        trace: [],
        resolveModel: (_a, _t, modelThay) =>
          new MockLanguageModelV4({
            doStream: async () => {
              const ten = modelThay ?? "chinh";
              goi.push(ten);
              if (hong.includes(ten)) throw loi403();
              return thanhKetQuaStream({ content: [{ type: "text", text: `từ ${ten}` }], finishReason: "stop", usage, warnings: [] });
            },
          }),
      });
    assert.match((await chayVoi([])).text, /ag\/claude-sonnet-4-6/);
    assert.deepEqual(goi, ["ag/claude-sonnet-4-6"]);
    goi.length = 0;
    datLaiModelNghiChoTest();
    assert.match((await chayVoi(["ag/claude-sonnet-4-6"])).text, /từ chinh/, "Claude lỗi thì về model của agent");
    assert.deepEqual(goi, ["ag/claude-sonnet-4-6", "chinh"]);
    setThreadPermissions({ accountId: account.id, threadId: "t-fb", botEnabled: true, mentionOverride: null, disabledTools: [], privacyTier: "normal", modelOverride: null });
  });

  it("không cấu hình model dự phòng thì giữ hành vi cũ: 403 dừng ngay", async () => {
    llm.updateLlmSettings({ fallbackModels: [] });
    await assert.rejects(chay());
  });
});
