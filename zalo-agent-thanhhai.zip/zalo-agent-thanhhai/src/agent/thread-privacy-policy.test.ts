import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { applyThreadPrivacyPolicy } from "./thread-privacy-policy.js";

const memory = {
  facts: [{ subjectId: "u-1", content: "thông tin riêng" }],
  threadSummary: "tóm tắt cuộc trò chuyện của chính thread",
};

describe("applyThreadPrivacyPolicy", () => {
  it("normal giữ nguyên memory và không tạo object mới", () => {
    assert.equal(applyThreadPrivacyPolicy(memory, "normal"), memory);
  });

  it("restricted chặn fact bền nhưng giữ summary của chính thread", () => {
    const result = applyThreadPrivacyPolicy(memory, "restricted");
    assert.deepEqual(result.facts, []);
    assert.equal(result.threadSummary, memory.threadSummary);
    assert.equal(result.restricted, true);
  });

  it("restricted không sửa object đầu vào", () => {
    applyThreadPrivacyPolicy(memory, "restricted");
    assert.equal(memory.facts.length, 1);
    assert.equal("restricted" in memory, false);
  });
});
