import type { LoaiLoiProvider } from "./provider-error-classifier.js";

/**
 * Model dự phòng cho lượt agent (2026-09-27): Gemini trên Antigravity gần cạn
 * lượt tuần trong khi Claude cùng tài khoản còn nguyên, chủ bot muốn tận dụng.
 *
 * Chạy trong CÙNG nhà cung cấp/base URL/khóa của cấu hình chung, chỉ đổi tên
 * model - nên chỉ áp cho agent KHÔNG có khóa riêng.
 *
 * Model hỏng vì hết lượt/bị chặn (429, 401/403) được "cho nghỉ" 10 phút trong
 * bộ nhớ: lượt sau đi thẳng model dự phòng thay vì mỗi tin lại tốn một request
 * hỏng. Lỗi thoáng qua (5xx, mạng) chỉ đổi model cho đúng lượt đó.
 */

const NGHI_MS = 10 * 60_000;
const nghiDen = new Map<string, number>();

/** [model chính, ...dự phòng], bỏ trùng, giữ thứ tự */
export function chuoiModelCuaLuot(chinh: string, duPhong: string[]): string[] {
  return [...new Set([chinh, ...duPhong].map((m) => m.trim()).filter(Boolean))];
}

/** Vị trí model đầu tiên không đang nghỉ; mọi model đều nghỉ thì về model chính */
export function viTriBatDau(chuoi: string[], now: number): number {
  const i = chuoi.findIndex((m) => (nghiDen.get(m) ?? 0) <= now);
  return i < 0 ? 0 : i;
}

/**
 * Có nên đổi sang model kế tiếp không. Không đổi khi: chưa cấu hình (model nào
 * cũng hỏng y hệt), ngữ cảnh tràn (đã có nhánh cắt bớt riêng).
 */
export function nenDoiModel(loai: LoaiLoiProvider): boolean {
  return loai !== "cau_hinh" && loai !== "context_overflow";
}

export function ghiModelHong(model: string, loai: LoaiLoiProvider, now: number): void {
  if (loai === "rate_limit" || loai === "auth") nghiDen.set(model, now + NGHI_MS);
}

/** Chỉ cho test */
export function datLaiModelNghiChoTest(): void {
  nghiDen.clear();
}
