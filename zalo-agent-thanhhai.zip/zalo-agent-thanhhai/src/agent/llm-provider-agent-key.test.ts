import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

/**
 * `taiCauHinhRieng` (llm-provider.ts): agent có `modelApiKey` RIÊNG thì được
 * phép chạy hẳn provider khác cấu hình chung - khác `doiProviderAnToan`
 * (llm-provider-safety.test.ts), vốn CHẶN đúng ca này khi chưa có khóa riêng.
 * Hai bộ test phải cùng tồn tại: bộ này chứng minh nhánh mới hoạt động, bộ kia
 * chứng minh rào chắn cũ KHÔNG bị phá khi agent chưa cấu hình gì ở đây.
 */

let dataDir: string;
let provider: typeof import("./llm-provider.js");

before(async () => {
  dataDir = setupTestEnv();
  provider = await import("./llm-provider.js");
});

after(async () => {
  const { closeDatabase } = await import("../conversation/database.js");
  closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("modelHieuLuc - agent có modelApiKey riêng", () => {
  it("provider khác cấu hình chung + có key riêng -> ĐỔI thật (khác doiProviderAnToan suông)", () => {
    // test-env-setup.ts đặt LLM_PROVIDER mặc định là "anthropic" - agent khai
    // "openai-compatible" (KHÁC hẳn) mà VẪN qua được vì có modelApiKey riêng
    const r = provider.modelHieuLuc({
      modelProvider: "openai-compatible",
      modelName: "gpt-combo",
      modelApiKey: "sk-router-rieng",
    });
    assert.deepEqual(r, { provider: "openai-compatible", model: "gpt-combo" });
  });

  it("có modelApiKey nhưng THIẾU modelProvider hoặc modelName -> không đủ để tự chạy riêng, rơi về doiProviderAnToan", () => {
    const r = provider.modelHieuLuc({ modelApiKey: "sk-ant-rieng", modelName: "claude-opus-5" });
    // Không có modelProvider -> taiCauHinhRieng trả null -> đi doiProviderAnToan,
    // mà modelProvider rỗng thì không kích hoạt chốt chặn, model vẫn qua được
    assert.equal(r.model, "claude-opus-5");
  });

  it("KHÔNG có modelApiKey thì hành vi y hệt trước đây - vẫn bị doiProviderAnToan chặn", () => {
    // test-env-setup.ts đặt LLM_PROVIDER mặc định là "anthropic" - khai
    // "openai-compatible" (KHÁC) mà không có key riêng phải bị chặn, rơi về "anthropic"
    const r = provider.modelHieuLuc({ modelProvider: "openai-compatible", modelName: "gpt-x" });
    assert.equal(r.provider, "anthropic");
  });
});

describe("resolveLanguageModel - agent có modelApiKey riêng không ném lỗi", () => {
  it("dựng được LanguageModel cho provider riêng của agent, không đụng cấu hình chung", () => {
    assert.doesNotThrow(() =>
      provider.resolveLanguageModel({
        modelProvider: "anthropic",
        modelName: "claude-opus-5",
        modelApiKey: "sk-ant-rieng",
      }),
    );
  });
});
