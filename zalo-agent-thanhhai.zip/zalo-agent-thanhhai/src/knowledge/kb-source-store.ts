/**
 * CRUD nguồn của Kho tri thức + trạng thái xử lý. Lược đồ ở `kb-schema.ts`.
 *
 * Adapt `trongGiaoDich`
 * sang chữ ký 1 tham số của local (`conversation/database.ts`).
 */

import { randomBytes } from "node:crypto";
import { db, trongGiaoDich } from "../conversation/database.js";

export type TrangThaiNguon = "cho_xu_ly" | "dang_xu_ly" | "san_sang" | "hong";
export type LoaiNguon = "file" | "text";

export type KbSource = {
  id: string;
  ten: string;
  loai: LoaiNguon;
  dinhDang: string;
  duongDan: string;
  noiDungGoc: string;
  trangThai: TrangThaiNguon;
  loi: string;
  soDoan: number;
  soByte: number;
  /** Số lần đã GIÀNH để xử lý (tăng ngay lúc giành, xem giaNguonChoXuLy) - trần chặn nguồn làm worker treo/chết lặp lại vô hạn */
  soLanThu: number;
  /** Hướng dẫn nạp theo nhu cầu: tool `nap_huong_dan` liệt kê tên + `moTa`, model cần mới đọc toàn văn */
  laHuongDan: boolean;
  moTa: string;
  /** Bộ kỹ năng (thư mục trên trang Kỹ năng); rỗng = kỹ năng lẻ */
  boKyNang: string;
  createdAt: string;
  updatedAt: string;
};

export type KbSourceRow = {
  id: string;
  ten: string;
  loai: LoaiNguon;
  dinh_dang: string;
  duong_dan: string;
  noi_dung_goc: string;
  trang_thai: TrangThaiNguon;
  loi: string;
  so_doan: number;
  so_byte: number;
  so_lan_thu: number;
  la_huong_dan: number;
  mo_ta: string;
  bo_ky_nang: string;
  created_at: string;
  updated_at: string;
};

/** Export để `kb-source-queries.ts` dùng lại - một nguồn ánh xạ row->domain, không lặp lại ở nơi khác */
export function mapRow(row: KbSourceRow): KbSource {
  return {
    id: row.id,
    ten: row.ten,
    loai: row.loai,
    dinhDang: row.dinh_dang,
    duongDan: row.duong_dan,
    noiDungGoc: row.noi_dung_goc,
    trangThai: row.trang_thai,
    loi: row.loi,
    soDoan: row.so_doan,
    soByte: row.so_byte,
    soLanThu: row.so_lan_thu,
    laHuongDan: row.la_huong_dan === 1,
    moTa: row.mo_ta,
    boKyNang: row.bo_ky_nang,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

const insertStmt = db.prepare(`
  INSERT INTO kb_sources (id, ten, loai, dinh_dang, duong_dan, noi_dung_goc, so_byte, la_huong_dan, mo_ta, bo_ky_nang)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);

export function taoNguon(p: {
  ten: string;
  loai: LoaiNguon;
  dinhDang?: string;
  duongDan?: string;
  noiDungGoc?: string;
  soByte?: number;
  laHuongDan?: boolean;
  moTa?: string;
  boKyNang?: string;
}): KbSource {
  const id = randomBytes(8).toString("hex");
  insertStmt.run(id, p.ten, p.loai, p.dinhDang ?? "", p.duongDan ?? "", p.noiDungGoc ?? "", p.soByte ?? 0, p.laHuongDan ? 1 : 0, p.moTa ?? "", p.boKyNang ?? "");
  // Vừa tự ghi xong với id vừa sinh nên đọc lại không thể miss - không kiểm null.
  return layNguon(id)!;
}

const datHuongDanStmt = db.prepare(`
  UPDATE kb_sources SET la_huong_dan = ?, mo_ta = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?
`);

const suaNguonStmt = db.prepare(`
  UPDATE kb_sources
     SET ten = ?, noi_dung_goc = ?, so_byte = ?, trang_thai = 'cho_xu_ly', loi = '', so_lan_thu = 0,
         updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
   WHERE id = ?
`);

/**
 * Sửa tên + toàn văn (chủ bot sửa tay trên dashboard, 2026-10-09) rồi đưa về
 * `cho_xu_ly` với budget thử mới để worker cắt đoạn lại - đoạn cũ bị
 * `luuDoan` xóa sạch lúc ghi đoạn mới. Nguồn file .md/.txt: caller đã ghi
 * đè file, `noiDungGoc` truyền "" như cũ. Trả false nếu không có nguồn.
 */
export function suaNguon(id: string, p: { ten: string; noiDungGoc: string; soByte: number }): boolean {
  return suaNguonStmt.run(p.ten, p.noiDungGoc, p.soByte, id).changes > 0;
}

const datBoStmt = db.prepare(`UPDATE kb_sources SET bo_ky_nang = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?`);
/** Xếp một kỹ năng vào bộ (thư mục). Trả false nếu không có nguồn. */
export function datBoKyNang(id: string, bo: string): boolean {
  return datBoStmt.run(bo.trim(), id).changes > 0;
}

const doiTenBoStmt = db.prepare(`UPDATE kb_sources SET bo_ky_nang = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE la_huong_dan = 1 AND bo_ky_nang = ?`);
/** Đổi tên cả bộ (gộp vào bộ khác nếu tên mới đã có). Trả số kỹ năng bị đổi. */
export function doiTenBoKyNang(tu: string, sang: string): number {
  return Number(doiTenBoStmt.run(sang.trim(), tu).changes);
}

const idTrongBoStmt = db.prepare(`SELECT id FROM kb_sources WHERE la_huong_dan = 1 AND bo_ky_nang = ?`);
export function idKyNangTrongBo(bo: string): string[] {
  return (idTrongBoStmt.all(bo) as { id: string }[]).map((r) => r.id);
}

/** Đánh dấu/bỏ đánh dấu nguồn là hướng dẫn nạp theo nhu cầu, kèm mô tả một dòng. Trả false nếu không có nguồn. */
export function datHuongDan(id: string, laHuongDan: boolean, moTa: string): boolean {
  return datHuongDanStmt.run(laHuongDan ? 1 : 0, moTa, id).changes > 0;
}

const getStmt = db.prepare(`SELECT * FROM kb_sources WHERE id = ?`);

export function layNguon(id: string): KbSource | null {
  const row = getStmt.get(id) as KbSourceRow | undefined;
  return row ? mapRow(row) : null;
}

const listStmt = db.prepare(`SELECT * FROM kb_sources ORDER BY created_at DESC`);

export function danhSachNguon(): KbSource[] {
  const rows = listStmt.all() as unknown as KbSourceRow[];
  return rows.map(mapRow);
}

const setTrangThaiStmt = db.prepare(`
  UPDATE kb_sources
     SET trang_thai = ?, loi = ?, so_doan = ?, so_lan_thu = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
   WHERE id = ?
`);

/**
 * ĐÚNG ba cột `datTrangThai` cần đọc lại để giữ nguyên giá trị cũ - KHÔNG dùng
 * `layNguon` (`SELECT *`, kéo theo cả `noi_dung_goc`).
 *
 * Đường này chạy dày: `goNguonKetDauTick()` gọi `datTrangThai` cho MỌI nguồn
 * đang kẹt, MỖI TICK 5 giây. Với nguồn gõ tay dài (trần tới `KB_MAX_FILE_MB`,
 * tức hàng chục MB) thì `SELECT *` nghĩa là kéo trọn toàn văn vào RAM chỉ để
 * đọc ba con số rồi vứt.
 */
const getPhanTrangThaiStmt = db.prepare(`SELECT loi, so_doan, so_lan_thu FROM kb_sources WHERE id = ?`);

type PhanTrangThaiRow = Pick<KbSourceRow, "loi" | "so_doan" | "so_lan_thu">;

/**
 * `loi`/`soDoan`/`soLanThu` bỏ trống thì GIỮ NGUYÊN giá trị cũ (đọc lại rồi
 * ghi đè, không phải reset về mặc định) - đổi trạng thái 'dang_xu_ly' ->
 * 'san_sang' không kèm soDoan mới thì không có lý do gì để đè số đoạn hiện có
 * về 0.
 *
 * `soLanThu` KHÔNG tự reset theo `trangThai` - caller phải truyền TƯỜNG MINH
 * khi muốn cấp lại một budget mới (nguồn vừa xử lý XONG, hoặc người vận hành
 * bấm "Xử lý lại" trên dashboard). Nếu tự động reset theo trạng thái đích thì
 * `goNguonKetDauTick()` (đưa `dang_xu_ly` -> `cho_xu_ly` để THỬ LẠI) sẽ vô
 * tình xoá mất chính bộ đếm nó cần đọc để quyết định thử tiếp hay bỏ hẳn.
 */
export function datTrangThai(
  id: string,
  trangThai: TrangThaiNguon,
  p?: { loi?: string; soDoan?: number; soLanThu?: number },
): void {
  const canDoc = p?.loi === undefined || p?.soDoan === undefined || p?.soLanThu === undefined;
  const hienTai = canDoc ? (getPhanTrangThaiStmt.get(id) as PhanTrangThaiRow | undefined) : undefined;
  const loi = p?.loi ?? hienTai?.loi ?? "";
  const soDoan = p?.soDoan ?? hienTai?.so_doan ?? 0;
  const soLanThu = p?.soLanThu ?? hienTai?.so_lan_thu ?? 0;
  setTrangThaiStmt.run(trangThai, loi, soDoan, soLanThu, id);
}

// ===== Xóa sạch: bất biến quan trọng nhất của Kho tri thức =====
//
// Không có FOREIGN KEY (xem `kb-schema.ts`), nên phải tự dọn CẢ BỐN nơi trong
// MỘT giao dịch: `kb_sources`, `kb_chunks`, `kb_chunks_fts`, `agent_kb_sources`.
// Xóa hàng FTS TRƯỚC khi xóa `kb_chunks` - subquery tra rowid cần bảng
// `kb_chunks` còn nguyên để biết đoạn nào thuộc nguồn đang xóa.

const demDoanCuaNguonStmt = db.prepare(`SELECT COUNT(*) AS n FROM kb_chunks WHERE source_id = ?`);
const xoaFtsCuaNguonStmt = db.prepare(
  `DELETE FROM kb_chunks_fts WHERE rowid IN (SELECT id FROM kb_chunks WHERE source_id = ?)`,
);
const xoaDoanCuaNguonStmt = db.prepare(`DELETE FROM kb_chunks WHERE source_id = ?`);
const xoaGanAgentCuaNguonStmt = db.prepare(`DELETE FROM agent_kb_sources WHERE source_id = ?`);
const xoaNguonStmt = db.prepare(`DELETE FROM kb_sources WHERE id = ?`);

export function xoaNguon(id: string): { soDoanDaXoa: number } {
  return trongGiaoDich(() => {
    const soDoanDaXoa = (demDoanCuaNguonStmt.get(id) as { n: number }).n;
    xoaFtsCuaNguonStmt.run(id);
    xoaDoanCuaNguonStmt.run(id);
    xoaGanAgentCuaNguonStmt.run(id);
    xoaNguonStmt.run(id);
    return { soDoanDaXoa };
  });
}
