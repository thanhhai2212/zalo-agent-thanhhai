import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let store: typeof import("./kb-source-store.js");
let binding: typeof import("./kb-agent-binding.js");
let database: typeof import("../conversation/database.js");
let n1: { id: string };
let n2: { id: string };

before(async () => {
  dataDir = setupTestEnv();
  store = await import("./kb-source-store.js");
  binding = await import("./kb-agent-binding.js");
  database = await import("../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  for (const t of ["kb_sources", "kb_chunks", "kb_chunks_fts", "agent_kb_sources"]) {
    database.db.exec(`DELETE FROM ${t}`);
  }
  n1 = store.taoNguon({ ten: "nguồn 1", loai: "text", noiDungGoc: "a" });
  n2 = store.taoNguon({ ten: "nguồn 2", loai: "text", noiDungGoc: "b" });
});

describe("kb-agent-binding - mặc định đóng", () => {
  it("agent chưa gán nguồn nào thì đọc được RỖNG - mặc định đóng", () => {
    assert.deepEqual(binding.nguonCuaAgent("agent-moi"), []);
  });

  it("agent khác được gán không làm agent này thấy nguồn", () => {
    binding.datNguonChoAgent("agent-a", [n1.id]);
    assert.deepEqual(binding.nguonCuaAgent("agent-b"), []);
  });

  /**
   * `tool-catalog-read.ts` dùng `scope` KHÔNG TRUYỀN (undefined) làm quy ước
   * "route /api/tools không biết agent nào" (rơi về `coNguonNao()` thay vì
   * `nguonCuaAgent`). Test này canh riêng cho `nguonCuaAgent("")`: hàm không
   * có gì đặc biệt hoá chuỗi rỗng (không chặn ở tầng ghi/đọc), nên nếu một
   * ngày nào đó có dòng agent_id = '' lọt vào bảng thì phải vẫn đọc ra RỖNG.
   */
  it("id rỗng cũng đọc ra RỖNG", () => {
    assert.deepEqual(binding.nguonCuaAgent(""), []);
  });
});

describe("kb-agent-binding - đặt lại là THAY THẾ", () => {
  it("đặt lại danh sách là THAY THẾ, không cộng dồn", () => {
    binding.datNguonChoAgent("a1", [n1.id, n2.id]);
    binding.datNguonChoAgent("a1", [n2.id]);
    assert.deepEqual(binding.nguonCuaAgent("a1"), [n2.id]);
  });

  it("đặt lại thành mảng rỗng thì thu hồi hết quyền đọc", () => {
    binding.datNguonChoAgent("a1", [n1.id, n2.id]);
    binding.datNguonChoAgent("a1", []);
    assert.deepEqual(binding.nguonCuaAgent("a1"), []);
  });

  it("id trùng trong danh sách truyền vào không làm nổ UNIQUE", () => {
    binding.datNguonChoAgent("a1", [n1.id, n1.id]);
    assert.deepEqual(binding.nguonCuaAgent("a1"), [n1.id]);
  });
});

describe("kb-agent-binding - agentCuaNguon (chiều ngược)", () => {
  it("một nguồn được nhiều agent gán thì trả đủ cả hai id", () => {
    binding.datNguonChoAgent("a1", [n1.id]);
    binding.datNguonChoAgent("a2", [n1.id]);
    assert.deepEqual(binding.agentCuaNguon(n1.id), ["a1", "a2"]);
  });

  it("nguồn chưa agent nào gán thì trả rỗng", () => {
    assert.deepEqual(binding.agentCuaNguon(n1.id), []);
  });

  it("chỉ trả agent gán ĐÚNG nguồn này, không lẫn nguồn khác", () => {
    binding.datNguonChoAgent("a1", [n1.id]);
    binding.datNguonChoAgent("a2", [n2.id]);
    assert.deepEqual(binding.agentCuaNguon(n1.id), ["a1"]);
  });
});

describe("kb-agent-binding - datAgentChoNguon (chiều gán tại trang Kho tri thức)", () => {
  it("gán nhiều agent cho một nguồn rồi đọc lại đúng danh sách", () => {
    binding.datAgentChoNguon(n1.id, ["a1", "a2"]);
    assert.deepEqual(binding.agentCuaNguon(n1.id), ["a1", "a2"]);
  });

  it("đặt lại là THAY THẾ, không cộng dồn - và không đụng nguồn khác", () => {
    binding.datAgentChoNguon(n1.id, ["a1"]);
    binding.datAgentChoNguon(n2.id, ["a2"]);
    binding.datAgentChoNguon(n1.id, ["a3"]);
    assert.deepEqual(binding.agentCuaNguon(n1.id), ["a3"]);
    assert.deepEqual(binding.agentCuaNguon(n2.id), ["a2"], "không được đụng nguồn khác");
  });
});

describe("kb-agent-binding - demAgentTheoNguon", () => {
  it("đếm đúng số agent cho từng nguồn, nguồn chưa ai gán VẮNG MẶT trong Map", () => {
    binding.datNguonChoAgent("a1", [n1.id]);
    binding.datNguonChoAgent("a2", [n1.id]);
    const dem = binding.demAgentTheoNguon();
    assert.equal(dem.get(n1.id), 2);
    assert.equal(dem.has(n2.id), false, "nguồn 0 agent phải VẮNG MẶT, không phải giá trị 0");
  });
});

describe("kb-agent-binding - xoaGanNguonCuaAgent (dọn khi agent bị xóa)", () => {
  it("dọn sạch mọi gán của agent, không đụng gán của agent khác", () => {
    binding.datNguonChoAgent("a1", [n1.id, n2.id]);
    binding.datNguonChoAgent("a2", [n1.id]);
    binding.xoaGanNguonCuaAgent("a1");
    assert.deepEqual(binding.nguonCuaAgent("a1"), []);
    assert.deepEqual(binding.nguonCuaAgent("a2"), [n1.id], "không được đụng agent khác");
  });
});
