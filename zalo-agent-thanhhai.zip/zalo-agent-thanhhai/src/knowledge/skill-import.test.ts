import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { taoZip } from "../shared/zip-test-helper.js";
import { docKyNangMd, docKyNangZip } from "./skill-import.js";

const skillMd = (name: string, desc: string, than = "# Cách làm\n1. Bước một.") => `---\nname: ${name}\ndescription: "${desc}"\n---\n${than}`;

describe("đọc bộ skill", () => {
  it("SKILL.md lẻ: tên + mô tả từ frontmatter; thiếu name thì lấy tên file", () => {
    const a = docKyNangMd("SKILL.md", Buffer.from(skillMd("bao-gia", "Khách hỏi giá")));
    assert.deepEqual([a.ten, a.moTa, a.soTepKem], ["bao-gia", "Khách hỏi giá", 0]);
    assert.ok(a.noiDung.includes("# Cách làm"));
    const b = docKyNangMd("viet-caption.md", Buffer.from("# Viết caption"));
    assert.deepEqual([b.ten, b.moTa], ["viet-caption", ""]);
  });

  it("zip nhiều thư mục skill: mỗi SKILL.md một kỹ năng, tài liệu cùng thư mục nối vào, script bị bỏ và ghi chú", () => {
    const zip = taoZip({
      "bo-skill/bao-gia/SKILL.md": skillMd("bao-gia", "Khách hỏi giá"),
      "bo-skill/bao-gia/references/bang-gia.md": "Gói A: 1 triệu",
      "bo-skill/bao-gia/scripts/tinh.py": "print(1)",
      "bo-skill/cham-soc/SKILL.md": skillMd("cham-soc", "Chăm sóc khách cũ"),
      "bo-skill/cham-soc/mau-tin.txt": "Chào anh",
      "bo-skill/README.md": "không thuộc skill nào",
      "__MACOSX/bo-skill/._SKILL.md": "rác",
    });
    const ds = docKyNangZip("bo-skill.zip", zip);
    assert.deepEqual(ds.map((k) => k.ten).sort(), ["bao-gia", "cham-soc"]);
    const bg = ds.find((k) => k.ten === "bao-gia")!;
    assert.equal(bg.soTepKem, 1);
    assert.match(bg.noiDung, /## Tài liệu kèm: references\/bang-gia\.md\n\nGói A: 1 triệu/);
    assert.deepEqual(bg.scriptBoQua, ["scripts/tinh.py"]);
    assert.match(bg.noiDung, /KHÔNG chạy được script/);
    assert.ok(!bg.noiDung.includes("không thuộc skill nào"), "README ngoài thư mục skill không bị nhận");
    const cs = ds.find((k) => k.ten === "cham-soc")!;
    assert.match(cs.noiDung, /mau-tin\.txt\n\nChào anh/);
  });

  it("zip không có SKILL.md thì báo lỗi rõ", () => {
    assert.throws(() => docKyNangZip("x.zip", taoZip({ "a/readme.md": "x" })), /không có SKILL\.md/);
  });

  it("tệp không phải dạng chữ (PDF, ảnh) được liệt kê và ghi chú, không bỏ im lặng; cấu trúc SKILL.md + thư mục quy-trinh", () => {
    const zip = taoZip({
      "SKILL.md": skillMd("tu-van", "Tư vấn", "Bước 1: đọc quy-trinh/01-chao.md"),
      "quy-trinh/01-chao.md": "Chào khách",
      "quy-trinh/bang-gia.pdf": "%PDF-1.4",
      "quy-trinh/so-do.png": "PNG",
    });
    const [k] = docKyNangZip("bo.zip", zip);
    assert.equal(k!.soTepKem, 1);
    assert.deepEqual(k!.tepBoQua, ["quy-trinh/bang-gia.pdf", "quy-trinh/so-do.png"]);
    assert.match(k!.noiDung, /Tài liệu kèm: quy-trinh\/01-chao\.md/);
    assert.match(k!.noiDung, /bang-gia\.pdf, quy-trinh\/so-do\.png\) nên KHÔNG được nạp/);
  });
});
