import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { MOC_GHI_CHU, MOC_TEP_KEM, noiDungKyNang, tachPhanKyNang, timTepKem } from "./skill-parts.js";

const than = (chinh: string, tep: [string, string][], ghiChu = "") =>
  chinh + tep.map(([p, n]) => `${MOC_TEP_KEM}${p}\n\n${n}`).join("") + (ghiChu ? `${MOC_GHI_CHU}${ghiChu}` : "");

describe("tachPhanKyNang", () => {
  it("tách phần chính + từng tài liệu kèm; ghi chú hệ thống về lại phần chính", () => {
    const r = tachPhanKyNang(than("Bước 1: đọc quy-trinh/01.md", [["quy-trinh/01.md", "Chào"], ["quy-trinh/02.md", "Báo giá"]], "có 1 script"));
    assert.equal(r.chinh, `Bước 1: đọc quy-trinh/01.md${MOC_GHI_CHU}có 1 script`);
    assert.deepEqual(r.tepKem, [
      { duongDan: "quy-trinh/01.md", noiDung: "Chào" },
      { duongDan: "quy-trinh/02.md", noiDung: "Báo giá" },
    ]);
  });

  it("không có tài liệu kèm thì cả bài là phần chính; chịu được CRLF do sửa tay", () => {
    assert.deepEqual(tachPhanKyNang("# A\r\nB"), { chinh: "# A\nB", tepKem: [] });
    const r = tachPhanKyNang(than("A", [["x.md", "X"]]).replace(/\n/g, "\r\n"));
    assert.deepEqual(r.tepKem, [{ duongDan: "x.md", noiDung: "X" }]);
  });
});

describe("timTepKem", () => {
  const ds = [
    { duongDan: "quy-trinh/01-chao.md", noiDung: "" },
    { duongDan: "references/01-chao.md", noiDung: "" },
    { duongDan: "references/bảng-giá.md", noiDung: "" },
  ];
  it("khớp đủ đường dẫn, bỏ ./ và dấu tiếng Việt", () => {
    assert.equal(timTepKem(ds, "./quy-trinh/01-chao.md").length, 1);
    assert.equal(timTepKem(ds, "bang-gia.md")[0]!.duongDan, "references/bảng-giá.md");
  });
  it("tên tệp trùng ở hai thư mục thì ra nhiều kết quả", () => {
    assert.equal(timTepKem(ds, "01-chao.md").length, 2);
    assert.equal(timTepKem(ds, "khong-co.md").length, 0);
  });
});

describe("noiDungKyNang", () => {
  it("kỹ năng vừa trần thì trả cả bộ như cũ", () => {
    const r = noiDungKyNang("K", than("Chính", [["a.md", "AAA"]]), undefined, 1000);
    assert.ok(r.ok && r.text.includes("AAA") && r.text.startsWith("# Hướng dẫn: K"));
  });

  it("dài quá trần: trả phần chính + danh sách tài liệu, KHÔNG cắt mất tài liệu kèm", () => {
    const t = than("Phần chính. Đọc a.md rồi b.md", [["a.md", "x".repeat(3000)], ["b.md", "y".repeat(3000)]]);
    const r = noiDungKyNang("K", t, undefined, 4000);
    assert.ok(r.ok);
    assert.ok(r.text.includes("Phần chính") && r.text.includes("- a.md") && r.text.includes("- b.md"));
    assert.ok(!r.text.includes("xxx"));
    const a = noiDungKyNang("K", t, ["b.md"], 4000);
    assert.ok(a.ok && a.text.includes("y".repeat(3000)));
  });

  it("đọc nhiều tệp một lần, gộp quá trần thì báo tệp chưa gửi", () => {
    const t = than("C", [["a.md", "x".repeat(3000)], ["b.md", "y".repeat(3000)]]);
    const r = noiDungKyNang("K", t, ["a.md", "b.md"], 4000);
    assert.ok(r.ok && r.text.includes("x".repeat(3000)) && !r.text.includes("yyy"));
    assert.match(r.ok ? r.text : "", /Chưa gửi.*b\.md/);
  });

  it("tệp không có hoặc khớp mơ hồ thì trả lỗi kèm danh sách", () => {
    const t = than("C", [["q/a.md", "1"], ["r/a.md", "2"]]);
    const r1 = noiDungKyNang("K", t, ["z.md"]);
    assert.ok(!r1.ok && r1.loi.includes("q/a.md"));
    const r2 = noiDungKyNang("K", t, ["a.md"]);
    assert.ok(!r2.ok && r2.loi.includes("khớp nhiều"));
    assert.ok(!noiDungKyNang("K", "chỉ có phần chính", ["a.md"]).ok);
  });
});
