import fs from "node:fs";
import path from "node:path";
import { dataDir } from "../config/env.js";
import { db } from "../conversation/database.js";
import { layDoanCuaNguon } from "./kb-chunk-store.js";
import type { KbSource } from "./kb-source-store.js";
import { tachFrontmatter, TRAN_KY_TU_HUONG_DAN } from "./skill-parts.js";

export { tachFrontmatter, TRAN_KY_TU_HUONG_DAN };

/**
 * "Hướng dẫn nạp theo nhu cầu" (2026-10-09, học cách gọi skill theo nhu cầu
 * của Grok Bot, tổng quát hóa `huong_dan_van_ban`): một nguồn Kho tri thức
 * được đánh dấu `la_huong_dan` kèm mô tả MỘT DÒNG. Tool `nap_huong_dan` kể tên
 * + mô tả trong mô tả tool (vài chục token mỗi hướng dẫn, mỗi lượt), model cần
 * mới đọc TOÀN VĂN - thay cho việc nhồi hướng dẫn dài vào persona đi kèm mọi
 * lượt. Vẫn được cắt đoạn và tra bằng `kb_search` như nguồn thường.
 *
 * Nội dung trả cho model KHÔNG bọc `wrapUntrustedContent`: người vận hành đã
 * chủ động đánh dấu "đây là hướng dẫn để làm theo" trên dashboard (khác tài
 * liệu thường chỉ để tra cứu) - bọc lại là tự vô hiệu chính thứ nó sinh ra.
 */

export type HuongDanTomTat = { id: string; ten: string; moTa: string; bo: string; trangThai: KbSource["trangThai"] };

/** Trần toàn văn đưa cho model một lần - hướng dẫn dài hơn thì cắt kèm ghi chú. */

const cuaAgentStmt = db.prepare(`
  SELECT s.id, s.ten, s.mo_ta, s.bo_ky_nang, s.trang_thai
    FROM kb_sources s JOIN agent_kb_sources a ON a.source_id = s.id
   WHERE a.agent_id = ? AND s.la_huong_dan = 1
   ORDER BY s.bo_ky_nang COLLATE NOCASE, s.ten COLLATE NOCASE
`);

export function huongDanCuaAgent(agentId: string): HuongDanTomTat[] {
  const rows = cuaAgentStmt.all(agentId) as unknown as { id: string; ten: string; mo_ta: string; bo_ky_nang: string; trang_thai: KbSource["trangThai"] }[];
  return rows.map((r) => ({ id: r.id, ten: r.ten, moTa: r.mo_ta, bo: r.bo_ky_nang, trangThai: r.trang_thai }));
}

const coHuongDanStmt = db.prepare(`SELECT 1 FROM kb_sources WHERE la_huong_dan = 1 LIMIT 1`);
export function coHuongDanNao(): boolean {
  return coHuongDanStmt.get() !== undefined;
}

const DOC_THANG = new Set(["md", "txt"]);
type NguonDoc = Pick<KbSource, "id" | "loai" | "dinhDang" | "duongDan" | "noiDungGoc">;

/** Sửa tay được trên dashboard: gõ tay, hoặc file chữ thuần (.md/.txt) ghi đè lại được. docx/pdf thì chỉ xem. */
export function suaDuocToanVan(s: Pick<KbSource, "loai" | "dinhDang">): boolean {
  return s.loai === "text" || DOC_THANG.has(s.dinhDang);
}

/**
 * Toàn văn GỐC (còn nguyên frontmatter nếu có): nguồn gõ tay đọc `noiDungGoc`;
 * file .md/.txt đọc thẳng file (giữ nguyên cấu trúc); định dạng khác
 * (docx/pdf...) ghép lại từ các đoạn đã cắt - có thể lặp chút ở biên đoạn
 * (overlap), chấp nhận được vì hướng dẫn thường là văn bản thuần.
 */
export function docToanVanGoc(s: NguonDoc): string {
  if (s.loai === "text") return s.noiDungGoc;
  if (DOC_THANG.has(s.dinhDang) && s.duongDan) return fs.readFileSync(path.join(dataDir, s.duongDan), "utf8");
  const phan: string[] = [];
  for (let offset = 0; ; offset += 100) {
    const trang = layDoanCuaNguon(s.id, offset, 100);
    phan.push(...trang.map((d) => d.noiDung));
    if (trang.length < 100) break;
  }
  return phan.join("\n\n");
}

/** Thân hướng dẫn CHƯA cắt (bỏ frontmatter) - `nap_huong_dan` tự chia phần qua `skill-parts.ts`. */
export function docThanHuongDan(s: NguonDoc): string {
  return tachFrontmatter(docToanVanGoc(s)).than.trim();
}

/** Toàn văn đưa cho model: bỏ frontmatter (siêu dữ liệu), cắt ở trần. */
export function docToanVanHuongDan(s: NguonDoc): string {
  const sach = docThanHuongDan(s);
  if (sach.length <= TRAN_KY_TU_HUONG_DAN) return sach;
  return `${sach.slice(0, TRAN_KY_TU_HUONG_DAN)}\n\n[Hướng dẫn dài hơn ${TRAN_KY_TU_HUONG_DAN} ký tự - phần sau đã cắt, tra chi tiết bằng kb_search nếu cần]`;
}
