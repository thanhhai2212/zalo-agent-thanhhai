/**
 * Dựng truy vấn MATCH an toàn cho `kb_chunks_fts` và chạy bm25 trên đó.
 *
 * Câu hỏi của khách đi thẳng vào đây - có thể chứa `-`, `*`, `"`, `(`, `:`,
 * `^` là cú pháp riêng của FTS5, không bọc là `MATCH` ném lỗi cú pháp và tool
 * chết giữa chừng. Xem thêm `kb-schema.ts` (vì sao cột `phang` đã bỏ dấu).
 *
 */

import { db } from "../conversation/database.js";
import { boDauTiengViet } from "../shared/bo-dau-tieng-viet.js";

/**
 * "" khi câu hỏi không còn TỪ nào dùng được (toàn dấu câu/emoji) - gọi nơi
 * cần phải tự kiểm chuỗi rỗng trước khi dựng MATCH, vì MATCH '' cũng là lỗi
 * cú pháp FTS5.
 *
 * Bọc TỪNG từ trong nháy kép rồi nối OR (không phải AND mặc định của FTS5):
 * AND đòi mọi từ phải khớp, một câu hỏi tự nhiên có từ thừa không nằm trong
 * tài liệu (vd "ship" trong "phí ship nội thành") làm cả câu không khớp gì.
 */
export function dungTruyVanFts(cauHoi: string): string {
  const tuKhoa = boDauTiengViet(cauHoi).match(/[\p{L}\p{N}]+/gu) ?? [];
  if (tuKhoa.length === 0) return "";
  return tuKhoa.map((tu) => `"${tu}"`).join(" OR ");
}

/**
 * Từ nối/từ hỏi không mang nội dung - bỏ khỏi truy vấn AND, không thì tên chủ
 * đề "Hỏi về giá khóa học" đòi cả chữ "hỏi" phải nằm trong tài liệu giá.
 */
const TU_DUNG = new Set(["hoi", "ve", "cach", "cua", "va", "cho", "voi", "la", "co", "khong", "duoc", "khi", "nao", "gi", "lam", "sao", "bi", "muon", "can", "the", "nhu", "nen", "the", "nao", "o", "tu", "den"]);

/** Truy vấn AND (mọi từ chính phải cùng có trong một đoạn) - để hỏi "kho ĐÃ có tài liệu về chủ đề này chưa". */
export function dungTruyVanAnd(cauHoi: string): string {
  const tu = (boDauTiengViet(cauHoi).toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? []).filter((t) => t.length >= 2 && !TU_DUNG.has(t));
  return tu.map((t) => `"${t}"`).join(" ");
}

const demKhopStmt = db.prepare(`SELECT COUNT(*) AS n FROM kb_chunks_fts WHERE phang MATCH ?`);

/**
 * Số đoạn trong TOÀN Kho tri thức (mọi nguồn, mọi agent) chứa đủ các từ chính
 * của `chuDe`. Dùng cho báo "nhiều người hỏi cùng một việc" (insight/hot-questions.ts)
 * để nói đúng "chưa có tài liệu" - câu hỏi ở tầm chủ bot nên không lọc theo agent.
 */
export function demDoanKhopMoiTu(chuDe: string): number {
  const q = dungTruyVanAnd(chuDe);
  if (!q) return 0;
  return (demKhopStmt.get(q) as { n: number }).n;
}

export type KetQuaFts = { chunkId: number };

/**
 * Tìm theo từ khóa qua bm25, chỉ trong `sourceIds` truyền vào - lọc NGAY
 * TRONG WHERE, không lấy top rồi lọc sau: lấy top-50 rồi lọc còn vài nguồn
 * là mất kết quả đúng đang nằm ở hạng ngoài 50.
 *
 * `soLuong` ở ĐÂY là số dòng LIMIT thẳng vào SQL - KHÔNG phải số đoạn cuối
 * cùng trả cho model. Caller (`kb-search.ts`) cố ý truyền một số LỚN HƠN số
 * đoạn cần để chừa chỗ khử trùng SAU.
 *
 * `rowid` của `kb_chunks_fts` chính là `kb_chunks.id` (gán tường minh lúc
 * chèn ở `kb-chunk-store.ts`) nên JOIN thẳng qua đó, không cần bảng trung gian.
 *
 * Không cache statement ở top-level: số lượng placeholder của `sourceIds`
 * đổi theo từng lần gọi (giống `layDoanTheoId`).
 */
export function timTheoTuKhoa(cauHoi: string, sourceIds: string[], soLuong: number): KetQuaFts[] {
  if (sourceIds.length === 0) return [];

  const matchQuery = dungTruyVanFts(cauHoi);
  if (!matchQuery) return [];

  const placeholders = sourceIds.map(() => "?").join(", ");
  // bm25() đòi TÊN BẢNG FTS5 thật, không nhận alias ("no such column: f" khi
  // gọi bm25(f)) - đã đo trên node:sqlite. Vì vậy JOIN không đặt alias cho
  // kb_chunks_fts, dùng thẳng tên bảng ở cả MATCH lẫn ORDER BY.
  const stmt = db.prepare(`
    SELECT c.id AS chunk_id
      FROM kb_chunks_fts
      JOIN kb_chunks c ON c.id = kb_chunks_fts.rowid
     WHERE kb_chunks_fts.phang MATCH ?
       AND c.source_id IN (${placeholders})
     ORDER BY bm25(kb_chunks_fts)
     LIMIT ?
  `);
  const rows = stmt.all(matchQuery, ...sourceIds, soLuong) as unknown as { chunk_id: number }[];
  return rows.map((r) => ({ chunkId: r.chunk_id }));
}
