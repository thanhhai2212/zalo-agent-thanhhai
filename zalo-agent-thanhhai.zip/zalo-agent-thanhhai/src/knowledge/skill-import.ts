import path from "node:path";
import { listZipEntries, readZipEntry } from "../shared/read-zip-entry.js";
import { MOC_GHI_CHU, MOC_TEP_KEM, tachFrontmatter } from "./skill-parts.js";

/**
 * Đọc bộ skill cá nhân (kiểu Claude skill: thư mục có `SKILL.md` + tài liệu
 * tham chiếu) thành các kỹ năng nạp vào Kho tri thức (`la_huong_dan = 1`), để
 * agent gọi bằng tool `nap_huong_dan` khi cần (2026-10-09, trang Kỹ năng).
 *
 * Nhận `.md` (một SKILL.md) hoặc `.zip` (một hay nhiều thư mục skill). Mỗi
 * `SKILL.md` trong zip là MỘT kỹ năng; tài liệu chữ (.md/.txt/.json/.yaml/.csv)
 * nằm cùng thư mục với nó được nối vào cuối làm phần "Tài liệu kèm", đúng chỗ
 * SKILL.md hay trỏ tới (`references/...`).
 *
 * KHÔNG chạy script trong skill (.py/.js/.sh...): bot đọc tin người lạ, chạy mã
 * từ một gói tải lên là đường thẳng tới chạy lệnh trên VPS. Tên các script bị
 * bỏ được ghi vào cuối kỹ năng để model biết và nói thật thay vì hứa chạy.
 * Tệp KHÔNG phải dạng chữ (PDF, Word, ảnh...) cũng không nạp - liệt kê trong
 * ghi chú đó và trong kết quả tải lên, không bỏ im lặng.
 */

export type KyNangNap = { ten: string; moTa: string; noiDung: string; soTepKem: number; scriptBoQua: string[]; tepBoQua: string[] };

const DUOI_CHU = new Set([".md", ".markdown", ".txt", ".json", ".yaml", ".yml", ".csv"]);
const DUOI_SCRIPT = new Set([".py", ".js", ".mjs", ".cjs", ".ts", ".sh", ".bash", ".ps1", ".bat", ".rb", ".php"]);
/** Trần chống zip bom / gói khổng lồ - kỹ năng là văn bản hướng dẫn, không phải kho dữ liệu. */
export const TRAN_SO_TEP_ZIP = 400;
export const TRAN_KY_TU_KY_NANG = 400_000;

const laSkillMd = (p: string) => path.posix.basename(p).toLowerCase() === "skill.md";
const boQua = (p: string) => p.endsWith("/") || /(^|\/)(__MACOSX|\.git|node_modules)\//.test(p) || path.posix.basename(p).startsWith(".");

function giaiMa(buf: Buffer): string {
  if (buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) return buf.subarray(3).toString("utf8");
  return buf.toString("utf8");
}

function dungKyNang(skillMd: string, tenDuPhong: string, kem: { duongDan: string; noiDung: string }[], scripts: string[], tepBoQua: string[] = []): KyNangNap {
  const { ten, moTa } = tachFrontmatter(skillMd);
  let noiDung = skillMd.trim();
  for (const k of kem) noiDung += `${MOC_TEP_KEM}${k.duongDan}\n\n${k.noiDung.trim()}`;
  // Tệp không đọc được (script, PDF, ảnh...) ghi chú ở cuối để model nói thật thay vì hứa làm.
  const ghiChu: string[] = [];
  if (scripts.length) {
    ghiChu.push(`gói skill gốc có ${scripts.length} script (${scripts.join(", ")}) - bot KHÔNG chạy được script. Bước nào cần chạy script thì tự làm bằng công cụ sẵn có hoặc nói rõ là không làm được.`);
  }
  if (tepBoQua.length) {
    ghiChu.push(`gói skill gốc có ${tepBoQua.length} tệp không phải dạng chữ (${tepBoQua.join(", ")}) nên KHÔNG được nạp - bot không đọc được nội dung của chúng, bước nào cần tới thì nói rõ là thiếu tài liệu đó.`);
  }
  if (ghiChu.length) noiDung += `${MOC_GHI_CHU}${ghiChu.join(" Ngoài ra, ")}`;
  if (noiDung.length > TRAN_KY_TU_KY_NANG) throw new Error(`Kỹ năng "${ten || tenDuPhong}" dài quá ${TRAN_KY_TU_KY_NANG.toLocaleString("vi-VN")} ký tự`);
  return { ten: (ten || tenDuPhong).slice(0, 200), moTa: moTa.slice(0, 200), noiDung, soTepKem: kem.length, scriptBoQua: scripts, tepBoQua };
}

/** Một file `.md` = một kỹ năng; tên dự phòng là tên file bỏ đuôi (SKILL.md thì không dùng được). */
export function docKyNangMd(tenFile: string, buf: Buffer): KyNangNap {
  const goc = path.basename(tenFile).replace(/\.(md|markdown)$/i, "");
  return dungKyNang(giaiMa(buf), goc.toLowerCase() === "skill" ? "Kỹ năng chưa đặt tên" : goc, [], []);
}

/** Mọi SKILL.md trong zip, mỗi cái kèm tài liệu chữ + danh sách script cùng thư mục với nó. */
export function docKyNangZip(tenFile: string, buf: Buffer): KyNangNap[] {
  const entries = listZipEntries(buf).filter((p) => !boQua(p));
  if (entries.length > TRAN_SO_TEP_ZIP) throw new Error(`File zip có ${entries.length} tệp, quá trần ${TRAN_SO_TEP_ZIP}`);
  const skills = entries.filter(laSkillMd).sort((a, b) => b.length - a.length);
  if (skills.length === 0) throw new Error("Trong file zip không có SKILL.md nào");
  const daNhan = new Set<string>();
  const kq: KyNangNap[] = [];
  // Thư mục SÂU trước: tệp thuộc skill con không bị skill cha nhận nhầm.
  for (const s of skills) {
    const thuMuc = path.posix.dirname(s) === "." ? "" : `${path.posix.dirname(s)}/`;
    const kem: { duongDan: string; noiDung: string }[] = [];
    const scripts: string[] = [];
    const khac: string[] = [];
    for (const p of entries) {
      if (p === s || daNhan.has(p) || !p.startsWith(thuMuc) || laSkillMd(p)) continue;
      const duoi = path.posix.extname(p).toLowerCase();
      const tuongDoi = p.slice(thuMuc.length);
      if (DUOI_CHU.has(duoi)) {
        const data = readZipEntry(buf, p);
        if (data) kem.push({ duongDan: tuongDoi, noiDung: giaiMa(data) });
        daNhan.add(p);
      } else if (DUOI_SCRIPT.has(duoi)) {
        scripts.push(tuongDoi);
        daNhan.add(p);
      } else {
        khac.push(tuongDoi);
        daNhan.add(p);
      }
    }
    const tenThuMuc = path.posix.basename(thuMuc.replace(/\/$/, "")) || path.basename(tenFile).replace(/\.zip$/i, "");
    kq.push(dungKyNang(giaiMa(readZipEntry(buf, s) ?? Buffer.alloc(0)), tenThuMuc, kem.sort((a, b) => a.duongDan.localeCompare(b.duongDan)), scripts.sort(), khac.sort()));
  }
  return kq.reverse();
}
