import { extractDocxText, extractPdfText, extractPptxText, extractXlsxText } from "../documents/extract-document-text.js";

/**
 * 5 định dạng nguồn Kho tri thức đọc được chữ - MỘT NHIỀU hơn upstream
 * (bản gốc chỉ có txt/md/docx/xlsx/pdf, không đọc pptx).
 *
 * KHÔNG port bộ trích xuất SAX tự viết của upstream (`docx-sax-*.ts`,
 * `xlsx-sax-*.ts`, `ooxml-limits.ts`) - local ĐÃ CÓ sẵn `extract-document-text.ts`
 * (mammoth/pdfjs-dist/exceljs/node-pptx-parser, dùng cho tài liệu người dùng
 * GỬI TỚI qua chat) đủ tốt để dùng lại, tránh vác thêm ~1600 dòng trích xuất
 * trùng chức năng. Đây CHÍNH LÀ lý do worker cần chạy TÁCH LUỒNG
 * (`chay-trich-xuat-tach-luong.ts`) dù thư viện dùng lại đã ổn định: cô lập
 * CPU/RAM cho tài liệu người lạ nạp lên là phòng thủ chung, không phụ thuộc
 * thư viện trích xuất cụ thể nào.
 *
 * KHÁC BIỆT DUY NHẤT với `extract-document-text.ts` gốc: PDF ở đây KHÔNG mô
 * tả ảnh tự động (`describePageImageIfAny` mặc định của hàm gốc gọi
 * `describeImage` -> `vision-sidecar.ts` -> đọc `runtime-vision-settings.ts`
 * + ghi `conversation/image-description-store.ts`, tức MỞ KẾT NỐI SQLite).
 * Bất biến bắt buộc của worker này là KHÔNG được mở SQLite (`kb-extract-worker.ts`
 * chạy trong `node:worker_threads`, "một connection cho cả process" chỉ đúng
 * ở LUỒNG CHÍNH) - nên PDF ảnh (bản scan/thiết kế đồ họa) trong Kho tri thức
 * chỉ lấy được lớp CHỮ THẬT, không có mô tả ảnh tự động như đường đọc file
 * chat. Đánh đổi đã ghi nhận, không phải bug: tài liệu KB thường là văn bản
 * tham khảo (chính sách, bảng giá), không phải ảnh chụp - có thể mở rộng sau
 * nếu cần bằng cách CHUYỂN bước mô tả ảnh ra LUỒNG CHÍNH (sau khi worker trả
 * kết quả), không phải chạy nó trong worker.
 */
export const DINH_DANG_HO_TRO = ["txt", "md", "docx", "xlsx", "pdf", "pptx"] as const;
export type DinhDangKb = (typeof DINH_DANG_HO_TRO)[number];

export function laDinhDangHoTro(x: string): x is DinhDangKb {
  return (DINH_DANG_HO_TRO as readonly string[]).includes(x);
}

/** Không mô tả ảnh - xem lý do ở docstring đầu file (worker không được mở SQLite). */
async function khongMoTaAnh(): Promise<{ hasImage: false }> {
  return { hasImage: false };
}

/**
 * Đọc chữ thô từ file theo định dạng, để `chunk-text.ts` cắt đoạn ngay sau.
 *
 * Ném lỗi có câu tiếng Việt đọc được khi file hỏng - caller (worker xử lý
 * nguồn, `kb-ingest-worker.ts`) bắt lại rồi ghi thẳng vào `kb_sources.loi` cho
 * người vận hành đọc, không phải kỹ sư. Mỗi extractor tự chịu trách nhiệm dịch
 * lỗi thư viện sang câu tiếng Việt - hàm này chỉ điều phối theo định dạng.
 */
export async function docChuTuFile(buf: Buffer, dinhDang: DinhDangKb): Promise<string> {
  switch (dinhDang) {
    case "txt":
    case "md":
      return buf.toString("utf-8");
    case "docx":
      return extractDocxText(buf);
    case "xlsx":
      return extractXlsxText(buf);
    case "pdf":
      return extractPdfText(buf, khongMoTaAnh);
    case "pptx":
      return extractPptxText(buf);
  }
}
