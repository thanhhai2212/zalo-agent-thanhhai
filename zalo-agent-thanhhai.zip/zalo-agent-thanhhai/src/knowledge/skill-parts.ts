import { boDauTiengViet } from "../shared/bo-dau-tieng-viet.js";

/**
 * Đọc kỹ năng THEO PHẦN (2026-10-09), giống cách Claude dùng skill gốc: SKILL.md
 * trước, tài liệu kèm (`references/`, `quy-trinh/`...) chỉ mở khi hướng dẫn bảo
 * đọc. Trước đó `nap_huong_dan` trả cả khối rồi cắt ở 40.000 ký tự - mà tài liệu
 * kèm nằm CUỐI nên chính chúng bị mất (đo: 8/18 kỹ năng của bộ AI Agent Business
 * Kit 2.0 dài 46.000-81.000 ký tự).
 *
 * Không đổi cách lưu: `skill-import.ts` vẫn nối tài liệu kèm vào một chuỗi bằng
 * MOC_TEP_KEM (kb_search cắt đoạn và trang xem/sửa vẫn chạy như cũ); ở đây chỉ
 * tách chuỗi đó ra lúc đọc, nên 18 kỹ năng đã nạp dùng được ngay không cần tải lại.
 * Thuần, không chạm DB.
 */

export const TRAN_KY_TU_HUONG_DAN = 40_000;
export const MOC_TEP_KEM = "\n\n---\n\n## Tài liệu kèm: ";
export const MOC_GHI_CHU = "\n\n---\n\nGhi chú hệ thống: ";
export const TOI_DA_TEP_MOI_LAN = 5;

/**
 * Tách YAML frontmatter kiểu SKILL.md (`---\nname: ...\ndescription: ...\n---`):
 * `moTa` lấy từ `description` (để dashboard tự điền mô tả khi tải bộ skill
 * lên), `than` là phần còn lại (frontmatter là siêu dữ liệu, không đưa cho model).
 */
export function tachFrontmatter(text: string): { ten: string; moTa: string; than: string } {
  const m = /^﻿?---\r?\n([\s\S]*?)\r?\n---\r?\n?/.exec(text);
  if (!m) return { ten: "", moTa: "", than: text };
  const dongs = m[1]!.split(/\r?\n/);
  const lay = (khoa: string) => {
    const dong = dongs.find((l) => new RegExp(`^${khoa}\\s*:`, "i").test(l));
    return dong ? dong.replace(new RegExp(`^${khoa}\\s*:\\s*`, "i"), "").trim().replace(/^(["'])(.*)\1$/, "$2") : "";
  };
  return { ten: lay("name"), moTa: lay("description"), than: text.slice(m[0].length) };
}

export type TepKem = { duongDan: string; noiDung: string };

/** Tách thân kỹ năng (đã bỏ frontmatter) thành phần chính + từng tài liệu kèm. Ghi chú hệ thống cuối gói về lại phần chính. */
export function tachPhanKyNang(than: string): { chinh: string; tepKem: TepKem[] } {
  const s = than.replace(/\r\n/g, "\n");
  const doan = s.split(MOC_TEP_KEM);
  let chinh = doan[0]!;
  const tepKem: TepKem[] = [];
  for (const d of doan.slice(1)) {
    const xuongDong = d.indexOf("\n");
    const duongDan = (xuongDong < 0 ? d : d.slice(0, xuongDong)).trim();
    tepKem.push({ duongDan, noiDung: xuongDong < 0 ? "" : d.slice(xuongDong) });
  }
  // Ghi chú về script/tệp bị bỏ được nối SAU tài liệu kèm cuối cùng - nó nói về cả gói, nên thuộc phần chính.
  const cuoi = tepKem.at(-1);
  const viTri = cuoi ? cuoi.noiDung.lastIndexOf(MOC_GHI_CHU) : -1;
  if (cuoi && viTri >= 0) {
    chinh += cuoi.noiDung.slice(viTri);
    cuoi.noiDung = cuoi.noiDung.slice(0, viTri);
  }
  for (const t of tepKem) t.noiDung = t.noiDung.trim();
  return { chinh: chinh.trim(), tepKem };
}

function catTran(text: string, tran: number): string {
  if (text.length <= tran) return text;
  return `${text.slice(0, tran)}\n\n[Phần này dài hơn ${tran.toLocaleString("vi-VN")} ký tự - phần sau đã cắt, tra chi tiết bằng kb_search nếu cần]`;
}

const chuan = (p: string) => boDauTiengViet(p).toLowerCase().replace(/\\/g, "/").replace(/^\.?\//, "").trim();
const tenTep = (p: string) => p.slice(p.lastIndexOf("/") + 1);

/** Tìm tài liệu kèm theo đường dẫn model đưa: khớp đủ đường dẫn, rồi tên tệp, rồi đuôi đường dẫn. */
export function timTepKem(tepKem: TepKem[], q: string): TepKem[] {
  const c = chuan(q);
  if (!c) return [];
  for (const khop of [
    (t: TepKem) => chuan(t.duongDan) === c,
    (t: TepKem) => tenTep(chuan(t.duongDan)) === tenTep(c),
    (t: TepKem) => chuan(t.duongDan).endsWith(c) || chuan(t.duongDan).includes(c),
  ]) {
    const kq = tepKem.filter(khop);
    if (kq.length) return kq;
  }
  return [];
}

function danhSachTep(tepKem: TepKem[]): string {
  return tepKem.map((t) => `- ${t.duongDan} (${t.noiDung.length.toLocaleString("vi-VN")} ký tự)`).join("\n");
}

/**
 * Nội dung trả cho model. Không có `tep`: kỹ năng vừa trần thì trả cả bộ như cũ
 * (đỡ một lượt gọi); dài hơn thì trả phần chính + danh sách tài liệu kèm. Có `tep`:
 * trả đúng các tài liệu đó, gộp lại không quá trần.
 */
export function noiDungKyNang(ten: string, than: string, tep?: string[], tran = TRAN_KY_TU_HUONG_DAN): { ok: true; text: string } | { ok: false; loi: string } {
  const { chinh, tepKem } = tachPhanKyNang(than);
  if (!tep?.length) {
    if (tepKem.length === 0 || than.trim().length <= tran) return { ok: true, text: `# Hướng dẫn: ${ten}\n\n${catTran(than.trim(), tran)}` };
    const ds = danhSachTep(tepKem);
    const huongDanGoi =
      `\n\n---\n\nKỹ năng này có ${tepKem.length} tài liệu kèm, CHƯA gửi ở đây vì cả bộ dài ${than.length.toLocaleString("vi-VN")} ký tự. ` +
      `Khi hướng dẫn trên bảo đọc/tham khảo một tài liệu (hoặc bước đang làm cần tới nó), gọi lại nap_huong_dan với cùng ten và tep = [đường dẫn] (tối đa ${TOI_DA_TEP_MOI_LAN} tệp một lần). Đừng đoán nội dung tài liệu chưa đọc.\n${ds}`;
    return { ok: true, text: `# Hướng dẫn: ${ten}\n\n${catTran(chinh, Math.max(1000, tran - huongDanGoi.length))}${huongDanGoi}` };
  }
  if (tepKem.length === 0) return { ok: false, loi: `Kỹ năng "${ten}" không có tài liệu kèm - gọi lại không kèm tep để đọc cả bài.` };

  const chon: TepKem[] = [];
  for (const q of tep.slice(0, TOI_DA_TEP_MOI_LAN)) {
    const kq = timTepKem(tepKem, q);
    if (kq.length === 0) return { ok: false, loi: `Kỹ năng "${ten}" không có tài liệu kèm "${q}". Hiện có:\n${danhSachTep(tepKem)}` };
    if (kq.length > 1) return { ok: false, loi: `"${q}" khớp nhiều tài liệu: ${kq.map((t) => t.duongDan).join(", ")} - gọi lại với đường dẫn đầy đủ.` };
    if (!chon.includes(kq[0]!)) chon.push(kq[0]!);
  }
  const phan: string[] = [];
  const conLai: string[] = [];
  let daDung = 0;
  for (const t of chon) {
    const khoi = `# Tài liệu kèm của "${ten}": ${t.duongDan}\n\n${t.noiDung}`;
    if (phan.length === 0) {
      phan.push(catTran(khoi, tran));
      daDung = Math.min(khoi.length, tran);
    } else if (daDung + khoi.length <= tran) {
      phan.push(khoi);
      daDung += khoi.length;
    } else conLai.push(t.duongDan);
  }
  const duoi = conLai.length ? `\n\n---\n\nChưa gửi vì quá dài cho một lần: ${conLai.join(", ")} - gọi lại riêng từng tệp.` : "";
  return { ok: true, text: phan.join("\n\n---\n\n") + duoi };
}
