import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let query: typeof import("./kb-fts-query.js");
let chunkStore: typeof import("./kb-chunk-store.js");
let sourceStore: typeof import("./kb-source-store.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  query = await import("./kb-fts-query.js");
  chunkStore = await import("./kb-chunk-store.js");
  sourceStore = await import("./kb-source-store.js");
  database = await import("../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("dungTruyVanFts", () => {
  it("bọc từng từ trong nháy kép và nối bằng OR", () => {
    assert.equal(query.dungTruyVanFts("phí ship nội thành"), '"phi" OR "ship" OR "noi" OR "thanh"');
  });

  it("ký tự cú pháp FTS5 trong câu hỏi KHÔNG làm ném lỗi", () => {
    // Chữ của người lạ đi thẳng vào đây - "-", "*", '"', "(" đều là cú pháp FTS5
    for (const cau of ['giá "combo" bao nhiêu', "shop ơi - còn hàng *không*", "a( b) c"]) {
      assert.doesNotThrow(() =>
        database.db.prepare("SELECT rowid FROM kb_chunks_fts WHERE phang MATCH ?").all(query.dungTruyVanFts(cau)),
      );
    }
  });

  it("câu hỏi không còn từ nào dùng được thì trả rỗng, KHÔNG dựng MATCH rỗng", () => {
    assert.equal(query.dungTruyVanFts("!!! ??? ..."), "");
  });
});

describe("dungTruyVanAnd / demDoanKhopMoiTu", () => {
  it("bỏ từ hỏi/từ nối, các từ còn lại nối bằng khoảng trắng (AND của FTS5)", () => {
    assert.equal(query.dungTruyVanAnd("Hỏi về giá khóa học"), '"gia" "khoa" "hoc"');
    assert.equal(query.dungTruyVanAnd("hỏi về"), "");
  });

  it("đếm đoạn chứa ĐỦ các từ chính trên toàn kho; thiếu một từ thì không tính", () => {
    const s = sourceStore.taoNguon({ ten: "Giá", loai: "text", noiDungGoc: "x" });
    chunkStore.luuDoan(s.id, [
      { thuTu: 0, tieuDe: "", noiDung: "Giá khóa học AI là 3 triệu" },
      { thuTu: 1, tieuDe: "", noiDung: "Khóa học có 12 buổi" },
    ]);
    assert.equal(query.demDoanKhopMoiTu("hỏi về giá khóa học"), 1);
    assert.equal(query.demDoanKhopMoiTu("cài đặt VPS"), 0);
    assert.equal(query.demDoanKhopMoiTu("???"), 0);
  });
});

describe("timTheoTuKhoa", () => {
  it("sourceIds rỗng thì trả rỗng ngay, không chạm SQL", () => {
    assert.deepEqual(query.timTheoTuKhoa("bất kỳ", [], 5), []);
  });

  it("câu hỏi rỗng-từ (chỉ dấu câu) thì trả rỗng, không ném MATCH ''", () => {
    const s = sourceStore.taoNguon({ ten: "Nguồn A", loai: "text" });
    chunkStore.luuDoan(s.id, [{ thuTu: 0, tieuDe: "", noiDung: "Chính sách đổi trả trong 7 ngày" }], s.ten);
    assert.deepEqual(query.timTheoTuKhoa("???", [s.id], 5), []);
  });

  it("chỉ tìm trong sourceIds được PHÉP - nguồn khác không lọt dù khớp từ khóa", () => {
    const a = sourceStore.taoNguon({ ten: "Nguồn A", loai: "text" });
    const b = sourceStore.taoNguon({ ten: "Nguồn B", loai: "text" });
    chunkStore.luuDoan(a.id, [{ thuTu: 0, tieuDe: "", noiDung: "Bảo hành 12 tháng" }], a.ten);
    chunkStore.luuDoan(b.id, [{ thuTu: 0, tieuDe: "", noiDung: "Bảo hành 12 tháng" }], b.ten);

    const chiA = query.timTheoTuKhoa("bảo hành", [a.id], 5);
    assert.ok(chiA.length > 0, "phải tìm thấy trong nguồn được phép");

    const chuA = chunkStore.layDoanTheoId(chiA.map((r) => r.chunkId));
    assert.ok(
      chuA.every((c) => c.sourceId === a.id),
      "không được lẫn kết quả của nguồn B dù nội dung khớp y hệt",
    );
  });

  it("tìm được dù câu hỏi CÓ dấu, nội dung KHÔNG dấu hay ngược lại (nhờ boDauTiengViet)", () => {
    const s = sourceStore.taoNguon({ ten: "Nguồn C", loai: "text" });
    chunkStore.luuDoan(s.id, [{ thuTu: 0, tieuDe: "", noiDung: "Phi ship noi thanh mien phi" }], s.ten);
    const ket = query.timTheoTuKhoa("phí ship nội thành", [s.id], 5);
    assert.ok(ket.length > 0, "câu hỏi có dấu phải khớp được nội dung không dấu");
  });
});
