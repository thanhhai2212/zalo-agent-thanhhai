import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let hd: typeof import("./kb-huong-dan.js");
let store: typeof import("./kb-source-store.js");
let binding: typeof import("./kb-agent-binding.js");
let fileStore: typeof import("./kb-file-store.js");
let chunkStore: typeof import("./kb-chunk-store.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  database = await import("../conversation/database.js");
  hd = await import("./kb-huong-dan.js");
  store = await import("./kb-source-store.js");
  binding = await import("./kb-agent-binding.js");
  fileStore = await import("./kb-file-store.js");
  chunkStore = await import("./kb-chunk-store.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  for (const t of ["kb_sources", "kb_chunks", "kb_chunks_fts", "agent_kb_sources"]) database.db.exec(`DELETE FROM ${t}`);
});

const SKILL = `---
name: bao-gia
description: "Khách hỏi giá khóa học hoặc xin ưu đãi"
---
# Báo giá
1. Hỏi học cho ai.`;

describe("tachFrontmatter", () => {
  it("lấy description của SKILL.md (bỏ nháy), thân bài không còn frontmatter", () => {
    const r = hd.tachFrontmatter(SKILL);
    assert.equal(r.ten, "bao-gia");
    assert.equal(r.moTa, "Khách hỏi giá khóa học hoặc xin ưu đãi");
    assert.ok(r.than.startsWith("# Báo giá"));
  });
  it("không có frontmatter thì giữ nguyên", () => {
    assert.deepEqual(hd.tachFrontmatter("# A\nb"), { ten: "", moTa: "", than: "# A\nb" });
  });
});

describe("huongDanCuaAgent / docToanVanHuongDan", () => {
  it("chỉ liệt kê nguồn ĐÃ gán cho agent và có cờ hướng dẫn, xếp theo tên", () => {
    const b = store.taoNguon({ ten: "B quy trình", loai: "text", noiDungGoc: "x", laHuongDan: true, moTa: "khi B" });
    const a = store.taoNguon({ ten: "A quy trình", loai: "text", noiDungGoc: "y", laHuongDan: true });
    const thuong = store.taoNguon({ ten: "Bảng giá", loai: "text", noiDungGoc: "z" });
    const khac = store.taoNguon({ ten: "Của agent khác", loai: "text", noiDungGoc: "w", laHuongDan: true });
    binding.datNguonChoAgent("ag1", [a.id, b.id, thuong.id]);
    binding.datNguonChoAgent("ag2", [khac.id]);
    assert.deepEqual(
      hd.huongDanCuaAgent("ag1").map((h) => [h.ten, h.moTa]),
      [["A quy trình", ""], ["B quy trình", "khi B"]],
    );
    assert.equal(hd.coHuongDanNao(), true);
    assert.equal(hd.huongDanCuaAgent("ag3").length, 0);
  });

  it("đọc toàn văn: gõ tay từ noiDungGoc, file .md đọc thẳng file (bỏ frontmatter), định dạng khác ghép từ đoạn", () => {
    const text = store.taoNguon({ ten: "T", loai: "text", noiDungGoc: SKILL, laHuongDan: true });
    assert.equal(hd.docToanVanHuongDan(text), "# Báo giá\n1. Hỏi học cho ai.");

    const duongDan = fileStore.luuFile("f1", "md", Buffer.from(SKILL));
    const md = store.taoNguon({ ten: "M", loai: "file", dinhDang: "md", duongDan, laHuongDan: true });
    assert.equal(hd.docToanVanHuongDan(md), "# Báo giá\n1. Hỏi học cho ai.");

    const docx = store.taoNguon({ ten: "D", loai: "file", dinhDang: "docx", duongDan: "kb/x.docx", laHuongDan: true });
    chunkStore.luuDoan(docx.id, [
      { thuTu: 0, tieuDe: "", noiDung: "Đoạn một" },
      { thuTu: 1, tieuDe: "", noiDung: "Đoạn hai" },
    ]);
    assert.equal(hd.docToanVanHuongDan(docx), "Đoạn một\n\nĐoạn hai");
  });

  it("dài quá trần thì cắt kèm ghi chú", () => {
    const dai = store.taoNguon({ ten: "L", loai: "text", noiDungGoc: "a".repeat(hd.TRAN_KY_TU_HUONG_DAN + 10), laHuongDan: true });
    const r = hd.docToanVanHuongDan(dai);
    assert.ok(r.length < hd.TRAN_KY_TU_HUONG_DAN + 200);
    assert.match(r, /đã cắt/);
  });

  it("datHuongDan đổi cờ + mô tả; id lạ trả false", () => {
    const s = store.taoNguon({ ten: "S", loai: "text", noiDungGoc: "x" });
    assert.equal(store.datHuongDan(s.id, true, "dùng khi S"), true);
    assert.deepEqual([store.layNguon(s.id)!.laHuongDan, store.layNguon(s.id)!.moTa], [true, "dùng khi S"]);
    assert.equal(store.datHuongDan("khong-co", true, ""), false);
  });
});
