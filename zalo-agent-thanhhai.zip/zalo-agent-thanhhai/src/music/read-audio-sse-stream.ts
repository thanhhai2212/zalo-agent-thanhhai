import { getTuning } from "../config/runtime-tuning-settings.js";

/**
 * Đọc stream SSE của OpenRouter chat completions khi xin audio
 * (`modalities:["text","audio"]`), trả về Buffer audio đã ghép đủ.
 *
 * Xác nhận từ docs thật OpenRouter (openrouter.ai/docs/guides/overview/multimodal/audio,
 * không đoán): audio BẮT BUỘC đi qua `stream:true`, mỗi sự kiện là một dòng
 * chuẩn OpenAI `data: {...}`, audio nằm ở `choices[0].delta.audio.data` (base64
 * MỘT ĐOẠN nhỏ, không phải toàn bộ file), kết thúc bằng `data: [DONE]`.
 *
 * Mỗi đoạn base64 tự đủ (padding riêng) nên phải decode TỪNG đoạn rồi nối
 * Buffer - nối chuỗi base64 trước rồi decode một lần dễ ra rác nếu ranh giới
 * đoạn không rơi đúng bội số 4 ký tự.
 *
 * Cùng lớp phòng thủ với `read-image-sse-stream.ts` (bỏ cuộc khi IM LẶNG quá
 * lâu, không phải theo tổng thời gian) - lý do y hệt: hạ tầng phía trước có
 * thể cắt kết nối im lặng trước khi bài hát tạo xong.
 */

const BLOCK_SEPARATOR = "\n\n";

type StreamReader = ReadableStreamDefaultReader<Uint8Array>;

async function readChunkOrStall(
  reader: StreamReader,
  stallMs: number,
): Promise<Awaited<ReturnType<StreamReader["read"]>>> {
  let timer: NodeJS.Timeout | undefined;
  try {
    return await Promise.race([
      reader.read(),
      new Promise<never>((_, reject) => {
        timer = setTimeout(
          () => reject(new Error(`Mất tín hiệu từ OpenRouter (im lặng quá ${Math.round(stallMs / 1000)} giây)`)),
          stallMs,
        );
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

/** Trích field `data:` (có thể nhiều dòng cộng dồn theo chuẩn SSE) khỏi 1 block */
function dataFieldOf(block: string): string {
  let data = "";
  for (const line of block.split("\n")) {
    if (line.startsWith("data:")) data += line.slice(5).trim();
  }
  return data;
}

type OpenRouterChunk = {
  choices?: { delta?: { audio?: { data?: string } } }[];
  error?: { message?: string } | string;
};

/**
 * Stream kết thúc êm (HTTP 200, finish_reason "stop") mà KHÔNG có đoạn audio nào -
 * Lyria preview thỉnh thoảng chỉ trả lại lời bài hát dạng chữ. Đo thật 2026-10-05:
 * cùng một loại yêu cầu lúc hỏng lúc được, nên gọi lại có tác dụng (khác lỗi cấu hình
 * sai model/voice, lỗi đó hỏng đều mọi lần).
 */
export class LoiKhongCoAudio extends Error {
  constructor() {
    super("OpenRouter không trả về audio nào (có thể model không hỗ trợ định dạng/voice đã chọn)");
    this.name = "LoiKhongCoAudio";
  }
}

export async function readAudioFromSseStream(
  response: Response,
  stallMs: number = getTuning("MUSIC_GEN_STALL_MS"),
): Promise<Buffer> {
  if (!response.body) throw new Error("OpenRouter không trả về nội dung stream");

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const parts: Buffer[] = [];

  try {
    while (true) {
      const { done, value } = await readChunkOrStall(reader, stallMs);
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let sep: number;
      while ((sep = buffer.indexOf(BLOCK_SEPARATOR)) !== -1) {
        const raw = dataFieldOf(buffer.slice(0, sep));
        buffer = buffer.slice(sep + BLOCK_SEPARATOR.length);
        if (!raw || raw === "[DONE]") continue;

        let evt: OpenRouterChunk;
        try {
          evt = JSON.parse(raw) as OpenRouterChunk;
        } catch {
          continue; // dòng lạ (comment SSE, keep-alive) - bỏ qua
        }

        if (evt.error) {
          const msg = typeof evt.error === "string" ? evt.error : (evt.error.message ?? "OpenRouter báo lỗi trong lúc tạo nhạc");
          throw new Error(msg);
        }

        const b64 = evt.choices?.[0]?.delta?.audio?.data;
        if (typeof b64 === "string" && b64) parts.push(Buffer.from(b64, "base64"));
      }
    }
  } finally {
    await reader.cancel().catch(() => {});
  }

  if (parts.length === 0) {
    throw new LoiKhongCoAudio();
  }
  return Buffer.concat(parts);
}
