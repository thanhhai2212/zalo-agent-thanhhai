import { createHourlyRateLimit } from "../shared/hourly-rate-limit.js";
import { getTuning } from "../config/runtime-tuning-settings.js";

/**
 * Trần số bài hát mỗi thread được tạo trong 1 giờ.
 *
 * Cùng lý do image-rate-limit.ts: mỗi lần tạo nhạc là TRẢ TIỀN thật ($0,08/bài)
 * cho OpenRouter và chiếm 40-60 giây. Bot đọc tin người lạ nên đây là hàng
 * phòng thủ chính chống đốt quota - trần DÙNG CHUNG cho mọi agent theo THREAD,
 * dù mỗi agent tự cấu hình API key riêng.
 */

const limiter = createHourlyRateLimit({
  limit: () => getTuning("MUSIC_GEN_MAX_PER_HOUR"),
  buildReason: ({ used, limit, waitMinutes }) =>
    `Đã tạo ${used} bài hát trong 1 giờ qua (trần ${limit}). Thử lại sau khoảng ${waitMinutes} phút.`,
});

export const checkMusicRateLimit = limiter.check;

/** Chỉ dùng cho test - xóa toàn bộ trạng thái đếm */
export const resetMusicRateLimit = limiter.reset;
