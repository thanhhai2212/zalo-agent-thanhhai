import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let rateLimit: typeof import("./music-rate-limit.js");

before(async () => {
  // Hai trần đặt LỆCH nhau: cắm nhầm biến env là test đổ ngay
  dataDir = setupTestEnv({ MUSIC_GEN_MAX_PER_HOUR: "2", IMAGE_GEN_MAX_PER_HOUR: "9" });
  rateLimit = await import("./music-rate-limit.js");
});

after(async () => {
  (await import("../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => rateLimit.resetMusicRateLimit());

describe("checkMusicRateLimit", () => {
  it("đọc trần từ MUSIC_GEN_MAX_PER_HOUR chứ không phải trần vẽ ảnh", () => {
    assert.equal(rateLimit.checkMusicRateLimit("acc:t1").ok, true);
    assert.equal(rateLimit.checkMusicRateLimit("acc:t1").ok, true);
    const blocked = rateLimit.checkMusicRateLimit("acc:t1");
    assert.equal(blocked.ok, false, "trần là 2 (MUSIC_GEN), không phải 9 (IMAGE_GEN)");
    assert.match(blocked.ok === false ? blocked.reason : "", /trần 2/);
  });

  it("câu báo nói rõ phải chờ bao lâu", () => {
    const t0 = Date.now();
    rateLimit.checkMusicRateLimit("acc:t1", t0);
    rateLimit.checkMusicRateLimit("acc:t1", t0 + 60_000);
    const blocked = rateLimit.checkMusicRateLimit("acc:t1", t0 + 20 * 60_000);
    const reason = blocked.ok === false ? blocked.reason : "";
    assert.match(reason, /khoảng 40 phút/);
  });

  it("đếm riêng từng thread", () => {
    rateLimit.checkMusicRateLimit("acc:t1");
    rateLimit.checkMusicRateLimit("acc:t1");
    assert.equal(rateLimit.checkMusicRateLimit("acc:t1").ok, false);
    assert.equal(rateLimit.checkMusicRateLimit("acc:t2").ok, true);
  });
});
