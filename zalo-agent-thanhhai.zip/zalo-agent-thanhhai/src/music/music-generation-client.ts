import { getTuning } from "../config/runtime-tuning-settings.js";
import { createLogger } from "../shared/logger.js";
import { LoiKhongCoAudio, readAudioFromSseStream } from "./read-audio-sse-stream.js";

const log = createLogger("music-generation-client");

/**
 * Tạo nhạc bằng AI - 2 nhà cung cấp hình dạng KHÁC HẲN nhau, không nhánh nào
 * dùng chung code với nhánh kia:
 *
 * - "openrouter" (mặc định, có từ trước): `google/lyria-3-pro-preview` qua
 *   OpenRouter. Xác nhận thật (không đoán, đo trực tiếp trên OpenRouter
 *   Playground vì trang model KHÔNG có ví dụ code riêng cho nhạc - panel "Get
 *   Code" chỉ lặp lại bản mẫu chung "What is in this image?" của MỌI model):
 *   endpoint CHUẨN OpenAI-compatible `/api/v1/chat/completions`, KHÔNG phải
 *   endpoint Image Generation riêng - Lyria trả audio qua CƠ CHẾ AUDIO
 *   MODALITY chung (`modalities:["text","audio"]`), BẮT BUỘC `stream:true`.
 *   `readAudioFromSseStream` xử lý phần đọc chunk `delta.audio.data`.
 * - "google-ai-studio" (2026-09-16): `lyria-3-clip-preview` (clip 30 giây,
 *   luôn MP3) hoặc `lyria-3.5` (bài hát ĐẦY ĐỦ dài vài phút, có cấu trúc
 *   verse/chorus/bridge, điều khiển qua chính nội dung prompt - vd mốc thời
 *   gian `[0:00-0:10] Intro: ...` hoặc câu "tạo bài hát 2 phút"). Đi qua
 *   "Interactions API" của Google (`POST
 *   generativelanguage.googleapis.com/v1beta/interactions`, header
 *   `x-goog-api-key`, body `{model, input}` - CÙNG endpoint với Gemini TTS
 *   (`tts-client.ts`'s `generateGoogleAiStudio`) nhưng KHÔNG cần
 *   `response_modalities`/`generation_config.speech_config` (tài liệu chính
 *   thức `aistudio.google.com/docs/music-generation` không yêu cầu 2 field
 *   đó cho nhạc - có `voice` là field của cơ chế audio dùng chung CỦA
 *   OPENROUTER, không áp dụng cho Interactions API của chính Google).
 *   **DÙNG CHUNG bộ API key với TTS** (`ttsApiKey` của agent, nhiều dòng, tự
 *   xoay vòng khi 1 key hết hạn mức) - nhánh này KHÔNG có cột key riêng, xem
 *   `create-music-tool.ts`'s `musicConfigCua()`.
 *
 *   Doc mô tả "mặc định MP3, có thể xin WAV qua `response_format`" nhưng ví
 *   dụ code CHÍNH THỨC lại gửi `response_format:{"type":"audio"}` (không phải
 *   `"wav"`) cho MỌI ngôn ngữ - cùng lớp bất nhất tài liệu đã gặp với
 *   `speech_config` của Gemini TTS. Vì KHÔNG có cách nào test thật để xác
 *   nhận field nào đúng, code này KHÔNG gửi `response_format` (giữ nguyên
 *   mặc định MP3 của provider) và tự NHẬN DIỆN đuôi file qua `mime_type` thật
 *   trả về - đúng chiến lược phòng thủ đã dùng cho Gemini TTS's
 *   `phanTichMimeAudio()`, không đoán mò field request chưa xác nhận được.
 *
 * **Nhiều key xoay vòng khi 1 key hỏng** (chỉ có ý nghĩa với google-ai-studio
 * vì DÙNG CHUNG key TTS nhiều dòng - openrouter vẫn dùng đúng 1 key OpenRouter
 * của agent, xoay vòng qua đúng vòng lặp này nhưng thường chỉ có 1 phần tử).
 * Lặp lại logic tách key + phân biệt lỗi 401/403/429 giống hệt `tts-client.ts`
 * THAY VÌ import chéo - đúng nếp KHÔNG import chéo giữa các domain đã dùng
 * cho `groupIdCua`/`tachDsKeyTts`.
 *
 * `fetchImpl` tiêm được để test không chạm mạng, không tốn tiền thật.
 */

export type MusicConfig = {
  /** "openrouter" (mặc định) | "google-ai-studio" */
  provider: string;
  /** openrouter: tên model OpenRouter, mặc định "google/lyria-3-pro-preview".
   *  google-ai-studio: "lyria-3-clip-preview" | "lyria-3.5", trống = "lyria-3.5" */
  model: string;
  /** Chỉ dùng cho openrouter - "" = client tự dùng "alloy" */
  voice: string;
  /** Chỉ dùng cho openrouter (wav|mp3|flac|opus|pcm16) - google-ai-studio tự
   *  nhận diện định dạng trả về qua mime_type, không đọc field này */
  format: string;
  /** openrouter: API key riêng của agent. google-ai-studio: bộ key TTS dùng
   *  chung (có thể nhiều dòng - xem `thuLanLuotKey`) */
  apiKey: string;
};

export type GeneratedMusic = {
  data: Buffer;
  /** Đuôi file (không dấu chấm) */
  ext: string;
};

const OPENROUTER_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions";
/** Theo đúng tập giá trị chung docs OpenRouter liệt kê cho audio modality */
const MUSIC_FORMAT_HOP_LE = new Set(["wav", "mp3", "flac", "opus", "pcm16"]);
const DEFAULT_VOICE = "alloy";

const GOOGLE_AI_STUDIO_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/interactions";
/** 2 model Lyria hợp lệ theo aistudio.google.com/docs/music-generation - giá trị lạ rơi về mặc định */
const GOOGLE_MUSIC_MODEL_HOP_LE = new Set(["lyria-3-clip-preview", "lyria-3.5"]);
const GOOGLE_MUSIC_DEFAULT_MODEL = "lyria-3.5";
/** mime_type -> đuôi file cho các container Google có thể trả (mặc định MP3 theo docs) */
const GOOGLE_MUSIC_MIME_TO_EXT: Record<string, string> = {
  "audio/mpeg": "mp3",
  "audio/mp3": "mp3",
  "audio/wav": "wav",
  "audio/x-wav": "wav",
};

export function isMusicConfigured(cfg: Pick<MusicConfig, "provider" | "model" | "apiKey">): boolean {
  if (!cfg.apiKey) return false;
  if (cfg.provider === "google-ai-studio") return true; // model có mặc định "lyria-3.5"
  return Boolean(cfg.model); // openrouter: chưa có model hợp lý để tự bịa mặc định ở đây
}

/**
 * Đọc câu lỗi khi response KHÔNG ok (trước lúc vào stream/parse JSON) - cả
 * OpenRouter lẫn Google đều trả lỗi dạng `{"error":{"message":...}}` hoặc
 * `{"error":"..."}` (đã đo với router 9router lẫn Interactions API của TTS).
 */
async function readErrorMessage(response: Response): Promise<string> {
  const raw = await response.text().catch(() => "");
  try {
    const parsed = JSON.parse(raw) as { error?: unknown };
    const err = parsed.error;
    if (typeof err === "string" && err) return err;
    if (err && typeof err === "object") {
      const message = (err as { message?: unknown }).message;
      if (typeof message === "string" && message) return message;
    }
  } catch {
    // Không phải JSON - rơi xuống dùng mã HTTP
  }
  return `HTTP ${response.status}${raw ? `: ${raw.slice(0, 200)}` : ""}`;
}

/**
 * Gắn mã HTTP vào Error - để `dangChoXoayKeyKhac()` phân biệt "key này đang
 * không dùng được" (401/403/429) với lỗi khác (400 nội dung sai, mọi key đều
 * hỏng y hệt) - mirror `loiHttp()` của tts-client.ts.
 */
function loiHttp(message: string, httpStatus: number): Error {
  return Object.assign(new Error(message), { httpStatus });
}

async function generateOpenRouterMusic(
  prompt: string,
  cfg: MusicConfig,
  fetchImpl: typeof fetch,
): Promise<GeneratedMusic> {
  const format = MUSIC_FORMAT_HOP_LE.has(cfg.format) ? cfg.format : "wav";
  const voice = cfg.voice || DEFAULT_VOICE;

  const response = await fetchImpl(OPENROUTER_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${cfg.apiKey}` },
    body: JSON.stringify({
      model: cfg.model,
      modalities: ["text", "audio"],
      audio: { voice, format },
      stream: true,
      messages: [{ role: "user", content: prompt }],
    }),
    // Phủ CẢ phần đọc stream, không riêng lúc mở kết nối - cùng nếp image-generation-client.ts
    signal: AbortSignal.timeout(getTuning("MUSIC_GEN_TIMEOUT_MS")),
  });
  if (!response.ok) throw loiHttp(await readErrorMessage(response), response.status);

  const data = await readAudioFromSseStream(response);
  return { data, ext: format === "pcm16" ? "pcm" : format };
}

/** Số lần gọi tối đa khi model trả 200 mà không có audio (mỗi lần tốn ~0,08 USD, nên chỉ thử lại 1 lần). */
const SO_LAN_THU_KHONG_AUDIO = 2;

async function generateOpenRouterMusicCoThuLai(prompt: string, cfg: MusicConfig, fetchImpl: typeof fetch): Promise<GeneratedMusic> {
  for (let lan = 1; ; lan++) {
    try {
      return await generateOpenRouterMusic(prompt, cfg, fetchImpl);
    } catch (err) {
      if (!(err instanceof LoiKhongCoAudio) || lan >= SO_LAN_THU_KHONG_AUDIO) throw err;
    }
  }
}

type GoogleAudioContent = { type?: string; data?: string; mime_type?: string };
type GoogleStep = { type?: string; content?: GoogleAudioContent[] };
type GoogleInteractionResponse = {
  status?: string;
  output_audio?: GoogleAudioContent;
  steps?: GoogleStep[];
  errors?: { message?: string }[];
};

/** Tìm content item đầu tiên có `type:"audio"` trong toàn bộ `steps[].content[]` */
function timAudioContentTrongSteps(steps: GoogleStep[] | undefined): GoogleAudioContent | undefined {
  for (const step of steps ?? []) {
    const item = step.content?.find((c) => c.type === "audio" && c.data);
    if (item) return item;
  }
  return undefined;
}

async function generateGoogleAiStudioMusic(
  prompt: string,
  cfg: MusicConfig,
  fetchImpl: typeof fetch,
): Promise<GeneratedMusic> {
  const model = GOOGLE_MUSIC_MODEL_HOP_LE.has(cfg.model) ? cfg.model : GOOGLE_MUSIC_DEFAULT_MODEL;

  const response = await fetchImpl(GOOGLE_AI_STUDIO_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": cfg.apiKey },
    body: JSON.stringify({ model, input: prompt }),
    signal: AbortSignal.timeout(getTuning("MUSIC_GEN_TIMEOUT_MS")),
  });
  if (!response.ok) throw loiHttp(await readErrorMessage(response), response.status);

  const body = (await response.json().catch(() => null)) as GoogleInteractionResponse | null;
  if (!body) throw new Error("Google AI Studio trả về phản hồi không đọc được");
  if (body.status && body.status !== "completed") {
    const chiTiet = body.errors?.[0]?.message;
    throw new Error(`Google AI Studio báo trạng thái "${body.status}"${chiTiet ? `: ${chiTiet}` : ""}`);
  }

  const audio = body.output_audio && body.output_audio.data ? body.output_audio : timAudioContentTrongSteps(body.steps);
  if (!audio?.data) throw new Error("Google AI Studio không trả về audio trong phản hồi");

  const raw = Buffer.from(audio.data, "base64");
  if (raw.length === 0) throw new Error("Provider trả audio rỗng");

  const base = (audio.mime_type ?? "").split(";")[0]!.trim().toLowerCase();
  // Không nhận diện được mime -> mặc định mp3 theo docs (khác TTS: nhạc không
  // có nhánh PCM trần cần tự bọc WAV theo tài liệu chính thức của Lyria).
  return { data: raw, ext: GOOGLE_MUSIC_MIME_TO_EXT[base] ?? "mp3" };
}

/** Nhiều key mỗi dòng 1 key - mirror `tachDanhSachKey` của tts-client.ts */
function tachDanhSachKey(raw: string): string[] {
  return raw
    .split(/\r?\n/)
    .map((k) => k.trim())
    .filter(Boolean);
}

/** Mirror `dangChoXoayKeyKhac` của tts-client.ts - lý do xem comment đầu file */
function dangChoXoayKeyKhac(err: unknown): boolean {
  const status = (err as { httpStatus?: unknown } | null)?.httpStatus;
  return status === 401 || status === 403 || status === 429;
}

async function goiProviderTuongUng(
  prompt: string,
  cfg: MusicConfig,
  fetchImpl: typeof fetch,
): Promise<GeneratedMusic> {
  return cfg.provider === "google-ai-studio"
    ? generateGoogleAiStudioMusic(prompt, cfg, fetchImpl)
    : generateOpenRouterMusicCoThuLai(prompt, cfg, fetchImpl);
}

export async function generateMusic(
  prompt: string,
  cfg: MusicConfig,
  fetchImpl: typeof fetch = fetch,
): Promise<GeneratedMusic> {
  if (!isMusicConfigured(cfg)) {
    throw new Error(
      cfg.provider === "google-ai-studio"
        ? "Tool tạo nhạc chưa cấu hình API key (dùng chung với mục Giọng nói/TTS - Google AI Studio)"
        : "Tool tạo nhạc chưa cấu hình đủ model + API key OpenRouter",
    );
  }
  const timeoutMs = getTuning("MUSIC_GEN_TIMEOUT_MS");

  // Bình thường chỉ 1 key (openrouter luôn vậy) - vòng lặp chạy đúng 1 lần.
  const danhSachKey = tachDanhSachKey(cfg.apiKey);
  const keys = danhSachKey.length > 0 ? danhSachKey : [cfg.apiKey];

  let loiCuoi: unknown;
  try {
    for (let i = 0; i < keys.length; i++) {
      try {
        return await goiProviderTuongUng(prompt, { ...cfg, apiKey: keys[i]! }, fetchImpl);
      } catch (err) {
        loiCuoi = err;
        const conKeyKhac = i < keys.length - 1;
        if (conKeyKhac && dangChoXoayKeyKhac(err)) {
          log.warn(
            { provider: cfg.provider, keyThu: i + 1, tongKey: keys.length, err },
            "Key tạo nhạc bị từ chối/hết hạn mức - thử key kế tiếp",
          );
          continue;
        }
        throw err;
      }
    }
    throw loiCuoi;
  } catch (err) {
    const name = err instanceof Error ? err.name : "";
    if (name === "AbortError" || name === "TimeoutError") {
      throw new Error(`Tạo nhạc quá lâu (hơn ${Math.round(timeoutMs / 1000)} giây) nên đã dừng`);
    }
    throw err;
  }
}
