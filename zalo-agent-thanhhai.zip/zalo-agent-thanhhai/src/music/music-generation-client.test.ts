import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let client: typeof import("./music-generation-client.js");

before(async () => {
  dataDir = setupTestEnv();
  client = await import("./music-generation-client.js");
});

after(async () => {
  (await import("../conversation/database.js")).closeDatabase();
  cleanupTestEnv(dataDir);
});

const CFG = {
  provider: "openrouter",
  model: "google/lyria-3-pro-preview",
  voice: "",
  format: "wav",
  apiKey: "sk-or-x",
};

function sseResponse(text: string): Response {
  return new Response(text, { status: 200, headers: { "Content-Type": "text/event-stream" } });
}
function audioChunk(bytes: number[]): string {
  return `data: ${JSON.stringify({ choices: [{ delta: { audio: { data: Buffer.from(bytes).toString("base64") } } }] })}\n\n`;
}
const DONE = "data: [DONE]\n\n";

describe("isMusicConfigured", () => {
  it("đủ model + key -> true", () => assert.equal(client.isMusicConfigured(CFG), true));
  it("thiếu key -> false", () => assert.equal(client.isMusicConfigured({ ...CFG, apiKey: "" }), false));
  it("thiếu model (openrouter) -> false", () => assert.equal(client.isMusicConfigured({ ...CFG, model: "" }), false));
  it("google-ai-studio: chỉ cần key, KHÔNG cần model (có mặc định lyria-3.5)", () =>
    assert.equal(
      client.isMusicConfigured({ provider: "google-ai-studio", model: "", apiKey: "AIzaS-key" }),
      true,
    ));
  it("google-ai-studio: thiếu key -> false", () =>
    assert.equal(
      client.isMusicConfigured({ provider: "google-ai-studio", model: "lyria-3.5", apiKey: "" }),
      false,
    ));
});

describe("generateMusic", () => {
  it("POST đúng endpoint OpenRouter, body modalities/audio/stream/messages, header Bearer", async () => {
    let capturedUrl = "";
    let capturedBody: Record<string, unknown> = {};
    let capturedAuth = "";
    const fetchFn = (async (url: Parameters<typeof fetch>[0], init?: Parameters<typeof fetch>[1]) => {
      capturedUrl = String(url);
      capturedBody = JSON.parse(String(init?.body)) as Record<string, unknown>;
      capturedAuth = String((init?.headers as Record<string, string>).Authorization);
      return sseResponse(audioChunk([1, 2, 3]) + DONE);
    }) as unknown as typeof fetch;

    const out = await client.generateMusic("một bản nhạc đồng quê", CFG, fetchFn);

    assert.equal(capturedUrl, "https://openrouter.ai/api/v1/chat/completions");
    assert.equal(capturedAuth, "Bearer sk-or-x");
    assert.equal(capturedBody.model, "google/lyria-3-pro-preview");
    assert.deepEqual(capturedBody.modalities, ["text", "audio"]);
    assert.equal(capturedBody.stream, true);
    assert.deepEqual(capturedBody.audio, { voice: "alloy", format: "wav" });
    assert.deepEqual(capturedBody.messages, [{ role: "user", content: "một bản nhạc đồng quê" }]);
    assert.deepEqual([...out.data], [1, 2, 3]);
    assert.equal(out.ext, "wav");
  });

  it("voice để trống -> tự điền 'alloy' (đúng mặc định quan sát được thật trên Playground)", async () => {
    let body: Record<string, unknown> = {};
    const fetchFn = (async (_u: unknown, init?: Parameters<typeof fetch>[1]) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return sseResponse(audioChunk([1]) + DONE);
    }) as unknown as typeof fetch;
    await client.generateMusic("x", { ...CFG, voice: "" }, fetchFn);
    assert.deepEqual(body.audio, { voice: "alloy", format: "wav" });
  });

  it("voice có cấu hình riêng -> gửi đúng voice đó, không ép về alloy", async () => {
    let body: Record<string, unknown> = {};
    const fetchFn = (async (_u: unknown, init?: Parameters<typeof fetch>[1]) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return sseResponse(audioChunk([1]) + DONE);
    }) as unknown as typeof fetch;
    await client.generateMusic("x", { ...CFG, voice: "nova" }, fetchFn);
    assert.deepEqual(body.audio, { voice: "nova", format: "wav" });
  });

  it("format lạ rơi về wav mặc định", async () => {
    const fetchFn = (async () => sseResponse(audioChunk([1]) + DONE)) as unknown as typeof fetch;
    const out = await client.generateMusic("x", { ...CFG, format: "xyz" }, fetchFn);
    assert.equal(out.ext, "wav");
  });

  it("format pcm16 -> đuôi file 'pcm'", async () => {
    const fetchFn = (async () => sseResponse(audioChunk([1]) + DONE)) as unknown as typeof fetch;
    const out = await client.generateMusic("x", { ...CFG, format: "pcm16" }, fetchFn);
    assert.equal(out.ext, "pcm");
  });

  it("lỗi HTTP trước khi vào stream (401, error là chuỗi) -> ném kèm thông điệp", async () => {
    const fetchFn = (async () =>
      new Response(JSON.stringify({ error: "Invalid API key" }), {
        status: 401,
        headers: { "content-type": "application/json" },
      })) as unknown as typeof fetch;
    await assert.rejects(client.generateMusic("x", CFG, fetchFn), /Invalid API key/);
  });

  it("lỗi HTTP trước khi vào stream (400, error là object) -> ném kèm message", async () => {
    const fetchFn = (async () =>
      new Response(JSON.stringify({ error: { message: "model không tồn tại" } }), {
        status: 400,
        headers: { "content-type": "application/json" },
      })) as unknown as typeof fetch;
    await assert.rejects(client.generateMusic("x", CFG, fetchFn), /model không tồn tại/);
  });

  it("stream không trả chunk audio nào (cả 2 lần) -> ném lỗi sau đúng 2 lần gọi", async () => {
    let soLan = 0;
    const fetchFn = (async () => (soLan++, sseResponse(DONE))) as unknown as typeof fetch;
    await assert.rejects(client.generateMusic("x", CFG, fetchFn), /không trả về audio/);
    assert.equal(soLan, 2);
  });

  it("lần đầu không có audio, lần hai có -> trả bài hát (Lyria thỉnh thoảng chỉ trả lời chữ)", async () => {
    let soLan = 0;
    const fetchFn = (async () => (soLan++ === 0 ? sseResponse(DONE) : sseResponse(audioChunk([1, 2, 3]) + DONE))) as unknown as typeof fetch;
    const ra = await client.generateMusic("x", CFG, fetchFn);
    assert.deepEqual([...ra.data], [1, 2, 3]);
    assert.equal(soLan, 2);
  });

  it("lỗi HTTP KHÔNG được gọi lại (chỉ thử lại khi 200 mà thiếu audio)", async () => {
    let soLan = 0;
    const fetchFn = (async () => (soLan++, new Response(JSON.stringify({ error: "x" }), { status: 400, headers: { "content-type": "application/json" } }))) as unknown as typeof fetch;
    await assert.rejects(client.generateMusic("x", CFG, fetchFn));
    assert.equal(soLan, 1);
  });

  it("chưa cấu hình đủ -> ném trước khi gọi mạng", async () => {
    let goi = false;
    const fetchFn = (async () => {
      goi = true;
      return sseResponse(DONE);
    }) as unknown as typeof fetch;
    await assert.rejects(client.generateMusic("x", { ...CFG, apiKey: "" }, fetchFn));
    assert.equal(goi, false);
  });
});

const GG_CFG = { provider: "google-ai-studio", model: "lyria-3.5", voice: "", format: "wav", apiKey: "AIzaS-key" };

function googleInteractionResponse(base64: string, mime = "audio/mpeg"): Response {
  return new Response(
    JSON.stringify({
      status: "completed",
      output_audio: { type: "audio", data: base64, mime_type: mime },
    }),
    { status: 200, headers: { "content-type": "application/json" } },
  );
}

describe("generateMusic - google-ai-studio (Interactions API, DÙNG CHUNG key TTS)", () => {
  it("POST đúng endpoint Interactions API, body {model, input}, header x-goog-api-key - KHÔNG gửi response_modalities/speech_config", async () => {
    let capturedUrl = "";
    let capturedBody: Record<string, unknown> = {};
    let capturedKey = "";
    const fetchFn = (async (url: Parameters<typeof fetch>[0], init?: Parameters<typeof fetch>[1]) => {
      capturedUrl = String(url);
      capturedBody = JSON.parse(String(init?.body)) as Record<string, unknown>;
      capturedKey = String((init?.headers as Record<string, string>)["x-goog-api-key"]);
      return googleInteractionResponse(Buffer.from([9, 9, 9]).toString("base64"));
    }) as unknown as typeof fetch;

    const out = await client.generateMusic("một bản ballad piano", GG_CFG, fetchFn);

    assert.equal(capturedUrl, "https://generativelanguage.googleapis.com/v1beta/interactions");
    assert.equal(capturedKey, "AIzaS-key");
    assert.deepEqual(capturedBody, { model: "lyria-3.5", input: "một bản ballad piano" });
    assert.deepEqual([...out.data], [9, 9, 9]);
    assert.equal(out.ext, "mp3");
  });

  it("model rỗng -> mặc định lyria-3.5", async () => {
    let body: Record<string, unknown> = {};
    const fetchFn = (async (_u: unknown, init?: Parameters<typeof fetch>[1]) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return googleInteractionResponse(Buffer.from([1]).toString("base64"));
    }) as unknown as typeof fetch;
    await client.generateMusic("x", { ...GG_CFG, model: "" }, fetchFn);
    assert.equal(body.model, "lyria-3.5");
  });

  it("model không hợp lệ -> rơi về mặc định lyria-3.5 (không gửi thẳng giá trị lạ)", async () => {
    let body: Record<string, unknown> = {};
    const fetchFn = (async (_u: unknown, init?: Parameters<typeof fetch>[1]) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return googleInteractionResponse(Buffer.from([1]).toString("base64"));
    }) as unknown as typeof fetch;
    await client.generateMusic("x", { ...GG_CFG, model: "lyria-9000" }, fetchFn);
    assert.equal(body.model, "lyria-3.5");
  });

  it("model lyria-3-clip-preview -> gửi đúng, không bị ép về lyria-3.5", async () => {
    let body: Record<string, unknown> = {};
    const fetchFn = (async (_u: unknown, init?: Parameters<typeof fetch>[1]) => {
      body = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return googleInteractionResponse(Buffer.from([1]).toString("base64"));
    }) as unknown as typeof fetch;
    await client.generateMusic("x", { ...GG_CFG, model: "lyria-3-clip-preview" }, fetchFn);
    assert.equal(body.model, "lyria-3-clip-preview");
  });

  it("mime_type audio/wav -> đuôi file wav", async () => {
    const fetchFn = (async () =>
      googleInteractionResponse(Buffer.from([1]).toString("base64"), "audio/wav")) as unknown as typeof fetch;
    const out = await client.generateMusic("x", GG_CFG, fetchFn);
    assert.equal(out.ext, "wav");
  });

  it("mime_type lạ -> mặc định mp3 (không đoán container khác)", async () => {
    const fetchFn = (async () =>
      googleInteractionResponse(Buffer.from([1]).toString("base64"), "audio/ogg")) as unknown as typeof fetch;
    const out = await client.generateMusic("x", GG_CFG, fetchFn);
    assert.equal(out.ext, "mp3");
  });

  it("audio nằm trong steps[].content[] (không có output_audio ở gốc) -> vẫn đọc được", async () => {
    const fetchFn = (async () =>
      new Response(
        JSON.stringify({
          status: "completed",
          steps: [{ type: "model_output", content: [{ type: "audio", data: Buffer.from([7]).toString("base64"), mime_type: "audio/mpeg" }] }],
        }),
        { status: 200, headers: { "content-type": "application/json" } },
      )) as unknown as typeof fetch;
    const out = await client.generateMusic("x", GG_CFG, fetchFn);
    assert.deepEqual([...out.data], [7]);
  });

  it("status khác 'completed' -> ném kèm lý do", async () => {
    const fetchFn = (async () =>
      new Response(JSON.stringify({ status: "failed", errors: [{ message: "nội dung vi phạm chính sách" }] }), {
        status: 200,
        headers: { "content-type": "application/json" },
      })) as unknown as typeof fetch;
    await assert.rejects(client.generateMusic("x", GG_CFG, fetchFn), /nội dung vi phạm chính sách/);
  });

  it("401 (key sai) -> ném kèm thông điệp", async () => {
    const fetchFn = (async () =>
      new Response(JSON.stringify({ error: { message: "API key not valid" } }), {
        status: 401,
        headers: { "content-type": "application/json" },
      })) as unknown as typeof fetch;
    await assert.rejects(client.generateMusic("x", GG_CFG, fetchFn), /API key not valid/);
  });

  it("nhiều key (dùng chung TTS) - key đầu 429 hết hạn mức -> tự xoay sang key kế tiếp, không lộ ra ngoài", async () => {
    const goiVoiKey: string[] = [];
    const fetchFn = (async (_u: unknown, init?: Parameters<typeof fetch>[1]) => {
      const key = String((init?.headers as Record<string, string>)["x-goog-api-key"]);
      goiVoiKey.push(key);
      if (key === "key-het-han") {
        return new Response(JSON.stringify({ error: "Resource exhausted" }), {
          status: 429,
          headers: { "content-type": "application/json" },
        });
      }
      return googleInteractionResponse(Buffer.from([5]).toString("base64"));
    }) as unknown as typeof fetch;

    const out = await client.generateMusic("x", { ...GG_CFG, apiKey: "key-het-han\nkey-con-song" }, fetchFn);

    assert.deepEqual(goiVoiKey, ["key-het-han", "key-con-song"]);
    assert.deepEqual([...out.data], [5]);
  });

  it("lỗi 400 (nội dung sai) -> KHÔNG xoay key, ném ngay ở lần thử đầu", async () => {
    let soLanGoi = 0;
    const fetchFn = (async () => {
      soLanGoi++;
      return new Response(JSON.stringify({ error: { message: "prompt bị chặn bởi bộ lọc an toàn" } }), {
        status: 400,
        headers: { "content-type": "application/json" },
      });
    }) as unknown as typeof fetch;

    await assert.rejects(
      client.generateMusic("x", { ...GG_CFG, apiKey: "key-1\nkey-2" }, fetchFn),
      /bộ lọc an toàn/,
    );
    assert.equal(soLanGoi, 1, "400 xảy ra giống hệt với mọi key nên không nên thử key kế tiếp");
  });
});
