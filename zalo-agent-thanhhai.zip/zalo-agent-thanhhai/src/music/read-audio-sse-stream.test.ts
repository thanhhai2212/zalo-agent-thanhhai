import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { readAudioFromSseStream } from "./read-audio-sse-stream.js";

/**
 * Trọng tâm giống read-image-sse-stream.test.ts: phân biệt "tạo lâu nhưng còn
 * sống" (nhiều chunk audio nhỏ dồn dập) với "kết nối đã chết" (im lặng quá lâu).
 */

function chunkOf(b64: string, extra: Record<string, unknown> = {}): string {
  return `data: ${JSON.stringify({ choices: [{ delta: { audio: { data: b64, ...extra } } }] })}\n\n`;
}
const DONE = "data: [DONE]\n\n";

/** Stream bắn từng mẩu theo lịch (ms kể từ lúc bắt đầu) */
function scheduledStream(parts: { atMs: number; text: string }[], endAfterMs?: number): Response {
  const enc = new TextEncoder();
  const timers: NodeJS.Timeout[] = [];
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      for (const part of parts) {
        timers.push(setTimeout(() => controller.enqueue(enc.encode(part.text)), part.atMs));
      }
      if (endAfterMs !== undefined) {
        timers.push(setTimeout(() => controller.close(), endAfterMs));
      }
    },
    cancel() {
      for (const t of timers) clearTimeout(t);
    },
  });
  return new Response(stream, { status: 200, headers: { "Content-Type": "text/event-stream" } });
}

describe("readAudioFromSseStream - ghép chunk", () => {
  it("nhiều chunk base64 nhỏ ghép đúng thành 1 Buffer, KHÔNG nối chuỗi base64 trước khi decode", async () => {
    const a = Buffer.from([1, 2, 3]).toString("base64");
    const b = Buffer.from([4, 5]).toString("base64");
    const c = Buffer.from([6, 7, 8, 9]).toString("base64");
    const response = scheduledStream(
      [
        { atMs: 5, text: chunkOf(a) },
        { atMs: 10, text: chunkOf(b) },
        { atMs: 15, text: chunkOf(c) },
        { atMs: 20, text: DONE },
      ],
      30,
    );
    const data = await readAudioFromSseStream(response, 5000);
    assert.deepEqual([...data], [1, 2, 3, 4, 5, 6, 7, 8, 9]);
  });

  it("chunk KHÔNG có audio (chỉ transcript) bị bỏ qua, không chèn byte rác", async () => {
    const a = Buffer.from([1, 2]).toString("base64");
    const response = scheduledStream(
      [
        { atMs: 5, text: 'data: {"choices":[{"delta":{"audio":{"transcript":"xin chao"}}}]}\n\n' },
        { atMs: 10, text: chunkOf(a) },
        { atMs: 15, text: DONE },
      ],
      20,
    );
    const data = await readAudioFromSseStream(response, 5000);
    assert.deepEqual([...data], [1, 2]);
  });

  it("stream kết thúc mà không có chunk audio nào -> ném lỗi, không trả Buffer rỗng", async () => {
    await assert.rejects(() => readAudioFromSseStream(scheduledStream([{ atMs: 0, text: DONE }], 10), 5000), /không trả về audio/);
  });
});

describe("readAudioFromSseStream - phân biệt chậm với chết", () => {
  it("stream CHẬM nhưng đều đặn vẫn chạy tới cùng, dù tổng lâu hơn trần im lặng nhiều lần", async () => {
    const a = Buffer.from([9]).toString("base64");
    const response = scheduledStream(
      [
        { atMs: 10, text: chunkOf(a) },
        { atMs: 50, text: chunkOf(a) },
        { atMs: 90, text: chunkOf(a) },
        { atMs: 130, text: DONE },
      ],
      140,
    );
    const data = await readAudioFromSseStream(response, 100);
    assert.equal(data.length, 3);
  });

  it("stream IM LẶNG quá trần -> dừng sớm, báo mất tín hiệu chứ không đợi hết tổng", async () => {
    const a = Buffer.from([9]).toString("base64");
    const response = scheduledStream([
      { atMs: 10, text: chunkOf(a) },
      { atMs: 5000, text: DONE },
    ]);
    const started = Date.now();
    await assert.rejects(() => readAudioFromSseStream(response, 100), /mất tín hiệu|im lặng/i);
    assert.ok(Date.now() - started < 2000, "phải cắt ngay khi im lặng, không chờ tới 5 giây");
  });
});

describe("readAudioFromSseStream - lỗi giữa chừng", () => {
  it("OpenRouter báo lỗi giữa stream (error object) -> ném kèm message", async () => {
    const err = 'data: {"error":{"message":"model không hỗ trợ voice này"}}\n\n';
    await assert.rejects(
      () => readAudioFromSseStream(scheduledStream([{ atMs: 0, text: err }], 20), 5000),
      /model không hỗ trợ voice này/,
    );
  });

  it("OpenRouter báo lỗi giữa stream (error là chuỗi) -> vẫn ném đúng message", async () => {
    const err = 'data: {"error":"invalid_request"}\n\n';
    await assert.rejects(() => readAudioFromSseStream(scheduledStream([{ atMs: 0, text: err }], 20), 5000), /invalid_request/);
  });
});
