import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, it } from "node:test";
import { docEnvFile, kiemCaiDat, kiemRouter, kiemUngDungDienThoai } from "./doctor-checks.js";

describe("doctor-checks", () => {
  it("đọc .env: bỏ dòng chú thích, bỏ ngoặc kép", () => {
    const d = fs.mkdtempSync(path.join(os.tmpdir(), "doctor-"));
    fs.writeFileSync(path.join(d, ".env"), '# chú thích\nDATA_DIR="./du-lieu"\r\nDASHBOARD_PORT=3901\n');
    assert.deepEqual(docEnvFile(path.join(d, ".env")), { DATA_DIR: "./du-lieu", DASHBOARD_PORT: "3901" });
    assert.deepEqual(docEnvFile(path.join(d, "khong-co")), {});
    fs.rmSync(d, { recursive: true, force: true });
  });

  it("máy MỚI chưa có .env: đề xuất tạo; đã có dữ liệu mà thiếu khóa thì KHÔNG đề xuất tạo khóa mới", () => {
    const d = fs.mkdtempSync(path.join(os.tmpdir(), "doctor-"));
    const moi = kiemCaiDat({ goc: d, env: {} }).find((k) => k.ten === "File .env");
    assert.ok(moi?.sua, "máy mới phải có bước tự sửa");
    moi!.sua!();
    assert.match(fs.readFileSync(path.join(d, ".env"), "utf8"), /^CREDENTIALS_ENCRYPTION_KEY=[0-9a-f]{64}$/m);

    fs.rmSync(path.join(d, ".env"));
    fs.mkdirSync(path.join(d, "data"));
    fs.writeFileSync(path.join(d, "data", "zalo-agent.db"), "");
    const cu = kiemCaiDat({ goc: d, env: {} }).find((k) => k.ten.startsWith("Khóa mã hóa"));
    assert.equal(cu?.muc, "loi");
    assert.equal(cu?.sua, undefined);
    assert.match(cu!.chiTiet, /đừng tạo khóa mới/);
    fs.rmSync(d, { recursive: true, force: true });
  });

  it("router: có phản hồi HTTP là thông; lỗi mạng trong Docker thì gợi ý host.docker.internal", async () => {
    const ok = await kiemRouter("http://r.test/v1", false, (async () => new Response("", { status: 401 })) as unknown as typeof fetch);
    assert.equal(ok.muc, "ok");
    const hong = await kiemRouter("http://localhost:20128/v1", true, (async () => {
      throw new Error("ECONNREFUSED");
    }) as unknown as typeof fetch);
    assert.equal(hong.muc, "loi");
    assert.match(hong.chiTiet, /host\.docker\.internal/);
  });
});

describe("kiemUngDungDienThoai", () => {
  const mt = { goc: ".", env: { DASHBOARD_PORT: "3900" } };

  it("chưa cài Tailscale thì cảnh báo nhẹ (không bao giờ là lỗi)", () => {
    const [k] = kiemUngDungDienThoai(mt, () => null);
    assert.equal(k!.muc, "canh");
    assert.match(k!.chiTiet, /chưa cài Tailscale/);
  });

  it("có Tailscale nhưng chưa chia sẻ cổng dashboard thì chỉ đúng lệnh cần chạy", () => {
    const [k] = kiemUngDungDienThoai(mt, (_l, a) => (a[0] === "version" ? "1.80" : "No serve config"));
    assert.equal(k!.muc, "canh");
    assert.match(k!.chiTiet, /tailscale serve --bg 3900/);
  });

  it("đã chia sẻ đúng cổng thì báo địa chỉ để mở trên điện thoại", () => {
    const status = ["https://may-cua-toi.tail1234.ts.net (tailnet only)", "|-- / proxy http://127.0.0.1:3900", ""].join("\n");
    const [k] = kiemUngDungDienThoai(mt, (_l, a) => (a[0] === "version" ? "1.80" : status));
    assert.equal(k!.muc, "ok");
    assert.match(k!.chiTiet, /https:\/\/may-cua-toi\.tail1234\.ts\.net\/m/);
  });

  it("chia sẻ cổng KHÁC thì không tính là đã sẵn sàng", () => {
    const status = ["https://may.ts.net", "|-- / proxy http://127.0.0.1:8080", ""].join("\n");
    const [k] = kiemUngDungDienThoai(mt, (_l, a) => (a[0] === "version" ? "1.80" : status));
    assert.equal(k!.muc, "canh");
  });
});
