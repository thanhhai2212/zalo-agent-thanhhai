import { execFileSync } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { timChrome } from "../documents/chrome-finder.js";

/**
 * Các bước chẩn đoán của `pnpm zalo-doctor` (2026-10-04, học từ `heo-agent doctor`).
 *
 * KHÔNG import `config/env.ts` hay `conversation/database.ts`: env.ts thoát cả
 * tiến trình khi cấu hình sai (đúng thứ doctor cần báo), còn database.ts chạy
 * migration - doctor chỉ ĐỌC DB ở chế độ read-only, chạy được cả lúc bot đang
 * chạy mà không đụng gì.
 *
 * Mỗi bước có thể kèm `sua` - chỉ những việc an toàn, không mất dữ liệu: tạo thư
 * mục, cài thư viện, dựng giao diện, xóa file tạm cũ, tạo .env cho máy MỚI (chưa
 * có DB). Không bao giờ tự đổi khóa mã hóa khi đã có dữ liệu.
 */

export type MucDo = "ok" | "canh" | "loi";
export type KetQuaKiem = { ten: string; muc: MucDo; chiTiet: string; sua?: () => string };

export type MoiTruong = { goc: string; env: Record<string, string> };

export function docEnvFile(file: string): Record<string, string> {
  if (!fs.existsSync(file)) return {};
  const ra: Record<string, string> = {};
  for (const dong of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(dong);
    if (m) ra[m[1]!] = m[2]!.replace(/^["']|["']$/g, "");
  }
  return ra;
}

const coLenh = (lenh: string, thamSo = ["-version"]) => {
  try {
    execFileSync(lenh, thamSo, { stdio: "ignore", timeout: 10_000 });
    return true;
  } catch {
    return false;
  }
};

const chay = (goc: string, thamSo: string[]) => {
  execFileSync(process.platform === "win32" ? "corepack.cmd" : "corepack", ["pnpm", ...thamSo], { cwd: goc, stdio: "inherit", shell: process.platform === "win32" });
  return `đã chạy pnpm ${thamSo.join(" ")}`;
};

export function kiemCaiDat({ goc, env }: MoiTruong): KetQuaKiem[] {
  const ra: KetQuaKiem[] = [];
  const [maj, min] = process.versions.node.split(".").map(Number);
  ra.push({ ten: "Node.js 22.13 trở lên", muc: maj! > 22 || (maj === 22 && min! >= 13) ? "ok" : "loi", chiTiet: `đang dùng ${process.versions.node}` });

  const nm = fs.existsSync(path.join(goc, "node_modules"));
  ra.push({ ten: "Đã cài thư viện", muc: nm ? "ok" : "loi", chiTiet: nm ? "" : "thiếu node_modules", sua: nm ? undefined : () => chay(goc, ["install", "--frozen-lockfile"]) });

  const web = fs.existsSync(path.join(goc, "web", "dist", "index.html"));
  ra.push({ ten: "Đã dựng giao diện dashboard", muc: web ? "ok" : "loi", chiTiet: web ? "" : "thiếu web/dist", sua: web ? undefined : () => chay(goc, ["run", "build:web"]) });

  const fileEnv = path.join(goc, ".env");
  const dataDir = path.resolve(goc, env.DATA_DIR || "./data");
  const coDb = fs.existsSync(path.join(dataDir, "zalo-agent.db"));
  const khoa = env.CREDENTIALS_ENCRYPTION_KEY ?? "";
  if (/^[0-9a-fA-F]{64}$/.test(khoa)) {
    ra.push({ ten: "Khóa mã hóa (CREDENTIALS_ENCRYPTION_KEY)", muc: "ok", chiTiet: "" });
  } else if (!fs.existsSync(fileEnv) && !coDb) {
    ra.push({
      ten: "File .env",
      muc: "loi",
      chiTiet: "chưa có .env (máy mới)",
      sua: () => {
        const mk = crypto.randomBytes(9).toString("base64url");
        fs.writeFileSync(fileEnv, `CREDENTIALS_ENCRYPTION_KEY=${crypto.randomBytes(32).toString("hex")}\nDASHBOARD_PASSWORD=${mk}\n`, { mode: 0o600 });
        return `đã tạo .env, mật khẩu dashboard lần đầu: ${mk}`;
      },
    });
  } else {
    ra.push({
      ten: "Khóa mã hóa (CREDENTIALS_ENCRYPTION_KEY)",
      muc: "loi",
      chiTiet: coDb
        ? "thiếu hoặc sai định dạng mà ĐÃ có dữ liệu - lấy lại đúng khóa cũ, đừng tạo khóa mới (mất phiên Zalo và API key)"
        : "thiếu hoặc sai định dạng (cần 64 ký tự hex)",
    });
  }

  if (fs.existsSync(dataDir)) {
    let ghi = true;
    try {
      fs.accessSync(dataDir, fs.constants.W_OK);
    } catch {
      ghi = false;
    }
    ra.push({ ten: `Thư mục dữ liệu ${dataDir}`, muc: ghi ? "ok" : "loi", chiTiet: ghi ? "" : "không có quyền ghi" });
    try {
      const st = fs.statfsSync(dataDir);
      const gb = (st.bavail * st.bsize) / 1024 ** 3;
      ra.push({ ten: "Dung lượng đĩa trống", muc: gb < 0.2 ? "loi" : gb < 1 ? "canh" : "ok", chiTiet: `${gb.toFixed(1)} GB` });
    } catch {
      /* hệ điều hành không hỗ trợ statfs - bỏ qua */
    }
  } else {
    ra.push({
      ten: `Thư mục dữ liệu ${dataDir}`,
      muc: "loi",
      chiTiet: "chưa có",
      sua: () => (fs.mkdirSync(dataDir, { recursive: true }), "đã tạo thư mục dữ liệu"),
    });
  }

  const ff = coLenh("ffmpeg");
  ra.push({ ten: "ffmpeg (tải video, nhạc)", muc: ff ? "ok" : "canh", chiTiet: ff ? "" : "thiếu thì tai_video/tai_mp3 không ghép được" });
  const ytdlp = env.YTDLP_PATH || process.env.YTDLP_PATH;
  ra.push({
    ten: "yt-dlp (tải video, đọc YouTube)",
    muc: ytdlp && fs.existsSync(ytdlp) ? "ok" : "canh",
    chiTiet: ytdlp ? (fs.existsSync(ytdlp) ? ytdlp : `YTDLP_PATH trỏ tới file không có: ${ytdlp}`) : "chưa đặt YTDLP_PATH trong .env",
  });
  ra.push({ ten: "Chrome/Chromium (in PDF)", muc: timChrome() ? "ok" : "canh", chiTiet: timChrome() ?? "không có thì tool tạo PDF tự ẩn" });
  return ra;
}

export function kiemDuLieu({ goc, env }: MoiTruong): KetQuaKiem[] {
  const dataDir = path.resolve(goc, env.DATA_DIR || "./data");
  const fileDb = path.join(dataDir, "zalo-agent.db");
  if (!fs.existsSync(fileDb)) return [{ ten: "Cơ sở dữ liệu", muc: "canh", chiTiet: "chưa có (bot chưa chạy lần nào)" }];
  const ra: KetQuaKiem[] = [];
  const db = new DatabaseSync(fileDb, { readOnly: true });
  try {
    const qc = (db.prepare("PRAGMA quick_check").get() as { quick_check: string }).quick_check;
    ra.push({ ten: "Cơ sở dữ liệu toàn vẹn", muc: qc === "ok" ? "ok" : "loi", chiTiet: qc === "ok" ? "" : qc });
    const cai = (k: string) => (db.prepare("SELECT value FROM runtime_settings WHERE key = ?").get(k) as { value: string } | undefined)?.value;

    const mk = Boolean(env.DASHBOARD_PASSWORD || cai("dashboard_password"));
    ra.push({ ten: "Mật khẩu dashboard", muc: mk ? "ok" : "loi", chiTiet: mk ? "" : "chưa đặt DASHBOARD_PASSWORD - dashboard sẽ tắt" });

    const baseUrl = cai("llm_base_url") ?? env.LLM_BASE_URL ?? "";
    const model = cai("llm_model") ?? env.LLM_MODEL ?? "";
    ra.push({ ten: "Cấu hình LLM", muc: baseUrl && model ? "ok" : "loi", chiTiet: baseUrl && model ? `${model} @ ${baseUrl}` : "chưa nhập ở dashboard > Nhà cung cấp LLM" });

    const tk = db.prepare("SELECT id, loai, enabled FROM accounts").all() as { id: string; loai: string; enabled: number }[];
    for (const a of tk.filter((x) => x.enabled === 1 && x.loai !== "bot")) {
      const co = fs.existsSync(path.join(dataDir, "accounts", a.id, "credentials.enc"));
      ra.push({ ten: `Tài khoản ${a.id}`, muc: co ? "ok" : "loi", chiTiet: co ? "có phiên đăng nhập" : "chưa đăng nhập - quét QR ở dashboard > Accounts" });
    }
    if (!tk.length) ra.push({ ten: "Tài khoản Zalo", muc: "canh", chiTiet: "chưa thêm tài khoản nào" });
  } finally {
    db.close();
  }

  const tmp = path.join(dataDir, "tmp");
  if (fs.existsSync(tmp)) {
    const cu = fs.readdirSync(tmp).map((f) => path.join(tmp, f)).filter((f) => Date.now() - fs.statSync(f).mtimeMs > 24 * 3600_000);
    if (cu.length) {
      ra.push({
        ten: "File tạm cũ",
        muc: "canh",
        chiTiet: `${cu.length} file tạm cũ hơn 1 ngày`,
        sua: () => (cu.forEach((f) => fs.rmSync(f, { recursive: true, force: true })), `đã xóa ${cu.length} file tạm`),
      });
    }
  }
  return ra;
}

export async function kiemDangChay({ env }: MoiTruong, fetchFn: typeof fetch = fetch): Promise<KetQuaKiem[]> {
  const ra: KetQuaKiem[] = [];
  const port = env.DASHBOARD_PORT || "3910";
  try {
    await fetchFn(`http://127.0.0.1:${port}/`, { signal: AbortSignal.timeout(3000) });
    ra.push({ ten: "Bot đang chạy", muc: "ok", chiTiet: `dashboard trả lời ở cổng ${port}` });
  } catch {
    ra.push({ ten: "Bot đang chạy", muc: "canh", chiTiet: `không có gì trả lời ở cổng ${port} - bot chưa chạy hoặc dashboard tắt` });
  }
  return ra;
}

/** Router LLM có trả lời không (mọi mã HTTP đều tính là thông; chỉ lỗi mạng là hỏng). */
export async function kiemRouter(baseUrl: string, trongDocker: boolean, fetchFn: typeof fetch = fetch): Promise<KetQuaKiem> {
  try {
    const r = await fetchFn(`${baseUrl.replace(/\/+$/, "")}/models`, { signal: AbortSignal.timeout(5000) });
    return { ten: "Kết nối router LLM", muc: "ok", chiTiet: `${baseUrl} (HTTP ${r.status})` };
  } catch {
    const goiY = trongDocker && /localhost|127\.0\.0\.1/.test(baseUrl) ? " - trong Docker hãy đổi localhost thành host.docker.internal" : "";
    return { ten: "Kết nối router LLM", muc: "loi", chiTiet: `không kết nối được ${baseUrl}${goiY}` };
  }
}

/** Chạy một lệnh ngoài và trả chữ in ra, hoặc null nếu lệnh không có/lỗi. Tiêm được để test. */
export type ChayLenh = (lenh: string, thamSo: string[]) => string | null;
const chayLenhThat: ChayLenh = (lenh, thamSo) => {
  try {
    return execFileSync(lenh, thamSo, { encoding: "utf8", timeout: 10_000, stdio: ["ignore", "pipe", "ignore"] });
  } catch {
    return null;
  }
};

/**
 * Điều kiện để xem Zalo Agent từ điện thoại (ứng dụng /m): Tailscale đã cài và đã `tailscale serve` cổng
 * dashboard qua HTTPS. KHÔNG bắt buộc nên chỉ báo "canh", không bao giờ "loi". Không in địa chỉ nào ngoài
 * địa chỉ https của chính máy này.
 */
export function kiemUngDungDienThoai({ env }: MoiTruong, chay: ChayLenh = chayLenhThat): KetQuaKiem[] {
  const port = env.DASHBOARD_PORT || "3910";
  if (chay("tailscale", ["version"]) === null) {
    return [{ ten: "Ứng dụng điện thoại", muc: "canh", chiTiet: "chưa cài Tailscale - cần nếu muốn xem bot từ điện thoại (xem docs/ung-dung-dien-thoai.md)" }];
  }
  const trangThai = chay("tailscale", ["serve", "status"]);
  const dong = trangThai?.split(/\r?\n/).find((d) => d.includes(`127.0.0.1:${port}`) || d.includes(`localhost:${port}`));
  const url = /https:\/\/[^\s]+/.exec(trangThai ?? "")?.[0];
  if (dong && url) return [{ ten: "Ứng dụng điện thoại", muc: "ok", chiTiet: `mở ${url.replace(/\/$/, "")}/m trên điện thoại (đã cài Tailscale và đăng nhập cùng tài khoản)` }];
  return [{ ten: "Ứng dụng điện thoại", muc: "canh", chiTiet: `đã có Tailscale nhưng chưa chia sẻ dashboard qua HTTPS - chạy: tailscale serve --bg ${port}` }];
}
