/**
 * Bảng màu cho file .pdf - model CHỌN theo ngữ cảnh tài liệu, không tự do hex.
 *
 * Dùng ĐÚNG 6 tên theme của `xlsx-themes.ts` và đúng các mã màu đó, cố ý:
 * model chỉ phải học một bộ từ vựng cho cả Excel lẫn PDF, và báo cáo xuất ra hai
 * định dạng thì trông như anh em thay vì hai tài liệu lạ. Màu nền đậm ở đây đã
 * được đo contrast với chữ trắng đạt WCAG AA - xem số đo trong `xlsx-themes.ts`.
 *
 * Module THUẦN: không log, không đọc env, không chạm DB.
 */

export type PdfTheme = {
  /** Màu đậm: tiêu đề, đầu bảng (chữ trắng đè lên), vạch nhấn */
  readonly chinh: string;
  /** Nền rất nhạt: sọc bảng, khối trích dẫn */
  readonly nhat: string;
  /** Viền nhạt cùng tông */
  readonly vien: string;
};

export const PDF_THEMES = {
  /** Trang trọng - báo cáo tổng hợp, mặc định */
  navy: { chinh: "#1F3864", nhat: "#F2F5FA", vien: "#C3CFE2" },
  /** Tài chính, kinh doanh, báo giá */
  blue: { chinh: "#1F4E79", nhat: "#F2F7FC", vien: "#C4D5EC" },
  /** Tăng trưởng, nông nghiệp, môi trường, kết quả tốt */
  green: { chinh: "#1E6B3A", nhat: "#F1F8F3", vien: "#BBD9C4" },
  /** Cảnh báo, rủi ro, pháp lý, sự cố */
  burgundy: { chinh: "#8B2635", nhat: "#FCF3F4", vien: "#E4C2C7" },
  /** Kỹ thuật, vận hành, trung tính */
  slate: { chinh: "#44546A", nhat: "#F4F6F8", vien: "#CDD5DF" },
  /** Y tế, giáo dục, dịch vụ */
  teal: { chinh: "#17646B", nhat: "#F0F8F8", vien: "#B6D8DB" },
} as const satisfies Record<string, PdfTheme>;

export type PdfThemeName = keyof typeof PDF_THEMES;

export const PDF_THEME_NAMES = Object.keys(PDF_THEMES) as [PdfThemeName, ...PdfThemeName[]];

export const DEFAULT_PDF_THEME: PdfThemeName = "navy";

/**
 * Nền bút dạ cho chữ nhấn. Một màu dùng chung cho mọi theme, cố ý: vàng hổ phách
 * là màu ai cũng đọc ra là "bôi highlight", và nó bổ trợ được cả 6 tông trên.
 * Chữ bên trong vẫn lấy màu đậm của theme nên tương phản luôn đủ.
 */
export const NEN_NHAN = "#FFF3CD";

export function chonPdfTheme(name: PdfThemeName | undefined): PdfTheme {
  return PDF_THEMES[name ?? DEFAULT_PDF_THEME];
}
