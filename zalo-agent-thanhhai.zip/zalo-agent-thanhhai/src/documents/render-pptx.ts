import { createRequire } from "node:module";
import type PptxGenJSType from "pptxgenjs";
import type { PresentationSlide } from "./document-content-schema.js";
import { chonPdfTheme, type PdfTheme, type PdfThemeName } from "./pdf-themes.js";

/**
 * Dựng file .pptx từ nội dung model cung cấp, bằng `pptxgenjs` (thuần JS/TS,
 * không phụ thuộc native hay Python - xem quyết định 2026-09-17 về việc từ
 * chối tích hợp PPTMaster vì nó là AI coding-agent tool Python, không phải
 * library gọi được).
 *
 * Dùng LẠI đúng bảng màu + tên theme của `create_pdf_file` (`pdf-themes.ts`) -
 * model chỉ học một bộ từ vựng màu cho mọi định dạng file xuất ra. pptxgenjs
 * nhận hex KHÔNG có dấu "#" (khác CSS của PDF) nên phải bỏ dấu đó trước khi
 * truyền màu vào thư viện - xem hàm `hex()`.
 *
 * 6 loại slide (title/section/bullets/table/stat_highlight/two_content) đủ
 * cho phần lớn nhu cầu thuyết trình mà không bắt model học API dựng
 * shape/text-box thủ công của pptxgenjs.
 *
 * **Giới hạn đã kiểm chứng thật (2026-09-22, so sánh 10 repo trình chiếu theo
 * yêu cầu người dùng): pptxgenjs KHÔNG hỗ trợ transition/animation lẫn
 * gradient** - grep thẳng bộ type của bản đã cài, không có dòng nào nhắc tới
 * "transition"/"animation"/"gradient". Đây là giới hạn CỨNG của thư viện
 * (định dạng OOXML animation nằm ở khối `p:timing` cực phức tạp mà hầu hết
 * thư viện sinh file - kể cả `python-pptx` - đều không đụng tới), không phải
 * do cách gọi. Các repo "đẹp/có hiệu ứng" khác đã khảo sát (reveal.js/Slidev/
 * Marp) đều KHÔNG sinh ra .pptx gốc sửa được: mặc định chụp ảnh từng slide rồi
 * nhét vào pptx (chữ không chọn được), chế độ "editable" của Marp còn đòi cài
 * LibreOffice (đúng thứ CLAUDE.md đã né từ trước). Repo duy nhất có animation
 * thật (`iOfficeAI/OfficeCLI`) là binary .NET, ngoài phạm vi Node/TS thuần.
 * Bản nâng cấp lần này vì vậy chỉ CẢI THIỆN BỐ CỤC/MÀU SẮC (slide master dùng
 * chung, đánh số trang tự động, thêm 2 loại slide), KHÔNG thêm animation.
 */

const PptxGenJS: typeof PptxGenJSType = createRequire(import.meta.url)("pptxgenjs");

const FONT_FACE = "Arial";
// 13.33" x 7.5" - khổ 16:9 chuẩn của PowerPoint hiện đại (LAYOUT_16x9 cũ hẹp hơn,
// dành cho màn hình đời trước)
const SLIDE_W = 13.33;
const SLIDE_H = 7.5;
const MARGIN = 0.5;
const CONTENT_W = SLIDE_W - MARGIN * 2;
const HEADING_H = 0.9;
/** Dải màu nhạt mỏng ngay dưới thanh tiêu đề đậm - tạo chiều sâu 2 tông màu vì
 * pptxgenjs không có gradient để làm mềm cạnh chuyển màu */
const ACCENT_H = 0.06;
/** Tên slide master DÙNG CHUNG cho mọi slide "nội dung" (khác title/section) -
 * gộp nền nhạt + đánh số trang tự động vào MỘT chỗ khai báo thay vì lặp lại
 * addShape/addText ở từng hàm render. */
const MASTER_NOI_DUNG = "ZALO_AGENT_NOI_DUNG";

/** pptxgenjs nhận hex KHÔNG có dấu "#", khác mọi theme khác trong repo */
const hex = (mau: string): string => mau.replace("#", "");

/**
 * Chữ có marker "**đậm**" -> mảng run cho pptxgenjs, cùng quy ước với
 * docx/xlsx. `breakLine` đặt ở run CUỐI của mỗi dòng để dòng sau xuống hàng
 * mới - đặt sai vị trí thì các dòng dính liền thành một đoạn.
 */
function boldRuns(
  text: string,
  base: Partial<PptxGenJSType.TextPropsOptions>,
  breakLineAtEnd: boolean,
): PptxGenJSType.TextProps[] {
  const parts = text.split(/\*\*([^*]+)\*\*/g).filter((s) => s.length > 0);
  const segments = parts.length > 0 ? parts : [""];
  return segments.map((part, index) => ({
    text: part,
    options: {
      ...base,
      bold: base.bold || index % 2 === 1,
      breakLine: index === segments.length - 1 ? breakLineAtEnd : false,
    },
  }));
}

/** Danh sách bullet -> 1 khối run duy nhất, mỗi item là 1 đoạn (paragraph) riêng */
function bulletRuns(items: string[], color: string): PptxGenJSType.TextProps[] {
  return items.flatMap((item, index) =>
    boldRuns(item, { fontFace: FONT_FACE, fontSize: 18, color, bullet: true }, index < items.length - 1),
  );
}

/**
 * Thanh tiêu đề 2 tông: dải đậm (màu chính) + dải nhạt mỏng ngay dưới. Thêm
 * `ZALO_AGENT_NOI_DUNG` làm slide master cho slide gọi hàm này nên KHÔNG cần
 * addSlide riêng - caller tự truyền `masterName` lúc addSlide.
 */
function addHeadingBar(slide: PptxGenJSType.Slide, heading: string, theme: PdfTheme): void {
  slide.addShape("rect", {
    x: 0,
    y: 0,
    w: SLIDE_W,
    h: HEADING_H,
    fill: { color: hex(theme.chinh) },
    line: { type: "none" },
  });
  slide.addShape("rect", {
    x: 0,
    y: HEADING_H,
    w: SLIDE_W,
    h: ACCENT_H,
    fill: { color: hex(theme.vien) },
    line: { type: "none" },
  });
  slide.addText(heading.replaceAll("**", ""), {
    x: MARGIN,
    y: 0,
    w: CONTENT_W,
    h: HEADING_H,
    fontFace: FONT_FACE,
    fontSize: 26,
    bold: true,
    color: "FFFFFF",
    valign: "middle",
  });
}

/** Khai slide master 1 lần/file: nền nhạt đồng bộ mọi slide nội dung + đánh số
 * trang tự động (field thật của PowerPoint, tự cập nhật nếu người nhận thêm/
 * xoá/đảo slide sau này - không phải chữ "2/8" viết cứng). */
function khaiSlideMaster(pptx: PptxGenJSType, theme: PdfTheme): void {
  pptx.defineSlideMaster({
    title: MASTER_NOI_DUNG,
    background: { color: hex(theme.nhat) },
    slideNumber: {
      x: SLIDE_W - 0.7,
      y: SLIDE_H - 0.35,
      w: 0.5,
      h: 0.3,
      fontFace: FONT_FACE,
      fontSize: 10,
      color: hex(theme.chinh),
      align: "right",
    },
  });
}

function renderTitleSlide(
  pptx: PptxGenJSType,
  slide: Extract<PresentationSlide, { type: "title" }>,
  theme: PdfTheme,
): void {
  const s = pptx.addSlide();
  s.background = { color: hex(theme.chinh) };
  s.addText(slide.title.replaceAll("**", ""), {
    x: MARGIN,
    y: SLIDE_H / 2 - 1,
    w: CONTENT_W,
    h: 1.4,
    fontFace: FONT_FACE,
    fontSize: 40,
    bold: true,
    color: "FFFFFF",
    align: "center",
    valign: "middle",
  });
  if (slide.subtitle) {
    s.addText(slide.subtitle, {
      x: MARGIN,
      y: SLIDE_H / 2 + 0.5,
      w: CONTENT_W,
      h: 0.8,
      fontFace: FONT_FACE,
      fontSize: 20,
      color: "FFFFFF",
      align: "center",
      valign: "middle",
    });
  }
}

/**
 * Slide chuyển chương - CỐ Ý khác dáng slide title (canh trái + vạch nhấn
 * ngang phía trên thay vì canh giữa) để người xem phân biệt được "đây là mở
 * đầu bài" hay "đây là chuyển sang phần mới" dù cùng tông màu đậm.
 */
function renderSectionSlide(
  pptx: PptxGenJSType,
  slide: Extract<PresentationSlide, { type: "section" }>,
  theme: PdfTheme,
): void {
  const s = pptx.addSlide();
  s.background = { color: hex(theme.chinh) };
  const midY = SLIDE_H / 2;
  s.addShape("rect", {
    x: MARGIN,
    y: midY - 0.5,
    w: 1.2,
    h: 0.06,
    fill: { color: "FFFFFF" },
    line: { type: "none" },
  });
  s.addText(slide.title.replaceAll("**", ""), {
    x: MARGIN,
    y: midY - 0.35,
    w: CONTENT_W,
    h: 1,
    fontFace: FONT_FACE,
    fontSize: 34,
    bold: true,
    color: "FFFFFF",
    align: "left",
    valign: "top",
  });
  if (slide.subtitle) {
    s.addText(slide.subtitle, {
      x: MARGIN,
      y: midY + 0.6,
      w: CONTENT_W,
      h: 0.6,
      fontFace: FONT_FACE,
      fontSize: 16,
      color: hex(theme.nhat),
      align: "left",
      valign: "top",
    });
  }
}

function renderBulletsSlide(
  pptx: PptxGenJSType,
  slide: Extract<PresentationSlide, { type: "bullets" }>,
  theme: PdfTheme,
): void {
  const s = pptx.addSlide({ masterName: MASTER_NOI_DUNG });
  addHeadingBar(s, slide.heading, theme);
  s.addText(bulletRuns(slide.items, "262626"), {
    x: MARGIN,
    y: HEADING_H + ACCENT_H + 0.3,
    w: CONTENT_W,
    h: SLIDE_H - HEADING_H - ACCENT_H - 0.7,
    valign: "top",
    lineSpacingMultiple: 1.3,
  });
}

function renderTableSlide(
  pptx: PptxGenJSType,
  slide: Extract<PresentationSlide, { type: "table" }>,
  theme: PdfTheme,
): void {
  const s = pptx.addSlide({ masterName: MASTER_NOI_DUNG });
  addHeadingBar(s, slide.heading, theme);

  const headerRow: PptxGenJSType.TableRow = slide.headers.map((h) => ({
    text: h,
    options: { fill: { color: hex(theme.chinh) }, color: "FFFFFF", bold: true },
  }));
  const dataRows: PptxGenJSType.TableRow[] = slide.rows.map((row, rowIndex) =>
    row.map((cell) => ({
      text: cell,
      // Sọc xen kẽ đổi màu để hợp NỀN NHẠT của slide master (trước đây nền
      // trắng, giờ nền đã có màu nên dòng chẵn cần đục hơn 1 chút mới hiện rõ)
      options: rowIndex % 2 === 1 ? { fill: { color: "FFFFFF" } } : {},
    })),
  );

  // KHÔNG bật `autoPage`: bẫy đã dính thật (2026-09-17) - pptxgenjs dùng cơ
  // chế reflow-theo-từ để ước lượng chiều cao khi autoPage bật, và cơ chế đó
  // LEAK thẳng ra XML thật, tách văn bản có khoảng trắng ("Cột A") thành 2
  // <a:p> riêng trong CÙNG một ô (đo: "Cột A" -> "Cột " + "A" tách đoạn, dù
  // input chỉ là 1 chuỗi). Chấp nhận đánh đổi: bảng dài tự tràn ra ngoài slide
  // trong PowerPoint thay vì tự tách trang - `checkPresentationLimits` +
  // DOCUMENT_MAX_ROWS đã chặn số dòng, và slide vốn không phải trang A4.
  s.addTable([headerRow, ...dataRows], {
    x: MARGIN,
    y: HEADING_H + ACCENT_H + 0.2,
    w: CONTENT_W,
    fontFace: FONT_FACE,
    fontSize: 13,
    color: "262626",
    border: { type: "solid", color: hex(theme.vien), pt: 0.75 },
  });
}

/** Tối đa 3 số cạnh nhau, chia đều bề ngang - dùng cho "báo cáo tác động"
 * (KPI, số liệu ấn tượng) thay vì nhồi vào bullet thường */
function renderStatHighlightSlide(
  pptx: PptxGenJSType,
  slide: Extract<PresentationSlide, { type: "stat_highlight" }>,
  theme: PdfTheme,
): void {
  const s = pptx.addSlide({ masterName: MASTER_NOI_DUNG });
  const top = slide.heading ? HEADING_H + ACCENT_H : 0;
  if (slide.heading) addHeadingBar(s, slide.heading, theme);

  const n = slide.stats.length;
  const gap = 0.4;
  const colW = (CONTENT_W - gap * (n - 1)) / n;
  const boxTop = top + (SLIDE_H - top - 2.6) / 2;

  slide.stats.forEach((stat, i) => {
    const x = MARGIN + i * (colW + gap);
    s.addText(stat.value, {
      x,
      y: boxTop,
      w: colW,
      h: 1.5,
      fontFace: FONT_FACE,
      fontSize: 44,
      bold: true,
      color: hex(theme.chinh),
      align: "center",
      valign: "bottom",
    });
    s.addText(stat.label, {
      x,
      y: boxTop + 1.5,
      w: colW,
      h: 0.7,
      fontFace: FONT_FACE,
      fontSize: 15,
      color: "262626",
      align: "center",
      valign: "top",
    });
    // Vạch mảnh phân cách giữa các số - chỉ vẽ TRƯỚC cột (không vẽ ở cột đầu)
    if (i > 0) {
      s.addShape("rect", {
        x: x - gap / 2,
        y: boxTop + 0.15,
        w: 0.012,
        h: 1.8,
        fill: { color: hex(theme.vien) },
        line: { type: "none" },
      });
    }
  });
}

function renderTwoContentSlide(
  pptx: PptxGenJSType,
  slide: Extract<PresentationSlide, { type: "two_content" }>,
  theme: PdfTheme,
): void {
  const s = pptx.addSlide({ masterName: MASTER_NOI_DUNG });
  addHeadingBar(s, slide.heading, theme);

  const colW = (CONTENT_W - 0.4) / 2;
  const top = HEADING_H + ACCENT_H + 0.3;
  const colH = SLIDE_H - top - 0.4;

  const column = (
    x: number,
    title: string | undefined,
    items: string[],
  ): void => {
    let y = top;
    if (title) {
      s.addText(title, {
        x,
        y,
        w: colW,
        h: 0.5,
        fontFace: FONT_FACE,
        fontSize: 18,
        bold: true,
        color: hex(theme.chinh),
      });
      y += 0.55;
    }
    s.addText(bulletRuns(items, "262626"), {
      x,
      y,
      w: colW,
      h: colH - (y - top),
      valign: "top",
      lineSpacingMultiple: 1.25,
    });
  };

  column(MARGIN, slide.leftTitle, slide.left);
  column(MARGIN + colW + 0.4, slide.rightTitle, slide.right);
}

export type PptxMeta = { theme?: PdfThemeName };

export async function renderPptx(slides: PresentationSlide[], meta: PptxMeta = {}): Promise<Buffer> {
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";
  const theme = chonPdfTheme(meta.theme);
  khaiSlideMaster(pptx, theme);

  for (const slide of slides) {
    switch (slide.type) {
      case "title":
        renderTitleSlide(pptx, slide, theme);
        break;
      case "section":
        renderSectionSlide(pptx, slide, theme);
        break;
      case "bullets":
        renderBulletsSlide(pptx, slide, theme);
        break;
      case "table":
        renderTableSlide(pptx, slide, theme);
        break;
      case "stat_highlight":
        renderStatHighlightSlide(pptx, slide, theme);
        break;
      case "two_content":
        renderTwoContentSlide(pptx, slide, theme);
        break;
    }
  }

  const data = await pptx.write({ outputType: "nodebuffer" });
  return Buffer.from(data as Uint8Array);
}
