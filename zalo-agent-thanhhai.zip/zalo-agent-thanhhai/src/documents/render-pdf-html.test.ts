import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { DocumentBlock } from "./document-content-schema.js";
import { dungHtmlChoPdf, thoatHtml } from "./render-pdf-html.js";
import { PDF_THEMES, PDF_THEME_NAMES } from "./pdf-themes.js";

const dung = (blocks: DocumentBlock[], title?: string): string =>
  dungHtmlChoPdf(blocks, title ? { title } : {});

/**
 * Chỉ phần THÂN trang. Bắt buộc khi so THỨ TỰ hoặc khẳng định "không có": tiêu đề
 * còn nằm trong thẻ title ở head, và mọi tên class đều có mặt trong khối CSS -
 * so trên cả file thì phép so vị trí luôn sai và phép phủ định luôn thất bại.
 */
const than = (html: string): string => html.slice(html.indexOf("<body>"));

describe("thoatHtml", () => {
  it("thoát đủ 4 ký tự nguy hiểm", () => {
    assert.equal(thoatHtml(`<a href="x">&</a>`), "&lt;a href=&quot;x&quot;&gt;&amp;&lt;/a&gt;");
  });

  it("thoát & TRƯỚC - không sinh ra thực thể sai", () => {
    assert.equal(thoatHtml("&lt;"), "&amp;lt;");
  });
});

describe("chốt chặn - chữ model không thành mã", () => {
  it("chữ của model KHÔNG thành thẻ HTML thật", () => {
    const html = dung([{ type: "paragraph", text: '<script>alert("x")</script>' }]);
    assert.ok(!html.includes("<script>"), "đây là đường model chèn mã vào trình duyệt");
    assert.ok(html.includes("&lt;script&gt;"));
  });

  it("tiêu đề tài liệu cũng được thoát", () => {
    const html = dung([{ type: "paragraph", text: "x" }], "<img src=x onerror=y>");
    assert.ok(!html.includes("<img src=x"));
  });

  it("ô trong bảng cũng được thoát", () => {
    const html = dung([{ type: "table", headers: ["<b>H</b>"], rows: [["<i>ô</i>"]] }]);
    assert.ok(!html.includes("<b>H</b>"));
    assert.ok(html.includes("&lt;b&gt;H&lt;/b&gt;"));
  });

  it("đậm chạy SAU khi thoát nên không mở được thẻ qua dấu sao", () => {
    const html = dung([{ type: "paragraph", text: "**<b>x</b>**" }]);
    assert.ok(html.includes("<strong>&lt;b&gt;x&lt;/b&gt;</strong>"));
  });
});

describe("trình bày dễ đọc", () => {
  it("**đậm** thành strong và được tô nền vàng để nhấn điểm chính", () => {
    const html = dung([{ type: "paragraph", text: "Doanh thu **tăng 40%** so với quý trước" }]);
    assert.ok(than(html).includes("<strong>tăng 40%</strong>"));
    assert.ok(html.includes("#FFF3CD"), "chữ nhấn phải có nền bút dạ");
  });

  it("nền bút dạ bị TẮT trong tiêu đề và đầu bảng - nền đậm rồi, bôi nữa là rối", () => {
    const html = dung([{ type: "heading", text: "Mục **quan trọng**", level: 2 }]);
    assert.ok(html.includes("h2.tieu-de strong"));
    assert.ok(html.includes("background: none"));
  });

  it("dãn dòng thoáng - chống khối chữ đặc khó nhìn", () => {
    const html = dung([{ type: "paragraph", text: "x" }]);
    assert.ok(html.includes("line-height: 1.7"));
  });

  it("mục có vạch nhấn bên trái để lướt mắt thấy bố cục", () => {
    const html = dung([{ type: "heading", text: "Mục 1", level: 2 }]);
    assert.ok(html.includes("border-left: 3pt solid"));
  });

  it("tiêu đề có vạch nhấn, nhưng KHÔNG có tiêu đề thì không vẽ vạch lơ lửng", () => {
    assert.ok(than(dung([{ type: "paragraph", text: "x" }], "Báo cáo")).includes("vach-tieu-de"));
    assert.ok(!than(dung([{ type: "paragraph", text: "x" }])).includes("vach-tieu-de"));
  });

  it("bảng có sọc xen kẽ và đầu bảng màu", () => {
    const html = dung([{ type: "table", headers: ["a"], rows: [["1"]] }]);
    assert.ok(html.includes("tbody tr:nth-child(even)"));
    assert.ok(html.includes("color: #fff"));
  });

  it("gạch đầu dòng có dấu chấm theo tông và các mục cách nhau", () => {
    const html = dung([{ type: "bullets", items: ["a", "b"] }]);
    assert.ok(html.includes("li::before"));
    assert.ok(html.includes("border-radius: 50%"));
  });
});

describe("giữ nguyên hành vi in ấn", () => {
  it("bảng có thead riêng để lặp hàng tiêu đề khi tràn trang", () => {
    const html = dung([{ type: "table", headers: ["Cột"], rows: [["1"]] }]);
    assert.ok(html.includes("<thead>"));
    assert.ok(html.includes("display: table-header-group"));
  });

  it("hàng bảng không bị cắt đôi giữa hai trang", () => {
    assert.ok(dung([{ type: "table", headers: ["a"], rows: [["b"]] }]).includes("page-break-inside: avoid"));
  });

  it("tiêu đề mục không nằm trơ cuối trang", () => {
    assert.ok(dung([{ type: "heading", text: "M", level: 2 }]).includes("page-break-after: avoid"));
  });

  // Hồi quy cho lỗi ĐÃ XẢY RA: máy bật dark mode làm Chrome đổi nền trang thành
  // đen, chữ đen trên nền đen, cả file PDF hỏng. Không test nào bắt được vì lỗi
  // chỉ hiện khi NHÌN bản in.
  it("ép giao diện sáng - nền trắng, không để dark mode của máy đổi nền", () => {
    const html = dung([{ type: "paragraph", text: "x" }]);
    assert.ok(html.includes("color-scheme: only light"));
    assert.ok(html.includes("background: #fff"));
  });

  it("khổ A4, chừa lề dưới rộng hơn cho chân trang", () => {
    const html = dung([{ type: "paragraph", text: "x" }]);
    assert.ok(html.includes("size: A4"));
    assert.ok(html.includes("margin: 16mm 18mm 24mm 18mm"), "lề dưới 24mm là chỗ của chân trang");
  });

  it("giữ nguyên dấu tiếng Việt", () => {
    const html = dung([{ type: "paragraph", text: "Cộng hòa xã hội chủ nghĩa Việt Nam" }]);
    assert.ok(html.includes("Cộng hòa xã hội chủ nghĩa Việt Nam"));
    assert.ok(html.includes('charset="utf-8"'));
  });
});

describe("tông màu", () => {
  it("mỗi tông cho ra màu khác nhau, không phải khai rồi bỏ đó", () => {
    const mau = PDF_THEME_NAMES.map(
      (tone) => dungHtmlChoPdf([{ type: "paragraph", text: "x" }], { tone }).includes(PDF_THEMES[tone].chinh),
    );
    assert.ok(mau.every(Boolean), "có tông không được áp vào CSS");
  });

  it("không chọn tông thì dùng navy", () => {
    assert.ok(dung([{ type: "paragraph", text: "x" }]).includes(PDF_THEMES.navy.chinh));
  });

  it("sáu tông của PDF trùng tên với sáu tông của Excel - model chỉ học một bộ", () => {
    assert.deepEqual([...PDF_THEME_NAMES].sort(), ["blue", "burgundy", "green", "navy", "slate", "teal"]);
  });
});
