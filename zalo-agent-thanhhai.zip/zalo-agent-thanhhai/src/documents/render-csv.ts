/**
 * Dựng nội dung .csv từ bảng (headers + rows).
 *
 * Hai việc, cả hai đều là chốt chặn chứ không phải định dạng cho đẹp:
 *
 * 1. TRÍCH DẪN theo RFC 4180 - ô chứa dấu phẩy, nháy kép hoặc xuống dòng phải
 *    bọc trong nháy kép và nhân đôi nháy bên trong. Thiếu bước này thì một ô có
 *    dấu phẩy làm lệch toàn bộ cột từ đó trở đi, mà file vẫn mở được nên không
 *    ai phát hiện.
 *
 * 2. CHẶN CSV INJECTION - ô bắt đầu bằng `=`, `+`, `-`, `@`, tab hoặc CR được
 *    Excel/Google Sheets hiểu là CÔNG THỨC, và có kỹ thuật `=cmd|'...'!A1` chạy
 *    lệnh trên máy người MỞ file. Đây đúng là mối lo repo đã xử ở ô Excel
 *    (`document-content-schema.ts`: chỉ nhận 2 phép có sẵn, không nhận công thức
 *    tự do). CSV mà thả thô là mở lại đúng cái lỗ vừa bịt, lần này nạn nhân là
 *    người nhận file chứ không phải chủ bot.
 *
 *    Cách chuẩn của OWASP: thêm dấu nháy đơn phía trước. Excel hiểu là "ô này
 *    là chữ", hiện đúng nội dung và không tính toán gì.
 *
 * Module THUẦN: không log, không đọc env, không chạm DB.
 */

/** Ký tự mở đầu khiến Excel/Sheets coi ô là công thức */
const KY_TU_NGUY_HIEM = ["=", "+", "-", "@", "\t", "\r"];

/** Thêm nháy đơn phía trước ô có thể bị hiểu là công thức */
export function chanCongThucCsv(o: string): string {
  if (!o) return o;
  return KY_TU_NGUY_HIEM.includes(o[0]!) ? `'${o}` : o;
}

/** Bọc ô theo RFC 4180 khi cần */
export function bocOCsv(o: string): string {
  if (/[",\r\n]/.test(o)) return `"${o.replace(/"/g, '""')}"`;
  return o;
}

const lamSachO = (o: string): string => bocOCsv(chanCongThucCsv(o));

export type BangCsv = {
  headers: string[];
  rows: string[][];
};

/**
 * Trả về chuỗi CSV. Dùng CRLF vì đó là dấu xuống dòng RFC 4180 quy định và là
 * thứ Excel trên Windows mong đợi.
 *
 * BOM UTF-8 đứng đầu: thiếu nó thì Excel bản Windows đọc file có dấu tiếng Việt
 * ra ký tự rác (mở bằng Notepad hay Google Sheets thì vẫn đúng, nên lỗi này rất
 * dễ lọt qua khâu kiểm thử của người viết code).
 */
export function renderCsv(bang: BangCsv): Buffer {
  const dong: string[] = [];
  dong.push(bang.headers.map(lamSachO).join(","));
  for (const row of bang.rows) {
    dong.push(row.map(lamSachO).join(","));
  }
  return Buffer.from(`﻿${dong.join("\r\n")}\r\n`, "utf-8");
}
