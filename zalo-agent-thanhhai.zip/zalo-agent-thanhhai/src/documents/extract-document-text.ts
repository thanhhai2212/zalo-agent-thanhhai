import crypto from "node:crypto";
import ExcelJS from "exceljs";
import mammoth from "mammoth";
// Type-only: entry point "legacy" dùng lúc CHẠY (`pdfjs-dist/legacy/build/pdf.mjs`,
// import động bên dưới) không tự export tên type, nhưng .d.ts của nó là
// `export * from "pdfjs-dist"` nên lấy type qua đường gốc vẫn đúng, không kéo
// runtime code (import type bị xoá lúc biên dịch).
import type { PDFPageProxy } from "pdfjs-dist";
import { describeImage } from "../agent/vision-sidecar.js";
import { createLogger } from "../shared/logger.js";
import { withTempFile } from "../shared/temp-file-store.js";
import { extractPlainText, PLAIN_TEXT_EXTENSIONS } from "./extract-plain-text.js";

const log = createLogger("extract-document-text");

/**
 * Trích chữ từ file người dùng GỬI ĐẾN (PDF/Word/Excel/PowerPoint) - khác hẳn
 * `src/documents/render-*.ts` (dựng file làm OUTPUT). Đây là bước TIỀN XỬ LÝ
 * INPUT, cùng vai trò với `stt-client.ts` cho tin nhắn thoại - không phải tool,
 * không cấu hình per-agent (chạy local, không gọi API ngoài).
 *
 * 4 thư viện chuyên biệt, không dùng `officeparser` (đọc được cả 4 định dạng
 * nhưng KÉO THEO `tesseract.js` như dependency BẮT BUỘC dù không bao giờ dùng
 * OCR - đã kiểm bằng `npm view officeparser dependencies`) và không dùng
 * `pdf-parse` (bản 2.x kéo `@napi-rs/canvas` chỉ để trích ẢNH, không cần cho
 * việc trích CHỮ). Toàn bộ pure JS/TS, không binary native - TRỪ MỘT NGOẠI LỆ
 * đã cân nhắc riêng: `@napi-rs/canvas` (dependencies) dùng để RENDER trang PDF
 * là ẢNH (không có lớp chữ) thành PNG rồi mô tả qua vision sidecar - có
 * prebuilt binary mọi platform (kiểm `npm view`), không cần Visual Studio
 * Build Tools như lo ngại ban đầu với `pdf-parse`.
 */

/** Cắt bớt để 1 file dài hàng trăm trang không phình context 1 lượt agent */
const MAX_EXTRACTED_CHARS = 20_000;

function capText(text: string): string {
  if (text.length <= MAX_EXTRACTED_CHARS) return text;
  return `${text.slice(0, MAX_EXTRACTED_CHARS)}\n\n[... đã cắt bớt, tài liệu dài hơn]`;
}

/**
 * Trang trích được ÍT chữ hơn mức này mới coi là "ứng viên" kiểm tra ảnh - đo
 * thật trên 1 báo cáo có trang chỉ lặp chân trang (~55 ký tự) xen giữa trang
 * có luận giải thật (500+ ký tự): mốc 150 tách rõ ràng 2 loại, không lãng phí
 * quét operator list trên trang chữ bình thường.
 */
const PDF_SPARSE_TEXT_CHARS = 150;
/** Trần số trang tự động render+mô tả/1 file - chặn 1 PDF toàn ảnh làm nghẽn cả lượt đang CHỜ (await) bước đọc file */
const MAX_AUTO_DESCRIBED_IMAGE_PAGES = 15;
/** Số lượt gọi vision song song - giảm tổng thời gian chờ khi nhiều trang ứng viên, không tránh khỏi hoàn toàn */
const IMAGE_DESCRIBE_CONCURRENCY = 3;
/** 1.5x đủ nét để vision đọc chữ trong ảnh, không quá nặng cho payload base64 */
const PDF_RENDER_SCALE = 1.5;

export type PageImageDescription =
  | { hasImage: false }
  | { hasImage: true; description: string | null };

/**
 * Trang có ẢNH (kiểm qua operator list, không đoán qua độ dài chữ) thì render
 * bằng `@napi-rs/canvas` (đúng pattern ví dụ Node CHÍNH THỨC của pdf.js -
 * `page.render({canvasContext, viewport})` rồi `canvas.toBuffer("image/png")`,
 * lấy từ `examples/node/pdf2png/pdf2png.mjs` qua `gh api`, không đoán) rồi mô
 * tả bằng `describeImage` (vision sidecar CÓ SẴN, dùng chung với `read_image`).
 * `cacheKey` = sha256 bytes PNG (không phải đường dẫn file - trang PDF không
 * có "đường dẫn" tự nhiên) nên nhiều trang dùng CHUNG 1 ảnh filler thì từ lần
 * 2 đọc cache tức thời, không tốn thêm lượt gọi.
 *
 * `description: null` (dù `hasImage: true`) nghĩa là sidecar chưa cấu hình
 * hoặc lỗi - KHÔNG coi là "không có ảnh", để caller ghi chú đúng thay vì im
 * lặng như trang thật sự không có gì. Bọc try/catch TOÀN BỘ: 1 trang ảnh hỏng
 * (render lỗi, sidecar sập) không được làm hỏng cả file - rơi về `{hasImage:true, description:null}`
 * (giả định thận trọng "có gì đó nhưng chưa xử lý được" thay vì im lặng coi
 * như trang trống).
 */
export async function describePageImageIfAny(
  page: PDFPageProxy,
  pageNum: number,
): Promise<PageImageDescription> {
  try {
    const { OPS } = await import("pdfjs-dist/legacy/build/pdf.mjs");
    const imageOps = new Set<number>([OPS.paintImageXObject, OPS.paintInlineImageXObject, OPS.paintImageXObjectRepeat]);
    const opList = await page.getOperatorList();
    if (!opList.fnArray.some((fn) => imageOps.has(fn))) return { hasImage: false };

    const { createCanvas } = await import("@napi-rs/canvas");
    const viewport = page.getViewport({ scale: PDF_RENDER_SCALE });
    const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
    const context = canvas.getContext("2d");
    // Ép qua đúng type tham số `page.render` khai báo (không nêu tên
    // `HTMLCanvasElement`/`CanvasRenderingContext2D` - type DOM, tsconfig dự án
    // không có lib "dom") - đối tượng `@napi-rs/canvas` trả về đúng hình dạng
    // pdf.js cần lúc CHẠY (đã xác nhận qua ví dụ Node chính thức của pdf.js),
    // chỉ lệch khai báo type vì bản .d.ts của pdfjs-dist viết cho môi trường DOM.
    const renderParams = { canvas, canvasContext: context, viewport } as unknown as Parameters<
      PDFPageProxy["render"]
    >[0];
    await page.render(renderParams).promise;
    const png = canvas.toBuffer("image/png");

    const cacheKey = `pdf-page:${crypto.createHash("sha256").update(png).digest("hex")}`;
    const description = await describeImage({ base64: png.toString("base64"), mediaType: "image/png", cacheKey });
    return { hasImage: true, description };
  } catch (err) {
    log.debug({ pageNum, err }, "Không mô tả được ảnh trang PDF - bỏ qua");
    return { hasImage: true, description: null };
  }
}

export type PageImageDescriber = typeof describePageImageIfAny;

/**
 * Ghép các item chữ của 1 trang thành dòng - dùng `item.hasEOL` (cờ CHÍNH THỨC
 * của pdf.js đánh dấu "sau item này có xuống dòng", xác nhận từ type def
 * `TextItem`), KHÔNG tự suy ra dòng qua toạ độ Y (dễ sai với bảng/cột lệch).
 *
 * Bản đầu ghép TẤT CẢ item của cả trang bằng dấu cách - đúng lỗi đã gặp thật:
 * bảng nhiều dòng/cột bị dồn thành 1 dòng chữ liền mạch, model đọc được số
 * liệu (tính đúng tổng) nhưng KHÔNG dám ghép lại chính xác từng dòng khi
 * người dùng nhờ tái tạo bảng đó ra file khác - đúng phản xạ thận trọng, vì
 * đầu vào của nó thật sự đã mất cấu trúc hàng/cột.
 */
// Không đặt tên type `TextItem`/`TextMarkedContent` tường minh - entry point
// "legacy" của pdfjs-dist không export riêng 2 type này, chỉ suy ra được qua
// kiểu trả về của `getTextContent()`. Để TS tự suy kiểu tham số, hàm này nằm
// NGAY TRONG `extractPdfText` thay vì tách file-scope với annotation tường minh.
function ghepDongTuTextItems(items: Awaited<ReturnType<PDFPageProxy["getTextContent"]>>["items"]): string {
  const lines: string[] = [];
  let current = "";
  for (const item of items) {
    if (!("str" in item)) continue;
    current += (current && !current.endsWith(" ") ? " " : "") + item.str;
    if (item.hasEOL) {
      lines.push(current);
      current = "";
    }
  }
  if (current) lines.push(current);
  return lines.join("\n");
}

/**
 * PDF không có lớp chữ Ở BẤT KỲ TRANG NÀO (bản scan/ảnh chụp toàn bộ) trả về
 * CHUỖI RỖNG sau `.trim()` - kết quả HỢP LỆ, không phải lỗi (`readBatchDocuments`
 * nhận diện ca này thành thông báo riêng). Dùng `pdfjs-dist` trực tiếp (không
 * qua `pdf-parse`) qua entry point "legacy" - bản dành cho Node.js, không cần
 * DOM/worker như bản browser mặc định (xác nhận từ ví dụ Node chính thức của
 * pdf.js, không đoán).
 *
 * Trang có ÍT chữ (dưới `PDF_SPARSE_TEXT_CHARS`, ví dụ chỉ lặp chân trang) mà
 * THẬT SỰ có ảnh thì tự render + mô tả qua `describePageImage` (xem
 * `describePageImageIfAny`) rồi GỘP THẲNG vào text - ca thật đã gặp: 1 báo cáo
 * PDF có hẳn 1 phần (36 trang) là thiết kế đồ họa xuất PDF, không có chữ thật.
 * Trang KHÔNG có chữ (0 item) vẫn bỏ hẳn như trước - CHƯA mở rộng kiểm ảnh cho
 * ca này (phạm vi khác: PDF toàn bộ là bản scan, để dành nếu cần sau).
 */
export async function extractPdfText(
  data: Buffer,
  describePageImage: PageImageDescriber = describePageImageIfAny,
): Promise<string> {
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  // Thiếu `standardFontDataUrl` (font chuẩn không nhúng trong PDF) chỉ sinh 1
  // WARNING vô hại (UnknownErrorException) - không ảnh hưởng chữ trích được,
  // vì text nằm trong content stream của PDF, không phụ thuộc dữ liệu font để
  // vẽ glyph. Không trỏ đường dẫn cho tham số này để tránh giả định cấu trúc
  // thư mục nội bộ của `pdfjs-dist` (đã đổi giữa các bản major).
  const loadingTask = getDocument({ data: new Uint8Array(data) });
  try {
    const doc = await loadingTask.promise;

    // Pass 1: trích text từng trang (rẻ) - ĐÁNH SỐ TRANG THẬT, đo thật trên
    // báo cáo Thần số học 63 trang: thiếu số trang, model được hỏi "trang nào
    // rỗng" phải ĐOÁN mò và bịa sai hẳn khoảng trang.
    const pageTexts: { pageNum: number; text: string }[] = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const page = await doc.getPage(i);
      try {
        const content = await page.getTextContent();
        const line = ghepDongTuTextItems(content.items);
        if (line) pageTexts.push({ pageNum: i, text: line });
      } finally {
        page.cleanup();
      }
    }

    // Pass 2: trang chữ ít -> kiểm/mô tả ảnh, tối đa MAX_AUTO_DESCRIBED_IMAGE_PAGES
    // trang ĐẦU trong số ứng viên, chạy IMAGE_DESCRIBE_CONCURRENCY lượt song
    // song mỗi đợt (đỡ tổng thời gian chờ - bước này đang bị `await` trước khi
    // lượt agent bắt đầu chạy).
    const candidates = pageTexts.filter((p) => p.text.length < PDF_SPARSE_TEXT_CHARS).map((p) => p.pageNum);
    const toDescribe = candidates.slice(0, MAX_AUTO_DESCRIBED_IMAGE_PAGES);
    const overflow = candidates.length - toDescribe.length;

    const descriptions = new Map<number, PageImageDescription>();
    for (let i = 0; i < toDescribe.length; i += IMAGE_DESCRIBE_CONCURRENCY) {
      const chunk = toDescribe.slice(i, i + IMAGE_DESCRIBE_CONCURRENCY);
      const results = await Promise.all(
        chunk.map(async (pageNum): Promise<[number, PageImageDescription]> => {
          const page = await doc.getPage(pageNum);
          try {
            return [pageNum, await describePageImage(page, pageNum)];
          } finally {
            page.cleanup();
          }
        }),
      );
      for (const [pageNum, result] of results) descriptions.set(pageNum, result);
    }

    const pages = pageTexts.map(({ pageNum, text }) => {
      const result = descriptions.get(pageNum);
      if (result?.hasImage && result.description) {
        return `=== Trang ${pageNum}/${doc.numPages} (ảnh - mô tả tự động) ===\n${result.description}`;
      }
      // `result.hasImage === true` mà `description === null` = sidecar lỗi/chưa
      // cấu hình - ghi chú thay vì im lặng nuốt. `result.hasImage === false`
      // (chữ ít nhưng KHÔNG có ảnh, vd 1 trang tiêu đề ngắn) thì giữ nguyên,
      // không thêm ghi chú sai sự thật.
      const note = result?.hasImage && !result.description ? " (trang có ảnh, chưa mô tả được)" : "";
      return `=== Trang ${pageNum}/${doc.numPages} ===\n${text}${note}`;
    });

    let ketQua = capText(pages.join("\n\n").trim());
    if (overflow > 0) {
      ketQua += `\n\n[... còn ${overflow} trang khác cũng là ảnh, chưa mô tả tự động - hỏi cụ thể số trang nếu cần]`;
    }
    return ketQua;
  } finally {
    // `.destroy()` nằm ở loading task (huỷ luôn worker), không phải ở document
    // proxy đã resolve - xác nhận từ chính type def của pdfjs-dist.
    await loadingTask.destroy();
  }
}

/** `extractRawText` (không phải `convertToMarkdown` - chính docs mammoth ghi rõ đường markdown đã deprecated) */
export async function extractDocxText(data: Buffer): Promise<string> {
  const result = await mammoth.extractRawText({ buffer: data });
  return capText(result.value.trim());
}

/** Mỗi sheet 1 khối, các ô nối bằng tab - đủ để agent đọc số liệu, không cần đẹp */
export async function extractXlsxText(data: Buffer): Promise<string> {
  const workbook = new ExcelJS.Workbook();
  // exceljs tự khai `declare interface Buffer extends ArrayBuffer {}` trong
  // index.d.ts (không bọc trong `declare global`, nên merge thẳng vào type
  // `Buffer` toàn cục) - lệch với `Buffer` generic của @types/node hiện tại
  // dù cùng là 1 Buffer thật lúc chạy. Ép qua đúng type tham số exceljs khai
  // báo (không nêu tên "Buffer" trực tiếp) để né việc merge đó.
  await workbook.xlsx.load(data as unknown as Parameters<typeof workbook.xlsx.load>[0]);

  const sheets: string[] = [];
  workbook.eachSheet((sheet) => {
    const lines: string[] = [`Sheet "${sheet.name}":`];
    sheet.eachRow((row) => {
      const cells = (row.values as unknown[]).slice(1).map((v) => (v == null ? "" : String(v)));
      lines.push(cells.join("\t"));
    });
    sheets.push(lines.join("\n"));
  });
  return capText(sheets.join("\n\n").trim());
}

/**
 * `node-pptx-parser` CHỈ nhận file path (không nhận buffer) - phải ghi tạm ra
 * đĩa. Dùng `withTempFile` (không phải `withNamedTempFile`): file này không
 * bao giờ hiện tên cho ai xem, chỉ để lib đọc rồi xóa ngay.
 */
export async function extractPptxText(data: Buffer): Promise<string> {
  const { default: PptxParser } = await import("node-pptx-parser");
  return withTempFile("tai-lieu.pptx", data, async (filePath) => {
    const parser = new PptxParser(filePath);
    const slides = await parser.extractText();
    const text = slides.map((slide) => slide.text.join("\n")).join("\n\n");
    return capText(text.trim());
  });
}

export const SUPPORTED_DOCUMENT_EXTENSIONS = ["pdf", "docx", "xlsx", "pptx", ...PLAIN_TEXT_EXTENSIONS] as const;
export type SupportedDocumentExtension = (typeof SUPPORTED_DOCUMENT_EXTENSIONS)[number];

export function isSupportedDocumentExtension(ext: string): ext is SupportedDocumentExtension {
  return (SUPPORTED_DOCUMENT_EXTENSIONS as readonly string[]).includes(ext);
}

/** Dispatch theo đuôi file - throw nếu đuôi lạ hoặc file hỏng, caller (media-store.ts) quyết định câu thông báo */
export async function extractDocumentText(data: Buffer, ext: string): Promise<string> {
  switch (ext) {
    case "pdf":
      return extractPdfText(data);
    case "docx":
      return extractDocxText(data);
    case "xlsx":
      return extractXlsxText(data);
    case "pptx":
      return extractPptxText(data);
    default:
      if ((PLAIN_TEXT_EXTENSIONS as readonly string[]).includes(ext)) return extractPlainText(data, ext);
      throw new Error(`Định dạng ".${ext}" chưa hỗ trợ đọc`);
  }
}
