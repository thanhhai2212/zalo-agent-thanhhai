/**
 * Lọc HTML do model sinh ra TRƯỚC khi ghi thành file gửi đi.
 *
 * Vì sao cần, dù model là "của mình": file .html gửi qua Zalo được NGƯỜI KHÁC mở
 * bằng trình duyệt, nên `<script>` trong đó chạy trên máy họ. Bot này đọc tin
 * của người lạ trong nhóm và kéo nội dung web về, nên nội dung điều khiển model
 * có thể do người ngoài soạn - đúng mô hình đe dọa mà repo đã chốt ở tool tài
 * liệu ("chỉ nhận dữ liệu, không chạy code do model sinh ra"). Ở đây không cấm
 * được HTML (đó là cả điểm của định dạng này), nên cấm phần CHẠY ĐƯỢC.
 *
 * Bỏ: thẻ script/iframe/object/embed/link/meta/base/form, mọi thuộc tính `on*`
 * (onclick, onerror, onload...), và URL giao thức `javascript:`/`vbscript:`/
 * `data:text/html`. Giữ nguyên phần trình bày: CSS trong `style`, bảng, màu, ảnh.
 *
 * MỌI biểu thức ở đây TUYẾN TÍNH - không có nhóm lặp lồng nhau, không backtrack
 * cấp số nhân. Nội dung vào đây có thể do người lạ lái nên ReDoS là rủi ro thật.
 *
 * Module THUẦN: không log, không đọc env, không chạm DB.
 */

/** Thẻ bị bỏ CẢ nội dung bên trong (mở -> đóng) */
const THE_BO_CA_RUOT = ["script", "iframe", "object", "embed", "form", "noscript"];

/** Thẻ bị bỏ, vốn không có nội dung */
const THE_DON_BO = ["link", "meta", "base"];

export type KetQuaLoc = {
  html: string;
  /** Tên những thứ đã bị bỏ - để báo lại cho model biết mà không im lặng */
  daBo: string[];
};

export function locHtmlAnToan(raw: string): KetQuaLoc {
  let html = raw;
  const daBo: string[] = [];

  for (const the of THE_BO_CA_RUOT) {
    // [^]*? lười, không lồng nhóm lặp -> tuyến tính
    const re = new RegExp(`<${the}\\b[^>]*>[^]*?</${the}\\s*>`, "gi");
    const truoc = html;
    html = html.replace(re, "");
    // Thẻ mở không có thẻ đóng (model viết lỗi) vẫn phải bỏ
    const reHo = new RegExp(`<\\/?${the}\\b[^>]*>`, "gi");
    html = html.replace(reHo, "");
    if (html !== truoc) daBo.push(`<${the}>`);
  }

  for (const the of THE_DON_BO) {
    const re = new RegExp(`<${the}\\b[^>]*>`, "gi");
    const truoc = html;
    html = html.replace(re, "");
    if (html !== truoc) daBo.push(`<${the}>`);
  }

  // Thuộc tính bắt sự kiện: on... = "..." | '...' | khong-nhay
  const truocOn = html;
  html = html.replace(/\son[a-z-]{2,24}\s*=\s*"[^"]*"/gi, "");
  html = html.replace(/\son[a-z-]{2,24}\s*=\s*'[^']*'/gi, "");
  html = html.replace(/\son[a-z-]{2,24}\s*=\s*[^\s>]+/gi, "");
  if (html !== truocOn) daBo.push("thuộc tính on* (onclick, onerror...)");

  // URL chạy được trong href/src/action - thay bằng # thay vì xóa cả thuộc tính
  // để bố cục không vỡ
  const truocUrl = html;
  html = html.replace(
    /\b(href|src|action|formaction)\s*=\s*"(?:\s|&#\d+;)*(?:javascript|vbscript):[^"]*"/gi,
    '$1="#"',
  );
  html = html.replace(
    /\b(href|src|action|formaction)\s*=\s*'(?:\s|&#\d+;)*(?:javascript|vbscript):[^']*'/gi,
    "$1='#'",
  );
  html = html.replace(
    /\b(href|src|action|formaction)\s*=\s*"\s*data:text\/html[^"]*"/gi,
    '$1="#"',
  );
  html = html.replace(
    /\b(href|src|action|formaction)\s*=\s*'\s*data:text\/html[^']*'/gi,
    "$1='#'",
  );
  if (html !== truocUrl) daBo.push("URL javascript:/data:text/html");

  return { html, daBo };
}

/**
 * Bọc thành trang HTML hoàn chỉnh nếu model chỉ gửi phần thân.
 *
 * Nhận biết bằng việc CÓ thẻ <html> hay không, không đoán theo độ dài: model
 * thường gửi trọn trang khi được yêu cầu "làm file HTML", nhưng cũng có lúc chỉ
 * gửi mấy khối <h1>/<p>.
 */
export function bocTrangHtml(noiDung: string, tieuDe: string): string {
  if (/<html\b/i.test(noiDung)) return noiDung;
  const tieuDeAnToan = tieuDe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  return [
    "<!doctype html>",
    '<html lang="vi">',
    "<head>",
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width, initial-scale=1">',
    `<title>${tieuDeAnToan}</title>`,
    "<style>",
    "body{font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;line-height:1.6;",
    "max-width:820px;margin:0 auto;padding:24px;color:#1a1a1a}",
    "table{border-collapse:collapse;width:100%;margin:16px 0}",
    "th,td{border:1px solid #d0d0d0;padding:8px 10px;text-align:left}",
    "th{background:#f4f4f5}",
    "code{background:#f4f4f5;padding:2px 5px;border-radius:3px}",
    "</style>",
    "</head>",
    "<body>",
    noiDung,
    "</body>",
    "</html>",
  ].join("\n");
}
