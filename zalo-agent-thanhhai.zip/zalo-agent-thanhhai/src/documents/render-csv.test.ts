import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { bocOCsv, chanCongThucCsv, renderCsv } from "./render-csv.js";

const doc = (buf: Buffer): string => buf.toString("utf-8").replace(/^﻿/, "");

describe("chanCongThucCsv", () => {
  it("thêm nháy đơn trước ô mở đầu bằng ký tự công thức", () => {
    for (const dau of ["=", "+", "-", "@", "\t", "\r"]) {
      assert.equal(chanCongThucCsv(`${dau}NGUY_HIEM`), `'${dau}NGUY_HIEM`);
    }
  });

  it("chặn đúng payload chạy lệnh kinh điển", () => {
    const out = chanCongThucCsv(`=cmd|'/c calc'!A1`);
    assert.ok(out.startsWith("'="), "phải bắt đầu bằng nháy đơn để Excel coi là chữ");
  });

  it("KHÔNG đụng vào ô bình thường", () => {
    assert.equal(chanCongThucCsv("Nguyễn Văn A"), "Nguyễn Văn A");
    assert.equal(chanCongThucCsv("1000"), "1000");
    assert.equal(chanCongThucCsv(""), "");
  });

  it("số âm cũng bị chặn - đúng ý, vì Excel vẫn tính nó là công thức", () => {
    assert.equal(chanCongThucCsv("-500"), "'-500");
  });
});

describe("bocOCsv", () => {
  it("bọc ô có dấu phẩy", () => {
    assert.equal(bocOCsv("Hà Nội, Việt Nam"), '"Hà Nội, Việt Nam"');
  });

  it("nhân đôi nháy kép bên trong", () => {
    assert.equal(bocOCsv('ông "Tư"'), '"ông ""Tư"""');
  });

  it("bọc ô có xuống dòng", () => {
    assert.equal(bocOCsv("dòng 1\ndòng 2"), '"dòng 1\ndòng 2"');
  });

  it("để yên ô bình thường", () => {
    assert.equal(bocOCsv("binh thuong"), "binh thuong");
  });
});

describe("renderCsv", () => {
  it("dựng đúng header và dòng, phân cách CRLF", () => {
    const out = doc(renderCsv({ headers: ["Tên", "Tuổi"], rows: [["An", "30"], ["Bình", "25"]] }));
    assert.equal(out, "Tên,Tuổi\r\nAn,30\r\nBình,25\r\n");
  });

  it("có BOM UTF-8 để Excel Windows đọc đúng tiếng Việt", () => {
    const buf = renderCsv({ headers: ["Tên"], rows: [["Đỗ"]] });
    assert.equal(buf[0], 0xef);
    assert.equal(buf[1], 0xbb);
    assert.equal(buf[2], 0xbf);
  });

  it("áp chốt công thức cho CẢ header, không chỉ ô dữ liệu", () => {
    const out = doc(renderCsv({ headers: ["=HACK()"], rows: [["ok"]] }));
    assert.ok(out.startsWith("'=HACK()"));
  });

  it("ô vừa có công thức vừa có dấu phẩy: chặn trước rồi mới bọc", () => {
    const out = doc(renderCsv({ headers: ["a"], rows: [["=A1,B1"]] }));
    assert.equal(out, `a\r\n"'=A1,B1"\r\n`);
  });
});
