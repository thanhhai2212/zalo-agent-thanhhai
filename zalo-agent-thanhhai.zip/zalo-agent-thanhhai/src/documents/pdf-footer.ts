/**
 * Chân trang lặp trên MỌI trang PDF: tên đơn vị (trái) - số trang (giữa) -
 * link (phải).
 *
 * Tách khỏi `render-pdf.ts` để test được mà không kéo theo `runtime-tuning-settings`
 * (module đó mở SQLite ngay lúc import - xem bẫy viết test trong CLAUDE.md).
 *
 * Chrome dựng chân trang bằng một trang RIÊNG, hoàn toàn không thấy CSS của tài
 * liệu, nên mọi kiểu dáng phải viết thẳng vào đây. Bốn điều dễ sai, cả bốn đều
 * hỏng CÂM (không có lỗi nào báo):
 *
 * 1. PHẢI khai `box-sizing:border-box`. Reset của tài liệu không với tới đây, mà
 *    mặc định là content-box: `width:100%` CỘNG thêm 36mm padding thành rộng hơn
 *    khổ giấy, đẩy "link ở mép phải" ra ngoài mép phải và bị cắt mất.
 *    Đã dính thật, chỉ lộ ra khi chụp ảnh khối này đúng bề ngang A4.
 * 2. Cỡ chữ mặc định của Chrome cho chân trang rất nhỏ và KHÔNG kế thừa gì, phải
 *    khai `font-size` tường minh nếu không nó ra bé li ti.
 * 3. Lề trái/phải cũng không kế thừa `@page`, phải tự đặt `padding` khớp lề tài
 *    liệu (18mm) thì chân trang mới thẳng hàng với thân bài.
 * 4. Chỉ hai class `pageNumber` và `totalPages` được Chrome thay bằng số thật;
 *    viết tên khác thì ô đó trống trơn.
 *
 * Lề dưới của `@page` là 24mm, rộng hơn 3 cạnh còn lại chính là để chừa chỗ cho
 * khối này - hạ xuống là chân trang bị cắt.
 *
 * ĐÃ ĐO thay vì tin: cùng tài liệu, bật chân trang ra 22.462 byte, tắt còn
 * 19.872 byte. Chữ trong chân trang bị mã hóa theo font subset nên tìm chuỗi
 * "facebook" trong file PDF KHÔNG thấy - đừng dùng cách đó để kết luận là hỏng.
 *
 * Module THUẦN: không log, không đọc env, không chạm DB.
 */

// Khách tự điền tên/link của mình; để rỗng thì chân trang chỉ còn số trang.
export const TEN_CHAN_TRANG = "";
export const LINK_CHAN_TRANG = "";

export const CHAN_TRANG_PDF = `
<div style="box-sizing:border-box;width:100%;padding:0 18mm;font-family:'Segoe UI',Arial,sans-serif;
            font-size:8pt;color:#8A8F98;display:flex;align-items:center;">
  <span style="flex:1;text-align:left;">${TEN_CHAN_TRANG}</span>
  <span style="flex:0 0 auto;"><span class="pageNumber"></span> / <span class="totalPages"></span></span>
  <span style="flex:1;text-align:right;">${LINK_CHAN_TRANG}</span>
</div>`;
