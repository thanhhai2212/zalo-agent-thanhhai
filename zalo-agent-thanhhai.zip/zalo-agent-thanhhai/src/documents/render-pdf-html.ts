import type { DocumentBlock } from "./document-content-schema.js";
import { cssVanBan } from "./render-pdf-css.js";
import { chonPdfTheme, type PdfThemeName } from "./pdf-themes.js";

/**
 * Dựng HTML để Chrome in ra PDF - kiểu báo cáo hiện đại, dễ đọc.
 *
 * Đầu vào là KHỐI DỮ LIỆU (cùng schema với create_word_document), KHÔNG phải HTML
 * của model - giữ đúng ràng buộc "tool chỉ nhận dữ liệu" trong CLAUDE.md. Nên mọi
 * chữ ở đây là chữ model viết và PHẢI thoát trước khi ghép vào HTML.
 *
 * Bản trước bám thể thức Nghị định 30 (khối quốc hiệu, đường kẻ, tiêu đề chèn
 * giữa) và ĐÃ BỎ theo yêu cầu: ràng buộc thể thức quá nhiều chỗ dễ sai, mà tài
 * liệu gửi qua Zalo phần lớn không phải văn bản trình ký. Giờ tiêu đề nằm trên
 * cùng như mọi báo cáo bình thường, không còn luật chèn theo vị trí.
 *
 * Module THUẦN: không log, không đọc env, không chạm DB.
 */

/** Thoát ký tự HTML - chốt chặn, không phải tiện ích trình bày */
export function thoatHtml(raw: string): string {
  return raw
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * `**đậm**` -> `<strong>`. Chạy SAU khi thoát HTML nên nội dung bên trong không
 * thể chứa thẻ thật. Biểu thức tuyến tính: không nhóm lặp lồng nhau.
 */
function inDam(daThoat: string): string {
  return daThoat.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
}

const chu = (raw: string): string => inDam(thoatHtml(raw));

function dungKhoi(block: DocumentBlock): string {
  switch (block.type) {
    case "heading":
      return `<h${block.level} class="tieu-de">${chu(block.text)}</h${block.level}>`;

    case "paragraph": {
      const canh =
        block.align && block.align !== "justify" ? ` style="text-align:${block.align}"` : "";
      return `<p${canh}>${chu(block.text)}</p>`;
    }

    case "bullets":
      return `<ul>${block.items.map((i) => `<li>${chu(i)}</li>`).join("")}</ul>`;

    case "table": {
      const th = block.headers.map((h) => `<th>${chu(h)}</th>`).join("");
      const tr = block.rows
        .map((row) => `<tr>${row.map((o) => `<td>${chu(o)}</td>`).join("")}</tr>`)
        .join("");
      // thead riêng để Chrome lặp lại hàng tiêu đề khi bảng tràn sang trang sau
      return `<table><thead><tr>${th}</tr></thead><tbody>${tr}</tbody></table>`;
    }

    case "two_columns": {
      const trai = block.left.map((d) => `<div>${chu(d)}</div>`).join("");
      const phai = block.right.map((d) => `<div>${chu(d)}</div>`).join("");
      return `<div class="hai-cot"><div class="cot">${trai}</div><div class="cot">${phai}</div></div>`;
    }
  }
}

export type TuyChonPdf = {
  /** Tiêu đề lớn ở đầu tài liệu */
  title?: string;
  /** Tông màu - model chọn theo nội dung, mặc định navy */
  tone?: PdfThemeName;
};

export function dungHtmlChoPdf(blocks: DocumentBlock[], tuyChon: TuyChonPdf = {}): string {
  const theme = chonPdfTheme(tuyChon.tone);

  // Vạch nhấn chỉ có khi CÓ tiêu đề - không thì nó thành một gạch lơ lửng vô nghĩa
  const tieuDe = tuyChon.title
    ? `<div class="tieu-de-chinh">${chu(tuyChon.title)}</div><div class="vach-tieu-de"></div>`
    : "";

  return [
    "<!doctype html>",
    '<html lang="vi"><head><meta charset="utf-8">',
    `<title>${thoatHtml(tuyChon.title ?? "Tài liệu")}</title>`,
    `<style>${cssVanBan(theme)}</style>`,
    "</head><body>",
    tieuDe,
    ...blocks.map(dungKhoi),
    "</body></html>",
  ].join("\n");
}
