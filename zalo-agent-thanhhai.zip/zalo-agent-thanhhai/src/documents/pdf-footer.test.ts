import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { CHAN_TRANG_PDF, LINK_CHAN_TRANG, TEN_CHAN_TRANG } from "./pdf-footer.js";

describe("chân trang PDF", () => {
  it("có số trang ở giữa, và hai ô tên/link nội suy đúng giá trị khai báo", () => {
    assert.ok(CHAN_TRANG_PDF.includes('class="pageNumber"'));
    assert.ok(CHAN_TRANG_PDF.includes('class="totalPages"'));
    assert.ok(CHAN_TRANG_PDF.includes(`text-align:left;">${TEN_CHAN_TRANG}</span>`));
    assert.ok(CHAN_TRANG_PDF.includes(`text-align:right;">${LINK_CHAN_TRANG}</span>`));
  });

  it("bản phát hành KHÔNG in sẵn tên hay link cá nhân nào lên PDF của khách", () => {
    assert.equal(TEN_CHAN_TRANG, "");
    assert.equal(LINK_CHAN_TRANG, "");
  });

  /*
   * Hồi quy cho lỗi ĐÃ XẢY RA: thiếu box-sizing thì width:100% cộng 36mm padding
   * vượt bề ngang khổ giấy, đẩy link ra ngoài mép phải và bị cắt mất. Chrome
   * không báo gì, bản in vẫn ra - chỉ mất chữ.
   */
  it("khai box-sizing:border-box - thiếu là link bị đẩy ra ngoài mép phải", () => {
    assert.ok(CHAN_TRANG_PDF.includes("box-sizing:border-box"));
  });

  it("khai cỡ chữ tường minh - Chrome không kế thừa gì cho chân trang", () => {
    assert.ok(/font-size:\s*\d/.test(CHAN_TRANG_PDF));
  });

  it("padding khớp lề tài liệu 18mm để thẳng hàng với thân bài", () => {
    assert.ok(CHAN_TRANG_PDF.includes("padding:0 18mm"));
  });

  it("chỉ dùng kiểu dáng nội tuyến - CSS tài liệu không với tới đây", () => {
    assert.ok(!CHAN_TRANG_PDF.includes("<style"));
    assert.ok(!/class="(?!pageNumber|totalPages)/.test(CHAN_TRANG_PDF));
  });
});
