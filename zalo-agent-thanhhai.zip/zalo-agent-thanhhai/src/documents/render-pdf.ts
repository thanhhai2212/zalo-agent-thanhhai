import puppeteer from "puppeteer-core";
import type { DocumentBlock } from "./document-content-schema.js";
import { timChrome } from "./chrome-finder.js";
import { dungHtmlChoPdf, type TuyChonPdf } from "./render-pdf-html.js";
import { CHAN_TRANG_PDF } from "./pdf-footer.js";
import { getTuning } from "../config/runtime-tuning-settings.js";

/**
 * In khối dữ liệu ra PDF bằng Chrome đã cài trên máy.
 *
 * Ba quyết định an toàn, không phải phòng xa:
 *
 * 1. `setJavaScriptEnabled(false)` TRƯỚC khi nạp nội dung. Nội dung vào đây là
 *    dữ liệu đã thoát HTML nên về lý thuyết không có script nào, nhưng đây là
 *    lớp thứ hai: bot đọc tin người lạ, mà mở cả một trình duyệt thật để render
 *    là bề mặt tấn công lớn nhất từ trước tới nay trong repo này. Tắt JS thì kể
 *    cả khi lớp thoát HTML thủng, cũng không có gì chạy được.
 * 2. KHÔNG `--no-sandbox`. Sandbox của Chrome là lớp cách ly cuối; tắt nó là
 *    thói quen sao chép từ Docker mà ở máy Windows này không cần.
 * 3. Trần thời gian + LUÔN đóng browser trong `finally`. Thiếu vế sau thì mỗi
 *    lần lỗi để lại một tiến trình Chrome sống, vài chục lần là hết RAM máy.
 *
 * `launchImpl` tiêm được để test không cần Chrome thật - cùng nếp `fetchImpl`
 * của `image-generation-client.ts`.
 */

export type LaunchImpl = typeof puppeteer.launch;

export async function renderPdf(
  blocks: DocumentBlock[],
  tuyChon: TuyChonPdf = {},
  launchImpl: LaunchImpl = puppeteer.launch,
): Promise<Buffer> {
  const chrome = timChrome();
  if (!chrome) {
    throw new Error(
      "Không tìm thấy Chrome hoặc Edge trên máy để in PDF. Cài Chrome, hoặc đặt biến CHROME_PATH trỏ tới file chạy.",
    );
  }

  const html = dungHtmlChoPdf(blocks, tuyChon);
  const tranMs = getTuning("PDF_RENDER_TIMEOUT_MS");

  const browser = await launchImpl({
    executablePath: chrome,
    headless: true,
    // Bỏ GPU: máy chủ không có màn hình, bật chỉ tốn thời gian khởi động
    args: ["--disable-gpu", "--disable-dev-shm-usage"],
    timeout: tranMs,
  });

  try {
    const page = await browser.newPage();
    // TẮT JS trước khi có bất kỳ nội dung nào - thứ tự quan trọng
    await page.setJavaScriptEnabled(false);
    await page.setContent(html, { waitUntil: "load", timeout: tranMs });

    const pdf = await page.pdf({
      format: "A4",
      printBackground: true,
      // Lề đã khai trong @page của CSS; để trống ở đây thì Chrome dùng @page
      preferCSSPageSize: true,
      displayHeaderFooter: true,
      headerTemplate: "<div></div>",
      footerTemplate: CHAN_TRANG_PDF,
      timeout: tranMs,
    });

    return Buffer.from(pdf);
  } finally {
    // Đóng dù thành công hay lỗi - xem lý do 3 ở đầu file
    await browser.close().catch(() => undefined);
  }
}
