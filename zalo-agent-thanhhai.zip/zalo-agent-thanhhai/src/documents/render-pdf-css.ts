import { NEN_NHAN, type PdfTheme } from "./pdf-themes.js";

/**
 * CSS cho bản in PDF - kiểu BÁO CÁO HIỆN ĐẠI, dễ đọc.
 *
 * Bản trước bám thể thức Nghị định 30 và đã bị bỏ theo yêu cầu: thể thức hành
 * chính có quá nhiều ràng buộc dễ sai (đường kẻ, tỷ lệ cột, thứ tự khối), mà
 * phần lớn tài liệu gửi qua Zalo không phải văn bản trình ký.
 *
 * Ba nguyên tắc trình bày ở đây, đều nhằm chống "khối chữ đặc khó nhìn":
 *
 * 1. THỞ. Dãn dòng 1,7 và khoảng cách giữa các khối rộng hẳn. Trang in ít chữ
 *    hơn một chút nhưng đọc trên điện thoại đỡ mỏi mắt hơn nhiều - mà người nhận
 *    file qua Zalo thì mở bằng điện thoại là chính.
 * 2. PHÂN CẤP NHÌN THẤY ĐƯỢC. Tiêu đề có màu và vạch nhấn bên trái, nên lướt mắt
 *    là thấy ngay bố cục thay vì phải đọc mới biết đang ở mục nào.
 * 3. NHẤN ĐÚNG CHỖ. Chữ trong `**...**` được bôi nền vàng hổ phách - model vốn
 *    đã bôi đậm những chỗ quan trọng, nên tận dụng luôn thay vì thêm cú pháp mới.
 *
 * Chữ dùng font không chân (Segoe UI) chứ không phải Times: tài liệu đọc trên
 * màn hình thì font không chân rõ hơn, và đây không còn là văn bản hành chính.
 */

export function cssVanBan(theme: PdfTheme): string {
  return `
@page { size: A4; margin: 16mm 18mm 24mm 18mm; }
/*
 * Ép giao diện SÁNG. Thiếu 2 dòng này thì máy đang bật dark mode làm Chrome đổi
 * nền trang thành đen, chữ đen trên nền đen, cả file hỏng. Đã dính thật.
 */
:root { color-scheme: only light; }
* { box-sizing: border-box; }
body {
  font-family: "Segoe UI", Arial, "Helvetica Neue", sans-serif;
  font-size: 11pt; line-height: 1.7; color: #1F2430; background: #fff; margin: 0;
}

/* ===== Tiêu đề tài liệu ===== */
.tieu-de-chinh {
  font-size: 20pt; font-weight: 700; color: ${theme.chinh};
  line-height: 1.25; margin: 0 0 6pt; letter-spacing: -0.2pt;
}
.vach-tieu-de {
  height: 3pt; width: 56pt; background: ${theme.chinh};
  border-radius: 2pt; margin: 0 0 20pt;
}

/* ===== Phân cấp mục - vạch nhấn bên trái để lướt mắt thấy ngay ===== */
h1.tieu-de, h2.tieu-de, h3.tieu-de {
  color: ${theme.chinh}; font-weight: 700;
  break-after: avoid; page-break-after: avoid;
}
h1.tieu-de {
  font-size: 15pt; margin: 20pt 0 8pt; padding-bottom: 5pt;
  border-bottom: 1pt solid ${theme.vien};
}
h2.tieu-de {
  font-size: 12.5pt; margin: 16pt 0 7pt;
  padding-left: 8pt; border-left: 3pt solid ${theme.chinh};
}
h3.tieu-de { font-size: 11pt; margin: 13pt 0 5pt; }

/* ===== Thân bài ===== */
p { margin: 0 0 10pt; text-align: justify; orphans: 2; widows: 2; }
p[style*="center"] { text-align: center; }
p[style*="right"] { text-align: right; }
/* Chữ nhấn: bôi nền như bút dạ, chữ vẫn màu đậm của tông nên đủ tương phản */
strong {
  color: ${theme.chinh}; font-weight: 700;
  background: ${NEN_NHAN}; padding: 0.5pt 3pt; border-radius: 2pt;
}
/* Trong tiêu đề và đầu bảng thì KHÔNG bôi nền - nền đậm rồi, bôi nữa là rối */
h1.tieu-de strong, h2.tieu-de strong, h3.tieu-de strong, th strong {
  background: none; padding: 0; color: inherit;
}

/* ===== Gạch đầu dòng - dấu chấm theo tông, các mục cách nhau rõ ===== */
ul { margin: 0 0 12pt; padding-left: 16pt; list-style: none; }
li { margin: 0 0 7pt; position: relative; padding-left: 12pt; }
li::before {
  content: ""; position: absolute; left: 0; top: 7pt;
  width: 5pt; height: 5pt; border-radius: 50%; background: ${theme.chinh};
}

/* ===== Bảng - đầu bảng đậm, sọc xen kẽ, viền mảnh ===== */
table {
  width: 100%; border-collapse: collapse; margin: 6pt 0 14pt;
  font-size: 10pt; page-break-inside: auto;
}
th {
  background: ${theme.chinh}; color: #fff; font-weight: 600;
  text-align: left; padding: 7pt 8pt; border: none;
}
td {
  padding: 6pt 8pt; border: none;
  border-bottom: 0.75pt solid ${theme.vien}; vertical-align: top;
}
tbody tr:nth-child(even) { background: ${theme.nhat}; }
tr { break-inside: avoid; page-break-inside: avoid; }
/* Bảng tràn trang thì lặp lại hàng tiêu đề */
thead { display: table-header-group; }

/* ===== Hai cột - dùng cho khối ký tên, thông tin đối chiếu ===== */
.hai-cot {
  display: flex; gap: 12pt; margin: 16pt 0; break-inside: avoid;
}
.hai-cot .cot {
  flex: 1; background: ${theme.nhat}; border-left: 2pt solid ${theme.vien};
  padding: 9pt 12pt; border-radius: 3pt;
}
.hai-cot .cot div { margin-bottom: 3pt; }
.hai-cot .cot div:last-child { margin-bottom: 0; }
`;
}
