import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { extractDocumentText, isSupportedDocumentExtension } from "./extract-document-text.js";
import { extractPlainText, TRAN_KY_TU_FILE_CHU } from "./extract-plain-text.js";

describe("đọc file dạng chữ", () => {
  it("md, txt, csv, json, mã nguồn đều nằm trong danh sách hỗ trợ; đuôi lạ thì không", () => {
    for (const ext of ["md", "txt", "html", "htm", "csv", "json", "py", "ts"]) assert.ok(isSupportedDocumentExtension(ext), ext);
    assert.ok(!isSupportedDocumentExtension("exe"));
    assert.ok(!isSupportedDocumentExtension("zip"));
  });

  it("markdown giữ nguyên chữ có dấu, bỏ BOM và \\r\\n", async () => {
    const md = Buffer.from("﻿# Tiêu đề\r\n- Mục một\r\n", "utf8");
    assert.equal(await extractDocumentText(md, "md"), "# Tiêu đề\n- Mục một");
  });

  it("HTML bóc thẻ, bỏ script/style, giữ xuống dòng", () => {
    const html = "<html><head><style>p{color:red}</style><script>alert(1)</script></head><body><h1>Chào</h1><p>Nội dung <b>đậm</b></p></body></html>";
    const kq = extractPlainText(Buffer.from(html), "html");
    assert.match(kq, /Chào\nNội dung đậm/);
    assert.ok(!kq.includes("alert") && !kq.includes("color:red"));
  });

  it("file UTF-16 (Notepad Windows cũ) vẫn đọc đúng", () => {
    const utf16 = Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from("Xin chào", "utf16le")]);
    assert.equal(extractPlainText(utf16, "txt"), "Xin chào");
  });

  it("file nhị phân đội lốt .txt thì báo lỗi; file quá dài bị cắt kèm ghi chú", () => {
    assert.throws(() => extractPlainText(Buffer.from([0x50, 0x4b, 0x03, 0x04, 0x00, 0x00]), "txt"), /nhị phân/);
    const dai = extractPlainText(Buffer.from("a".repeat(TRAN_KY_TU_FILE_CHU + 500)), "txt");
    assert.match(dai, /file còn 500 ký tự nữa/);
  });
});
