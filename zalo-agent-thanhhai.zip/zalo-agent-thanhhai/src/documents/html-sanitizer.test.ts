import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { bocTrangHtml, locHtmlAnToan } from "./html-sanitizer.js";

describe("locHtmlAnToan", () => {
  it("bỏ thẻ script cùng toàn bộ nội dung bên trong", () => {
    const { html, daBo } = locHtmlAnToan('<p>Xin chào</p><script>alert("hack")</script>');
    assert.equal(html, "<p>Xin chào</p>");
    assert.ok(!html.includes("alert"));
    assert.ok(daBo.includes("<script>"));
  });

  it("bỏ thẻ script viết hoa và có thuộc tính", () => {
    const { html } = locHtmlAnToan('<SCRIPT SRC="http://ke-xau.test/a.js"></SCRIPT><p>ok</p>');
    assert.equal(html, "<p>ok</p>");
  });

  it("bỏ cả thẻ script mở mà không có thẻ đóng", () => {
    const { html } = locHtmlAnToan("<p>a</p><script>var x = 1;");
    assert.ok(!html.includes("<script"));
  });

  it("bỏ thuộc tính bắt sự kiện ở cả ba kiểu viết nháy", () => {
    const { html, daBo } = locHtmlAnToan(
      `<img src="a.png" onerror="steal()"><div onclick='go()'>x</div><b onmouseover=z()>y</b>`,
    );
    assert.ok(!/onerror/i.test(html));
    assert.ok(!/onclick/i.test(html));
    assert.ok(!/onmouseover/i.test(html));
    assert.ok(daBo.some((d) => d.includes("on*")));
  });

  it("đổi link javascript: thành # chứ không xóa cả thuộc tính", () => {
    const { html } = locHtmlAnToan(`<a href="javascript:alert(1)">bấm</a>`);
    assert.equal(html, `<a href="#">bấm</a>`);
  });

  it("chặn cả data:text/html trong href", () => {
    const { html } = locHtmlAnToan(`<a href="data:text/html;base64,PHNjcmlwdD4=">x</a>`);
    assert.ok(!html.includes("data:text/html"));
  });

  it("bỏ iframe, object, embed, form", () => {
    const { html } = locHtmlAnToan(
      '<iframe src="x"></iframe><object data="y"></object><embed src="z"><form action="a"></form><p>giữ</p>',
    );
    assert.equal(html, "<p>giữ</p>");
  });

  it("GIỮ NGUYÊN phần trình bày: css, bảng, màu, ảnh thường", () => {
    const goc =
      '<style>body{color:red}</style><table><tr><td style="color:blue">1</td></tr></table><img src="anh.png">';
    const { html, daBo } = locHtmlAnToan(goc);
    assert.equal(html, goc);
    assert.deepEqual(daBo, []);
  });

  it("nội dung sạch thì daBo rỗng - không báo nhầm cho model", () => {
    const { daBo } = locHtmlAnToan("<h1>Báo cáo</h1><p>Nội dung bình thường</p>");
    assert.deepEqual(daBo, []);
  });
});

describe("bocTrangHtml", () => {
  it("bọc khung khi model chỉ gửi phần thân", () => {
    const out = bocTrangHtml("<h1>Chào</h1>", "Tiêu đề");
    assert.ok(out.startsWith("<!doctype html>"));
    assert.ok(out.includes("<title>Tiêu đề</title>"));
    assert.ok(out.includes("<h1>Chào</h1>"));
  });

  it("giữ nguyên khi model đã gửi trọn trang", () => {
    const trang = "<!doctype html><html><body>có rồi</body></html>";
    assert.equal(bocTrangHtml(trang, "bỏ qua"), trang);
  });

  it("thoát ký tự đặc biệt trong tiêu đề - không cho chèn thẻ qua đường title", () => {
    const out = bocTrangHtml("<p>x</p>", "</title><script>alert(1)</script>");
    assert.ok(!out.includes("<script>"));
    assert.ok(out.includes("&lt;/title&gt;"));
  });
});
