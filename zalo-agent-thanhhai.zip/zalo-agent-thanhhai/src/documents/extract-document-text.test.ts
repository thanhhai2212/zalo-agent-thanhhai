import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import ExcelJS from "exceljs";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

/**
 * PDF/DOCX/XLSX dùng fixture THẬT (không mock thư viện parse) - round-trip
 * qua đúng hàm sẽ chạy trong production. DOCX dùng lại `renderDocx` sẵn có
 * của dự án (không cần Chrome, khác `renderPdf`). PDF không có code TẠO sẵn
 * trong dự án (renderPdf cần Chrome thật, không hợp làm fixture test nhanh/
 * xác định) nên tự dựng PDF tối giản hợp lệ (kỹ thuật "minimal PDF" phổ biến -
 * offset xref tính TỰ ĐỘNG từ độ dài chuỗi thật, không gõ tay để tránh sai số).
 *
 * `extractPdfText` giờ (nhánh mô tả ảnh) import xuyên `vision-sidecar.ts` ->
 * `runtime-vision-settings.ts` -> DB, nên phải `setupTestEnv()` TRƯỚC rồi mới
 * `import()` động - luật đã ghi trong CLAUDE.md, khác file test PDF trước đây
 * (lúc đó chưa chạm DB nên import tĩnh vô hại).
 */

let dataDir: string;
let extract: typeof import("./extract-document-text.js");
let database: typeof import("../conversation/database.js");
let renderDocxModule: typeof import("./render-docx.js");

before(async () => {
  dataDir = setupTestEnv();
  extract = await import("./extract-document-text.js");
  database = await import("../conversation/database.js");
  renderDocxModule = await import("./render-docx.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

function buildPdfFromObjects(bodies: string[]): Buffer {
  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  bodies.forEach((body, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xrefStart = pdf.length;
  pdf += `xref\n0 ${bodies.length + 1}\n0000000000 65535 f \n`;
  for (const off of offsets) pdf += `${off.toString().padStart(10, "0")} 00000 n \n`;
  pdf += `trailer\n<< /Size ${bodies.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;
  return Buffer.from(pdf, "latin1");
}

function buildMinimalPdfFromStream(stream: string): Buffer {
  return buildPdfFromObjects([
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /MediaBox [0 0 300 300] /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
  ]);
}

function buildMinimalPdf(text: string): Buffer {
  return buildMinimalPdfFromStream(`BT /F1 24 Tf 10 100 Td (${text}) Tj ET`);
}

/** Nhiều dòng, mỗi dòng lùi xuống bằng `Td` tương đối - đúng cách 1 PDF thật dựng bảng nhiều hàng */
function buildMultiLinePdf(lines: string[]): Buffer {
  const ops = lines.map((line, i) => `${i === 0 ? "10 250" : "0 -20"} Td (${line}) Tj`).join(" ");
  return buildMinimalPdfFromStream(`BT /F1 12 Tf ${ops} ET`);
}

/**
 * N trang, mỗi trang 1 (hoặc nhiều, nếu dài) dòng chữ - dùng cho test
 * orchestration, không cần ảnh thật. Text dài (>40 ký tự) được TỰ CHIA thành
 * nhiều lệnh `Tj` ngắn thay vì 1 chuỗi PDF string literal dài - đã đo thật:
 * pdfjs-dist CẮT CỤT chuỗi trong 1 lệnh `Tj` khi PDF tối giản (không nhúng
 * font, thiếu `standardFontDataUrl`) đủ dài (~100+ ký tự), dù byte thô trong
 * file hoàn toàn đúng và PDF thật (không tối giản) không hề gặp lỗi này -
 * đây là hạn chế của KỸ THUẬT DỰNG FIXTURE tối giản, không phải bug của
 * `extractPdfText`. Chia nhỏ né được vấn đề, chấp nhận sai lệch vài ký tự ở
 * ranh giới (không ảnh hưởng mục đích test: so sánh với ngưỡng 150 ký tự).
 */
function buildMultiPagePdf(texts: string[]): Buffer {
  const n = texts.length;
  const fontObj = 3 + n;
  const bodies: string[] = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    `<< /Type /Pages /Kids [${Array.from({ length: n }, (_, i) => `${3 + i} 0 R`).join(" ")}] /Count ${n} >>`,
  ];
  for (let i = 0; i < n; i++) {
    bodies.push(
      `<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 ${fontObj} 0 R >> >> /MediaBox [0 0 200 200] /Contents ${fontObj + 1 + i} 0 R >>`,
    );
  }
  bodies.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  for (const t of texts) {
    const chunks = t.match(/.{1,40}/g) ?? [t];
    const ops = chunks.map((chunk, i) => `${i === 0 ? "10 190" : "0 -14"} Td (${chunk}) Tj`).join(" ");
    const stream = `BT /F1 12 Tf ${ops} ET`;
    bodies.push(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
  }
  return buildPdfFromObjects(bodies);
}

/** 1 trang có ẢNH THẬT (2x2 RGB thô, không nén) - dùng để test pipeline render THẬT (không tiêm gì) */
function buildPdfWithRealImage(): Buffer {
  const imageBytes = [255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 255, 0];
  const imageStream = String.fromCharCode(...imageBytes);
  const drawOps = "q 100 0 0 100 0 0 cm /Im0 Do Q";
  return buildPdfFromObjects([
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /Resources << /XObject << /Im0 4 0 R >> >> /MediaBox [0 0 100 100] /Contents 5 0 R >>",
    `<< /Type /XObject /Subtype /Image /Width 2 /Height 2 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Length ${imageBytes.length} >>\nstream\n${imageStream}\nendstream`,
    `<< /Length ${drawOps.length} >>\nstream\n${drawOps}\nendstream`,
  ]);
}

describe("extractPdfText - trích chữ", () => {
  it("trích đúng chữ từ PDF hợp lệ", async () => {
    const pdf = buildMinimalPdf("Hello PDF Test");
    const text = await extract.extractPdfText(pdf);
    assert.ok(text.includes("Hello PDF Test"), `expected text to include the sample string, got: "${text}"`);
  });

  it("PDF không có lớp chữ (trang trống) -> chuỗi rỗng, KHÔNG throw", async () => {
    const pdf = buildMinimalPdf("");
    const text = await extract.extractPdfText(pdf);
    assert.equal(text, "");
  });

  it("PDF nhiều dòng (mô phỏng bảng nhiều hàng) -> giữ MỖI DÒNG riêng biệt, không dồn thành 1 dòng liền mạch", async () => {
    // Hồi quy cho lỗi đã gặp thật: bảng 40 hàng bị dồn thành 1 chuỗi liền mạch
    // khiến model đọc được số liệu nhưng không tái tạo lại đúng từng hàng khi
    // được nhờ chuyển sang file khác.
    const pdf = buildMultiLinePdf(["STT Ten Tien", "1 VatTuA 1000", "2 VatTuB 2000", "3 VatTuC 3000"]);
    const text = await extract.extractPdfText(pdf);
    const lines = text.split("\n");

    assert.equal(lines.length, 5, `expected page marker + 4 separate lines, got: ${JSON.stringify(lines)}`);
    assert.equal(lines[0], "=== Trang 1/1 ===");
    assert.equal(lines[1], "STT Ten Tien");
    assert.equal(lines[2], "1 VatTuA 1000");
    assert.equal(lines[3], "2 VatTuB 2000");
    assert.equal(lines[4], "3 VatTuC 3000");
  });

  it("đánh số đúng trang thật khi có trang RỖNG xen giữa - trang rỗng không đánh số, không để lại dòng thừa", async () => {
    // Hồi quy cho lỗi đã gặp thật: model được hỏi "trang nào rỗng" phải đoán mò
    // vì text trích ra không có số trang, nên bịa sai hẳn khoảng trang (nói
    // "17-52 rỗng" trong khi 17-21 thật ra có chữ) - đo trên 1 báo cáo demo
    // 63 trang thật. Giữ đúng số trang GỐC (không đánh số lại liên tục) để
    // agent trích dẫn đúng "trang 20" thay vì "trang thứ 3 có chữ".
    const bodies = [
      "<< /Type /Catalog /Pages 2 0 R >>",
      "<< /Type /Pages /Kids [3 0 R 4 0 R 5 0 R] /Count 3 >>",
      "<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 6 0 R >> >> /MediaBox [0 0 200 200] /Contents 7 0 R >>",
      "<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 6 0 R >> >> /MediaBox [0 0 200 200] >>",
      "<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 6 0 R >> >> /MediaBox [0 0 200 200] /Contents 8 0 R >>",
      "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ];
    const stream1 = "BT /F1 24 Tf 10 100 Td (Trang mot co chu) Tj ET";
    const stream3 = "BT /F1 24 Tf 10 100 Td (Trang ba co chu) Tj ET";
    bodies.push(`<< /Length ${stream1.length} >>\nstream\n${stream1}\nendstream`);
    bodies.push(`<< /Length ${stream3.length} >>\nstream\n${stream3}\nendstream`);

    const text = await extract.extractPdfText(buildPdfFromObjects(bodies));
    assert.ok(text.includes("=== Trang 1/3 ===\nTrang mot co chu"));
    assert.ok(!text.includes("Trang 2/3"), "trang 2 hoàn toàn rỗng - không được đánh số");
    assert.ok(text.includes("=== Trang 3/3 ===\nTrang ba co chu"));
  });
});

describe("extractPdfText - mô tả tự động trang là ẢNH (vision sidecar)", () => {
  it("pipeline THẬT (không tiêm gì): phát hiện đúng trang có ảnh, render không lỗi - sidecar chưa cấu hình trong test nên mô tả null", async () => {
    // Xác nhận dây nối THẬT (operator list -> @napi-rs/canvas render -> describeImage)
    // chạy được không throw - không assert nội dung mô tả vì sidecar không cấu
    // hình trong môi trường test (setupTestEnv không set biến vision nào).
    const pdf = buildPdfWithRealImage();
    const result = await extract.describePageImageIfAny(
      await (async () => {
        const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
        const doc = await getDocument({ data: new Uint8Array(pdf) }).promise;
        return doc.getPage(1);
      })(),
      1,
    );
    assert.equal(result.hasImage, true);
    if (result.hasImage) assert.equal(result.description, null, "sidecar chưa cấu hình trong test env");
  });

  it("trang chữ ít + CÓ ảnh (tiêm giả) -> thay bằng mô tả, đánh dấu '(ảnh - mô tả tự động)'", async () => {
    // Trang 2 PHẢI dài hơn PDF_SPARSE_TEXT_CHARS (150) để không bị coi là ứng viên
    const noiDungDai = "noi dung binh thuong dai hon nguong sparse ".repeat(4);
    assert.ok(noiDungDai.length >= 150, "fixture phải đủ dài hơn ngưỡng sparse để test có ý nghĩa");
    const pdf = buildMultiPagePdf(["x", noiDungDai, "y"]);
    const goiVoiTrang: number[] = [];
    const text = await extract.extractPdfText(pdf, async (_page, pageNum) => {
      goiVoiTrang.push(pageNum);
      if (pageNum === 1) return { hasImage: true, description: "Mô tả ảnh trang 1 do sidecar trả về" };
      return { hasImage: false };
    });

    assert.ok(text.includes("=== Trang 1/3 (ảnh - mô tả tự động) ===\nMô tả ảnh trang 1 do sidecar trả về"));
    // Trang 2 chữ dài (không sparse) - KHÔNG được gọi describePageImage
    assert.ok(!goiVoiTrang.includes(2), "trang chữ đủ dài không cần kiểm ảnh");
    assert.ok(goiVoiTrang.includes(3));
  });

  it("trang chữ ít + CÓ ảnh nhưng sidecar lỗi/chưa cấu hình (description null) -> giữ chữ gốc + ghi chú, KHÔNG mất thông tin", async () => {
    const pdf = buildMinimalPdf("01");
    const text = await extract.extractPdfText(pdf, async () => ({ hasImage: true, description: null }));
    assert.ok(text.includes("=== Trang 1/1 ===\n01 (trang có ảnh, chưa mô tả được)"));
  });

  it("trang chữ ít nhưng KHÔNG có ảnh (vd tiêu đề ngắn) -> giữ nguyên, KHÔNG thêm ghi chú sai sự thật", async () => {
    const pdf = buildMinimalPdf("Muc luc");
    const text = await extract.extractPdfText(pdf, async () => ({ hasImage: false }));
    assert.ok(text.includes("=== Trang 1/1 ===\nMuc luc"));
    assert.ok(!text.includes("trang có ảnh"));
  });

  it("vượt trần 15 trang -> chỉ mô tả 15 trang ĐẦU, còn lại ghi 1 dòng gộp", async () => {
    const texts = Array.from({ length: 20 }, (_, i) => `trang-${i + 1}`);
    const pdf = buildMultiPagePdf(texts);
    let soLanGoi = 0;
    const text = await extract.extractPdfText(pdf, async () => {
      soLanGoi++;
      return { hasImage: false };
    });

    assert.equal(soLanGoi, 15, "chỉ 15 trang đầu trong số 20 ứng viên được thử mô tả");
    assert.ok(
      text.includes("[... còn 5 trang khác cũng là ảnh, chưa mô tả tự động - hỏi cụ thể số trang nếu cần]"),
    );
  });

  it("không vượt trần thì KHÔNG có dòng ghi chú tràn", async () => {
    const texts = Array.from({ length: 5 }, (_, i) => `trang-${i + 1}`);
    const pdf = buildMultiPagePdf(texts);
    const text = await extract.extractPdfText(pdf, async () => ({ hasImage: false }));
    assert.ok(!text.includes("chưa mô tả tự động"));
  });

  it("describePageImage ném lỗi ở tầng gọi (ngoài try/catch nội bộ của bản thật) không làm hỏng cả extractPdfText - lỗi văng lên, đúng cùng luật throw của extractDocumentText", async () => {
    // Bản thật (`describePageImageIfAny`) tự bọc try/catch không bao giờ throw;
    // đây chỉ xác nhận orchestration KHÔNG tự nuốt lỗi hộ nếu hàm tiêm vào lỡ throw
    // (khác hợp đồng) - orchestration tin tưởng hợp đồng "không throw" của seam.
    const pdf = buildMinimalPdf("01");
    await assert.rejects(() =>
      extract.extractPdfText(pdf, async () => {
        throw new Error("lỗi giả lập");
      }),
    );
  });
});

describe("extractDocxText", () => {
  it("trích đúng chữ từ file docx thật (dựng bằng renderDocx sẵn có của dự án)", async () => {
    const docx = await renderDocxModule.renderDocx([{ type: "paragraph", text: "Nội dung Word thử nghiệm 12345" }]);
    const text = await extract.extractDocxText(docx);
    assert.ok(text.includes("Nội dung Word thử nghiệm 12345"));
  });
});

describe("extractXlsxText", () => {
  it("trích đúng số liệu từ file xlsx thật (dựng bằng ExcelJS)", async () => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Doanh thu");
    sheet.addRow(["Tháng", "Số tiền"]);
    sheet.addRow(["1", "1000000"]);
    const buffer = Buffer.from(await workbook.xlsx.writeBuffer());

    const text = await extract.extractXlsxText(buffer);
    assert.ok(text.includes('Sheet "Doanh thu"'));
    assert.ok(text.includes("Tháng"));
    assert.ok(text.includes("1000000"));
  });
});

describe("extractDocumentText - dispatch", () => {
  it("đuôi lạ -> throw thay vì âm thầm trả rỗng", async () => {
    await assert.rejects(() => extract.extractDocumentText(Buffer.from("x"), "zip"));
  });

  it("dispatch đúng hàm theo từng đuôi hỗ trợ", async () => {
    const pdf = buildMinimalPdf("Dispatch PDF");
    assert.ok((await extract.extractDocumentText(pdf, "pdf")).includes("Dispatch PDF"));

    const docx = await renderDocxModule.renderDocx([{ type: "paragraph", text: "Dispatch DOCX" }]);
    assert.ok((await extract.extractDocumentText(docx, "docx")).includes("Dispatch DOCX"));

    const workbook = new ExcelJS.Workbook();
    workbook.addWorksheet("S1").addRow(["Dispatch XLSX"]);
    const xlsx = Buffer.from(await workbook.xlsx.writeBuffer());
    assert.ok((await extract.extractDocumentText(xlsx, "xlsx")).includes("Dispatch XLSX"));
  });
});

describe("isSupportedDocumentExtension", () => {
  it("4 đuôi hỗ trợ trả true, đuôi khác trả false", () => {
    assert.equal(extract.isSupportedDocumentExtension("pdf"), true);
    assert.equal(extract.isSupportedDocumentExtension("docx"), true);
    assert.equal(extract.isSupportedDocumentExtension("xlsx"), true);
    assert.equal(extract.isSupportedDocumentExtension("pptx"), true);
    assert.equal(extract.isSupportedDocumentExtension("zip"), false);
    assert.equal(extract.isSupportedDocumentExtension(""), false);
  });
});

// extractPptxText KHÔNG có test round-trip thật ở đây: node-pptx-parser chỉ
// nhận FILE PATH (không nhận buffer) và dự án không có sẵn code TẠO .pptx để
// dựng fixture (chỉ có docx/xlsx/pdf/csv). Nhánh dispatch/lỗi của
// `extractDocumentText`/`readBatchDocuments` cho pptx đã phủ qua injected fake
// ở `media-store.test.ts`. Bản thân `extractPptxText` gọi thư viện thật - xác
// nhận bằng gửi file .pptx thật qua Zalo sau khi triển khai (xem plan).
