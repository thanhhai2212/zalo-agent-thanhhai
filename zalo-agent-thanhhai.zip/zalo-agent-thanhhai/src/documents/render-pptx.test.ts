import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { renderPptx } from "./render-pptx.js";
import { listZipEntries, readZipEntryText } from "../shared/read-zip-entry.js";
import type { PresentationSlide } from "./document-content-schema.js";

/** Slide master tự đặt tên nên layout của nó không cố định là file nào - tìm
 * theo NỘI DUNG (tên master trong `<p:cSld name="...">`) thay vì đoán số thứ tự. */
function timLayoutMaster(data: Buffer): string {
  const layout = listZipEntries(data)
    .filter((p) => /^ppt\/slideLayouts\/slideLayout\d+\.xml$/.test(p))
    .find((p) => readZipEntryText(data, p).includes("ZALO_AGENT_NOI_DUNG"));
  if (!layout) throw new Error("Không tìm thấy slide layout của master ZALO_AGENT_NOI_DUNG");
  return layout;
}

describe("renderPptx", () => {
  it("dựng file .pptx hợp lệ (zip PK) với đúng số slide", async () => {
    const slides: PresentationSlide[] = [
      { type: "title", title: "Báo cáo quý 3", subtitle: "Phòng Kinh doanh" },
      { type: "bullets", heading: "Kết quả", items: ["Doanh thu **tăng 20%**", "Chi phí giảm"] },
      { type: "table", heading: "Số liệu", headers: ["Tháng", "Doanh thu"], rows: [["7", "100tr"]] },
      {
        type: "two_content",
        heading: "So sánh",
        leftTitle: "Trước",
        left: ["Chậm"],
        rightTitle: "Sau",
        right: ["Nhanh"],
      },
    ];

    const data = await renderPptx(slides);
    assert.equal(data.subarray(0, 2).toString(), "PK");

    const presXml = readZipEntryText(data, "ppt/presentation.xml");
    // 4 slide -> 4 tham chiếu sldId trong presentation.xml. Regex có dấu cách
    // sau "sldId" để KHÔNG khớp luôn thẻ bao "<p:sldIdLst>" (chứa cùng tiền tố).
    assert.equal((presXml.match(/<p:sldId /g) ?? []).length, 4, "phải có đúng 4 slide");
  });

  it("title slide: chữ (kể cả dấu tiếng Việt) vào đúng slide1.xml", async () => {
    const data = await renderPptx([{ type: "title", title: "Xin chào", subtitle: "Phụ đề" }]);
    const xml = readZipEntryText(data, "ppt/slides/slide1.xml");
    assert.ok(xml.includes("Xin chào") && xml.includes("Phụ đề"), "phải chứa nội dung title + subtitle");
  });

  it("bullets slide: marker **đậm** tách thành run riêng có b=\"1\", không lộ dấu **", async () => {
    const data = await renderPptx([
      { type: "bullets", heading: "Đầu mục", items: ["Bình thường **In đậm** còn lại"] },
    ]);
    const xml = readZipEntryText(data, "ppt/slides/slide1.xml");
    assert.ok(!xml.includes("**"), "dấu ** không được lộ ra file thật");
    // pptxgenjs ghi đậm bằng thuộc tính b="1" trên <a:rPr>, KHÔNG phải thẻ <a:b>
    assert.match(xml, /b="1"[^>]*>[\s\S]*?<a:t>In đậm<\/a:t>/, "run \"In đậm\" phải có thuộc tính b=\"1\"");
  });

  it("table slide: header + dữ liệu vào đúng ppt/slides", async () => {
    const data = await renderPptx([
      { type: "table", heading: "Bảng test", headers: ["Cột A", "Cột B"], rows: [["1", "2"]] },
    ]);
    const xml = readZipEntryText(data, "ppt/slides/slide1.xml");
    assert.ok(xml.includes("Cột A") && xml.includes("Cột B"));
  });

  it("two_content slide: cả 2 cột đều có mặt", async () => {
    const data = await renderPptx([
      {
        type: "two_content",
        heading: "So sánh",
        left: ["Nhược điểm A"],
        right: ["Ưu điểm B"],
      },
    ]);
    const xml = readZipEntryText(data, "ppt/slides/slide1.xml");
    assert.ok(xml.includes("Nhược điểm A") && xml.includes("Ưu điểm B"));
  });

  it("theme khác nhau ra màu banner khác nhau (hex KHÔNG có dấu #)", async () => {
    const slide: PresentationSlide = { type: "bullets", heading: "H", items: ["x"] };
    const navy = await renderPptx([slide], { theme: "navy" });
    const burgundy = await renderPptx([slide], { theme: "burgundy" });
    const navyXml = readZipEntryText(navy, "ppt/slides/slide1.xml");
    const burgundyXml = readZipEntryText(burgundy, "ppt/slides/slide1.xml");
    assert.ok(navyXml.includes("1F3864"), "navy phải dùng đúng mã màu, không có dấu #");
    assert.ok(burgundyXml.includes("8B2635"));
    assert.ok(!navyXml.includes("#1F3864"), "pptxgenjs không nhận dấu # trong hex");
  });

  it("section slide: canh trái + nền màu đậm, KHÁC dáng title slide (canh giữa)", async () => {
    const data = await renderPptx([{ type: "section", title: "Phần 1", subtitle: "Giới thiệu chung" }]);
    const xml = readZipEntryText(data, "ppt/slides/slide1.xml");
    assert.ok(xml.includes("Phần 1") && xml.includes("Giới thiệu chung"));
    assert.match(xml, /algn="l"/, "tiêu đề section phải canh TRÁI, không canh giữa như title");
    assert.ok(xml.includes("1F3864"), "nền section vẫn dùng màu chính của theme");
  });

  it("stat_highlight: tối đa 3 số, mỗi số kèm nhãn, không lẫn giữa các số", async () => {
    const data = await renderPptx([
      {
        type: "stat_highlight",
        heading: "Kết quả quý 3",
        stats: [
          { value: "+42%", label: "tăng trưởng doanh thu" },
          { value: "1.200", label: "khách hàng mới" },
        ],
      },
    ]);
    const xml = readZipEntryText(data, "ppt/slides/slide1.xml");
    assert.ok(xml.includes("+42%") && xml.includes("tăng trưởng doanh thu"));
    assert.ok(xml.includes("1.200") && xml.includes("khách hàng mới"));
  });

  it("stat_highlight không có heading: vẫn dựng được, không có thanh tiêu đề", async () => {
    const data = await renderPptx([{ type: "stat_highlight", stats: [{ value: "Top 1", label: "thị phần" }] }]);
    const xml = readZipEntryText(data, "ppt/slides/slide1.xml");
    assert.ok(xml.includes("Top 1") && xml.includes("thị phần"));
  });

  describe("slide master (nền dùng chung + đánh số trang tự động)", () => {
    it("slide nội dung (bullets/table/two_content/stat_highlight) dùng CHUNG 1 master, có nền nhạt + field số trang", async () => {
      const data = await renderPptx([
        { type: "bullets", heading: "H", items: ["x"] },
        { type: "table", heading: "H", headers: ["A"], rows: [["1"]] },
        { type: "two_content", heading: "H", left: ["a"], right: ["b"] },
        { type: "stat_highlight", stats: [{ value: "1", label: "l" }] },
      ]);
      const layoutPath = timLayoutMaster(data);
      const layoutXml = readZipEntryText(data, layoutPath);
      assert.match(layoutXml, /<p:bg>[\s\S]*srgbClr val="F2F5FA"/, "nền master phải đúng màu nhạt của theme navy");
      assert.match(layoutXml, /type="slidenum"/, "phải có field số trang tự động của PowerPoint");

      for (const n of [1, 2, 3, 4]) {
        const rels = readZipEntryText(data, `ppt/slides/_rels/slide${n}.xml.rels`);
        assert.ok(rels.includes(layoutPath.split("/").pop()!), `slide${n} phải dùng đúng layout của master`);
      }
    });

    it("title/section KHÔNG dùng master nội dung - giữ nền đậm full-bleed riêng, không bị số trang chèn lên chữ trắng", async () => {
      const data = await renderPptx([
        { type: "title", title: "T" },
        { type: "section", title: "S" },
      ]);
      const layoutPath = timLayoutMaster(data);
      for (const n of [1, 2]) {
        const rels = readZipEntryText(data, `ppt/slides/_rels/slide${n}.xml.rels`);
        assert.ok(!rels.includes(layoutPath.split("/").pop()!), `slide${n} (title/section) không được dùng master nội dung`);
      }
    });
  });
});
