import fs from "node:fs";

/**
 * Tìm trình duyệt Chromium để in PDF.
 *
 * Dùng `puppeteer-core` chứ KHÔNG dùng `puppeteer`: bản đầy đủ tải kèm một bản
 * Chromium ~170MB mỗi lần cài, trong khi máy chạy bot đã có Chrome. Đổi lại
 * `puppeteer-core` bắt buộc phải tự chỉ đường dẫn - đó là việc của file này.
 *
 * Thứ tự thử: biến môi trường (người dùng chỉ định) -> Chrome -> Edge (cùng nhân
 * Chromium, in PDF y hệt) -> các đường dẫn Linux thường gặp, để sau này chuyển
 * VPS chỉ cần `apt install chromium` là chạy, không phải sửa code.
 *
 * Trả `null` thay vì ném: tool sẽ tự ẩn khỏi schema qua `available()`, cùng khuôn
 * với `create_image` khi chưa cấu hình endpoint vẽ.
 */

const DUONG_DAN_WINDOWS = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
];

const DUONG_DAN_LINUX = [
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser",
  "/usr/bin/google-chrome",
  "/usr/bin/google-chrome-stable",
];

const DUONG_DAN_MAC = [
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/Applications/Chromium.app/Contents/MacOS/Chromium",
];

/**
 * Đường dẫn Chrome dùng được, hoặc null.
 *
 * KHÔNG cache kết quả: người dùng cài Chrome xong phải thấy tool bật lên ngay,
 * không phải khởi động lại bot. Chi phí là vài lệnh `existsSync` mỗi lượt - rẻ
 * hơn nhiều so với một câu hỏi hỗ trợ "tôi cài Chrome rồi mà vẫn báo chưa có".
 */
export function timChrome(): string | null {
  const tuEnv = process.env.CHROME_PATH?.trim();
  if (tuEnv && fs.existsSync(tuEnv)) return tuEnv;

  const ungVien =
    process.platform === "win32"
      ? DUONG_DAN_WINDOWS
      : process.platform === "darwin"
        ? [...DUONG_DAN_MAC, ...DUONG_DAN_LINUX]
        : DUONG_DAN_LINUX;

  // Đường dẫn LOCALAPPDATA chỉ có trên Windows và phụ thuộc user đang chạy
  const localApp = process.env.LOCALAPPDATA;
  const themLocal =
    localApp && process.platform === "win32"
      ? [`${localApp}\\Google\\Chrome\\Application\\chrome.exe`]
      : [];

  return [...ungVien, ...themLocal].find((p) => fs.existsSync(p)) ?? null;
}

export function coTheInPdf(): boolean {
  return timChrome() !== null;
}
