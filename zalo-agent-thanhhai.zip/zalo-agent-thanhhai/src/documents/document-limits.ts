import type { DocumentBlock, PresentationSlide, Sheet } from "./document-content-schema.js";
import { getTuning } from "../config/runtime-tuning-settings.js";

/**
 * Chặn nội dung quá khổ TRƯỚC khi dựng file. Bot đọc tin người lạ nên đây là
 * chốt chặn thật, không phải phòng xa: dựng file là việc tốn CPU nhất trong một
 * lượt agent.
 *
 * Trả về lý do bằng tiếng Việt thay vì throw - tool sẽ đưa nguyên câu đó cho
 * model đọc để nó tự rút gọn rồi gọi lại (cùng luật với web_search/read_image).
 */

export type LimitCheck = { ok: true } | { ok: false; reason: string };

const ok: LimitCheck = { ok: true };
const fail = (reason: string): LimitCheck => ({ ok: false, reason });

function countBlockChars(block: DocumentBlock): number {
  switch (block.type) {
    case "heading":
    case "paragraph":
      return block.text.length;
    case "bullets":
      return block.items.reduce((sum, item) => sum + item.length, 0);
    case "table":
      return (
        block.headers.reduce((sum, h) => sum + h.length, 0) +
        block.rows.reduce((sum, row) => sum + row.reduce((s, cell) => s + cell.length, 0), 0)
      );
    case "two_columns":
      return [...block.left, ...block.right].reduce((sum, line) => sum + line.length, 0);
  }
}

export function checkDocumentLimits(blocks: DocumentBlock[]): LimitCheck {
  if (blocks.length > getTuning("DOCUMENT_MAX_BLOCKS")) {
    return fail(
      `Tài liệu có ${blocks.length} phần, vượt trần ${getTuning("DOCUMENT_MAX_BLOCKS")}. Hãy rút gọn rồi gọi lại.`,
    );
  }

  for (const block of blocks) {
    if (block.type === "table" && block.rows.length > getTuning("DOCUMENT_MAX_ROWS")) {
      return fail(
        `Bảng có ${block.rows.length} dòng, vượt trần ${getTuning("DOCUMENT_MAX_ROWS")}. Hãy bớt dòng rồi gọi lại.`,
      );
    }
    // Bảng lệch số cột so với header thì file dựng ra méo mó - chặn ngay
    if (block.type === "table") {
      const bad = block.rows.findIndex((row) => row.length !== block.headers.length);
      if (bad >= 0) {
        return fail(
          `Dòng ${bad + 1} của bảng có ${block.rows[bad]!.length} ô nhưng bảng có ${block.headers.length} cột. Mọi dòng phải đủ số ô.`,
        );
      }
    }
  }

  const chars = blocks.reduce((sum, block) => sum + countBlockChars(block), 0);
  if (chars > getTuning("DOCUMENT_MAX_CHARS")) {
    return fail(
      `Nội dung dài ${chars} ký tự, vượt trần ${getTuning("DOCUMENT_MAX_CHARS")}. Hãy tóm gọn lại rồi gọi lại.`,
    );
  }

  return ok;
}

export function checkSpreadsheetLimits(sheets: Sheet[]): LimitCheck {
  if (sheets.length > getTuning("DOCUMENT_MAX_SHEETS")) {
    return fail(`Có ${sheets.length} sheet, vượt trần ${getTuning("DOCUMENT_MAX_SHEETS")}.`);
  }

  let chars = 0;
  for (const sheet of sheets) {
    if (sheet.rows.length > getTuning("DOCUMENT_MAX_ROWS")) {
      return fail(
        `Sheet "${sheet.name}" có ${sheet.rows.length} dòng, vượt trần ${getTuning("DOCUMENT_MAX_ROWS")}.`,
      );
    }
    const bad = sheet.rows.findIndex((row) => row.length !== sheet.headers.length);
    if (bad >= 0) {
      return fail(
        `Sheet "${sheet.name}" dòng ${bad + 1} có ${sheet.rows[bad]!.length} ô nhưng có ${sheet.headers.length} cột. Mọi dòng phải đủ số ô.`,
      );
    }
    chars += sheet.headers.reduce((sum, h) => sum + h.length, 0);
    for (const row of sheet.rows) {
      for (const cell of row) {
        if (cell.kind === "text") chars += cell.value.length;
      }
    }
  }

  if (chars > getTuning("DOCUMENT_MAX_CHARS")) {
    return fail(`Nội dung dài ${chars} ký tự, vượt trần ${getTuning("DOCUMENT_MAX_CHARS")}.`);
  }

  return ok;
}

function countSlideChars(slide: PresentationSlide): number {
  switch (slide.type) {
    case "title":
    case "section":
      return slide.title.length + (slide.subtitle?.length ?? 0);
    case "bullets":
      return slide.heading.length + slide.items.reduce((sum, item) => sum + item.length, 0);
    case "stat_highlight":
      return (
        (slide.heading?.length ?? 0) +
        slide.stats.reduce((sum, stat) => sum + stat.value.length + stat.label.length, 0)
      );
    case "table":
      return (
        slide.heading.length +
        slide.headers.reduce((sum, h) => sum + h.length, 0) +
        slide.rows.reduce((sum, row) => sum + row.reduce((s, cell) => s + cell.length, 0), 0)
      );
    case "two_content":
      return (
        slide.heading.length +
        (slide.leftTitle?.length ?? 0) +
        (slide.rightTitle?.length ?? 0) +
        [...slide.left, ...slide.right].reduce((sum, line) => sum + line.length, 0)
      );
  }
}

export function checkPresentationLimits(slides: PresentationSlide[]): LimitCheck {
  if (slides.length > getTuning("DOCUMENT_MAX_SLIDES")) {
    return fail(
      `Bài trình chiếu có ${slides.length} slide, vượt trần ${getTuning("DOCUMENT_MAX_SLIDES")}. Hãy rút gọn rồi gọi lại.`,
    );
  }

  for (const slide of slides) {
    if (slide.type !== "table") continue;
    if (slide.rows.length > getTuning("DOCUMENT_MAX_ROWS")) {
      return fail(
        `Slide "${slide.heading}" có bảng ${slide.rows.length} dòng, vượt trần ${getTuning("DOCUMENT_MAX_ROWS")}. Hãy bớt dòng rồi gọi lại.`,
      );
    }
    const bad = slide.rows.findIndex((row) => row.length !== slide.headers.length);
    if (bad >= 0) {
      return fail(
        `Slide "${slide.heading}" dòng ${bad + 1} có ${slide.rows[bad]!.length} ô nhưng bảng có ${slide.headers.length} cột. Mọi dòng phải đủ số ô.`,
      );
    }
  }

  const chars = slides.reduce((sum, slide) => sum + countSlideChars(slide), 0);
  if (chars > getTuning("DOCUMENT_MAX_CHARS")) {
    return fail(
      `Nội dung dài ${chars} ký tự, vượt trần ${getTuning("DOCUMENT_MAX_CHARS")}. Hãy tóm gọn lại rồi gọi lại.`,
    );
  }

  return ok;
}

/**
 * Tên file an toàn: bỏ đường dẫn, bỏ ký tự lạ, ép đúng đuôi. Model có thể gửi
 * "../../data/accounts/credentials" hoặc "bao gia.exe" - cả hai đều phải về
 * dạng vô hại trước khi chạm đĩa.
 */
export type DuoiFileChoPhep = "docx" | "xlsx" | "pptx" | "pdf" | "md" | "html" | "csv" | "txt" | "mp4";

/**
 * Trần cho file văn bản thuần (.md/.txt/.html) - nội dung vào dạng CHUỖI THÔ
 * chứ không phải khối có cấu trúc, nên `checkDocumentLimits` không đếm được.
 *
 * Dùng chung `DOCUMENT_MAX_CHARS` để người dùng chỉ phải chỉnh một con số trên
 * trang Cấu hình, thay vì đoán xem trần nào áp cho định dạng nào.
 */
export function checkTextContentLimits(noiDung: string): LimitCheck {
  const tran = getTuning("DOCUMENT_MAX_CHARS");
  if (noiDung.length > tran) {
    return fail(
      `Nội dung dài ${noiDung.length} ký tự, vượt trần ${tran}. Hãy tóm gọn lại rồi gọi lại.`,
    );
  }
  if (!noiDung.trim()) return fail("Nội dung rỗng - không có gì để ghi vào file.");
  return ok;
}

export function safeFileName(raw: string, extension: DuoiFileChoPhep): string {
  const base = raw
    .replace(/[\\/]/g, " ") // chặn path traversal ngay từ đầu
    .replace(/\.[^.]*$/, "") // bỏ đuôi cũ (kể cả .exe)
    .replace(/[^\p{L}\p{N}\s._-]/gu, "") // giữ chữ (có dấu), số, khoảng trắng, . _ -
    // Gộp chuỗi dấu chấm liên tiếp rồi cắt dấu chấm ở hai đầu: "../.." sau các
    // bước trên còn ".. .." - không thoát được thư mục (đã có path.basename) nhưng
    // là tên file bẩn, và dấu chấm đầu tên tạo file ẩn trên Linux
    .replace(/\.{2,}/g, ".")
    .replace(/^[.\s]+|[.\s]+$/g, "")
    .trim()
    .slice(0, 80);
  return `${base || "tai-lieu"}.${extension}`;
}
