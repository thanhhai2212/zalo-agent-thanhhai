import { htmlToReadableText } from "../shared/html-to-text.js";

/**
 * Đọc file DẠNG CHỮ người dùng gửi qua Zalo (.md, .txt, .html, .csv, .json,
 * mã nguồn...) - 2026-09-28, trước đó bot báo "định dạng chưa hỗ trợ đọc" cho
 * mọi file ngoài PDF/Word/Excel/PowerPoint dù đây là loại dễ đọc nhất.
 *
 * Không cần thư viện: giải mã chữ rồi (với HTML) bóc thẻ bằng đúng bộ lọc
 * `web_fetch` đang dùng. Chỉ ĐỌC, không chạy gì trong file.
 */

export const HTML_EXTENSIONS = ["html", "htm", "xhtml"] as const;

export const PLAIN_TEXT_EXTENSIONS = [
  ...HTML_EXTENSIONS,
  "md", "markdown", "txt", "text", "log", "csv", "tsv", "json", "jsonl", "xml", "yaml", "yml",
  "ini", "toml", "env", "srt", "vtt", "sql", "rtf",
  "js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "java", "c", "cpp", "h", "cs", "go", "rs", "php", "rb",
  "sh", "bat", "ps1", "css", "scss", "vue", "svelte", "kt", "swift", "dart", "r", "lua", "pl",
] as const;

/** Trần chữ đưa cho model: file chữ có thể rất dài (log, CSV lớn), cắt để không đốt hết ngữ cảnh. */
export const TRAN_KY_TU_FILE_CHU = 60_000;

/** Giải mã theo BOM (UTF-8/UTF-16), mặc định UTF-8 - file Windows cũ lưu UTF-16 vẫn đọc được. */
export function giaiMaChu(data: Buffer): string {
  if (data.length >= 2 && data[0] === 0xff && data[1] === 0xfe) return data.subarray(2).toString("utf16le");
  if (data.length >= 2 && data[0] === 0xfe && data[1] === 0xff) {
    const lat = Buffer.from(data.subarray(2));
    lat.swap16();
    return lat.toString("utf16le");
  }
  const s = data.toString("utf8");
  return s.charCodeAt(0) === 0xfeff ? s.slice(1) : s;
}

export function extractPlainText(data: Buffer, ext: string): string {
  // File nhị phân đội lốt đuôi chữ (có byte 0 sớm) thì không đọc - tránh đổ rác cho model.
  if (data.subarray(0, 4096).includes(0) && !(data[0] === 0xff || data[0] === 0xfe)) {
    throw new Error("File có vẻ là nhị phân, không phải chữ");
  }
  let text = giaiMaChu(data).replace(/\r\n?/g, "\n");
  if ((HTML_EXTENSIONS as readonly string[]).includes(ext)) text = htmlToReadableText(text);
  text = text.trim();
  if (text.length > TRAN_KY_TU_FILE_CHU) {
    const conLai = text.length - TRAN_KY_TU_FILE_CHU;
    text = `${text.slice(0, TRAN_KY_TU_FILE_CHU)}\n\n[... file còn ${conLai} ký tự nữa, bot chỉ đọc ${TRAN_KY_TU_FILE_CHU} ký tự đầu]`;
  }
  return text;
}
