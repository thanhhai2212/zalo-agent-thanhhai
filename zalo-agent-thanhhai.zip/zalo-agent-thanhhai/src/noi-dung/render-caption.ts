import type { DocumentBlock } from "../documents/document-content-schema.js";
import { renderDocx } from "../documents/render-docx.js";

/**
 * Dựng file Word caption từ lịch content: mỗi bài một mục (kênh, định dạng, tiêu đề, caption
 * đầy đủ, hashtag, gợi ý hình). Cảnh báo/chỗ cần điền do CODE phát hiện, không để model tự khai.
 */

export type BaiCaption = {
  ngay: string;
  kenh: string;
  dinh_dang: string;
  tieu_de: string;
  caption: string;
  hashtag: string[];
  cta: string;
  y_tuong_hinh: string;
};

export type BoCaption = {
  tieu_de: string;
  thuong_hieu: string;
  bai: BaiCaption[];
};

const CHO_TRONG_RE = /\[[^\]\n]{1,200}\]/g;
const TUYEN_BO_RE = /chữa (khỏi|bệnh|trị)|trị bệnh|ngừa ung thư|giảm cân|tăng cường miễn dịch|đảm bảo 100|cam kết hiệu quả|hiệu quả 100|khỏi bệnh/i;

function toanVan(b: BaiCaption): string {
  return [b.caption, b.cta, b.hashtag.join(" ")].join("\n");
}

export function choCanDien(b: BaiCaption): string[] {
  return [...new Set([...(toanVan(b) + "\n" + b.y_tuong_hinh).matchAll(CHO_TRONG_RE)].map((m) => m[0]))];
}

/** Cảnh báo không chặn, để model nói thật với người dùng khi bàn giao. */
export function canhBaoCaption(bo: BoCaption): string[] {
  const ra: string[] = [];
  for (const b of bo.bai) {
    const nhan = `${b.ngay} (${b.kenh})`;
    const dai = [b.caption, b.cta, b.hashtag.join(" ")].join("\n").length;
    if (/tiktok/i.test(b.kenh) && dai > 2200) ra.push(`${nhan}: caption TikTok ${dai} ký tự, vượt giới hạn 2200`);
    if (b.hashtag.length > 10) ra.push(`${nhan}: ${b.hashtag.length} hashtag, nên 3-8`);
    if (b.hashtag.length === 0) ra.push(`${nhan}: chưa có hashtag`);
    if (TUYEN_BO_RE.test(toanVan(b))) ra.push(`${nhan}: có câu giống tuyên bố sức khỏe/quá mức, cần rà lại`);
  }
  return ra;
}

const chuanHashtag = (h: string) => (h.startsWith("#") ? h : `#${h.replace(/^\s+/, "")}`).replace(/\s+/g, "");

export function dungKhoiCaption(bo: BoCaption): DocumentBlock[] {
  const kh: DocumentBlock[] = [
    { type: "paragraph", text: `**Thương hiệu:** ${bo.thuong_hieu}`, align: "left" },
    {
      type: "paragraph",
      text: "**Cách dùng:** đây là bản nháp do AI soạn. Chỗ trong ngoặc vuông [ ] là chi tiết riêng chỉ bạn biết, hãy điền chuyện thật trước khi đăng. Đọc lại giá, ưu đãi, thông tin sản phẩm và điều chỉnh cho đúng giọng của bạn. Đừng đăng chi tiết không có thật.",
      align: "left",
    },
  ];
  bo.bai.forEach((b, i) => {
    kh.push({ type: "heading", text: `${i + 1}. ${b.ngay} - ${b.kenh} - ${b.dinh_dang}: ${b.tieu_de}`, level: 1 });
    kh.push({ type: "paragraph", text: "**Caption:**", align: "left" });
    kh.push({ type: "paragraph", text: b.caption, align: "left" });
    kh.push({ type: "paragraph", text: `**CTA:** ${b.cta}`, align: "left" });
    if (b.hashtag.length) kh.push({ type: "paragraph", text: `**Hashtag:** ${b.hashtag.map(chuanHashtag).join(" ")}`, align: "left" });
    kh.push({ type: "paragraph", text: `**Gợi ý hình/cảnh:** ${b.y_tuong_hinh}`, align: "left" });
    const dien = choCanDien(b);
    if (dien.length) kh.push({ type: "paragraph", text: `**Cần bạn điền trước khi đăng:** ${dien.join(" ; ")}`, align: "left" });
  });
  return kh;
}

export async function renderCaption(bo: BoCaption): Promise<Buffer> {
  return renderDocx(dungKhoiCaption(bo), { title: bo.tieu_de });
}
