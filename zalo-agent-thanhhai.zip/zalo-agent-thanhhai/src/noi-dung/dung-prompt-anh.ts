import { TI_LE_ANH, type TiLeAnh } from "../images/crop-ti-le.js";

/**
 * Dựng prompt vẽ ảnh bài đăng. Khối phong cách thương hiệu, quy tắc chữ trên ảnh và các điều
 * cấm do CODE chèn vào mọi ảnh của bộ, nên cả bộ nhất quán dù model viết ý tưởng mỗi ảnh một kiểu.
 */

export type PhongCachThuongHieu = {
  thuong_hieu: string;
  /** Phong cách thị giác chung: loại ảnh, ánh sáng, cảm giác. */
  phong_cach: string;
  /** Bảng màu chủ đạo. */
  mau_sac: string;
  /** Điều cần tránh riêng của thương hiệu (tùy chọn). */
  tranh?: string;
};

export type YTuongAnh = {
  ti_le: TiLeAnh;
  y_tuong: string;
  /** Chữ DUY NHẤT hiện trên ảnh (ngắn); bỏ trống = ảnh không có chữ. */
  chu_tren_anh?: string;
};

export function dungPromptAnh(pc: PhongCachThuongHieu, a: YTuongAnh): string {
  const chu = a.chu_tren_anh?.trim()
    ? `Chữ trên ảnh: chỉ có đúng dòng chữ "${a.chu_tren_anh.trim()}", viết tiếng Việt có dấu chính xác từng ký tự, chữ lớn, đậm, dễ đọc, không thêm chữ nào khác.`
    : "Không có chữ, không logo, không watermark trên ảnh.";
  return [
    `Ảnh bài đăng mạng xã hội cho thương hiệu "${pc.thuong_hieu}".`,
    `Phong cách thị giác chung (giữ nhất quán cho cả bộ ảnh): ${pc.phong_cach}. Bảng màu chủ đạo: ${pc.mau_sac}.`,
    `Tỉ lệ khung hình ${a.ti_le} (${TI_LE_ANH[a.ti_le].mo_ta}). Đặt chủ thể ở giữa và chừa lề an toàn để cắt đúng tỉ lệ.`,
    `Nội dung ảnh: ${a.y_tuong.trim()}.`,
    chu,
    `Tránh: ${pc.tranh?.trim() ? pc.tranh.trim() + "; " : ""}logo hoặc thương hiệu thật của hãng khác, người nổi tiếng, hình ảnh gây hiểu nhầm về sản phẩm.`,
  ].join("\n");
}
