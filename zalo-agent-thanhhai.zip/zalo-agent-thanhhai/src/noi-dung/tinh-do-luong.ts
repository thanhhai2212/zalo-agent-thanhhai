/**
 * Tính số liệu đo lường bài đăng. TẤT CẢ phép tính nằm ở đây (không để model tính nhẩm): tỉ lệ
 * tương tác từng bài, gộp theo trụ cột / kênh / định dạng, top-bottom, cảnh báo mẫu ít. Ô thiếu
 * là null và KHÔNG bị coi là 0 (thiếu số khác với số 0).
 */

export type So = number | null | undefined;

export type BaiDoLuong = {
  ngay: string;
  kenh: string;
  dinh_dang: string;
  tru_cot?: string;
  tieu_de: string;
  tiep_can?: So;
  luot_xem?: So;
  thich?: So;
  binh_luan?: So;
  chia_se?: So;
  luu?: So;
  click?: So;
  don?: So;
};

export type BaiDaTinh = BaiDoLuong & {
  tuongTac: number | null;
  nen: number | null;
  loaiNen: "tiếp cận" | "lượt xem" | null;
  er: number | null;
  chuyenDoi: number | null;
};

export type TheoNen = { n: number; tuongTac: number; nen: number; er: number | null };

/**
 * Nhóm KHÔNG có tỉ lệ gộp: mỗi nhóm có hai tỉ lệ riêng theo nền (tiếp cận / lượt xem). Gộp hai nền
 * làm tỉ lệ bị kéo theo cơ cấu kênh của nhóm (đo thật 2026-10-02: trụ cột nhiều bài TikTok trông
 * "mạnh nhất" chỉ vì tính trên lượt xem), nên chỉ so sánh trong CÙNG nền.
 */
export type Nhom = {
  loai: "Trụ cột" | "Kênh" | "Định dạng";
  ten: string;
  soBai: number;
  soBaiCoEr: number;
  tiepCan: TheoNen;
  luotXem: TheoNen;
  doTinCay: string;
};

const co = (v: So): v is number => typeof v === "number" && Number.isFinite(v);

export function tinhBai(b: BaiDoLuong): BaiDaTinh {
  const cacSo = [b.thich, b.binh_luan, b.chia_se, b.luu].filter(co);
  const tuongTac = cacSo.length ? cacSo.reduce((a, v) => a + v, 0) : null;
  let nen: number | null = null;
  let loaiNen: BaiDaTinh["loaiNen"] = null;
  if (co(b.tiep_can) && b.tiep_can > 0) {
    nen = b.tiep_can;
    loaiNen = "tiếp cận";
  } else if (co(b.luot_xem) && b.luot_xem > 0) {
    nen = b.luot_xem;
    loaiNen = "lượt xem";
  }
  const er = tuongTac !== null && nen !== null ? tuongTac / nen : null;
  const chuyenDoi = co(b.don) && co(b.click) && b.click > 0 ? b.don / b.click : null;
  return { ...b, tuongTac, nen, loaiNen, er, chuyenDoi };
}

function theoNen(ds: BaiDaTinh[], loaiNen: BaiDaTinh["loaiNen"]): TheoNen {
  const x = ds.filter((b) => b.er !== null && b.loaiNen === loaiNen);
  const tuongTac = x.reduce((a, b) => a + b.tuongTac!, 0);
  const nen = x.reduce((a, b) => a + b.nen!, 0);
  return { n: x.length, tuongTac, nen, er: nen > 0 ? tuongTac / nen : null };
}

export function gomNhom(loai: Nhom["loai"], bai: BaiDaTinh[], khoa: (b: BaiDaTinh) => string | undefined): Nhom[] {
  const map = new Map<string, BaiDaTinh[]>();
  for (const b of bai) {
    const k = (khoa(b) ?? "").trim() || "(chưa gán)";
    map.set(k, [...(map.get(k) ?? []), b]);
  }
  return [...map.entries()]
    .map(([ten, ds]) => {
      const tiepCan = theoNen(ds, "tiếp cận");
      const luotXem = theoNen(ds, "lượt xem");
      const coEr = tiepCan.n + luotXem.n;
      let doTinCay = "Đủ mẫu (so sánh trong cùng nền tính)";
      if (coEr === 0) doTinCay = "Chưa có số liệu để tính";
      else if (Math.max(tiepCan.n, luotXem.n) < 3) doTinCay = "Mẫu ít (dưới 3 bài cùng nền), chỉ tham khảo";
      return { loai, ten, soBai: ds.length, soBaiCoEr: coEr, tiepCan, luotXem, doTinCay };
    })
    .sort((a, b) => b.soBai - a.soBai);
}

export type KetQuaDoLuong = {
  bai: BaiDaTinh[];
  nhom: Nhom[];
  tong: { soBai: number; soBaiCoEr: number; tuongTac: number; nen: number; er: number | null; tiepCan: number; luotXem: number; don: number; click: number };
  /** Bài nổi bật theo TỪNG nền tính (không xếp hạng lẫn tiếp cận với lượt xem). */
  noiBat: { nen: "tiếp cận" | "lượt xem"; top: BaiDaTinh[]; bottom: BaiDaTinh[] }[];
  canhBao: string[];
};

export function tinhDoLuong(dau: BaiDoLuong[]): KetQuaDoLuong {
  const bai = dau.map(tinhBai);
  const coEr = bai.filter((b) => b.er !== null);
  const tuongTac = coEr.reduce((a, b) => a + b.tuongTac!, 0);
  const nen = coEr.reduce((a, b) => a + b.nen!, 0);
  const tong = {
    soBai: bai.length,
    soBaiCoEr: coEr.length,
    tuongTac,
    nen,
    er: nen > 0 ? tuongTac / nen : null,
    tiepCan: bai.reduce((a, b) => a + (co(b.tiep_can) ? b.tiep_can : 0), 0),
    luotXem: bai.reduce((a, b) => a + (co(b.luot_xem) ? b.luot_xem : 0), 0),
    don: bai.reduce((a, b) => a + (co(b.don) ? b.don : 0), 0),
    click: bai.reduce((a, b) => a + (co(b.click) ? b.click : 0), 0),
  };
  const noiBat = (["tiếp cận", "lượt xem"] as const)
    .map((loaiNen) => {
      const xep = coEr.filter((b) => b.loaiNen === loaiNen).sort((a, b) => b.er! - a.er!);
      const n = xep.length >= 6 ? 3 : Math.floor(xep.length / 2);
      return { nen: loaiNen, top: xep.slice(0, n), bottom: n > 0 ? xep.slice(-n).reverse() : [] };
    })
    .filter((x) => x.top.length > 0);
  const nhom = [
    ...gomNhom("Trụ cột", bai, (b) => b.tru_cot),
    ...gomNhom("Kênh", bai, (b) => b.kenh),
    ...gomNhom("Định dạng", bai, (b) => b.dinh_dang),
  ];

  const canhBao: string[] = [];
  if (bai.length < 5) canhBao.push(`Chỉ có ${bai.length} bài: quá ít để rút ra quy luật, chỉ nên coi là tham khảo.`);
  else if (coEr.length < 5) canhBao.push(`Chỉ ${coEr.length}/${bai.length} bài đủ số liệu để tính tỉ lệ tương tác: kết luận còn yếu.`);
  const thieu = bai.length - coEr.length;
  if (thieu > 0 && bai.length >= 5) canhBao.push(`${thieu} bài thiếu số tiếp cận/lượt xem hoặc số tương tác nên chưa được tính tỉ lệ.`);
  if (new Set(coEr.map((b) => b.loaiNen)).size > 1) canhBao.push("Có bài tính trên lượt tiếp cận, có bài trên lượt xem: tỉ lệ được TÁCH THEO NỀN và chỉ so sánh trong cùng nền; không xếp hạng lẫn hai loại.");
  return { bai, nhom, tong, noiBat, canhBao };
}

export function phanTram(v: number | null): string {
  return v === null ? "chưa có" : `${(v * 100).toFixed(1)}%`;
}
