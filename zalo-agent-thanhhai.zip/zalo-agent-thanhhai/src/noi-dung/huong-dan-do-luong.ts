/**
 * Quy trình đo lường bài đăng (khâu 5 của hướng "Zalo Agent business", 2026-10-02). Nạp THEO
 * YÊU CẦU qua tool `huong_dan_do_luong`; bot dựng báo cáo bằng `bao_cao_do_luong`.
 */
export const HUONG_DAN_DO_LUONG = `# Đo lường bài đăng

Mục tiêu: biết bài nào, trụ cột nào, kênh nào đang hiệu quả để chỉnh lịch tuần sau. Bot KHÔNG tự lấy số từ Facebook hay TikTok của người dùng: số liệu do người dùng đưa vào. MỌI phép tính do công cụ làm, bạn không tính nhẩm.

## 1. Lấy số liệu (một trong ba cách)
- Người dùng gửi file Excel/CSV xuất từ Meta Business Suite, TikTok Analytics hoặc file nhập tay: đọc file, ghép cột.
- Người dùng nhập số qua chat hoặc gửi ảnh chụp màn hình thống kê: đọc ra từng bài.
- Lịch content trong cuộc trò chuyện: dùng để gắn trụ cột, kênh, định dạng cho từng bài (khớp theo ngày và tiêu đề).

## 2. Hỏi nếu thiếu (một tin gộp, đánh số)
1. Kỳ đo (từ ngày nào đến ngày nào)?
2. Mục tiêu đo (tương tác, inbox, đơn hàng)?
3. Số liệu lấy ở nền tảng nào và lấy ngày nào (số liệu bài mới đăng thì chưa ổn định, tốt nhất đo sau 3 đến 7 ngày)?
Đủ thông tin rồi thì làm, đừng hỏi lại.

## 3. Nhập liệu đúng
- Mỗi bài: ngay, kenh, dinh_dang, tru_cot (lấy từ lịch nếu có), tieu_de, rồi các số có được: tiep_can, luot_xem, thich, binh_luan, chia_se, luu, click, don.
- Số nào KHÔNG có thì BỎ TRỐNG (null), tuyệt đối không điền 0 và không đoán. Thiếu số khác với số 0.
- Đổi "1,2K" thành 1200, "3,4 triệu" thành 3400000 CHỈ khi chắc chắn; không chắc thì bỏ trống và ghi vào gioi_han.
- Không bịa số, không "làm tròn cho đẹp", không suy số từ bài khác.
- Dữ liệu người dùng nói rõ là mẫu/thử nghiệm: đặt du_lieu_mau=true. Bài có tiêu đề bắt đầu bằng [MẪU] công cụ tự nhận ra.

## 4. Nhận định và đề xuất (phần của bạn)
- Đọc các sheet số liệu mà công cụ tính (tỉ lệ tương tác, theo trụ cột, theo kênh, theo định dạng, bài nổi bật).
- nhan_dinh_ai: điều số liệu gợi ý, viết thận trọng ("có vẻ", "gợi ý rằng"). Mẫu dưới 5 bài, hoặc nhóm dưới 3 bài thì KHÔNG kết luận chắc, chỉ nói cần thêm dữ liệu.
- de_xuat: điều chỉnh cụ thể cho lịch tuần sau, bám trụ cột và định dạng trong lịch (đổi tỷ trọng, thêm bài định dạng hiệu quả, bỏ bài kém). Mỗi đề xuất nêu dựa trên con số nào.
- gioi_han: số liệu thiếu, nền tính khác nhau, bài còn quá mới, không phân biệt được tác động của giờ đăng hay nội dung.
- KHÔNG xếp hạng trụ cột hay kênh bằng một tỉ lệ gộp: bài tính trên LƯỢT XEM (TikTok) và bài tính trên TIẾP CẬN (Facebook) không so sánh được. Công cụ tách tỉ lệ theo từng nền; bạn chỉ so sánh trong CÙNG nền, và nói rõ nhóm nào cơ cấu kênh khác nhau.
- Tương quan không phải nhân quả: đừng khẳng định "vì X nên tăng".

## 5. Dựng file
Gọi bao_cao_do_luong. Công cụ tự tính tỉ lệ, gom nhóm, cảnh báo mẫu ít, và đánh dấu dữ liệu mẫu ở mọi sheet. Sau khi file gửi, nhắn tin ngắn: nêu 2 đến 3 điểm chính, các cảnh báo công cụ trả về, và hỏi có muốn chỉnh lịch tuần sau theo đề xuất không. KHÔNG dán lại cả bảng vào chat.

## Quy tắc
- Chỉ phân tích số người dùng cung cấp. Không hứa kết quả tăng trưởng.
- Dữ liệu mẫu phải luôn được nói rõ là mẫu, không dùng để ra quyết định thật.`;
