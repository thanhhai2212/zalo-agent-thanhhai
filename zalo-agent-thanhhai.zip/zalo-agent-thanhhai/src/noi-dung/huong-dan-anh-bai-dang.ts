/**
 * Quy trình tạo ảnh bài đăng (khâu 4 của hướng "Zalo Agent business", 2026-10-02). Nạp THEO YÊU
 * CẦU qua tool `huong_dan_anh_bai_dang`; bot vẽ bằng tool `tao_anh_bai_dang`.
 */
export const HUONG_DAN_ANH_BAI_DANG = `# Tạo ảnh bài đăng

Mục tiêu: một bộ ảnh nhất quán thương hiệu, đúng khung từng kênh, lấy ý tưởng từ cột "Gợi ý hình" của caption/lịch. Mỗi ảnh vẽ mất khoảng 1 đến 3 phút và tốn hạn mức nên chỉ vẽ ảnh người dùng chọn.

## 1. Lấy đầu vào
- Lấy các bài cần ảnh từ caption/lịch trong cuộc trò chuyện (ngày, kênh, định dạng, ý tưởng hình). Không còn thì nhờ người dùng gửi lại file.
- Hỏi ngắn (một tin, đánh số) nếu thiếu: vẽ ảnh cho bài nào (tối đa 6 ảnh mỗi lần), phong cách thị giác thương hiệu (ảnh chụp thật hay minh họa, ánh sáng, cảm giác), bảng màu, điều cần tránh, có cần chữ trên ảnh không.
- Đã có phong cách và bảng màu trong lịch hoặc trước đó thì dùng lại, đừng hỏi lại.

## 2. Chuẩn bị từng ảnh
- ti_le theo kênh: Facebook bài thường 1:1 hoặc 4:5; carousel 1:1 hoặc 4:5 (mỗi slide một ảnh); TikTok/Reels/Story 9:16; ảnh bìa ngang 16:9. Công cụ tự cắt về đúng tỉ lệ.
- y_tuong: mô tả CẢNH cụ thể: chủ thể, bối cảnh, hành động, góc máy, ánh sáng. Một ý chính mỗi ảnh. Không dán nguyên cả caption vào.
- Chữ trên ảnh: model vẽ chữ tiếng Việt dễ sai dấu. Mặc định KHÔNG chữ. Cần chữ thì tối đa 4 đến 6 từ, in hoa hoặc câu ngắn; chữ dài, giá, số điện thoại, tên riêng thì để người dùng thêm bằng Canva hoặc công cụ chỉnh ảnh.
- Carousel: mỗi slide là một ảnh riêng, cùng phong cách và bảng màu, ghi số thứ tự trong ten.

## 3. Trung thực (bắt buộc)
- Ảnh do AI vẽ là ảnh MINH HỌA. Không dùng để giả làm ảnh sản phẩm thật, vườn thật, quy trình thật, người thật của thương hiệu khi chưa chụp. Cần minh bạch thì nhắc người dùng ghi chú "ảnh minh họa".
- Không tạo ảnh có người nổi tiếng, logo thương hiệu khác, ảnh "trước và sau", kết quả sức khỏe, giấy chứng nhận hay đánh giá giả.
- Bài có chuyện cá nhân thật: gợi ý người dùng dùng ảnh chụp thật của họ thay vì ảnh AI.

## 4. Vẽ
Gọi tao_anh_bai_dang một lần cho cả bộ (tối đa 6 ảnh), kèm phong cách thương hiệu. Công cụ chèn phong cách vào mọi ảnh, vẽ, cắt đúng tỉ lệ rồi gửi từng ảnh vào chat. Chạm trần ảnh mỗi giờ thì ảnh còn lại báo "chưa vẽ". Sau khi xong, nhắn tin ngắn: ảnh nào đã xong, ảnh nào lỗi, nhắc ảnh AI là minh họa và chữ dài nên thêm sau, rồi hỏi có muốn vẽ lại hoặc chỉnh ảnh nào không (sửa ảnh dùng create_image).

## Quy tắc
- Chỉ tạo ảnh, không đăng bài. Không gợi ý ảnh gây hiểu nhầm hoặc vi phạm điều khoản nền tảng.`;
