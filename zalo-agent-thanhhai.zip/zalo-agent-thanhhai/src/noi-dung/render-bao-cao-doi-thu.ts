import type { DocumentBlock } from "../documents/document-content-schema.js";
import { renderDocx } from "../documents/render-docx.js";

/**
 * Dựng báo cáo nghiên cứu đối thủ thành file Word. Model chỉ đưa DỮ LIỆU; bố cục cố
 * định ở đây nên báo cáo luôn có cùng khung: tóm tắt, từng đối thủ (kèm độ tin cậy và
 * nguồn), bảng so sánh, cơ hội, đề xuất, giới hạn dữ liệu.
 */

export type DoTinCay = "cao" | "vua" | "thap";

export type DoiThu = {
  ten: string;
  website?: string;
  dinh_vi: string;
  diem_manh: string[];
  diem_yeu: string[];
  /** Ý kiến/đánh giá của AI KHÔNG có nguồn trực tiếp (vd "ít tương tác cộng đồng"). */
  nhan_dinh_ai?: string[];
  gia?: string;
  kenh?: string[];
  thong_diep?: string;
  do_tin_cay: DoTinCay;
  nguon: string[];
};

export type BaoCaoDoiThu = {
  tieu_de: string;
  san_pham: string;
  thi_truong: string;
  tom_tat: string[];
  doi_thu: DoiThu[];
  bang_so_sanh?: { tieu_chi: string[]; hang: { ten: string; gia_tri: string[] }[] };
  co_hoi: string[];
  de_xuat: string[];
  han_che_du_lieu: string[];
};

const NHAN_TIN_CAY: Record<DoTinCay, string> = { cao: "Cao", vua: "Vừa", thap: "Thấp (cần xác minh thêm)" };

export function dungKhoiBaoCao(b: BaoCaoDoiThu): DocumentBlock[] {
  const kh: DocumentBlock[] = [
    { type: "paragraph", text: `**Sản phẩm/dịch vụ:** ${b.san_pham}`, align: "left" },
    { type: "paragraph", text: `**Thị trường:** ${b.thi_truong}`, align: "left" },
    {
      type: "paragraph",
      text: "**Cách đọc báo cáo:** điểm mạnh, điểm yếu, giá và thông điệp của từng đối thủ là dữ kiện có nguồn ở cuối mục đó. Mục \"Nhận định của AI\", cơ hội và đề xuất là phân tích của AI dựa trên dữ kiện, cần bạn kiểm chứng trước khi quyết định.",
      align: "left",
    },
    { type: "heading", text: "1. Tóm tắt", level: 1 },
    { type: "bullets", items: b.tom_tat },
    { type: "heading", text: "2. Từng đối thủ", level: 1 },
  ];
  for (const d of b.doi_thu) {
    kh.push({ type: "heading", text: d.ten, level: 2 });
    kh.push({ type: "paragraph", text: `**Định vị:** ${d.dinh_vi}`, align: "left" });
    if (d.website) kh.push({ type: "paragraph", text: `**Website:** ${d.website}`, align: "left" });
    if (d.gia) kh.push({ type: "paragraph", text: `**Giá:** ${d.gia}`, align: "left" });
    if (d.thong_diep) kh.push({ type: "paragraph", text: `**Thông điệp chính:** ${d.thong_diep}`, align: "left" });
    if (d.kenh?.length) kh.push({ type: "paragraph", text: `**Kênh:** ${d.kenh.join(", ")}`, align: "left" });
    kh.push({ type: "paragraph", text: "**Điểm mạnh:**", align: "left" }, { type: "bullets", items: d.diem_manh });
    kh.push({ type: "paragraph", text: "**Điểm yếu:**", align: "left" }, { type: "bullets", items: d.diem_yeu });
    if (d.nhan_dinh_ai?.length) {
      kh.push({ type: "paragraph", text: "**Nhận định của AI (không có nguồn trực tiếp, cần kiểm chứng):**", align: "left" }, { type: "bullets", items: d.nhan_dinh_ai });
    }
    kh.push({ type: "paragraph", text: `**Độ tin cậy dữ liệu:** ${NHAN_TIN_CAY[d.do_tin_cay]}`, align: "left" });
    kh.push({ type: "paragraph", text: "**Nguồn:**", align: "left" }, { type: "bullets", items: d.nguon });
  }
  if (b.bang_so_sanh && b.bang_so_sanh.hang.length) {
    const t = b.bang_so_sanh;
    kh.push({ type: "heading", text: "3. Bảng so sánh", level: 1 });
    kh.push({
      type: "table",
      // Bảng Word tối đa 8 cột (schema khối): cột đầu là tên đối thủ + 7 tiêu chí đầu.
      headers: ["Đối thủ", ...t.tieu_chi.slice(0, 7)],
      rows: t.hang.map((h) => [h.ten, ...t.tieu_chi.slice(0, 7).map((_, i) => h.gia_tri[i] ?? "chưa rõ")]),
    });
  }
  kh.push({ type: "heading", text: "4. Cơ hội và khoảng trống", level: 1 }, { type: "bullets", items: b.co_hoi });
  kh.push({ type: "heading", text: "5. Đề xuất hành động", level: 1 }, { type: "bullets", items: b.de_xuat });
  kh.push({ type: "heading", text: "6. Giới hạn dữ liệu", level: 1 }, { type: "bullets", items: b.han_che_du_lieu });
  return kh;
}

export async function renderBaoCaoDoiThu(b: BaoCaoDoiThu): Promise<Buffer> {
  return renderDocx(dungKhoiBaoCao(b), { title: b.tieu_de });
}

/**
 * Độ tin cậy do model tự chấm hay quá lạc quan (đo thật 2026-10-02: một nguồn mà chấm "Cao").
 * Trần theo số TRANG nguồn khác nhau: 1 nguồn thì tối đa "vừa" nếu chỉ một tên miền, các nguồn
 * cùng một tên miền không tính là xác nhận chéo. "Cao" cần ít nhất 2 tên miền khác nhau.
 */
export function chinhDoTinCay(d: Pick<DoiThu, "do_tin_cay" | "nguon">): { muc: DoTinCay; daHa: boolean } {
  const mien = new Set(
    d.nguon.map((n) => {
      try {
        return new URL(n.trim()).hostname.replace(/^www./, "");
      } catch {
        return n;
      }
    }),
  );
  if (d.do_tin_cay === "cao" && mien.size < 2) return { muc: "vua", daHa: true };
  return { muc: d.do_tin_cay, daHa: false };
}

/** Nguồn phải là địa chỉ web thật (http/https), không chấp nhận chữ trơn kiểu "theo báo chí". */
export function nguonHopLe(n: string): boolean {
  try {
    const u = new URL(n.trim());
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}
