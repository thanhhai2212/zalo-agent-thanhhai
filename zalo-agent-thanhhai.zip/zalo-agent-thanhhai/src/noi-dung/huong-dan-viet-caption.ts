/**
 * Quy trình viết caption/bài đăng từ lịch content (khâu 3 của hướng "Zalo Agent business",
 * 2026-10-02). Nạp THEO YÊU CẦU qua tool `huong_dan_viet_caption`; bot dựng file bằng
 * `viet_caption`. Bot chỉ SOẠN, không đăng bài.
 */
export const HUONG_DAN_VIET_CAPTION = `# Viết caption từ lịch content

Mục tiêu: caption đăng được ngay (sau khi người dùng điền chuyện thật và rà soát), đúng giọng thương hiệu, đúng kênh. Bot chỉ soạn, KHÔNG đăng bài.

## 1. Lấy đầu vào
- Lấy lịch từ cuộc trò chuyện (file Excel kế hoạch content đã lập). Không còn thì nhờ người dùng gửi lại file Excel lịch, bạn đọc được file.
- Lấy giọng thương hiệu, thông điệp chính, điều không được nói từ lịch (sheet Tổng quan).
- Hỏi ngắn nếu thiếu: viết cho những ngày nào (tuần 1, cả tháng?), có hashtag thương hiệu cố định, tên thương hiệu/số liên hệ/địa chỉ để đặt vào CTA không.
- Mỗi lần gọi viet_caption nên tối đa khoảng 10 đến 12 bài. Lịch dài thì chia theo tuần, mỗi tuần một file.

## 2. Viết từng caption (theo kênh)
Facebook:
- Dòng đầu là hook (từ lịch, có thể chỉnh cho tự nhiên). Thân bài 80 đến 220 chữ, đoạn ngắn 1 đến 3 câu, có khoảng trắng giữa đoạn. Cuối bài một CTA rõ.
- Bài kể chuyện: bối cảnh, vấn đề, bước ngoặt, kết quả. Bài kiến thức: mở bằng câu hỏi hoặc điều nhiều người hiểu sai, rồi 3 đến 5 ý ngắn.
- Carousel: ghi caption chung kèm nội dung từng slide trong y_tuong_hinh.
TikTok:
- Caption ngắn 1 đến 3 dòng (dưới 300 ký tự là tốt), hook mạnh, 3 đến 6 hashtag. Tối đa 2200 ký tự.
- Video: caption không thay thế kịch bản, chỉ bổ trợ.
Chung:
- Giọng đúng thương hiệu. Tiếng Việt tự nhiên, không sáo rỗng, không "giá cả hợp lý, chất lượng vượt trội".
- Emoji vừa phải (0 đến 3 mỗi bài), đúng giọng.
- Hashtag: 3 đến 8, trộn hashtag thương hiệu, ngành, chủ đề. Không dùng hashtag không liên quan.
- CTA: một hành động (nhắn tin, bình luận, lưu bài, đặt hàng). Dùng đúng CTA trong lịch hoặc cải thiện, không thêm nhiều CTA.
- y_tuong_hinh: mô tả hình/ảnh/cảnh cần chụp hoặc tạo (bố cục, ánh sáng, chữ trên ảnh), đủ để sau này tạo ảnh hoặc nhờ người chụp.

## 3. Trung thực (bắt buộc)
- KHÔNG dựng trải nghiệm cá nhân của chủ thương hiệu, lời khách hàng, đánh giá, số lô, số đơn, mốc ra mắt, giải thưởng, chứng nhận chưa được cung cấp. Chỗ cần chi tiết riêng để [điền chuyện thật của bạn: ...].
- Không tuyên bố sức khỏe/y tế, không "chữa", "đảm bảo 100%", "cam kết hiệu quả". Không so sánh nêu tên đối thủ theo hướng xúc phạm hoặc chưa có bằng chứng.
- Giá, ưu đãi, thời hạn: chỉ ghi khi người dùng đã cung cấp.
- Bài bán hàng vẫn phải trung thực; không tạo khan hiếm giả.

## 4. Dựng file
Gọi viet_caption. Công cụ cảnh báo nếu caption TikTok vượt giới hạn, quá nhiều hashtag, có câu giống tuyên bố sức khỏe/quá mức, và liệt kê bài còn chỗ cần điền. Sau khi file gửi, nhắn tin ngắn: nêu số bài, các bài còn chỗ cần họ điền chuyện thật, các cảnh báo (nếu có), và hỏi có muốn chỉnh giọng, rút ngắn, hay tạo ảnh cho bài nào không. KHÔNG dán lại cả caption vào chat.

## Quy tắc
- Chỉ soạn, không đăng bài hay hứa kết quả.
- Tôn trọng điều khoản nền tảng, không gợi ý mua tương tác, spam hay nói sai sự thật.`;
