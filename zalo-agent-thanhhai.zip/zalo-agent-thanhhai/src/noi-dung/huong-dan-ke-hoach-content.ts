/**
 * Quy trình lập kế hoạch content (khâu thứ hai của hướng "Zalo Agent business", 2026-10-02),
 * nối tiếp báo cáo đối thủ. Nạp THEO YÊU CẦU qua tool `huong_dan_ke_hoach_content`; bot dựng
 * lịch bằng tool `ke_hoach_content` (file Excel). Bot chỉ LẬP KẾ HOẠCH, không đăng bài.
 */
export const HUONG_DAN_KE_HOACH_CONTENT = `# Lập kế hoạch content

Mục tiêu: một lịch nội dung dùng được ngay, bám theo khoảng trống đã nghiên cứu, có hook và câu chuyện cho từng bài. Bot chỉ lập kế hoạch, KHÔNG đăng bài thay người dùng.

## 1. Lấy đầu vào
- Nếu trong cuộc trò chuyện đã có báo cáo nghiên cứu đối thủ: dùng khoảng trống, thông điệp, đề xuất trong đó làm gốc, nói rõ bạn đang dựa vào báo cáo nào.
- Chưa có thì hỏi ngắn hoặc đề nghị nghiên cứu đối thủ trước.

## 2. Hỏi trước khi làm (một tin gộp, đánh số, đủ các câu cần thiết; mục đã biết thì bỏ qua)
1. Mục tiêu 30 ngày tới: tăng nhận diện, tăng inbox/đơn, tăng tương tác hay giới thiệu sản phẩm mới?
2. Khách mục tiêu là ai (độ tuổi, nhu cầu, vấn đề họ gặp)?
3. Đăng ở kênh nào (Facebook, TikTok, Zalo OA, YouTube, Instagram)?
4. Tần suất làm được (mấy bài mỗi tuần), có ai quay video, chụp ảnh không?
5. Giọng thương hiệu (thân thiện, chuyên gia, hài hước...) và điều KHÔNG được nói.
6. Ngày bắt đầu (để gắn ngày thật vào lịch).
Chưa rõ mục tiêu, kênh hoặc tần suất thì CHƯA lập.

## 3. Xây khung
- Thông điệp chính: một câu, khác biệt với đối thủ (lấy từ khoảng trống).
- 3 đến 5 trụ cột nội dung với tỷ trọng cộng lại bằng 100%. Gợi ý: Giáo dục/kiến thức, Câu chuyện thương hiệu và con người, Bằng chứng (đánh giá, kết quả, hậu trường), Bán hàng/ưu đãi, Tương tác (hỏi đáp, minigame).
- Quy tắc cân bằng: không quá 30% bài bán hàng trực tiếp.

## 4. Viết từng bài (mỗi dòng của lịch)
- tieu_de: chủ đề bài, cụ thể (không chung chung kiểu "giới thiệu sản phẩm").
- hook: câu mở 1 đến 2 dòng đủ khiến người xem dừng lại (câu hỏi, con số, mâu thuẫn, mở đầu câu chuyện).
- y_chinh: dàn ý ngắn, theo storytelling khi hợp: bối cảnh, vấn đề, bước ngoặt, kết quả; hoặc công thức PAS (Vấn đề, Khuấy động, Giải pháp).
- cta: một hành động rõ (nhắn tin, bình luận, lưu bài, đặt hàng), không dồn nhiều CTA.
- dinh_dang: bài viết, ảnh đơn, carousel, video ngắn, video dài, story, livestream.
- Video ngắn: ghi ở y_chinh ý chính từng cảnh để sau này viết kịch bản; ảnh: ghi ý hình cần tạo.
- KHÔNG tự dựng trải nghiệm cá nhân của chủ thương hiệu: không viết "lần đầu mình lên vườn...", lời thoại của người thật, buổi sáng thường ngày, mốc "ra mắt một tháng", số lô/số đơn. Bài kể chuyện chỉ ghi KHUNG (bối cảnh, mâu thuẫn, bước ngoặt) và để [điền chuyện thật của bạn: ...] ở chỗ cần chi tiết riêng; hook thì dùng câu hỏi hoặc kiến thức đúng chung, không giả làm kỷ niệm thật.
- Không bịa số liệu, đánh giá khách, tên người hay ưu đãi chưa được người dùng cung cấp.
- Số bài và tỷ trọng: đếm lại số bài theo từng trụ cột TRƯỚC khi gọi tool, cho khớp tỷ trọng đã nêu; lịch phải phủ đủ số ngày người dùng yêu cầu (bài cuối gần ngày cuối).
- Mỗi trụ cột phải có bài; trải đều các kênh theo thế mạnh của kênh đó.

## 5. Dựng file
Gọi ke_hoach_content. Công cụ từ chối nếu bài trỏ tới trụ cột không có, ngày ngoài khoảng, hoặc tỷ trọng trụ cột không cộng được khoảng 100%. Sau khi file gửi, nhắn tin ngắn: nêu thông điệp chính, tỷ trọng các trụ cột, 2 đến 3 bài nổi bật nhất, và hỏi có muốn viết chi tiết bài nào hoặc lên kịch bản video từ lịch này không. KHÔNG dán lại cả lịch vào chat.

## Quy tắc
- Chỉ lập kế hoạch, không đăng bài hay hứa kết quả (tăng bao nhiêu khách).
- Tôn trọng điều khoản nền tảng, không gợi ý mua tương tác, spam hay nói sai sự thật.`;
