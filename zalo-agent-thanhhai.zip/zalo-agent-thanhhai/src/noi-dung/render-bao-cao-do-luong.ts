import type { Sheet } from "../documents/document-content-schema.js";
import { renderXlsx } from "../documents/render-xlsx.js";
import { phanTram, type KetQuaDoLuong } from "./tinh-do-luong.js";

/**
 * Dựng file Excel báo cáo đo lường. Số liệu do code tính (xem `tinh-do-luong.ts`); phần model
 * viết (nhận định, đề xuất, giới hạn) nằm ở sheet riêng và gắn nhãn để không lẫn với số.
 * Dữ liệu mẫu luôn có biểu ngữ ở mọi sheet để không ai nhầm với số thật.
 */

export type NoiDungDoLuong = {
  tieu_de: string;
  ky_do: string;
  nguon_so_lieu: string;
  du_lieu_mau: boolean;
  nhan_dinh_ai: string[];
  de_xuat: string[];
  gioi_han: string[];
};

const text = (value: string) => ({ kind: "text", value }) as const;
const so = (value: number) => ({ kind: "number", value, format: "plain" }) as const;
const soHoacChua = (v: number | null) => (v === null ? text("chưa có") : so(v));
const BIEU_NGU_MAU = "DỮ LIỆU MẪU, KHÔNG PHẢN ÁNH THỰC TẾ";

export function dungSheetsDoLuong(kq: KetQuaDoLuong, nd: NoiDungDoLuong): Sheet[] {
  const mau = nd.du_lieu_mau;
  const tieuDe = (t: string) => (mau ? `${t} - ${BIEU_NGU_MAU}` : t);
  const ghiChuMau = mau ? `${BIEU_NGU_MAU}. Số liệu chỉ để thử quy trình.` : undefined;

  const tongQuan: Sheet = {
    name: "Tổng quan",
    theme: "green",
    title: tieuDe(nd.tieu_de.toUpperCase()),
    subtitle: `Kỳ đo: ${nd.ky_do} | Nguồn: ${nd.nguon_so_lieu}`,
    headers: ["Chỉ số", "Giá trị"],
    rows: [
      [text("Số bài trong kỳ"), so(kq.tong.soBai)],
      [text("Số bài đủ số liệu để tính tỉ lệ"), so(kq.tong.soBaiCoEr)],
      [text("Tổng lượt tiếp cận"), so(kq.tong.tiepCan)],
      [text("Tổng lượt xem"), so(kq.tong.luotXem)],
      [text("Tổng tương tác (thích, bình luận, chia sẻ, lưu)"), so(kq.tong.tuongTac)],
      [text("Tỉ lệ tương tác gộp (chỉ tham khảo, trộn hai nền tính)"), text(phanTram(kq.tong.er))],
      [text("Tổng click / đơn hàng"), text(`${kq.tong.click} / ${kq.tong.don}`)],
      [text("Tỉ lệ đơn trên click"), text(kq.tong.click > 0 ? phanTram(kq.tong.don / kq.tong.click) : "chưa có")],
      ...kq.canhBao.map((c, i) => [text(`Cảnh báo ${i + 1}`), text(c)]),
    ],
    note: ghiChuMau ?? "Tỉ lệ tương tác = (thích + bình luận + chia sẻ + lưu) chia cho lượt tiếp cận (nếu không có thì lượt xem). Ô thiếu số ghi \"chưa có\", không coi là 0.",
  };

  const theoBai: Sheet = {
    name: "Theo bài",
    theme: "green",
    title: tieuDe("SỐ LIỆU TỪNG BÀI"),
    headers: ["Ngày", "Kênh", "Định dạng", "Trụ cột", "Tiêu đề", "Nền tính", "Số nền", "Tương tác", "Tỉ lệ tương tác", "Click", "Đơn", "Đơn/Click"],
    rows: kq.bai.map((b) => [
      text(b.ngay),
      text(b.kenh),
      text(b.dinh_dang),
      text(b.tru_cot ?? ""),
      text(b.tieu_de),
      text(b.loaiNen ?? "chưa có"),
      soHoacChua(b.nen),
      soHoacChua(b.tuongTac),
      text(phanTram(b.er)),
      soHoacChua(typeof b.click === "number" ? b.click : null),
      soHoacChua(typeof b.don === "number" ? b.don : null),
      text(phanTram(b.chuyenDoi)),
    ]),
    note: ghiChuMau,
  };

  const phanNhom: Sheet = {
    name: "Theo nhóm",
    theme: "green",
    title: tieuDe("SO SÁNH THEO TRỤ CỘT, KÊNH, ĐỊNH DẠNG"),
    headers: ["Loại nhóm", "Nhóm", "Số bài", "Số bài có tỉ lệ", "Tỉ lệ (tính trên tiếp cận)", "Số bài tiếp cận", "Tỉ lệ (tính trên lượt xem)", "Số bài lượt xem", "Độ tin cậy"],
    rows: kq.nhom.map((n) => [
      text(n.loai),
      text(n.ten),
      so(n.soBai),
      so(n.soBaiCoEr),
      text(phanTram(n.tiepCan.er)),
      so(n.tiepCan.n),
      text(phanTram(n.luotXem.er)),
      so(n.luotXem.n),
      text(n.doTinCay),
    ]),
    note: ghiChuMau ?? "Hai tỉ lệ tính trên hai nền khác nhau nên KHÔNG so sánh chéo. Nhóm dưới 3 bài cùng nền chỉ để tham khảo.",
  };

  const dong = (b: KetQuaDoLuong["bai"][number]) => [text(b.ngay), text(b.kenh), text(b.tieu_de), text(phanTram(b.er))];
  const topBottom: Sheet = {
    name: "Bài nổi bật",
    theme: "green",
    title: tieuDe("BÀI TỐT NHẤT VÀ KÉM NHẤT (THEO TỪNG NỀN TÍNH)"),
    headers: ["Nhóm", "Ngày", "Kênh", "Tiêu đề", "Tỉ lệ tương tác"],
    rows: kq.noiBat.length
      ? kq.noiBat.flatMap((x) => [
          ...x.top.map((b) => [text(`Tốt nhất (tính trên ${x.nen})`), ...dong(b)]),
          ...x.bottom.map((b) => [text(`Kém nhất (tính trên ${x.nen})`), ...dong(b)]),
        ])
      : [[text("Chưa đủ số liệu"), text(""), text(""), text("Cần thêm bài có số tiếp cận/lượt xem và số tương tác"), text("")]],
    note: ghiChuMau ?? "Mỗi nền tính xếp hạng riêng; không so bài tính trên tiếp cận với bài tính trên lượt xem.",
  };

  const dongPhanTich = [
    ...nd.nhan_dinh_ai.map((t) => [text("Nhận định của AI (cần kiểm chứng)"), text(t)]),
    ...nd.de_xuat.map((t) => [text("Đề xuất điều chỉnh"), text(t)]),
    ...nd.gioi_han.map((t) => [text("Giới hạn dữ liệu"), text(t)]),
  ];
  const phanTich: Sheet = {
    name: "Nhận định và đề xuất",
    theme: "green",
    title: tieuDe("NHẬN ĐỊNH VÀ ĐỀ XUẤT"),
    headers: ["Loại", "Nội dung"],
    rows: dongPhanTich.length ? dongPhanTich : [[text("Ghi chú"), text("Chưa có nhận định")]],
    note: ghiChuMau ?? "Nhận định và đề xuất do AI viết dựa trên số liệu ở các sheet khác; số liệu do máy tính, không do AI.",
  };

  return [tongQuan, theoBai, phanNhom, topBottom, phanTich];
}

export async function renderBaoCaoDoLuong(kq: KetQuaDoLuong, nd: NoiDungDoLuong): Promise<Buffer> {
  return renderXlsx(dungSheetsDoLuong(kq, nd));
}

/** Dữ liệu mẫu nhận ra từ chính tiêu đề bài, không chỉ dựa vào cờ do model đặt. */
export function laDuLieuMau(tieuDe: string[], coDoModel: boolean): boolean {
  if (coDoModel) return true;
  if (!tieuDe.length) return false;
  return tieuDe.filter((t) => /^\s*\[\s*mẫu\s*\]/i.test(t)).length * 2 >= tieuDe.length;
}
