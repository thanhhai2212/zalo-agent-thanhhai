import type { Sheet } from "../documents/document-content-schema.js";
import { renderXlsx } from "../documents/render-xlsx.js";

/**
 * Dựng file Excel kế hoạch content: sheet "Lịch nội dung" (từng bài), "Trụ cột nội dung"
 * (tỷ trọng đề ra so với thực tế - lệch thì thấy ngay) và "Tổng quan". Model chỉ đưa
 * DỮ LIỆU; ngày thật, thứ trong tuần và tỷ trọng thực tế do code tính, không để model tự điền.
 */

export type TruCot = { ten: string; mo_ta: string; ty_trong: number };
export type BaiContent = {
  ngay: number;
  kenh: string;
  dinh_dang: string;
  tru_cot: string;
  tieu_de: string;
  hook: string;
  y_chinh: string;
  cta: string;
};
export type KeHoachContent = {
  tieu_de: string;
  muc_tieu: string;
  khach_muc_tieu: string;
  thong_diep_chinh: string;
  giong_thuong_hieu?: string;
  so_ngay: number;
  /** YYYY-MM-DD; có thì gắn ngày thật và thứ vào lịch. */
  ngay_bat_dau?: string;
  tru_cot: TruCot[];
  bai: BaiContent[];
  ghi_chu?: string[];
};

const THU = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
const text = (value: string) => ({ kind: "text", value }) as const;

/** Ngày thật của "Ngày N" tính từ ngày bắt đầu (UTC để không lệch múi giờ máy chủ). */
export function ngayThat(batDau: string | undefined, n: number): { ngay: string; thu: string } | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(batDau ?? "");
  if (!m) return null;
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]) + (n - 1)));
  if (Number.isNaN(d.getTime())) return null;
  const dd = String(d.getUTCDate()).padStart(2, "0");
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  return { ngay: `${dd}/${mm}/${d.getUTCFullYear()}`, thu: THU[d.getUTCDay()]! };
}

/** Lỗi cấu trúc mà model phải sửa trước khi dựng (trả null nếu hợp lệ). */
export function kiemTraKeHoach(k: KeHoachContent): string | null {
  const ten = new Set(k.tru_cot.map((t) => t.ten.trim().toLowerCase()));
  if (ten.size !== k.tru_cot.length) return "Tên các trụ cột bị trùng nhau.";
  const tong = k.tru_cot.reduce((a, t) => a + t.ty_trong, 0);
  if (tong < 95 || tong > 105) return `Tỷ trọng các trụ cột cộng lại là ${tong}%, phải khoảng 100%.`;
  const la = k.bai.filter((b) => !ten.has(b.tru_cot.trim().toLowerCase()));
  if (la.length) return `Bài ngày ${la.map((b) => b.ngay).join(", ")} trỏ tới trụ cột không có trong danh sách: ${[...new Set(la.map((b) => b.tru_cot))].join(", ")}.`;
  const ngoai = k.bai.filter((b) => b.ngay < 1 || b.ngay > k.so_ngay);
  if (ngoai.length) return `Có bài ngoài khoảng ngày 1-${k.so_ngay}: ngày ${ngoai.map((b) => b.ngay).join(", ")}.`;
  const thieu = k.tru_cot.filter((t) => !k.bai.some((b) => b.tru_cot.trim().toLowerCase() === t.ten.trim().toLowerCase()));
  if (thieu.length) return `Trụ cột chưa có bài nào: ${thieu.map((t) => t.ten).join(", ")}.`;
  return null;
}

/** Cảnh báo (không chặn) để model nói thật với người dùng khi bàn giao. */
export function canhBaoKeHoach(k: KeHoachContent): string[] {
  const ra: string[] = [];
  const tong = Math.max(1, k.bai.length);
  for (const t of k.tru_cot) {
    const thucTe = Math.round((k.bai.filter((b) => b.tru_cot.trim().toLowerCase() === t.ten.trim().toLowerCase()).length / tong) * 100);
    if (Math.abs(thucTe - t.ty_trong) > 8) ra.push(`trụ cột "${t.ten}" đề ra ${t.ty_trong}% nhưng thực tế ${thucTe}%`);
  }
  const cuoi = Math.max(...k.bai.map((b) => b.ngay));
  if (cuoi < k.so_ngay - 2) ra.push(`bài cuối ở ngày ${cuoi}/${k.so_ngay}, ${k.so_ngay - cuoi} ngày cuối chưa có bài`);
  return ra;
}

export function dungSheets(k: KeHoachContent): Sheet[] {
  const bai = [...k.bai].sort((a, b) => a.ngay - b.ngay);
  const lich: Sheet = {
    name: "Lịch nội dung",
    theme: "blue",
    title: k.tieu_de.toUpperCase(),
    subtitle: `Mục tiêu: ${k.muc_tieu}`,
    headers: ["Ngày", "Thứ", "Kênh", "Định dạng", "Trụ cột", "Tiêu đề bài", "Hook (câu mở)", "Ý chính / storytelling", "CTA", "Trạng thái"],
    rows: bai.map((b) => {
      const t = ngayThat(k.ngay_bat_dau, b.ngay);
      return [
        text(t ? t.ngay : `Ngày ${b.ngay}`),
        text(t ? t.thu : ""),
        text(b.kenh),
        text(b.dinh_dang),
        text(b.tru_cot),
        text(b.tieu_de),
        text(b.hook),
        text(b.y_chinh),
        text(b.cta),
        text("Chưa làm"),
      ];
    }),
    note: "Cột Trạng thái để bạn tự cập nhật (Chưa làm / Đang làm / Đã đăng). Bot chỉ lập kế hoạch, không đăng bài.",
  };

  const dem = (ten: string) => bai.filter((b) => b.tru_cot.trim().toLowerCase() === ten.trim().toLowerCase()).length;
  const pillars: Sheet = {
    name: "Trụ cột nội dung",
    theme: "blue",
    title: "TRỤ CỘT NỘI DUNG",
    headers: ["Trụ cột", "Mô tả", "Tỷ trọng đề ra", "Số bài", "Tỷ trọng thực tế"],
    rows: k.tru_cot.map((t) => [
      text(t.ten),
      text(t.mo_ta),
      text(`${t.ty_trong}%`),
      text(String(dem(t.ten))),
      text(`${Math.round((dem(t.ten) / Math.max(1, bai.length)) * 100)}%`),
    ]),
    note: `Tổng ${bai.length} bài trong ${k.so_ngay} ngày. Tỷ trọng thực tế lệch nhiều so với đề ra thì cân lại lịch.`,
  };

  const tong: Sheet = {
    name: "Tổng quan",
    theme: "blue",
    title: "TỔNG QUAN KẾ HOẠCH",
    headers: ["Mục", "Nội dung"],
    rows: [
      [text("Mục tiêu"), text(k.muc_tieu)],
      [text("Khách mục tiêu"), text(k.khach_muc_tieu)],
      [text("Thông điệp chính"), text(k.thong_diep_chinh)],
      ...(k.giong_thuong_hieu ? [[text("Giọng thương hiệu"), text(k.giong_thuong_hieu)]] : []),
      [text("Thời gian"), text(`${k.so_ngay} ngày${k.ngay_bat_dau ? `, bắt đầu ${ngayThat(k.ngay_bat_dau, 1)?.ngay ?? k.ngay_bat_dau}` : ""}`)],
      [text("Lưu ý quan trọng"), text("Các hook và ý chính dạng kể chuyện cá nhân chỉ là KHUNG gợi ý. Thay bằng trải nghiệm, con số và lời nói THẬT của bạn trước khi đăng; đừng đăng chuyện không có thật.")],
      ...(k.ghi_chu ?? []).map((g, i) => [text(`Ghi chú ${i + 1}`), text(g)]),
    ],
  };
  return [lich, pillars, tong];
}

export async function renderKeHoachContent(k: KeHoachContent): Promise<Buffer> {
  return renderXlsx(dungSheets(k));
}
