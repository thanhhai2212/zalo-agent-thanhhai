import { randomBytes } from "node:crypto";
import type {
  OAuthAuthorizationServerInformation,
  OAuthClientInformation,
  OAuthClientMetadata,
  OAuthClientProvider,
  OAuthTokens,
} from "@ai-sdk/mcp";
import { env } from "../config/env.js";
import { decryptSecret, encryptSecret } from "../config/secret-cipher.js";
import { db } from "../conversation/database.js";
import { createLogger } from "../shared/logger.js";

/**
 * Kho đăng nhập OAuth cho server MCP (vd Canva Remote MCP, 2026-10-06).
 *
 * Mọi thứ nhạy cảm (thông tin client đã đăng ký, access/refresh token, mã xác minh PKCE,
 * state) nằm trong MỘT cột `mcp_servers.oauth_ma_hoa` dạng JSON ĐÃ MÃ HÓA (AES-256-GCM như
 * mọi secret khác), không bao giờ lộ ra dashboard - route chỉ thấy cờ `daDangNhap`.
 *
 * Bước "Cho phép" trên trang của nhà cung cấp là việc của NGƯỜI (bot không làm thay được).
 * VPS không có domain công khai nên địa chỉ chuyển về là `http://localhost:<cổng>/...` -
 * trình duyệt người dùng báo lỗi không mở được, và họ dán lại địa chỉ đó vào dashboard
 * (xem `mcp-oauth-flow.ts`). Đã thử thật: Canva nhận đăng ký client với địa chỉ này.
 *
 * Hai chế độ của provider:
 *   - TƯƠNG TÁC (chỉ từ `mcp-oauth-flow.ts`): được lưu mã xác minh/state và nhận địa chỉ cấp quyền.
 *   - IM LẶNG (mọi lần nối nền): KHÔNG ghi mã xác minh/state và KHÔNG chuyển hướng - nếu cho phép,
 *     một nhịp health ở giữa lúc người dùng đang đăng nhập sẽ ghi đè mã xác minh làm hỏng cả lượt.
 */

const log = createLogger("mcp-oauth-store");

export type KhoOauth = {
  clientInformation?: OAuthClientInformation;
  tokens?: OAuthTokens;
  codeVerifier?: string;
  state?: string;
  authServerInfo?: OAuthAuthorizationServerInformation;
};

function giaiMa(maHoa: string): KhoOauth {
  if (!maHoa) return {};
  try {
    return JSON.parse(decryptSecret(maHoa)) as KhoOauth;
  } catch (err) {
    log.error({ err }, "Giải mã kho OAuth lỗi - coi như chưa đăng nhập");
    return {};
  }
}

/** Dùng cho cột đã đọc sẵn (danh sách server) - có token chưa. */
export function coTokenOauth(maHoa: string): boolean {
  return !!giaiMa(maHoa).tokens?.access_token;
}

const getStmt = db.prepare("SELECT oauth_ma_hoa FROM mcp_servers WHERE id = ?");
const setStmt = db.prepare("UPDATE mcp_servers SET oauth_ma_hoa = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?");

export function docKhoOauth(id: string): KhoOauth {
  const row = getStmt.get(id) as { oauth_ma_hoa: string } | undefined;
  return giaiMa(row?.oauth_ma_hoa ?? "");
}

export function ghiKhoOauth(id: string, kho: KhoOauth): void {
  const rong = Object.keys(kho).length === 0;
  setStmt.run(rong ? "" : encryptSecret(JSON.stringify(kho)), id);
}

function capNhatKho(id: string, patch: (k: KhoOauth) => KhoOauth): void {
  ghiKhoOauth(id, patch(docKhoOauth(id)));
}

export function diaChiChuyenVeOauth(): string {
  return `http://localhost:${env.DASHBOARD_PORT}/api/mcp/oauth/callback`;
}

export function daCoTokenOauth(id: string): boolean {
  return !!docKhoOauth(id).tokens?.access_token;
}

/** Xóa token (đăng xuất), GIỮ thông tin client đã đăng ký để lần đăng nhập sau không phải đăng ký lại. */
export function xoaTokenOauth(id: string): void {
  capNhatKho(id, ({ tokens: _t, codeVerifier: _v, state: _s, ...con }) => con);
}

export class MaOauthProvider implements OAuthClientProvider {
  /** Địa chỉ cấp quyền SDK vừa yêu cầu chuyển hướng tới (chỉ chế độ tương tác). */
  authUrl: string | null = null;

  constructor(
    private readonly id: string,
    private readonly tuongTac: boolean,
  ) {}

  get redirectUrl(): string {
    return diaChiChuyenVeOauth();
  }

  get clientMetadata(): OAuthClientMetadata {
    return {
      redirect_uris: [diaChiChuyenVeOauth()],
      client_name: "Zalo Agent",
      grant_types: ["authorization_code", "refresh_token"],
      response_types: ["code"],
      // Client công khai (không có secret để giữ kín trên máy chủ này); nhà cung cấp bắt secret thì
      // phản hồi đăng ký sẽ kèm `client_secret` và SDK tự dùng.
      token_endpoint_auth_method: "none",
    };
  }

  tokens(): OAuthTokens | undefined {
    return docKhoOauth(this.id).tokens;
  }

  saveTokens(tokens: OAuthTokens): void {
    // Đổi mã lấy token xong thì mã xác minh + state hết tác dụng, xóa luôn.
    capNhatKho(this.id, (k) => ({ ...k, tokens, codeVerifier: undefined, state: undefined }));
  }

  redirectToAuthorization(url: URL): void {
    if (!this.tuongTac) throw new Error("Cần đăng nhập OAuth - bấm nút Đăng nhập ở dòng server này");
    this.authUrl = url.toString();
  }

  saveCodeVerifier(v: string): void {
    if (this.tuongTac) capNhatKho(this.id, (k) => ({ ...k, codeVerifier: v }));
  }

  codeVerifier(): string {
    const v = docKhoOauth(this.id).codeVerifier;
    if (!v) throw new Error("Thiếu mã xác minh PKCE - bấm Đăng nhập lại từ đầu");
    return v;
  }

  state(): string {
    return randomBytes(16).toString("hex");
  }

  saveState(s: string): void {
    if (this.tuongTac) capNhatKho(this.id, (k) => ({ ...k, state: s }));
  }

  storedState(): string | undefined {
    return docKhoOauth(this.id).state;
  }

  clientInformation(): OAuthClientInformation | undefined {
    return docKhoOauth(this.id).clientInformation;
  }

  saveClientInformation(info: OAuthClientInformation): void {
    capNhatKho(this.id, (k) => ({ ...k, clientInformation: info }));
  }

  isClientInformationDynamicallyRegistered(): boolean {
    return true;
  }

  authorizationServerInformation(): OAuthAuthorizationServerInformation | undefined {
    return docKhoOauth(this.id).authServerInfo;
  }

  saveAuthorizationServerInformation(info: OAuthAuthorizationServerInformation): void {
    capNhatKho(this.id, (k) => ({ ...k, authServerInfo: info }));
  }

  /** Máy chủ cấp quyền do server MCP chỉ ra: bắt buộc https, không đi theo địa chỉ http/nội bộ. */
  validateAuthorizationServerURL(_serverUrl: string | URL, authorizationServerUrl: string | URL): void {
    if (new URL(authorizationServerUrl).protocol !== "https:") {
      throw new Error("Máy chủ cấp quyền OAuth phải dùng https");
    }
  }

  invalidateCredentials(scope: "all" | "client" | "tokens" | "verifier"): void {
    if (scope === "all") ghiKhoOauth(this.id, {});
    else if (scope === "tokens") xoaTokenOauth(this.id);
    else if (scope === "client") capNhatKho(this.id, ({ clientInformation: _c, ...con }) => con);
    else capNhatKho(this.id, ({ codeVerifier: _v, ...con }) => con);
  }
}
