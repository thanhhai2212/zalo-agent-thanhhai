import type { DatabaseSync } from "node:sqlite";

/**
 * Lược đồ MCP client: server ngoài (URL + headers mã hóa) -> gán theo agent.
 * Gọi từ `database.ts` (`runMigrations()`), CÙNG connection với mọi bảng khác.
 *
 *
 * KHÔNG dùng FOREIGN KEY (cùng lý do kb-schema.ts): `database.ts` không bật
 * `PRAGMA foreign_keys`. Mọi nơi xóa `mcp_servers` phải tự dọn `agent_mcp_servers`
 * tường minh - xem `mcp-server-store.ts#xoaServer`.
 *
 * `id` sinh ngẫu nhiên (`randomBytes(8).hex`), KHÔNG PHẢI slug từ tên - cố ý,
 * để server MỚI tạo không bao giờ "hồi sinh" gán cũ trong `agent_mcp_servers`
 * nếu trùng tên với một server đã xóa.
 */
export function taoBangMcp(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS mcp_servers (
      id             TEXT PRIMARY KEY,
      ten            TEXT NOT NULL,
      url            TEXT NOT NULL,
      headers_ma_hoa TEXT NOT NULL DEFAULT '',
      enabled        INTEGER NOT NULL DEFAULT 1,
      trang_thai     TEXT NOT NULL DEFAULT 'cho_ket_noi'
                     CHECK (trang_thai IN ('cho_ket_noi', 'da_ket_noi', 'loi', 'can_duyet_lai')),
      loi            TEXT NOT NULL DEFAULT '',
      tools_snapshot TEXT NOT NULL DEFAULT '',
      fingerprint    TEXT NOT NULL DEFAULT '',
      created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS agent_mcp_servers (
      agent_id  TEXT NOT NULL,
      server_id TEXT NOT NULL,
      PRIMARY KEY (agent_id, server_id)
    );
  `);
}
