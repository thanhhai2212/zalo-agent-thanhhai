import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let oauthStore: typeof import("./mcp-oauth-store.js");
let flow: typeof import("./mcp-oauth-flow.js");
let store: typeof import("./mcp-server-store.js");
let pool: typeof import("./mcp-connection-pool.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  oauthStore = await import("./mcp-oauth-store.js");
  flow = await import("./mcp-oauth-flow.js");
  store = await import("./mcp-server-store.js");
  pool = await import("./mcp-connection-pool.js");
  database = await import("../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

let id: string;
beforeEach(() => {
  database.db.exec("DELETE FROM mcp_servers; DELETE FROM agent_mcp_servers");
  pool.resetPoolChoTest();
  id = store.taoServer({ ten: "Canva", url: "https://mcp.example.com/mcp", dungOauth: true }).id;
});

const cotOauth = () => (database.db.prepare("SELECT oauth_ma_hoa FROM mcp_servers WHERE id = ?").get(id) as { oauth_ma_hoa: string }).oauth_ma_hoa;

describe("server OAuth - cấu hình", () => {
  it("mặc định CHỈ CHỦ BOT (token mang quyền tài khoản chủ), server thường thì không", () => {
    assert.equal(store.layServer(id)!.chiChuBot, true);
    assert.equal(store.layServer(id)!.dungOauth, true);
    assert.equal(store.taoServer({ ten: "Thường", url: "https://x.example.com/mcp" }).chiChuBot, false);
    assert.equal(store.taoServer({ ten: "OAuth mở", url: "https://y.example.com/mcp", dungOauth: true, chiChuBot: false }).chiChuBot, false, "tắt tường minh thì được");
  });

  it("chuTrongNhom: mặc định tắt, chỉ có nghĩa khi đã chỉ-chủ-bot, tắt chỉ-chủ-bot thì tự xóa", () => {
    assert.equal(store.layServer(id)!.chuTrongNhom, false);
    assert.equal(store.taoServer({ ten: "A", url: "https://a.example.com/mcp", chiChuBot: true, chuTrongNhom: true }).chuTrongNhom, true);
    assert.equal(
      store.taoServer({ ten: "B", url: "https://b.example.com/mcp", chiChuBot: false, chuTrongNhom: true }).chuTrongNhom,
      false,
      "server mở cho mọi người thì quyền riêng của chủ bot không có nghĩa",
    );
    assert.equal(store.capNhatServer(id, { chuTrongNhom: true })!.chuTrongNhom, true);
    assert.equal(store.capNhatServer(id, { chiChuBot: true })!.chuTrongNhom, true, "không đụng tới cờ khi chỉ đổi chiChuBot=true");
    assert.equal(store.capNhatServer(id, { chiChuBot: false })!.chuTrongNhom, false, "tắt chỉ-chủ-bot thì xóa quyền trong nhóm");
    assert.equal(store.capNhatServer(id, { chiChuBot: true })!.chuTrongNhom, false, "bật lại không sống lại ngầm");
  });

  it("token lưu MÃ HÓA, không lộ chữ thường trong DB, danh sách chỉ lộ cờ daDangNhap", () => {
    const p = new oauthStore.MaOauthProvider(id, true);
    assert.equal(store.layServer(id)!.daDangNhap, false);
    p.saveTokens({ access_token: "tok-bi-mat-123", refresh_token: "ref-bi-mat-456", token_type: "Bearer" });
    assert.doesNotMatch(cotOauth(), /tok-bi-mat|ref-bi-mat/);
    assert.equal(p.tokens()?.access_token, "tok-bi-mat-123");
    assert.equal(store.layServer(id)!.daDangNhap, true);
    assert.doesNotMatch(JSON.stringify(store.danhSachServer()), /tok-bi-mat|ref-bi-mat/);
  });

  it("đăng xuất xóa token nhưng GIỮ thông tin client đã đăng ký", () => {
    const p = new oauthStore.MaOauthProvider(id, true);
    p.saveClientInformation({ client_id: "cid-1" });
    p.saveTokens({ access_token: "a", token_type: "Bearer" });
    oauthStore.xoaTokenOauth(id);
    assert.equal(p.tokens(), undefined);
    assert.equal(p.clientInformation()?.client_id, "cid-1");
  });
});

describe("provider - hai chế độ", () => {
  it("tương tác: lưu mã xác minh + state và nhận địa chỉ cấp quyền", () => {
    const p = new oauthStore.MaOauthProvider(id, true);
    p.saveCodeVerifier("v1");
    p.saveState("s1");
    p.redirectToAuthorization(new URL("https://auth.example.com/authorize?x=1"));
    assert.equal(p.codeVerifier(), "v1");
    assert.equal(p.storedState(), "s1");
    assert.equal(p.authUrl, "https://auth.example.com/authorize?x=1");
  });

  it("IM LẶNG (nối nền): không ghi đè mã xác minh/state đang chờ, không chuyển hướng", () => {
    new oauthStore.MaOauthProvider(id, true).saveState("dang-cho");
    const nen = new oauthStore.MaOauthProvider(id, false);
    nen.saveState("ghi-de");
    nen.saveCodeVerifier("ghi-de");
    assert.equal(nen.storedState(), "dang-cho");
    assert.throws(() => nen.redirectToAuthorization(new URL("https://a.example.com/")), /Cần đăng nhập OAuth/);
  });

  it("máy chủ cấp quyền phải là https", () => {
    const p = new oauthStore.MaOauthProvider(id, true);
    assert.throws(() => p.validateAuthorizationServerURL("https://mcp.example.com", "http://noi-bo.local"), /https/);
    assert.doesNotThrow(() => p.validateAuthorizationServerURL("https://mcp.example.com", "https://auth.example.com"));
  });

  it("địa chỉ chuyển về dùng đúng cổng dashboard", () => {
    assert.match(oauthStore.diaChiChuyenVeOauth(), /^http:\/\/localhost:\d+\/api\/mcp\/oauth\/callback$/);
  });
});

describe("luồng đăng nhập", () => {
  const authGia = (kq: "REDIRECT" | "AUTHORIZED", hanhDong?: (p: import("./mcp-oauth-store.js").MaOauthProvider, o: Record<string, unknown>) => void) =>
    ({
      auth: async (p: import("./mcp-oauth-store.js").MaOauthProvider, o: Record<string, unknown>) => {
        hanhDong?.(p, o);
        return kq;
      },
    }) as never;

  it("bắt đầu: trả địa chỉ cấp quyền, state đã lưu để bước sau đối chiếu", async () => {
    const kq = await flow.batDauOauth(
      id,
      authGia("REDIRECT", (p) => {
        p.saveState("st-1");
        p.saveCodeVerifier("cv-1");
        p.redirectToAuthorization(new URL("https://auth.example.com/authorize?state=st-1"));
      }),
    );
    assert.deepEqual(kq, { authUrl: "https://auth.example.com/authorize?state=st-1" });
    assert.equal(new oauthStore.MaOauthProvider(id, true).storedState(), "st-1");
  });

  it("chỉ chạy cho server OAuth dùng https", async () => {
    const thuong = store.taoServer({ ten: "T", url: "https://t.example.com/mcp" }).id;
    await assert.rejects(flow.batDauOauth(thuong, authGia("REDIRECT")), /không dùng đăng nhập OAuth/);
    const http = store.taoServer({ ten: "H", url: "http://h.example.com/mcp", dungOauth: true }).id;
    await assert.rejects(flow.batDauOauth(http, authGia("REDIRECT")), /https/);
    await assert.rejects(flow.batDauOauth("khong-co", authGia("REDIRECT")), /Không tìm thấy/);
  });

  it("đọc địa chỉ dán: lấy code/state, báo lỗi nhà cung cấp, chấp nhận chuỗi truy vấn trần", () => {
    assert.deepEqual(flow.docDiaChiChuyenVe("http://localhost:3900/api/mcp/oauth/callback?code=abc&state=s1"), { code: "abc", state: "s1", iss: null });
    assert.equal(flow.docDiaChiChuyenVe("?code=xyz&state=s2").code, "xyz");
    assert.throws(() => flow.docDiaChiChuyenVe("http://localhost:3900/cb?error=access_denied&error_description=Nguoi+dung+tu+choi"), /Nguoi dung tu choi/);
    assert.throws(() => flow.docDiaChiChuyenVe("http://localhost:3900/cb?state=s1"), /không có mã đăng nhập/);
  });

  it("hoàn tất: từ chối khi chưa có phiên chờ hoặc state không khớp", async () => {
    await assert.rejects(flow.hoanTatOauth(id, "http://localhost/cb?code=c&state=s", authGia("AUTHORIZED")), /Chưa có phiên đăng nhập đang chờ/);
    new oauthStore.MaOauthProvider(id, true).saveState("dung");
    await assert.rejects(flow.hoanTatOauth(id, "http://localhost/cb?code=c&state=sai", authGia("AUTHORIZED")), /không khớp/);
  });

  it("hoàn tất thành công: đổi mã lấy token, lưu mã hóa, xóa state đã dùng", async () => {
    new oauthStore.MaOauthProvider(id, true).saveState("dung");
    let thamSo: Record<string, unknown> = {};
    await flow.hoanTatOauth(
      id,
      "http://localhost:3900/api/mcp/oauth/callback?code=ma-1&state=dung",
      authGia("AUTHORIZED", (p, o) => {
        thamSo = o;
        p.saveTokens({ access_token: "tok", refresh_token: "ref", token_type: "Bearer" });
      }),
    );
    assert.equal(thamSo.authorizationCode, "ma-1");
    assert.equal(thamSo.callbackState, "dung");
    assert.equal(store.layServer(id)!.daDangNhap, true);
    assert.equal(new oauthStore.MaOauthProvider(id, true).storedState(), undefined, "state dùng một lần");
  });

  it("đổi mã lỗi thì báo rõ, không để lại token", async () => {
    new oauthStore.MaOauthProvider(id, true).saveState("dung");
    const hong = { auth: async () => { throw new Error("invalid_grant"); } } as never;
    await assert.rejects(flow.hoanTatOauth(id, "?code=c&state=dung", hong), /Đổi mã lấy token thất bại: invalid_grant/);
    assert.equal(store.layServer(id)!.daDangNhap, false);
  });
});

describe("pool - nối server OAuth", () => {
  it("chưa có token thì KHÔNG nối nền (không mở lại luồng cấp quyền mỗi nhịp health)", async () => {
    let daGoi = 0;
    pool.datKetNoiServerChoTest((async () => {
      daGoi += 1;
      throw new Error("không được gọi");
    }) as never);
    await assert.rejects(pool.nap(id, false), /Chưa đăng nhập OAuth/);
    assert.equal(daGoi, 0);
  });

  it("có token thì nối với provider IM LẶNG; lỗi 401 được dịch thành câu bảo đăng nhập lại", async () => {
    new oauthStore.MaOauthProvider(id, true).saveTokens({ access_token: "a", token_type: "Bearer" });
    let thuNhan: unknown;
    pool.datKetNoiServerChoTest((async (cfg: { authProvider?: unknown }) => {
      thuNhan = cfg.authProvider;
      throw new Error("Không nối được MCP server: Unauthorized");
    }) as never);
    await assert.rejects(pool.nap(id, false), /hết hạn hoặc bị thu hồi - bấm Đăng nhập lại/);
    assert.ok(thuNhan instanceof oauthStore.MaOauthProvider);
    assert.throws(() => (thuNhan as import("./mcp-oauth-store.js").MaOauthProvider).redirectToAuthorization(new URL("https://a.example.com/")), /Cần đăng nhập/);
  });
});
