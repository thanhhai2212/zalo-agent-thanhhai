import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { tool, type ToolSet } from "ai";
import { z } from "zod";
import { chupFingerprint, soDrift } from "./mcp-tool-drift.js";

const dungTool = (moTa: string, schema: Record<string, unknown> = {}): ToolSet => ({
  demo: tool({ description: moTa, inputSchema: z.object(schema) }),
});

describe("mcp-tool-drift", () => {
  it("mốc rỗng (chưa từng duyệt) thì KHÔNG coi là drift", async () => {
    const kq = await soDrift(dungTool("mô tả A"), "");
    assert.equal(kq.drift, false);
    assert.deepEqual(kq.them, []);
    assert.deepEqual(kq.doi, []);
    assert.deepEqual(kq.bo, []);
  });

  it("bộ tool giống hệt mốc thì không drift", async () => {
    const tools = dungTool("mô tả A");
    const moc = await chupFingerprint(tools);
    const kq = await soDrift(tools, moc);
    assert.equal(kq.drift, false);
  });

  it("đổi description thì bắt được drift ở nhánh 'đổi'", async () => {
    const moc = await chupFingerprint(dungTool("mô tả GỐC"));
    const kq = await soDrift(dungTool("mô tả ĐÃ ĐỔI"), moc);
    assert.equal(kq.drift, true);
    assert.deepEqual(kq.doi, ["demo"]);
    assert.deepEqual(kq.them, []);
    assert.deepEqual(kq.bo, []);
  });

  it("thêm tool mới thì bắt được ở nhánh 'thêm'", async () => {
    const moc = await chupFingerprint(dungTool("mô tả A"));
    const tools2: ToolSet = { ...dungTool("mô tả A"), tool_moi: tool({ description: "mới", inputSchema: z.object({}) }) };
    const kq = await soDrift(tools2, moc);
    assert.equal(kq.drift, true);
    assert.deepEqual(kq.them, ["tool_moi"]);
  });

  it("bớt tool thì bắt được ở nhánh 'bỏ'", async () => {
    const moc = await chupFingerprint({
      demo: tool({ description: "A", inputSchema: z.object({}) }),
      demo2: tool({ description: "B", inputSchema: z.object({}) }),
    });
    const kq = await soDrift(dungTool("A"), moc);
    assert.equal(kq.drift, true);
    assert.deepEqual(kq.bo, ["demo2"]);
  });
});
