import { createMCPClient, type OAuthClientProvider } from "@ai-sdk/mcp";
import type { Tool } from "ai";

/**
 * Bắt tay với một MCP server ngoài, có timeout. Tách khỏi `mcp-connection-pool.ts`
 * để lõi kết nối có seam tiêm được cho test (không gọi HTTP thật).
 *
 *
 * HTTP-only (Streamable HTTP) - bot hạn chế chạy lệnh trên VPS nên KHÔNG hỗ
 * trợ transport `stdio`.
 *
 * `redirect` mặc định `'error'` của `@ai-sdk/mcp` (không tự theo redirect) là
 * một lớp phòng SSRF-qua-redirect miễn phí - đúng tinh thần "chặn ở TẦNG
 * ĐÓNG-VAI-TRÒ THẤP NHẤT" đã dùng cho `tai_video`'s whitelist domain.
 */

export type KetNoiMcp = {
  tools(): Promise<Record<string, Tool>>;
  close(): Promise<void>;
};

export type LoiKetNoiMcp = Error & { loaiLoi: "ket_noi" };

function loiKetNoi(message: string): LoiKetNoiMcp {
  const err = new Error(message) as LoiKetNoiMcp;
  err.loaiLoi = "ket_noi";
  return err;
}

export type ConnectDeps = {
  taoClient: (cfg: { url: string; headers: Record<string, string>; authProvider?: OAuthClientProvider }) => Promise<KetNoiMcp>;
};

const depThat: ConnectDeps = {
  taoClient: async (cfg) => {
    const client = await createMCPClient({
      transport: { type: "http", url: cfg.url, headers: cfg.headers, ...(cfg.authProvider ? { authProvider: cfg.authProvider } : {}) },
    });
    return { tools: () => client.tools(), close: () => client.close() };
  },
};

export async function ketNoiServer(
  cfg: { url: string; headers: Record<string, string>; connectTimeoutMs: number; authProvider?: OAuthClientProvider },
  deps: ConnectDeps = depThat,
): Promise<KetNoiMcp> {
  let t: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      deps.taoClient({ url: cfg.url, headers: cfg.headers, authProvider: cfg.authProvider }).catch((e: unknown) => {
        throw loiKetNoi(`Không nối được MCP server: ${e instanceof Error ? e.message : String(e)}`);
      }),
      new Promise<never>((_, reject) => {
        t = setTimeout(() => reject(loiKetNoi(`Nối MCP server quá ${cfg.connectTimeoutMs}ms`)), cfg.connectTimeoutMs);
      }),
    ]);
  } finally {
    if (t) clearTimeout(t);
  }
}
