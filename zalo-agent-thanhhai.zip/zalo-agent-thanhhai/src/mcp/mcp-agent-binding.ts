/**
 * Gán server MCP cho từng agent. Lược đồ ở `mcp-schema.ts`.
 *
 * Agent CHƯA gán server nào -> đọc RỖNG, mặc định ĐÓNG - cùng bất biến với
 * `kb-agent-binding.ts` (không dòng nào nghĩa là "chưa cấu hình", không phải
 * "được dùng hết").
 *
 * Adapt `trongGiaoDich`
 * sang chữ ký 1 tham số của local. Mirror `kb-agent-binding.ts`.
 */

import { db, trongGiaoDich } from "../conversation/database.js";

const layDanhSachStmt = db.prepare(
  `SELECT server_id FROM agent_mcp_servers WHERE agent_id = ? ORDER BY server_id`,
);

export function serversCuaAgent(agentId: string): string[] {
  const rows = layDanhSachStmt.all(agentId) as unknown as { server_id: string }[];
  return rows.map((r) => r.server_id);
}

const layAgentTheoServerStmt = db.prepare(
  `SELECT agent_id FROM agent_mcp_servers WHERE server_id = ? ORDER BY agent_id`,
);

export function agentCuaServer(serverId: string): string[] {
  const rows = layAgentTheoServerStmt.all(serverId) as unknown as { agent_id: string }[];
  return rows.map((r) => r.agent_id);
}

const xoaGanCuaAgentStmt = db.prepare(`DELETE FROM agent_mcp_servers WHERE agent_id = ?`);
const xoaGanCuaServerStmt = db.prepare(`DELETE FROM agent_mcp_servers WHERE server_id = ?`);
const chenGanStmt = db.prepare(`INSERT INTO agent_mcp_servers (agent_id, server_id) VALUES (?, ?)`);

/** ĐẶT LẠI toàn bộ danh sách server của agent - THAY THẾ, không cộng dồn. */
export function datServerChoAgent(agentId: string, serverIds: string[]): void {
  const idDuyNhat = [...new Set(serverIds)];
  trongGiaoDich(() => {
    xoaGanCuaAgentStmt.run(agentId);
    for (const serverId of idDuyNhat) chenGanStmt.run(agentId, serverId);
  });
}

/** Chiều ngược của `datServerChoAgent` - gán MỘT server cho nhiều agent, cho đường gán ngay tại trang MCP. */
export function datAgentChoServer(serverId: string, agentIds: string[]): void {
  const idDuyNhat = [...new Set(agentIds)];
  trongGiaoDich(() => {
    xoaGanCuaServerStmt.run(serverId);
    for (const agentId of idDuyNhat) chenGanStmt.run(agentId, serverId);
  });
}

const demAgentTheoServerStmt = db.prepare(
  `SELECT server_id, COUNT(*) AS so FROM agent_mcp_servers GROUP BY server_id`,
);

/** Server KHÔNG có agent nào sẽ VẮNG MẶT trong Map - caller hiểu "không có khóa" là 0. */
export function demAgentTheoServer(): Map<string, number> {
  const rows = demAgentTheoServerStmt.all() as unknown as { server_id: string; so: number }[];
  return new Map(rows.map((r) => [r.server_id, r.so]));
}

/** Dọn sạch gán server của một agent - gọi từ `agent-store.ts` khi agent bị XÓA. */
export function xoaGanServerCuaAgent(agentId: string): void {
  xoaGanCuaAgentStmt.run(agentId);
}
