import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import type { Tool } from "ai";
import { z } from "zod";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let pool: typeof import("./mcp-connection-pool.js");
let store: typeof import("./mcp-server-store.js");
let binding: typeof import("./mcp-agent-binding.js");
let drift: typeof import("./mcp-tool-drift.js");
let database: typeof import("../conversation/database.js");
let tuning: typeof import("../config/runtime-tuning-settings.js");

before(async () => {
  dataDir = setupTestEnv();
  pool = await import("./mcp-connection-pool.js");
  store = await import("./mcp-server-store.js");
  binding = await import("./mcp-agent-binding.js");
  drift = await import("./mcp-tool-drift.js");
  database = await import("../conversation/database.js");
  tuning = await import("../config/runtime-tuning-settings.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  for (const t of ["mcp_servers", "agent_mcp_servers"]) {
    database.db.exec(`DELETE FROM ${t}`);
  }
  pool.resetPoolChoTest();
  pool.datKetNoiServerChoTest(async () => {
    throw new Error("test quên tiêm ketNoiFn giả");
  });
});

/** Client giả: `tools` là các tool AI SDK thật (cần cho fingerprintTools). */
function clientGia(toolsShape: Record<string, { description: string }>) {
  let closed = false;
  return {
    tools: async () => {
      const { tool } = await import("ai");
      const ra: Record<string, Tool> = {};
      for (const [ten, t] of Object.entries(toolsShape)) {
        ra[ten] = tool({ description: t.description, inputSchema: z.object({}), execute: async () => "ok" }) as Tool;
      }
      return ra;
    },
    close: async () => {
      closed = true;
    },
    daDong: () => closed,
  };
}

describe("mcp-connection-pool - nap() thành công", () => {
  it("nối được thì dựng ToolDefinition cho từng tool, lưu mốc lần đầu, đổi trạng thái da_ket_noi", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    const client = clientGia({ search: { description: "tìm kiếm" } });
    pool.datKetNoiServerChoTest(async () => client);

    await pool.nap(s.id, false);

    assert.equal(store.layServer(s.id)!.trangThai, "da_ket_noi");
    assert.notEqual(store.layFingerprint(s.id), "");
    const defs = pool.mcpToolDefinitions("agent-1");
    assert.equal(defs.length, 1);
    assert.match(defs[0]!.key, /^mcp__srv__search$/);
  });

  it("agent CHƯA gán server này thì mcpToolDefinitions trả rỗng dù server đã nối", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    pool.datKetNoiServerChoTest(async () => clientGia({ search: { description: "tìm" } }));
    await pool.nap(s.id, false);
    assert.deepEqual(pool.mcpToolDefinitions("agent-khong-lien-quan"), []);
  });

  it("server enabled=false thì KHÔNG nối, tự đặt lại cho_ket_noi", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp", enabled: false });
    let daGoi = false;
    pool.datKetNoiServerChoTest(async () => {
      daGoi = true;
      return clientGia({});
    });
    await pool.nap(s.id, false);
    assert.equal(daGoi, false);
    assert.equal(store.layServer(s.id)!.trangThai, "cho_ket_noi");
  });
});

describe("mcp-connection-pool - drift", () => {
  it("mốc đã có, bộ tool đổi -> can_duyet_lai, KHÔNG nạp tool vào cache, ĐÓNG client", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    // Lưu mốc TRƯỚC bằng bộ tool A
    const moc = await drift.chupFingerprint({
      search: (await import("ai")).tool({ description: "bản GỐC", inputSchema: z.object({}) }),
    });
    store.luuSnapshotFingerprint(s.id, [{ ten: "search", moTa: "bản GỐC" }], moc);

    // Nối lại với bộ tool B (description đã đổi)
    const client = clientGia({ search: { description: "bản ĐÃ ĐỔI" } });
    pool.datKetNoiServerChoTest(async () => client);
    await pool.nap(s.id, false);

    assert.equal(store.layServer(s.id)!.trangThai, "can_duyet_lai");
    assert.deepEqual(pool.mcpToolDefinitions("agent-1"), []);
    assert.equal(client.daDong(), true);
  });

  it("duyệt lại (luuMoc=true) BỎ QUA kiểm drift, luôn nạp + ghi đè mốc mới", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    const moc = await drift.chupFingerprint({
      search: (await import("ai")).tool({ description: "bản GỐC", inputSchema: z.object({}) }),
    });
    store.luuSnapshotFingerprint(s.id, [{ ten: "search", moTa: "bản GỐC" }], moc);

    pool.datKetNoiServerChoTest(async () => clientGia({ search: { description: "bản ĐÃ ĐỔI" } }));
    await pool.nap(s.id, true);

    assert.equal(store.layServer(s.id)!.trangThai, "da_ket_noi");
    assert.equal(pool.mcpToolDefinitions("agent-1").length, 1);
  });
});

describe("mcp-connection-pool - lỗi", () => {
  it("khám phá tool (tools()) quá hạn thì đóng handle rồi ném, không rò kết nối", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    // Sàn thật của tham số này (env.ts LẪN tuning-definitions.ts) là 1000ms -
    // dưới đó `getTuning` âm thầm rơi về mặc định 15000ms (giá trị trong DB
    // hỏng thì bị bỏ qua), khiến test này chờ oan 15 giây mà không báo gì.
    // Đặt ĐÚNG sàn để vẫn đo được hành vi timeout mà không phải hạ sàn Zod
    // xuống chỉ để phục vụ 1 test (không có ca thật nào cần nối trong <1s).
    tuning.setTuning("MCP_CONNECT_TIMEOUT_MS", 1000);
    let closed = false;
    pool.datKetNoiServerChoTest(async () => ({
      tools: () => new Promise<Record<string, never>>(() => {}),
      close: async () => {
        closed = true;
      },
    }));
    try {
      await assert.rejects(pool.nap(s.id, false));
      assert.equal(closed, true);
    } finally {
      tuning.setTuning("MCP_CONNECT_TIMEOUT_MS", null);
    }
  });
});

describe("mcp-connection-pool - ngatServer / dongTatCaKetNoi", () => {
  it("ngatServer đóng client và xóa khỏi cache", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    const client = clientGia({ search: { description: "x" } });
    pool.datKetNoiServerChoTest(async () => client);
    await pool.nap(s.id, false);

    await pool.ngatServer(s.id);
    assert.equal(client.daDong(), true);
    assert.deepEqual(pool.mcpToolDefinitions("agent-1"), []);
  });

  it("ngatServer với id chưa từng nối là no-op, không ném", async () => {
    await pool.ngatServer("khong-ton-tai");
  });
});

describe("mcp-connection-pool - tự nối lại khi phiên MCP hết hạn (bug thật 2026-09-25, Apify)", () => {
  /** Client có tool `search` chạy `hanhVi` - dùng để giả phiên cũ hỏng, phiên mới chạy được. */
  function clientVoi(hanhVi: () => Promise<string>) {
    let closed = false;
    return {
      tools: async () => {
        const { tool } = await import("ai");
        return { search: tool({ description: "tìm", inputSchema: z.object({}), execute: hanhVi }) as Tool };
      },
      close: async () => {
        closed = true;
      },
      daDong: () => closed,
    };
  }
  const ctx = { api: null, account: {}, agent: { id: "agent-1" }, message: {}, batch: [] } as never;

  it("tool gọi trên phiên đã hết hạn: tự nối lại, gọi lại trên client mới, lượt vẫn ra kết quả", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    const cu = clientVoi(async () => {
      throw new Error("Session not found");
    });
    const moi = clientVoi(async () => "kết quả mới");
    const hangDoi = [cu, moi];
    let soLanNoi = 0;
    pool.datKetNoiServerChoTest(async () => {
      soLanNoi++;
      return hangDoi.shift()!;
    });
    await pool.nap(s.id, false);

    const def = pool.mcpToolDefinitions("agent-1")[0]!;
    const kq = await (def.build(ctx) as any).execute({}, {});

    assert.equal(typeof kq, "string");
    assert.match(kq as string, /kết quả mới/);
    assert.equal(soLanNoi, 2);
    assert.ok(cu.daDong(), "client phiên cũ phải được đóng");
    assert.equal(store.layServer(s.id)!.trangThai, "da_ket_noi");
  });

  it("hai lượt cùng dính hết phiên chỉ nối lại MỘT lần", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    const cu = clientVoi(async () => {
      throw new Error("Session not found");
    });
    const hangDoi = [cu, clientVoi(async () => "ok"), clientVoi(async () => "ok")];
    let soLanNoi = 0;
    pool.datKetNoiServerChoTest(async () => {
      soLanNoi++;
      return hangDoi.shift()!;
    });
    await pool.nap(s.id, false);

    const t = pool.mcpToolDefinitions("agent-1")[0]!.build(ctx) as any;
    await Promise.all([t.execute({}, {}), t.execute({}, {})]);
    assert.equal(soLanNoi, 2, "1 lần nối đầu + đúng 1 lần nối lại");
  });

  it("nối lại hỏng thì báo lỗi cho model và đánh server 'loi' để health thử tiếp", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    const cu = clientVoi(async () => {
      throw new Error("Session not found");
    });
    let lan = 0;
    pool.datKetNoiServerChoTest(async () => {
      if (lan++ === 0) return cu;
      throw new Error("server không trả lời");
    });
    await pool.nap(s.id, false);

    const kq = await (pool.mcpToolDefinitions("agent-1")[0]!.build(ctx) as any).execute({}, {});
    assert.equal(typeof kq, "object", "phải là ketQuaLoi, không phải chuỗi thành công");
    assert.equal(store.layServer(s.id)!.trangThai, "loi");
  });
});
