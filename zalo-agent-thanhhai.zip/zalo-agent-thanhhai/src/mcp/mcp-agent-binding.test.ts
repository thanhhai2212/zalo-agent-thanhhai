import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let binding: typeof import("./mcp-agent-binding.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  binding = await import("./mcp-agent-binding.js");
  database = await import("../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  for (const t of ["mcp_servers", "agent_mcp_servers"]) {
    database.db.exec(`DELETE FROM ${t}`);
  }
});

describe("mcp-agent-binding - mặc định ĐÓNG", () => {
  it("agent chưa gán server nào thì đọc RỖNG", () => {
    assert.deepEqual(binding.serversCuaAgent("agent-moi"), []);
  });

  it("server chưa gán agent nào thì đọc RỖNG", () => {
    assert.deepEqual(binding.agentCuaServer("server-moi"), []);
  });
});

describe("mcp-agent-binding - datServerChoAgent (THAY THẾ, không cộng dồn)", () => {
  it("gán lần 2 thay thế hoàn toàn danh sách lần 1", () => {
    binding.datServerChoAgent("agent-1", ["s1", "s2"]);
    binding.datServerChoAgent("agent-1", ["s3"]);
    assert.deepEqual(binding.serversCuaAgent("agent-1"), ["s3"]);
  });

  it("id trùng trong mảng đầu vào bị lọc, không ném lỗi UNIQUE", () => {
    binding.datServerChoAgent("agent-1", ["s1", "s1", "s2"]);
    assert.deepEqual(binding.serversCuaAgent("agent-1"), ["s1", "s2"]);
  });

  it("mảng rỗng thì XÓA SẠCH gán cũ", () => {
    binding.datServerChoAgent("agent-1", ["s1"]);
    binding.datServerChoAgent("agent-1", []);
    assert.deepEqual(binding.serversCuaAgent("agent-1"), []);
  });
});

describe("mcp-agent-binding - datAgentChoServer (chiều ngược)", () => {
  it("gán 1 server cho nhiều agent, thay thế danh sách cũ", () => {
    binding.datAgentChoServer("s1", ["a1", "a2"]);
    binding.datAgentChoServer("s1", ["a3"]);
    assert.deepEqual(binding.agentCuaServer("s1"), ["a3"]);
    assert.deepEqual(binding.serversCuaAgent("a1"), []);
    assert.deepEqual(binding.serversCuaAgent("a3"), ["s1"]);
  });
});

describe("mcp-agent-binding - demAgentTheoServer", () => {
  it("server không có agent nào VẮNG MẶT trong Map (không phải giá trị 0)", () => {
    binding.datServerChoAgent("a1", ["s1"]);
    const dem = binding.demAgentTheoServer();
    assert.equal(dem.get("s1"), 1);
    assert.equal(dem.has("s-chua-gan"), false);
  });
});

describe("mcp-agent-binding - xoaGanServerCuaAgent", () => {
  it("dọn sạch gán của agent, không đụng gán của agent khác", () => {
    binding.datServerChoAgent("a1", ["s1"]);
    binding.datServerChoAgent("a2", ["s1"]);
    binding.xoaGanServerCuaAgent("a1");
    assert.deepEqual(binding.serversCuaAgent("a1"), []);
    assert.deepEqual(binding.serversCuaAgent("a2"), ["s1"]);
  });
});
