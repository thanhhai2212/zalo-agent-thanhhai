import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let store: typeof import("./mcp-server-store.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  store = await import("./mcp-server-store.js");
  database = await import("../conversation/database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  for (const t of ["mcp_servers", "agent_mcp_servers"]) {
    database.db.exec(`DELETE FROM ${t}`);
  }
});

describe("mcp-server-store - tạo và đọc", () => {
  it("tạo server rồi đọc lại thấy đúng, mặc định bật và chờ kết nối", () => {
    const s = store.taoServer({ ten: "Notion", url: "https://mcp.notion.example/mcp" });
    const doc = store.layServer(s.id)!;
    assert.equal(doc.ten, "Notion");
    assert.equal(doc.enabled, true);
    assert.equal(doc.trangThai, "cho_ket_noi");
    assert.deepEqual(doc.toolsSnapshot, []);
  });

  it("id là ngẫu nhiên, KHÔNG phải slug từ tên", () => {
    const a = store.taoServer({ ten: "Notion", url: "https://x.example/mcp" });
    const b = store.taoServer({ ten: "Notion", url: "https://y.example/mcp" });
    assert.notEqual(a.id, b.id);
  });

  it("layServerNoiBo giải mã headers, danh sách công khai KHÔNG lộ headers", () => {
    const s = store.taoServer({
      ten: "Github",
      url: "https://mcp.github.example/mcp",
      headers: { Authorization: "Bearer bi-mat" },
    });
    const noiBo = store.layServerNoiBo(s.id)!;
    assert.deepEqual(noiBo.headers, { Authorization: "Bearer bi-mat" });
    // McpServer (bản công khai) không có field headers ở kiểu, nhưng kiểm
    // runtime cho chắc: JSON không lộ chuỗi bí mật ra ngoài.
    assert.ok(!JSON.stringify(store.layServer(s.id)).includes("bi-mat"));
  });

  it("không headers thì layServerNoiBo trả object rỗng, không ném", () => {
    const s = store.taoServer({ ten: "Không header", url: "https://x.example/mcp" });
    assert.deepEqual(store.layServerNoiBo(s.id)!.headers, {});
  });
});

describe("mcp-server-store - capNhatServer (ô trống = giữ nguyên)", () => {
  it("chỉ sửa field được truyền, field khác giữ nguyên", () => {
    const s = store.taoServer({ ten: "Cũ", url: "https://cu.example/mcp" });
    const sau = store.capNhatServer(s.id, { ten: "Mới" })!;
    assert.equal(sau.ten, "Mới");
    assert.equal(sau.url, "https://cu.example/mcp");
  });

  it("truyền headers rỗng {} là XÓA SẠCH, không phải giữ nguyên", () => {
    const s = store.taoServer({ ten: "A", url: "https://a.example/mcp", headers: { X: "1" } });
    store.capNhatServer(s.id, { headers: {} });
    assert.deepEqual(store.layServerNoiBo(s.id)!.headers, {});
  });

  it("không truyền patch nào thì trả nguyên trạng, không lỗi", () => {
    const s = store.taoServer({ ten: "A", url: "https://a.example/mcp" });
    const sau = store.capNhatServer(s.id, {})!;
    assert.equal(sau.ten, "A");
  });
});

describe("mcp-server-store - trạng thái + fingerprint", () => {
  it("datTrangThaiServer ghi đúng trạng thái + lỗi", () => {
    const s = store.taoServer({ ten: "A", url: "https://a.example/mcp" });
    store.datTrangThaiServer(s.id, "loi", "hết giờ");
    const doc = store.layServer(s.id)!;
    assert.equal(doc.trangThai, "loi");
    assert.equal(doc.loi, "hết giờ");
  });

  it("chưa từng lưu mốc thì layFingerprint trả rỗng", () => {
    const s = store.taoServer({ ten: "A", url: "https://a.example/mcp" });
    assert.equal(store.layFingerprint(s.id), "");
  });

  it("luuSnapshotFingerprint ghi cả snapshot lẫn fingerprint", () => {
    const s = store.taoServer({ ten: "A", url: "https://a.example/mcp" });
    store.luuSnapshotFingerprint(s.id, [{ ten: "tool1", moTa: "làm gì đó" }], "abc123");
    const doc = store.layServer(s.id)!;
    assert.deepEqual(doc.toolsSnapshot, [{ ten: "tool1", moTa: "làm gì đó" }]);
    assert.equal(store.layFingerprint(s.id), "abc123");
  });
});

describe("mcp-server-store - xóa sạch", () => {
  it("xoaServer dọn cả dòng server lẫn gán agent, trong 1 giao dịch", async () => {
    const binding = await import("./mcp-agent-binding.js");
    const s = store.taoServer({ ten: "A", url: "https://a.example/mcp" });
    binding.datServerChoAgent("agent-1", [s.id]);
    store.xoaServer(s.id);
    assert.equal(store.layServer(s.id), null);
    assert.deepEqual(binding.serversCuaAgent("agent-1"), []);
  });
});
