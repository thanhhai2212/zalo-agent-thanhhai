/**
 * CRUD server MCP + trạng thái kết nối/fingerprint. Lược đồ ở `mcp-schema.ts`.
 *
 * Adapt `trongGiaoDich`
 * sang chữ ký 1 tham số của local. Mirror `kb-source-store.ts`.
 */

import { randomBytes } from "node:crypto";
import { decryptSecret, encryptSecret } from "../config/secret-cipher.js";
import { db, trongGiaoDich } from "../conversation/database.js";
import { createLogger } from "../shared/logger.js";
import { coTokenOauth } from "./mcp-oauth-store.js";
import type { McpServer, McpServerNoiBo, McpToolInfo, TrangThaiServer } from "./mcp-types.js";

const log = createLogger("mcp-server-store");

type Row = {
  id: string;
  ten: string;
  url: string;
  headers_ma_hoa: string;
  enabled: number;
  chi_chu_bot: number;
  chu_trong_nhom: number;
  dung_oauth: number;
  oauth_ma_hoa: string;
  trang_thai: TrangThaiServer;
  loi: string;
  tools_snapshot: string;
  fingerprint: string;
  created_at: string;
  updated_at: string;
};

/** Headers hỏng (key xoay, dữ liệu cũ) không được crash cả process - rỗng thì nối không header */
function giaiMaHeaders(maHoa: string): Record<string, string> {
  if (!maHoa) return {};
  try {
    return JSON.parse(decryptSecret(maHoa)) as Record<string, string>;
  } catch (err) {
    log.error({ err }, "Giải mã headers MCP lỗi - coi như không có header");
    return {};
  }
}

function docSnapshot(json: string): McpToolInfo[] {
  if (!json) return [];
  try {
    return JSON.parse(json) as McpToolInfo[];
  } catch {
    return [];
  }
}

function mapRow(row: Row): McpServer {
  return {
    id: row.id,
    ten: row.ten,
    url: row.url,
    enabled: row.enabled === 1,
    chiChuBot: row.chi_chu_bot === 1,
    chuTrongNhom: row.chu_trong_nhom === 1,
    dungOauth: row.dung_oauth === 1,
    daDangNhap: row.dung_oauth === 1 && coTokenOauth(row.oauth_ma_hoa),
    trangThai: row.trang_thai,
    loi: row.loi,
    toolsSnapshot: docSnapshot(row.tools_snapshot),
    tenHeaders: Object.keys(giaiMaHeaders(row.headers_ma_hoa)),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

const insertStmt = db.prepare(`
  INSERT INTO mcp_servers (id, ten, url, headers_ma_hoa, enabled, chi_chu_bot, chu_trong_nhom, dung_oauth)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`);

export function taoServer(p: {
  ten: string;
  url: string;
  headers?: Record<string, string>;
  enabled?: boolean;
  chiChuBot?: boolean;
  chuTrongNhom?: boolean;
  dungOauth?: boolean;
}): McpServer {
  const id = randomBytes(8).toString("hex");
  const headersJson =
    p.headers && Object.keys(p.headers).length > 0 ? encryptSecret(JSON.stringify(p.headers)) : "";
  // Server OAuth mặc định CHỈ CHỦ BOT: token mang quyền của tài khoản chủ (sửa thiết kế, ghi
  // dữ liệu...), mà bot đọc tin người lạ - mở cho mọi người phải là quyết định tường minh.
  const chiChu = p.chiChuBot ?? p.dungOauth === true;
  // Chủ trong nhóm chỉ có nghĩa khi đã "chỉ chủ bot" - không bật thì bỏ.
  const chuNhom = chiChu && p.chuTrongNhom === true;
  insertStmt.run(id, p.ten, p.url, headersJson, (p.enabled ?? true) ? 1 : 0, chiChu ? 1 : 0, chuNhom ? 1 : 0, p.dungOauth ? 1 : 0);
  return layServer(id)!;
}

const getStmt = db.prepare(`SELECT * FROM mcp_servers WHERE id = ?`);

export function layServer(id: string): McpServer | null {
  const row = getStmt.get(id) as Row | undefined;
  return row ? mapRow(row) : null;
}

/** Bản NỘI BỘ, kèm headers ĐÃ giải mã - chỉ manager/pool được gọi, không lộ ra route dashboard */
export function layServerNoiBo(id: string): McpServerNoiBo | null {
  const row = getStmt.get(id) as Row | undefined;
  if (!row) return null;
  return {
    id: row.id,
    ten: row.ten,
    url: row.url,
    headers: giaiMaHeaders(row.headers_ma_hoa),
    chiChuBot: row.chi_chu_bot === 1,
    dungOauth: row.dung_oauth === 1,
    enabled: row.enabled === 1,
    trangThai: row.trang_thai,
    loi: row.loi,
  };
}

const listStmt = db.prepare(`SELECT * FROM mcp_servers ORDER BY created_at DESC`);

export function danhSachServer(): McpServer[] {
  const rows = listStmt.all() as unknown as Row[];
  return rows.map(mapRow);
}

/**
 * Cập nhật từng phần - `undefined` nghĩa là GIỮ NGUYÊN giá trị hiện có (đúng
 * quy ước "ô trống = giữ" của mọi field cấu hình trong repo). `headers`
 * truyền `{}` để XÓA SẠCH (dùng `xoaHeaders` cho rõ ý hơn), truyền object có
 * key để THAY THẾ TOÀN BỘ (không merge).
 */
export function capNhatServer(
  id: string,
  patch: {
    ten?: string;
    url?: string;
    headers?: Record<string, string>;
    enabled?: boolean;
    chiChuBot?: boolean;
    chuTrongNhom?: boolean;
  },
): McpServer | null {
  const sets: string[] = [];
  const vals: (string | number)[] = [];
  if (patch.ten !== undefined) {
    sets.push("ten = ?");
    vals.push(patch.ten);
  }
  if (patch.url !== undefined) {
    sets.push("url = ?");
    vals.push(patch.url);
  }
  if (patch.headers !== undefined) {
    sets.push("headers_ma_hoa = ?");
    vals.push(Object.keys(patch.headers).length > 0 ? encryptSecret(JSON.stringify(patch.headers)) : "");
  }
  if (patch.enabled !== undefined) {
    sets.push("enabled = ?");
    vals.push(patch.enabled ? 1 : 0);
  }
  if (patch.chiChuBot !== undefined) {
    sets.push("chi_chu_bot = ?");
    vals.push(patch.chiChuBot ? 1 : 0);
    // Tắt "chỉ chủ bot" thì quyền "chủ trong nhóm" hết nghĩa - xóa luôn, khỏi sống lại ngầm khi bật lại.
    if (!patch.chiChuBot) {
      sets.push("chu_trong_nhom = ?");
      vals.push(0);
    }
  }
  if (patch.chuTrongNhom !== undefined && patch.chiChuBot !== false) {
    sets.push("chu_trong_nhom = ?");
    vals.push(patch.chuTrongNhom ? 1 : 0);
  }
  if (sets.length === 0) return layServer(id);
  sets.push("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");
  db.prepare(`UPDATE mcp_servers SET ${sets.join(", ")} WHERE id = ?`).run(...vals, id);
  return layServer(id);
}

const xoaHeadersStmt = db.prepare(
  `UPDATE mcp_servers SET headers_ma_hoa = '', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?`,
);

export function xoaHeaders(id: string): void {
  xoaHeadersStmt.run(id);
}

const setTrangThaiStmt = db.prepare(
  `UPDATE mcp_servers SET trang_thai = ?, loi = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?`,
);

export function datTrangThaiServer(id: string, trangThai: TrangThaiServer, loi = ""): void {
  setTrangThaiStmt.run(trangThai, loi, id);
}

const setSnapshotStmt = db.prepare(`
  UPDATE mcp_servers
     SET tools_snapshot = ?, fingerprint = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
   WHERE id = ?
`);

export function luuSnapshotFingerprint(id: string, snapshot: McpToolInfo[], fingerprint: string): void {
  setSnapshotStmt.run(JSON.stringify(snapshot), fingerprint, id);
}

const getFpStmt = db.prepare(`SELECT fingerprint FROM mcp_servers WHERE id = ?`);

export function layFingerprint(id: string): string {
  const row = getFpStmt.get(id) as { fingerprint: string } | undefined;
  return row?.fingerprint ?? "";
}

// ===== Xóa sạch =====
const xoaGanServerStmt = db.prepare(`DELETE FROM agent_mcp_servers WHERE server_id = ?`);
const xoaServerStmt = db.prepare(`DELETE FROM mcp_servers WHERE id = ?`);

export function xoaServer(id: string): void {
  trongGiaoDich(() => {
    xoaGanServerStmt.run(id);
    xoaServerStmt.run(id);
  });
}
