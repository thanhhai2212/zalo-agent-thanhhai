import { auth } from "@ai-sdk/mcp";
import { createLogger } from "../shared/logger.js";
import { MaOauthProvider, daCoTokenOauth, xoaTokenOauth } from "./mcp-oauth-store.js";
import { layServerNoiBo } from "./mcp-server-store.js";

/**
 * Luồng đăng nhập OAuth cho server MCP (Canva...), hai bước do người vận hành bấm trên dashboard:
 *   1. `batDauOauth`: SDK tự khám phá, tự đăng ký client (DCR) và dựng địa chỉ cấp quyền (PKCE).
 *      Người dùng mở địa chỉ đó, bấm "Cho phép" bằng tài khoản CỦA MÌNH.
 *   2. `hoanTatOauth`: nhà cung cấp chuyển trình duyệt về `http://localhost:<cổng>/...` (trang báo
 *      lỗi không mở được là bình thường vì VPS không có domain công khai). Người dùng dán địa chỉ đó
 *      vào dashboard; ta chỉ đọc `code`/`state` trong chuỗi dán, rồi đổi lấy token.
 *
 * Đây là hành động của NGƯỜI qua dashboard, không phải tool cho model gọi. Hàm `auth` tiêm được để
 * test không gọi mạng.
 */

const log = createLogger("mcp-oauth-flow");

export type PhuThuocOauth = { auth: typeof auth };
const depThat: PhuThuocOauth = { auth };

export class LoiOauth extends Error {}

function layServerOauth(id: string) {
  const svr = layServerNoiBo(id);
  if (!svr) throw new LoiOauth("Không tìm thấy server");
  if (!svr.dungOauth) throw new LoiOauth("Server này không dùng đăng nhập OAuth");
  if (!svr.url.startsWith("https://")) throw new LoiOauth("Đăng nhập OAuth chỉ hỗ trợ server https");
  return svr;
}

export async function batDauOauth(id: string, deps: PhuThuocOauth = depThat): Promise<{ authUrl: string } | { daDangNhap: true }> {
  const svr = layServerOauth(id);
  const provider = new MaOauthProvider(id, true);
  let kq: Awaited<ReturnType<typeof auth>>;
  try {
    kq = await deps.auth(provider, { serverUrl: svr.url });
  } catch (err) {
    log.warn({ serverId: id, err: err instanceof Error ? err.message : String(err) }, "Bắt đầu OAuth lỗi");
    throw new LoiOauth(`Không bắt đầu được đăng nhập OAuth: ${err instanceof Error ? err.message : String(err)}`);
  }
  if (kq === "AUTHORIZED") return { daDangNhap: true };
  if (!provider.authUrl) throw new LoiOauth("Máy chủ không trả địa chỉ cấp quyền");
  return { authUrl: provider.authUrl };
}

/** Tách `code`/`state`/lỗi từ địa chỉ người dùng dán (chấp nhận cả chuỗi `?code=...&state=...` trần). */
export function docDiaChiChuyenVe(dan: string): { code: string; state: string | null; iss: string | null } {
  const s = dan.trim();
  let u: URL;
  try {
    u = new URL(s);
  } catch {
    try {
      u = new URL(`http://localhost/?${s.replace(/^[?#]/, "")}`);
    } catch {
      throw new LoiOauth("Địa chỉ dán vào không hợp lệ");
    }
  }
  const loi = u.searchParams.get("error");
  if (loi) throw new LoiOauth(`Nhà cung cấp từ chối: ${u.searchParams.get("error_description") || loi}`);
  const code = u.searchParams.get("code");
  if (!code) throw new LoiOauth("Địa chỉ dán vào không có mã đăng nhập (code) - hãy copy đúng địa chỉ trên thanh trình duyệt sau khi bấm Cho phép");
  return { code, state: u.searchParams.get("state"), iss: u.searchParams.get("iss") };
}

export async function hoanTatOauth(id: string, diaChiDan: string, deps: PhuThuocOauth = depThat): Promise<void> {
  const svr = layServerOauth(id);
  const { code, state, iss } = docDiaChiChuyenVe(diaChiDan);
  const provider = new MaOauthProvider(id, true);
  const stateDaLuu = provider.storedState();
  if (!stateDaLuu) throw new LoiOauth("Chưa có phiên đăng nhập đang chờ - bấm Đăng nhập lại từ đầu");
  if (state !== stateDaLuu) throw new LoiOauth("Địa chỉ dán vào không khớp phiên đăng nhập đang chờ - bấm Đăng nhập lại từ đầu");
  try {
    await deps.auth(provider, { serverUrl: svr.url, authorizationCode: code, callbackState: state, ...(iss ? { callbackIssuer: iss } : {}) });
  } catch (err) {
    log.warn({ serverId: id, err: err instanceof Error ? err.message : String(err) }, "Hoàn tất OAuth lỗi");
    throw new LoiOauth(`Đổi mã lấy token thất bại: ${err instanceof Error ? err.message : String(err)}`);
  }
  if (!daCoTokenOauth(id)) throw new LoiOauth("Đăng nhập không lưu được token");
}

export function dangXuatOauth(id: string): void {
  layServerOauth(id);
  xoaTokenOauth(id);
}
