import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import type { Tool } from "ai";
import { z } from "zod";
import { doiChoDenKhi } from "../shared/doi-cho-den-khi.js";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let manager: typeof import("./mcp-manager.js");
let store: typeof import("./mcp-server-store.js");
let provider: typeof import("../agent/tools/mcp-tool-provider.js");
let database: typeof import("../conversation/database.js");
let tuning: typeof import("../config/runtime-tuning-settings.js");

before(async () => {
  dataDir = setupTestEnv();
  manager = await import("./mcp-manager.js");
  store = await import("./mcp-server-store.js");
  provider = await import("../agent/tools/mcp-tool-provider.js");
  database = await import("../conversation/database.js");
  tuning = await import("../config/runtime-tuning-settings.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

beforeEach(() => {
  for (const t of ["mcp_servers", "agent_mcp_servers"]) {
    database.db.exec(`DELETE FROM ${t}`);
  }
  manager.resetChoTest();
  manager.datKetNoiServerChoTest(async () => {
    throw new Error("test quên tiêm ketNoiFn giả");
  });
});

function clientGiaCham(msDelay: number, tools: Record<string, { description: string }> = {}) {
  return {
    tools: async () => {
      await new Promise((r) => setTimeout(r, msDelay));
      const { tool } = await import("ai");
      const ra: Record<string, Tool> = {};
      for (const [ten, t] of Object.entries(tools)) {
        ra[ten] = tool({ description: t.description, inputSchema: z.object({}) }) as Tool;
      }
      return ra;
    },
    close: async () => {},
  };
}

describe("mcp-manager - chốt tái nhập dangNap", () => {
  it("2 lời gọi ketNoiLaiServer CHỒNG NHAU trên CÙNG server chỉ thật sự nối 1 lần", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    let soLanGoiConnect = 0;
    manager.datKetNoiServerChoTest(async () => {
      soLanGoiConnect++;
      return clientGiaCham(30);
    });
    await Promise.all([manager.ketNoiLaiServer(s.id), manager.ketNoiLaiServer(s.id)]);
    assert.equal(soLanGoiConnect, 1, "lời gọi thứ 2 phải bị chặn bởi dangNap, không nối chồng");
  });

  it("ketNoiLaiServer và duyetLaiDrift dùng CHUNG chốt - chồng nhau cũng chỉ nối 1 lần", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    let soLan = 0;
    manager.datKetNoiServerChoTest(async () => {
      soLan++;
      return clientGiaCham(30);
    });
    await Promise.all([manager.ketNoiLaiServer(s.id), manager.duyetLaiDrift(s.id)]);
    assert.equal(soLan, 1);
  });

  it("nối lỗi thì ghi trang_thai=loi, KHÔNG ném ra ngoài caller", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    manager.datKetNoiServerChoTest(async () => {
      throw new Error("mạng hỏng");
    });
    await manager.ketNoiLaiServer(s.id);
    const doc = store.layServer(s.id)!;
    assert.equal(doc.trangThai, "loi");
    assert.match(doc.loi, /mạng hỏng/);
  });
});

describe("mcp-manager - startMcpManager", () => {
  it("MCP_ENABLED=false thì không đăng ký nguồn, không nối server nào", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    let daGoiConnect = false;
    manager.datKetNoiServerChoTest(async () => {
      daGoiConnect = true;
      return clientGiaCham(0);
    });
    tuning.setTuning("MCP_ENABLED", false);
    try {
      const stop = manager.startMcpManager();
      await new Promise((r) => setTimeout(r, 10));
      stop();
      assert.equal(daGoiConnect, false);
      assert.equal(store.layServer(s.id)!.trangThai, "cho_ket_noi");
    } finally {
      tuning.setTuning("MCP_ENABLED", null);
    }
  });

  it("boot nối mọi server enabled, bỏ qua server disabled", async () => {
    const bat = store.taoServer({ ten: "Bật", url: "https://a.example/mcp" });
    store.taoServer({ ten: "Tắt", url: "https://b.example/mcp", enabled: false });
    const daNoi = new Set<string>();
    manager.datKetNoiServerChoTest(async (cfg) => {
      daNoi.add(cfg.url);
      return clientGiaCham(0);
    });
    const stop = manager.startMcpManager();
    try {
      // Chờ ĐIỀU KIỆN THẬT (server đã đổi trạng thái), không sleep cố định -
      // máy bận thì `nap()` chưa kịp resolve trong một mốc thời gian cứng.
      await doiChoDenKhi(() => store.layServer(bat.id)!.trangThai === "da_ket_noi", {
        moTa: "server Bật nối xong",
      });
    } finally {
      stop();
    }
    assert.ok(daNoi.has("https://a.example/mcp"));
    assert.equal(daNoi.has("https://b.example/mcp"), false);
  });

  it("đăng ký nguồn cho tool-provider - layToolMcpChoAgent đọc được ngay sau start", async () => {
    const s = store.taoServer({ ten: "Srv", url: "https://x.example/mcp" });
    const binding = await import("./mcp-agent-binding.js");
    binding.datServerChoAgent("agent-1", [s.id]);
    manager.datKetNoiServerChoTest(async () => clientGiaCham(0, { search: { description: "tìm" } }));
    const stop = manager.startMcpManager();
    try {
      await doiChoDenKhi(() => provider.layToolMcpChoAgent("agent-1").length === 1, {
        moTa: "tool ngoài của agent-1 xuất hiện sau khi manager nối xong",
      });
    } finally {
      stop();
    }
  });
});

describe("mcp-manager - chờ nối xong lần đầu sau boot", () => {
  it("doiMcpNoiXongLanDau chờ tới khi server nối xong (tool đã vào cache), không phải trả về ngay", async () => {
    const s = store.taoServer({ ten: "chậm", url: "https://x.test/mcp" });
    manager.datKetNoiServerChoTest(async () => clientGiaCham(150, { t1: { description: "mô tả" } }) as never);
    const dung = manager.startMcpManager();
    try {
      const t0 = Date.now();
      await manager.doiMcpNoiXongLanDau(5000);
      assert.ok(Date.now() - t0 >= 100, "phải đợi nối xong, không trả về ngay");
      assert.equal(store.layServer(s.id)?.trangThai, "da_ket_noi");
    } finally {
      dung();
    }
  });

  it("server treo thì chờ có trần, không kẹt vĩnh viễn", async () => {
    store.taoServer({ ten: "treo", url: "https://x.test/mcp" });
    manager.datKetNoiServerChoTest(async () => clientGiaCham(60_000) as never);
    const dung = manager.startMcpManager();
    try {
      const t0 = Date.now();
      await manager.doiMcpNoiXongLanDau(200);
      assert.ok(Date.now() - t0 < 2000);
    } finally {
      dung();
    }
  });
});
