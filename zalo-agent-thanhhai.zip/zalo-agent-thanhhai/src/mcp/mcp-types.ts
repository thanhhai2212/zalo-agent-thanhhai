/**
 * Kiểu dùng chung của module MCP - tách riêng để store/pool/manager/routes
 * không import vòng lẫn nhau.
 *
 */

export type TrangThaiServer = "cho_ket_noi" | "da_ket_noi" | "loi" | "can_duyet_lai";

export type McpToolInfo = { ten: string; moTa: string };

/** Hàng thật trong DB, headers ĐÃ giải mã - chỉ dùng nội bộ (manager/pool), không lộ ra dashboard */
export type McpServerNoiBo = {
  id: string;
  ten: string;
  url: string;
  headers: Record<string, string>;
  enabled: boolean;
  /** Tool của server chỉ dùng được khi CHÍNH chủ bot nhắn RIÊNG (dữ liệu khách hàng...) */
  chiChuBot: boolean;
  /** Đăng nhập bằng OAuth (token do bot tự giữ + làm mới) thay vì header dán sẵn */
  dungOauth: boolean;
  trangThai: TrangThaiServer;
  loi: string;
};

/** Dữ liệu cấu hình một server - KHÔNG kèm headers (secret, mã hóa riêng) */
export type McpServer = {
  id: string;
  ten: string;
  url: string;
  enabled: boolean;
  chiChuBot: boolean;
  /** Kèm `chiChuBot`: chủ bot dùng được cả trong nhóm (lượt chỉ có tin của chủ bot) */
  chuTrongNhom: boolean;
  dungOauth: boolean;
  /** Đã có token OAuth (chưa chắc còn hạn - bot tự làm mới) */
  daDangNhap: boolean;
  trangThai: TrangThaiServer;
  loi: string;
  toolsSnapshot: McpToolInfo[];
  /** TÊN các header đã lưu (không bao giờ kèm giá trị) - để dashboard nói đúng "header ĐÃ lưu, server vẫn từ chối" */
  tenHeaders: string[];
  createdAt: string;
  updatedAt: string;
};

/** Trả cho dashboard: McpServer + số agent đang gán + trạng thái LIVE (RAM, không phải DB) */
export type McpServerView = McpServer & { soAgent: number };
