import { DEFAULT_PERSONA } from "./default-persona.js";
import { db } from "../conversation/database.js";
import type { ReasoningEffort } from "../agent/reasoning-options.js";
import { xoaGanNguonCuaAgent } from "../knowledge/kb-agent-binding.js";
import { xoaGanServerCuaAgent } from "../mcp/mcp-agent-binding.js";
import { parseDisabledTools } from "./parse-disabled-tools.js";
import type { LlmProviderKind } from "./llm-provider-kind.js";
import { createLogger } from "../shared/logger.js";
import { decryptSecret, encryptSecret } from "./secret-cipher.js";

const log = createLogger("agent-store");

/** Não của bot: persona + model override. Gắn vào account qua accounts.agent_id. */
export type AgentProfile = {
  id: string;
  icon: string;
  name: string;
  persona: string;
  /**
   * Override model riêng; null = dùng cấu hình Providers chung.
   *
   * An toàn để LỆCH provider chung chỉ khi `modelApiKey` cũng có giá trị -
   * `doiProviderAnToan` (llm-provider.ts) vẫn bỏ qua override lệch nếu agent
   * này chưa có khóa riêng, để không gửi nhầm khóa của cấu hình chung sang
   * hãng khác.
   */
  modelProvider: LlmProviderKind | null;
  modelName: string | null;
  /** Chỉ có nghĩa khi provider là openai-compatible VÀ có modelApiKey riêng */
  modelBaseUrl: string | null;
  /** Đã giải mã, dùng nội bộ. null = agent này dùng khóa của cấu hình chung */
  modelApiKey: string | null;
  /**
   * DB có ciphertext nhưng giải mã HỎNG (CREDENTIALS_ENCRYPTION_KEY đổi so với
   * lúc lưu) - mirror `apiKeyHong` của `runtime-llm-settings.ts`. `modelApiKey`
   * sẽ là null trong ca này để KHÔNG âm thầm rơi về cấu hình chung.
   */
  modelApiKeyHong: boolean;
  maxSteps: number | null;
  /** Mức suy nghĩ riêng; null = dùng mức mặc định ở trang Cấu hình */
  reasoningEffort: ReasoningEffort | null;
  /**
   * Tool agent này KHÔNG dùng (danh sách TẮT, rỗng = bật hết).
   *
   * GIAO với `AccountConfig.disabledTools`, không thay thế: tool dùng được là
   * phần không bên nào tắt. Agent khai năng lực, account áp chính sách - xem
   * `listAvailableTools` ở `tool-registry.ts`.
   */
  disabledTools: string[];
  /**
   * Trần token cho phần input mỗi lần gọi model; null = theo LLM_CONTEXT_WINDOW
   * ở trang Cấu hình. Ở đây chứ không chỉ ở cấu hình chung vì trần phụ thuộc
   * cửa sổ của MODEL, mà model đặt được theo từng agent.
   */
  contextWindow: number | null;


  // ===== TTS RIÊNG cho tool create_voice (giọng nói độc lập từng agent) =====
  /** "openai-compatible" | "elevenlabs" | "vbee" | "google-ai-studio" - hình dạng request khác hẳn nhau, xem tts-client.ts */
  ttsProvider: string;
  /** Chỉ có nghĩa khi ttsProvider="openai-compatible" - các hãng khác cố định domain riêng */
  ttsBaseUrl: string;
  /** openai-compatible: tên model (tts-1...). elevenlabs: model_id. vbee: không dùng.
   *  google-ai-studio: tên model TTS (BẮT BUỘC, vd gemini-2.5-flash-preview-tts) */
  ttsModel: string;
  /** openai-compatible: tên giọng (alloy...) hoặc rỗng nếu giọng nằm trong model.
   *  elevenlabs: voice_id (BẮT BUỘC). vbee: voiceCode (BẮT BUỘC, vd hn_female_ngochuyen_full_48k-fhg).
   *  google-ai-studio: tên giọng dựng sẵn (vd Kore), rỗng = mặc định "Kore" */
  ttsVoice: string;
  /** openai-compatible: mp3|aac|opus|wav|flac. elevenlabs: mp3_44100_128|... vbee: mp3|wav.
   *  google-ai-studio: không dùng - bot tự nhận diện định dạng Gemini trả về */
  ttsFormat: string;
  /** Key TTS đã giải mã; null = agent này chưa cấu hình TTS.
   *  vbee: đây là access_token (header Authorization: Bearer) */
  ttsApiKey: string | null;
  /** DB có key nhưng giải mã HỎNG - mirror modelApiKeyHong */
  ttsApiKeyHong: boolean;
  /** Chỉ dùng cho vbee - header "App-Id" bắt buộc đi kèm access_token */
  ttsVbeeAppId: string;

  // ===== Tạo NHẠC RIÊNG cho tool create_music - 2 nhà cung cấp, xem music-generation-client.ts =====
  /** "openrouter" (mặc định) | "google-ai-studio" */
  musicProvider: string;
  /** openrouter: tên model, mặc định "google/lyria-3-pro-preview".
   *  google-ai-studio: "lyria-3-clip-preview" (clip 30s) | "lyria-3.5" (bài hát
   *  dài vài phút) - trống = mặc định "lyria-3.5" */
  musicModel: string;
  /** Chỉ dùng cho openrouter - "alloy" nếu để trống, xem music-generation-client.ts */
  musicVoice: string;
  /** wav|mp3|flac|opus|pcm16 - chỉ dùng cho openrouter. google-ai-studio tự
   *  nhận diện định dạng trả về, không dùng field này (cùng lý do ttsFormat
   *  bị ẩn với ttsProvider="google-ai-studio") */
  musicFormat: string;
  /** access_token OpenRouter đã giải mã; null = agent này chưa cấu hình tạo
   *  nhạc qua OpenRouter. KHÔNG dùng cho google-ai-studio - nhánh đó DÙNG
   *  CHUNG `ttsApiKey` ở trên (đọc trực tiếp khi provider="google-ai-studio",
   *  không có cột key riêng). */
  musicApiKey: string | null;
  /** DB có key nhưng giải mã HỎNG - mirror modelApiKeyHong */
  musicApiKeyHong: boolean;

  // ===== Tạo VIDEO RIÊNG cho tool create_video (bytedance/seedance-2.0-mini qua OpenRouter) =====
  /** "openrouter" (Seedance, key riêng bên dưới) | "grok" (Grok Imagine qua 9Router, dùng router + key LLM chung) */
  videoProvider: string;
  /** Tên model OpenRouter, mặc định "bytedance/seedance-2.0-mini" */
  videoModel: string;
  /** access_token OpenRouter đã giải mã; null = agent này chưa cấu hình tạo video */
  videoApiKey: string | null;
  /** DB có key nhưng giải mã HỎNG - mirror modelApiKeyHong */
  videoApiKeyHong: boolean;

  // ===== STT RIÊNG cho việc phiên âm tin nhắn THOẠI đến (độc lập từng agent) =====
  /** Chỉ 1 nhà cung cấp openai-compatible (/v1/audio/transcriptions) - xem stt-client.ts */
  sttBaseUrl: string;
  /** Tên model (vd gemini-3.5-flash qua 9router) */
  sttModel: string;
  /** Key STT đã giải mã; null = agent này chưa cấu hình STT - tin thoại vẫn
   *  được báo cho người dùng biết là "chưa cấu hình" thay vì im lặng bỏ qua */
  sttApiKey: string | null;
  /** DB có key nhưng giải mã HỎNG - mirror modelApiKeyHong */
  sttApiKeyHong: boolean;
  /** Nút gạt RIÊNG - tắt thì KHÔNG xoá base URL/model/key, chỉ tạm ngưng phiên âm */
  sttEnabled: boolean;

  isDefault: boolean;
};

type Row = {
  id: string;
  icon: string;
  name: string;
  persona: string;
  model_provider: string | null;
  model_name: string | null;
  model_base_url: string | null;
  model_api_key: string | null;
  max_steps: number | null;
  reasoning_effort: string | null;
  disabled_tools: string;
  context_window: number | null;
  tts_provider: string;
  tts_base_url: string;
  tts_model: string;
  tts_voice: string;
  tts_format: string;
  tts_api_key: string | null;
  tts_vbee_app_id: string;
  music_provider: string;
  music_model: string;
  music_voice: string;
  music_format: string;
  music_api_key: string | null;
  video_provider: string;
  video_model: string;
  video_api_key: string | null;
  stt_base_url: string;
  stt_model: string;
  stt_api_key: string | null;
  stt_enabled: number;
  is_default: number;
};

/** Mirror `giaiMaAnToan` của runtime-llm-settings.ts - không để lỗi giải mã thoát ra */
function giaiMaBiMat(encrypted: string | null, ten: string): { value: string | null; hong: boolean } {
  if (!encrypted) return { value: null, hong: false };
  try {
    return { value: decryptSecret(encrypted), hong: false };
  } catch (err) {
    log.error(
      { err },
      `Không giải mã được ${ten} của agent - CREDENTIALS_ENCRYPTION_KEY có đúng khóa lúc lưu không?`,
    );
    return { value: null, hong: true };
  }
}

const toProfile = (r: Row): AgentProfile => {
  const key = giaiMaBiMat(r.model_api_key, "model_api_key");
  const tts = giaiMaBiMat(r.tts_api_key, "tts_api_key");
  const music = giaiMaBiMat(r.music_api_key, "music_api_key");
  const video = giaiMaBiMat(r.video_api_key, "video_api_key");
  const stt = giaiMaBiMat(r.stt_api_key, "stt_api_key");
  return {
    id: r.id,
    icon: r.icon,
    name: r.name,
    persona: r.persona,
    modelProvider: (r.model_provider as AgentProfile["modelProvider"]) ?? null,
    modelName: r.model_name,
    modelBaseUrl: r.model_base_url,
    modelApiKey: key.value,
    modelApiKeyHong: key.hong,
    maxSteps: r.max_steps,
    reasoningEffort: (r.reasoning_effort as ReasoningEffort | null) ?? null,
    disabledTools: parseDisabledTools(r.disabled_tools),
    contextWindow: r.context_window,
    ttsProvider: r.tts_provider,
    ttsBaseUrl: r.tts_base_url,
    ttsModel: r.tts_model,
    ttsVoice: r.tts_voice,
    ttsFormat: r.tts_format,
    ttsApiKey: tts.value,
    ttsApiKeyHong: tts.hong,
    ttsVbeeAppId: r.tts_vbee_app_id,
    musicProvider: r.music_provider,
    musicModel: r.music_model,
    musicVoice: r.music_voice,
    musicFormat: r.music_format,
    musicApiKey: music.value,
    musicApiKeyHong: music.hong,
    videoProvider: r.video_provider,
    videoModel: r.video_model,
    videoApiKey: video.value,
    videoApiKeyHong: video.hong,
    sttBaseUrl: r.stt_base_url,
    sttModel: r.stt_model,
    sttApiKey: stt.value,
    sttApiKeyHong: stt.hong,
    sttEnabled: r.stt_enabled === 1,
    isDefault: r.is_default === 1,
  };
};

const SELECT = `SELECT id, icon, name, persona, model_provider, model_name, model_base_url, model_api_key,
                       max_steps, reasoning_effort, disabled_tools, context_window,
                       tts_provider, tts_base_url, tts_model, tts_voice, tts_format, tts_api_key, tts_vbee_app_id,
                       music_provider, music_model, music_voice, music_format, music_api_key,
                       video_provider, video_model, video_api_key,
                       stt_base_url, stt_model, stt_api_key, stt_enabled,
                       is_default
                FROM agents`;

const DEFAULT_AGENT_ID = "tro-ly-mac-dinh";

/** Agent mặc định luôn tồn tại - account mới/agent bị xóa đều rơi về đây */
export function ensureDefaultAgent(): AgentProfile {
  const existing = db.prepare(`${SELECT} WHERE is_default = 1 LIMIT 1`).get() as Row | undefined;
  if (existing) return toProfile(existing);

  db.prepare(
    "INSERT OR IGNORE INTO agents (id, icon, name, persona, is_default) VALUES (?, '🤖', ?, ?, 1)",
  ).run(DEFAULT_AGENT_ID, "Trợ lý mặc định", DEFAULT_PERSONA);
  db.prepare("UPDATE agents SET is_default = 1 WHERE id = ?").run(DEFAULT_AGENT_ID);
  return getAgent(DEFAULT_AGENT_ID)!;
}

export function getAgent(id: string): AgentProfile | null {
  const row = db.prepare(`${SELECT} WHERE id = ?`).get(id) as Row | undefined;
  return row ? toProfile(row) : null;
}

/** Agent của account - account trỏ agent đã bị xóa thì rơi về agent mặc định */
export function getAgentForAccount(agentId: string): AgentProfile {
  return getAgent(agentId) ?? ensureDefaultAgent();
}

export function listAgents(): (AgentProfile & { accountCount: number })[] {
  const rows = db
    .prepare(
      `${SELECT.replace("FROM agents", ", (SELECT COUNT(*) FROM accounts WHERE accounts.agent_id = agents.id) AS account_count FROM agents")}
       ORDER BY is_default DESC, id`,
    )
    .all() as unknown as (Row & { account_count: number })[];
  return rows.map((r) => ({ ...toProfile(r), accountCount: r.account_count }));
}

/**
 * Nhiều key TTS mỗi dòng 1 key (xem `tts-client.ts`'s `tachDanhSachKey` - lặp
 * lại logic ở đây thay vì import chéo config <- voice, đúng nếp KHÔNG import
 * chéo giữa các domain đã dùng cho `groupIdCua` ở nhóm tool quản trị nhóm).
 */
export function tachDsKeyTts(raw: string | null): string[] {
  return (raw ?? "")
    .split(/\r?\n/)
    .map((k) => k.trim())
    .filter(Boolean);
}

/**
 * Tính lại danh sách key TTS sau patch - trả `undefined` nghĩa là KHÔNG đổi gì
 * (giữ nguyên cột DB qua COALESCE ở `db.prepare` bên dưới).
 *
 * **Bẫy đã dính thật (2026-09-16), lộ ra khi người dùng đã lưu sẵn cả chục
 * key TTS rồi muốn thêm 1 key nữa**: bản đầu coi `ttsApiKey` không rỗng là
 * THAY THẾ TOÀN BỘ (`ttsApiKey && ttsApiKey !== "" ? encryptSecret(ttsApiKey)
 * : undefined`) - đúng ngữ nghĩa cũ khi mỗi field chỉ có 1 giá trị, nhưng sai
 * hoàn toàn với field nhiều dòng: gõ thêm 1 key rồi bấm Lưu sẽ XÓA SẠCH toàn
 * bộ key cũ, chỉ còn lại đúng 1 key vừa gõ. Sửa bằng cách MERGE - key mới
 * cộng thêm vào danh sách cũ, bỏ trùng khớp tuyệt đối, giữ thứ tự cũ trước.
 */
function tinhTtsKeyMoi(
  hienTai: string | null,
  patch: { ttsApiKey?: string; ttsApiKeyClearAll?: boolean },
): string | undefined {
  if (patch.ttsApiKeyClearAll) return "";
  if (!patch.ttsApiKey || patch.ttsApiKey === "") return undefined;

  const cu = tachDsKeyTts(hienTai);
  const moi = tachDsKeyTts(patch.ttsApiKey);
  const guDaCo = new Set(cu);
  const themVao = moi.filter((k) => !guDaCo.has(k));
  return [...cu, ...themVao].join("\n");
}

export function createAgent(input: {
  id: string;
  icon?: string;
  name: string;
  persona?: string;
}): AgentProfile {
  db.prepare("INSERT INTO agents (id, icon, name, persona) VALUES (?, ?, ?, ?)").run(
    input.id,
    input.icon ?? "🤖",
    input.name,
    input.persona ?? "",
  );
  return getAgent(input.id)!;
}

export function updateAgent(
  id: string,
  patch: Partial<
    Pick<
      AgentProfile,
      | "icon"
      | "name"
      | "persona"
      | "modelProvider"
      | "modelName"
      | "modelBaseUrl"
      | "maxSteps"
      | "reasoningEffort"
      | "disabledTools"
      | "contextWindow"
      | "ttsProvider"
      | "ttsBaseUrl"
      | "ttsModel"
      | "ttsVoice"
      | "ttsFormat"
      | "ttsVbeeAppId"
      | "musicProvider"
      | "musicModel"
      | "musicVoice"
      | "musicFormat"
      | "videoProvider"
      | "videoModel"
      | "sttBaseUrl"
      | "sttModel"
      | "sttEnabled"
    >
  > & {
    /** Plaintext để mã hóa; "" hoặc undefined = GIỮ NGUYÊN key hiện tại - đúng
     * ngữ nghĩa `LlmSettingsUpdate.apiKey` của runtime-llm-settings.ts */
    modelApiKey?: string;
    /** Plaintext key TTS MỚI cần THÊM VÀO danh sách đang lưu (mỗi dòng 1 key) -
     * "" hoặc undefined = không thêm gì. KHÔNG PHẢI toàn bộ danh sách - xem
     * `tinhTtsKeyMoi()` lý do vì sao không còn là "thay thế". */
    ttsApiKey?: string;
    /** true = xóa SẠCH toàn bộ danh sách key TTS, bỏ qua `ttsApiKey` nếu có kèm theo */
    ttsApiKeyClearAll?: boolean;
    /** Plaintext key OpenRouter (tạo nhạc); "" hoặc undefined = GIỮ NGUYÊN key hiện tại */
    musicApiKey?: string;
    /** Plaintext key OpenRouter (tạo video); "" hoặc undefined = GIỮ NGUYÊN key hiện tại */
    videoApiKey?: string;
    /** Plaintext key STT; "" hoặc undefined = GIỮ NGUYÊN key hiện tại */
    sttApiKey?: string;
  },
): AgentProfile | null {
  const current = getAgent(id);
  if (!current) return null;
  // Bỏ key có giá trị `undefined` TRƯỚC khi trộn: `Partial<>` cho phép truyền
  // `undefined` tường minh mà vẫn qua được typecheck, và lúc đó `next.x` thành
  // undefined -> node:sqlite ném "Provided value cannot be bound to SQLite
  // parameter". Zod ở biên API đã loại key vắng mặt nên đường route không dính,
  // nhưng call site nội bộ thì không có ai đỡ. Các secret (`modelApiKey`,
  // `ttsApiKey`, `musicApiKey`, `videoApiKey`, `sttApiKey`) cũng lọc ở đây -
  // phân biệt với các field khác vì "" mang nghĩa GIỮ NGUYÊN, không phải "đặt
  // thành rỗng".
  const { modelApiKey, ttsApiKey, ttsApiKeyClearAll, musicApiKey, videoApiKey, sttApiKey, ...rest } =
    patch;
  const patchSach = Object.fromEntries(
    Object.entries(rest).filter(([, v]) => v !== undefined),
  ) as typeof rest;
  const next = { ...current, ...patchSach };
  const apiKeyMoi = modelApiKey && modelApiKey !== "" ? encryptSecret(modelApiKey) : undefined;
  const ttsDanhSachMoi = tinhTtsKeyMoi(current.ttsApiKey, { ttsApiKey, ttsApiKeyClearAll });
  const ttsKeyMoi = ttsDanhSachMoi !== undefined ? encryptSecret(ttsDanhSachMoi) : undefined;
  const musicKeyMoi = musicApiKey && musicApiKey !== "" ? encryptSecret(musicApiKey) : undefined;
  const videoKeyMoi = videoApiKey && videoApiKey !== "" ? encryptSecret(videoApiKey) : undefined;
  const sttKeyMoi = sttApiKey && sttApiKey !== "" ? encryptSecret(sttApiKey) : undefined;
  db.prepare(
    `UPDATE agents SET icon = ?, name = ?, persona = ?, model_provider = ?, model_name = ?,
                       model_base_url = ?, model_api_key = COALESCE(?, model_api_key), max_steps = ?,
                       reasoning_effort = ?, disabled_tools = ?, context_window = ?,
                       tts_provider = ?, tts_base_url = ?, tts_model = ?, tts_voice = ?, tts_format = ?,
                       tts_api_key = COALESCE(?, tts_api_key), tts_vbee_app_id = ?,
                       music_provider = ?, music_model = ?, music_voice = ?, music_format = ?,
                       music_api_key = COALESCE(?, music_api_key),
                       video_provider = ?, video_model = ?, video_api_key = COALESCE(?, video_api_key),
                       stt_base_url = ?, stt_model = ?, stt_api_key = COALESCE(?, stt_api_key), stt_enabled = ?
     WHERE id = ?`,
  ).run(
    next.icon,
    next.name,
    next.persona,
    next.modelProvider,
    next.modelName,
    next.modelBaseUrl,
    apiKeyMoi ?? null,
    next.maxSteps,
    next.reasoningEffort,
    JSON.stringify(next.disabledTools),
    next.contextWindow,
    next.ttsProvider,
    next.ttsBaseUrl,
    next.ttsModel,
    next.ttsVoice,
    next.ttsFormat,
    ttsKeyMoi ?? null,
    next.ttsVbeeAppId,
    next.musicProvider,
    next.musicModel,
    next.musicVoice,
    next.musicFormat,
    musicKeyMoi ?? null,
    next.videoProvider,
    next.videoModel,
    videoKeyMoi ?? null,
    next.sttBaseUrl,
    next.sttModel,
    sttKeyMoi ?? null,
    next.sttEnabled ? 1 : 0,
    id,
  );
  return getAgent(id);
}

/** Không xóa được agent mặc định hoặc agent đang có account dùng */
export function deleteAgent(id: string): { ok: boolean; reason?: string } {
  const agent = getAgent(id);
  if (!agent) return { ok: false, reason: "Agent không tồn tại" };
  if (agent.isDefault) return { ok: false, reason: "Không xóa được agent mặc định" };

  const used = db.prepare("SELECT COUNT(*) AS n FROM accounts WHERE agent_id = ?").get(id) as {
    n: number;
  };
  if (used.n > 0) return { ok: false, reason: `Đang có ${used.n} account dùng agent này` };

  db.prepare("DELETE FROM agents WHERE id = ?").run(id);
  // Agent id là SLUG TẤT ĐỊNH sinh từ tên (slugify-vietnamese.ts): xóa agent
  // "Bán hàng" (id ban-hang) rồi tạo lại agent CÙNG TÊN ra ĐÚNG id cũ. Thiếu
  // bước dọn này thì agent "mới" đọc lại được tài liệu Kho tri thức chưa ai
  // từng gán cho NÓ - lật ngược bất biến "mặc định ĐÓNG" của kb-agent-binding.ts.
  xoaGanNguonCuaAgent(id);
  // Cùng lý do dòng trên: agent id là slug tất định, tạo lại agent CÙNG TÊN
  // sẽ ra ĐÚNG id cũ và đọc lại được server MCP chưa ai từng gán cho NÓ nếu
  // thiếu bước dọn này.
  xoaGanServerCuaAgent(id);
  return { ok: true };
}
