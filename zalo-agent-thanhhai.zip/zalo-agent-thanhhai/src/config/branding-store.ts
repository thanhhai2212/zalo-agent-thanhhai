import fs from "node:fs";
import path from "node:path";
import { db } from "../conversation/database.js";
import { dataDir } from "./env.js";

/**
 * Thương hiệu của không gian làm việc (2026-10-05): khách business tự đổi tên,
 * màu chủ đạo và logo của dashboard + trang đăng nhập.
 *
 * Lưu một dòng JSON trong `runtime_settings`; logo là file trong
 * `data/branding/`, tên kèm phiên bản để trình duyệt không giữ ảnh cũ trong cache.
 *
 * Logo chỉ nhận PNG, JPEG, WebP (kiểm chữ ký file, không tin đuôi tên). KHÔNG
 * nhận SVG: SVG chứa được script, mà file này phục vụ cùng tên miền với dashboard
 * và không cần đăng nhập để xem (trang đăng nhập phải hiện được logo).
 */

export type NenThuongHieu = "mac_dinh" | "nga_am";
/** Nền biểu tượng ứng dụng điện thoại dựng từ logo: trắng, đen than hoặc màu chủ đạo */
export type NenBieuTuong = "sang" | "toi" | "mau";

export type ThuongHieu = {
  ten: string;
  mau: string;
  hienVanHanh: boolean;
  /** Nền giao diện sáng + nền ảnh infographic: trắng xám (mặc định) hoặc ngà ấm */
  nen: NenThuongHieu;
  /** Chữ ở chân ảnh infographic (vd "fb/tenban"); rỗng = dùng tên thương hiệu */
  chuKyAnh: string;
  /** Tên dưới biểu tượng ứng dụng điện thoại (white-label), tối đa 12 ký tự vì iPhone cắt dài hơn */
  tenApp: string;
  nenBieuTuong: NenBieuTuong;
  logo: { file: string; ver: number; loai: string } | null;
};

export const THUONG_HIEU_MAC_DINH: ThuongHieu = { ten: "zalo Bot", mau: "#0068FF", hienVanHanh: true, nen: "mac_dinh", chuKyAnh: "", tenApp: "zalo Bot", nenBieuTuong: "sang", logo: null };
export const LOGO_TOI_DA_BYTE = 1024 * 1024;

const KHOA = "branding";
const getStmt = db.prepare("SELECT value FROM runtime_settings WHERE key = ?");
const setStmt = db.prepare(`
  INSERT INTO runtime_settings (key, value, updated_at)
  VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);

const thuMuc = () => path.join(dataDir, "branding");

export function docThuongHieu(): ThuongHieu {
  const raw = (getStmt.get(KHOA) as { value: string } | undefined)?.value;
  if (!raw) return { ...THUONG_HIEU_MAC_DINH };
  try {
    const v = JSON.parse(raw) as Partial<ThuongHieu>;
    return {
      ten: typeof v.ten === "string" && v.ten.trim() ? v.ten : THUONG_HIEU_MAC_DINH.ten,
      mau: typeof v.mau === "string" && laMauHopLe(v.mau) ? v.mau : THUONG_HIEU_MAC_DINH.mau,
      hienVanHanh: typeof v.hienVanHanh === "boolean" ? v.hienVanHanh : true,
      nen: v.nen === "nga_am" ? "nga_am" : "mac_dinh",
      chuKyAnh: typeof v.chuKyAnh === "string" ? v.chuKyAnh.slice(0, 40) : "",
      tenApp: typeof v.tenApp === "string" && v.tenApp.trim() ? v.tenApp.trim().slice(0, 12) : THUONG_HIEU_MAC_DINH.tenApp,
      nenBieuTuong: v.nenBieuTuong === "toi" || v.nenBieuTuong === "mau" ? v.nenBieuTuong : "sang",
      logo: v.logo && typeof v.logo.file === "string" && /^logo-\d+\.(png|jpg|webp)$/.test(v.logo.file) ? v.logo : null,
    };
  } catch {
    return { ...THUONG_HIEU_MAC_DINH };
  }
}

function ghi(t: ThuongHieu): ThuongHieu {
  setStmt.run(KHOA, JSON.stringify(t));
  return t;
}

export const laMauHopLe = (m: string) => /^#[0-9a-fA-F]{6}$/.test(m);

export function luuThuongHieu(p: { ten?: string; mau?: string; hienVanHanh?: boolean; nen?: NenThuongHieu; chuKyAnh?: string; tenApp?: string; nenBieuTuong?: NenBieuTuong }): ThuongHieu {
  const cu = docThuongHieu();
  return ghi({
    ...cu,
    ten: p.ten !== undefined ? p.ten.trim().slice(0, 40) || THUONG_HIEU_MAC_DINH.ten : cu.ten,
    mau: p.mau !== undefined && laMauHopLe(p.mau) ? p.mau.toUpperCase() : cu.mau,
    hienVanHanh: p.hienVanHanh ?? cu.hienVanHanh,
    nen: p.nen ?? cu.nen,
    chuKyAnh: p.chuKyAnh !== undefined ? p.chuKyAnh.replace(/\s+/g, " ").trim().slice(0, 40) : cu.chuKyAnh,
    tenApp: p.tenApp !== undefined ? p.tenApp.replace(/\s+/g, " ").trim().slice(0, 12) || THUONG_HIEU_MAC_DINH.tenApp : cu.tenApp,
    nenBieuTuong: p.nenBieuTuong ?? cu.nenBieuTuong,
  });
}

/** Nhận diện loại ảnh theo chữ ký đầu file; null nếu không phải PNG/JPEG/WebP. */
export function loaiAnhLogo(buf: Buffer): { ext: "png" | "jpg" | "webp"; mime: string } | null {
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { ext: "png", mime: "image/png" };
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { ext: "jpg", mime: "image/jpeg" };
  if (buf.length >= 12 && buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WEBP") return { ext: "webp", mime: "image/webp" };
  return null;
}

export function luuLogo(buf: Buffer, now = Date.now()): ThuongHieu {
  const loai = loaiAnhLogo(buf);
  if (!loai) throw new Error("Logo phải là ảnh PNG, JPEG hoặc WebP");
  if (buf.length > LOGO_TOI_DA_BYTE) throw new Error("Logo tối đa 1 MB");
  fs.mkdirSync(thuMuc(), { recursive: true });
  const file = `logo-${now}.${loai.ext}`;
  fs.writeFileSync(path.join(thuMuc(), file), buf);
  const cu = docThuongHieu();
  if (cu.logo) fs.rmSync(path.join(thuMuc(), cu.logo.file), { force: true });
  return ghi({ ...cu, logo: { file, ver: now, loai: loai.mime } });
}

export function xoaLogo(): ThuongHieu {
  const cu = docThuongHieu();
  if (cu.logo) fs.rmSync(path.join(thuMuc(), cu.logo.file), { force: true });
  return ghi({ ...cu, logo: null });
}

export function docFileLogo(): { data: Buffer; loai: string } | null {
  const t = docThuongHieu();
  if (!t.logo) return null;
  const p = path.join(thuMuc(), t.logo.file);
  return fs.existsSync(p) ? { data: fs.readFileSync(p), loai: t.logo.loai } : null;
}

/** Dạng gửi cho trình duyệt - không lộ tên file trên đĩa. */
export function thuongHieuCongKhai(t = docThuongHieu()) {
  return {
    ten: t.ten,
    mau: t.mau,
    hienVanHanh: t.hienVanHanh,
    nen: t.nen,
    chuKyAnh: t.chuKyAnh,
    tenApp: t.tenApp,
    nenBieuTuong: t.nenBieuTuong,
    logoUrl: t.logo ? `/api/branding/logo?v=${t.logo.ver}` : null,
  };
}
