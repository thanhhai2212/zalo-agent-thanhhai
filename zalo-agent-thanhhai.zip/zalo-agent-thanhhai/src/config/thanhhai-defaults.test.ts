import assert from "node:assert/strict";
import fs from "node:fs";
import { after, before, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let agents: typeof import("./agent-store.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv();
  agents = await import("./agent-store.js");
  database = await import("../conversation/database.js");
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

it("fresh installs use the Thanh Hai persona; customized personas survive startup", () => {
  const expected = fs.readFileSync("docs/danh-tinh-thanhhai.md", "utf8").replace(/\r\n/g, "\n").trim();
  const initial = agents.ensureDefaultAgent();
  assert.equal(initial.persona, expected);
  agents.updateAgent(initial.id, { persona: "Danh tính do người dùng tự đổi" });
  assert.equal(agents.ensureDefaultAgent().persona, "Danh tính do người dùng tự đổi");
  agents.updateAgent(initial.id, { persona: "" });
  assert.equal(agents.ensureDefaultAgent().persona, "");
});
