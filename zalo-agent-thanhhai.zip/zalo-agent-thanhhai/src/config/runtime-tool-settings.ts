import { db } from "../conversation/database.js";
import { env } from "./env.js";
import { decryptSecret, encryptSecret, maskSecret } from "./secret-cipher.js";

/**
 * Cấu hình các tool web sửa được từ dashboard (nút Settings trên dòng tool ở
 * trang Tools), lưu trong bảng runtime_settings dùng chung. Key Brave mã hóa
 * AES-256-GCM như key LLM.
 *
 * Cả hai tool đều là CHUỖI có thứ tự (mô hình Extractor Chain của GoClaw):
 * thử từ trên xuống tới khi có kết quả dùng được. Bậc CUỐI của mỗi chuỗi
 * không tắt được - nhờ vậy tool không bao giờ rơi vào trạng thái "chưa cấu
 * hình": web_search luôn còn DuckDuckGo, web_fetch luôn còn tầng tự tải.
 */

export type SearchProvider = "duckduckgo" | "brave";

export type SearchSettings = {
  provider: SearchProvider;
  /** Rỗng nghĩa là chưa có key ở cả DB lẫn env */
  braveApiKey: string;
  /**
   * Tavily/Exa KHÔNG theo mô hình `provider` chọn-một-trong-nhiều như Brave -
   * có key là `searchWeb()` tự dùng luôn, đứng ƯU TIÊN trước cả Brave. Rỗng
   * nghĩa là chưa có key ở cả DB lẫn env, cùng quy ước với `braveApiKey`.
   *
   * **NHẬN NHIỀU KEY, mỗi dòng một key (2026-09-17)** - cùng cơ chế xoay vòng
   * đã dùng cho `ttsApiKey` của agent (`tinhTtsKeyMoi` ở `agent-store.ts`):
   * hết hạn mức/bị từ chối ở key nào thì `searchWeb()` tự chuyển sang key kế
   * tiếp CỦA ĐÚNG PROVIDER ĐÓ trước khi rơi xuống provider sau trong chuỗi.
   */
  tavilyApiKey: string;
  exaApiKey: string;
  linkupApiKey: string;
};

const PROVIDER_KEY = "search_provider";
const BRAVE_KEY = "search_brave_api_key";
const TAVILY_KEY = "search_tavily_api_key";
const EXA_KEY = "search_exa_api_key";
const LINKUP_KEY = "search_linkup_api_key";

const getStmt = db.prepare("SELECT value FROM runtime_settings WHERE key = ?");
const setStmt = db.prepare(`
  INSERT INTO runtime_settings (key, value, updated_at)
  VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
`);
const delStmt = db.prepare("DELETE FROM runtime_settings WHERE key = ?");

function read(key: string): string | undefined {
  return (getStmt.get(key) as { value: string } | undefined)?.value;
}

/** Đọc 1 key mã hóa trong DB, đè lên env - dùng chung cho Brave/Tavily/Exa */
function readApiKey(dbKey: string, envFallback: string): string {
  const stored = read(dbKey);
  if (stored) {
    try {
      return decryptSecret(stored);
    } catch {
      // Key hỏng (đổi CREDENTIALS_ENCRYPTION_KEY) - rơi về env thay vì chết tool
      return envFallback;
    }
  }
  return envFallback;
}

/** Key Brave hiệu lực: DB (nhập từ dashboard) đè lên env */
export function getBraveApiKey(): string {
  return readApiKey(BRAVE_KEY, env.BRAVE_SEARCH_API_KEY);
}

/** Key Tavily hiệu lực - cùng quy ước với `getBraveApiKey` */
export function getTavilyApiKey(): string {
  return readApiKey(TAVILY_KEY, env.TAVILY_API_KEY);
}

/** Key Exa hiệu lực - cùng quy ước với `getBraveApiKey` */
export function getExaApiKey(): string {
  return readApiKey(EXA_KEY, env.EXA_API_KEY);
}

/** Key Linkup hiệu lực - cùng quy ước với `getBraveApiKey` */
export function getLinkupApiKey(): string {
  return readApiKey(LINKUP_KEY, env.LINKUP_API_KEY);
}

/**
 * Nhiều key mỗi dòng 1 key - mirror `tachDsKeyTts` của `agent-store.ts`, lặp
 * lại logic THAY VÌ import chéo (đúng nếp không import chéo giữa các domain
 * đã dùng cho `tachDsKeyTts`/`groupIdCua`/`tachDanhSachKey` của tts-client.ts).
 */
export function tachDsKeyTimKiem(raw: string | null): string[] {
  return (raw ?? "")
    .split(/\r?\n/)
    .map((k) => k.trim())
    .filter(Boolean);
}

/**
 * Tính lại danh sách key sau patch - trả `undefined` nghĩa là KHÔNG đổi gì
 * (giữ nguyên cột DB). Mirror `tinhTtsKeyMoi` của `agent-store.ts`: giá trị
 * gửi lên là key MỚI cần THÊM VÀO, không phải toàn bộ danh sách - bài học đã
 * trả giá thật với `ttsApiKey` (xem CLAUDE.md) áp dụng nguyên vẹn ở đây: field
 * "để trống = giữ nguyên" ngầm giả định một key duy nhất, giả định đó sai
 * ngay khi field chứa NHIỀU key độc lập.
 */
function tinhDsKeyMoi(hienTai: string, keyMoi: string | undefined, clearAll: boolean | undefined): string | undefined {
  if (clearAll) return "";
  if (!keyMoi || keyMoi === "") return undefined;

  const cu = tachDsKeyTimKiem(hienTai);
  const moi = tachDsKeyTimKiem(keyMoi);
  const guDaCo = new Set(cu);
  const themVao = moi.filter((k) => !guDaCo.has(k));
  return [...cu, ...themVao].join("\n");
}

/**
 * Cấu hình đang hiệu lực. Chọn brave nhưng key biến mất (bị xóa tay trong DB,
 * đổi khóa mã hóa) thì tự hạ về duckduckgo - thà tìm được bằng DDG còn hơn
 * gọi Brave với key rỗng rồi lỗi.
 */
export function getSearchSettings(): SearchSettings {
  const braveApiKey = getBraveApiKey();
  const stored = read(PROVIDER_KEY);
  const provider: SearchProvider = stored === "brave" && braveApiKey ? "brave" : "duckduckgo";
  return {
    provider,
    braveApiKey,
    tavilyApiKey: getTavilyApiKey(),
    exaApiKey: getExaApiKey(),
    linkupApiKey: getLinkupApiKey(),
  };
}

export type SearchSettingsUpdate = {
  provider?: SearchProvider;
  /** Bỏ trống = giữ key hiện tại; chuỗi rỗng tường minh = xóa key. Brave vẫn
   * MỘT key duy nhất (gắn với công tắc chọn provider) - không đổi ngữ nghĩa. */
  braveApiKey?: string;
  /**
   * KHÔNG PHẢI toàn bộ danh sách - key MỚI cần THÊM VÀO danh sách đang lưu
   * (mỗi dòng 1 key). "" hoặc undefined = không thêm gì. Xem `tinhDsKeyMoi()`.
   */
  tavilyApiKey?: string;
  /** true = xóa SẠCH toàn bộ danh sách key Tavily, bỏ qua `tavilyApiKey` nếu có kèm theo */
  tavilyApiKeyClearAll?: boolean;
  exaApiKey?: string;
  exaApiKeyClearAll?: boolean;
  linkupApiKey?: string;
  linkupApiKeyClearAll?: boolean;
};

function ghiHoacXoaKey(dbKey: string, value: string): void {
  if (value === "") delStmt.run(dbKey);
  else setStmt.run(dbKey, encryptSecret(value));
}

/**
 * Ném lỗi khi chọn brave mà không có key - chặn ở tầng store để API và mọi
 * caller khác đều dính cùng một luật. Tavily/Exa/Linkup không có "provider"
 * để chọn nên không cần luật này - xóa hết key là tự ngưng dùng ở lần tìm sau.
 */
export function updateSearchSettings(update: SearchSettingsUpdate): SearchSettings {
  if (update.braveApiKey !== undefined) ghiHoacXoaKey(BRAVE_KEY, update.braveApiKey);

  const tavilyMoi = tinhDsKeyMoi(getTavilyApiKey(), update.tavilyApiKey, update.tavilyApiKeyClearAll);
  if (tavilyMoi !== undefined) ghiHoacXoaKey(TAVILY_KEY, tavilyMoi);

  const exaMoi = tinhDsKeyMoi(getExaApiKey(), update.exaApiKey, update.exaApiKeyClearAll);
  if (exaMoi !== undefined) ghiHoacXoaKey(EXA_KEY, exaMoi);

  const linkupMoi = tinhDsKeyMoi(getLinkupApiKey(), update.linkupApiKey, update.linkupApiKeyClearAll);
  if (linkupMoi !== undefined) ghiHoacXoaKey(LINKUP_KEY, linkupMoi);

  if (update.provider !== undefined) {
    if (update.provider === "brave" && !getBraveApiKey()) {
      throw new Error("Cần nhập API key Brave trước khi bật provider này");
    }
    setStmt.run(PROVIDER_KEY, update.provider);
  }

  return getSearchSettings();
}

/** Dạng an toàn để trả về dashboard - không bao giờ lộ key đầy đủ */
export function getSearchSettingsForApi() {
  const settings = getSearchSettings();
  return {
    provider: settings.provider,
    braveApiKeyMasked: maskSecret(settings.braveApiKey),
    hasBraveApiKey: Boolean(settings.braveApiKey),
    tavilyApiKeyMasked: maskSecret(settings.tavilyApiKey),
    hasTavilyApiKey: Boolean(settings.tavilyApiKey),
    /** Che TỪNG key riêng - hiện danh sách đã lưu, không phải bản che của cả chuỗi nhiều dòng dồn lại */
    tavilyApiKeyMaskedList: tachDsKeyTimKiem(settings.tavilyApiKey).map(maskSecret),
    exaApiKeyMasked: maskSecret(settings.exaApiKey),
    hasExaApiKey: Boolean(settings.exaApiKey),
    exaApiKeyMaskedList: tachDsKeyTimKiem(settings.exaApiKey).map(maskSecret),
    linkupApiKeyMasked: maskSecret(settings.linkupApiKey),
    hasLinkupApiKey: Boolean(settings.linkupApiKey),
    linkupApiKeyMaskedList: tachDsKeyTimKiem(settings.linkupApiKey).map(maskSecret),
  };
}

// ===== web_fetch: chuỗi 2 tầng, tầng tự tải không tắt được =====

const FETCH_FALLBACK_KEY = "fetch_fallback_enabled";

export type FetchSettings = {
  /** Bậc 2 (Jina Reader) - bậc 1 tự tải luôn bật, không có công tắc */
  fallbackEnabled: boolean;
};

export function getFetchSettings(): FetchSettings {
  const stored = read(FETCH_FALLBACK_KEY);
  // Chưa đặt trong DB thì theo env; đặt rồi thì DB thắng
  if (stored === undefined) return { fallbackEnabled: env.WEB_FETCH_FALLBACK_ENABLED };
  return { fallbackEnabled: stored === "true" };
}

export function updateFetchSettings(update: Partial<FetchSettings>): FetchSettings {
  if (update.fallbackEnabled !== undefined) {
    setStmt.run(FETCH_FALLBACK_KEY, String(update.fallbackEnabled));
  }
  return getFetchSettings();
}
