import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let store: typeof import("./runtime-tool-settings.js");

before(async () => {
  dataDir = setupTestEnv();
  store = await import("./runtime-tool-settings.js");
});

after(async () => {
  const { closeDatabase } = await import("../conversation/database.js");
  closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("runtime-tool-settings", () => {
  it("mặc định là duckduckgo, chưa có key - web search không bao giờ 'chưa cấu hình'", () => {
    const settings = store.getSearchSettings();
    assert.equal(settings.provider, "duckduckgo");
    assert.equal(settings.braveApiKey, "");
    assert.equal(settings.tavilyApiKey, "");
    assert.equal(settings.exaApiKey, "");
    assert.equal(settings.linkupApiKey, "");
  });

  it("chọn brave khi chưa có key thì bị chặn ngay ở store", () => {
    assert.throws(() => store.updateSearchSettings({ provider: "brave" }), /API key Brave/);
    assert.equal(store.getSearchSettings().provider, "duckduckgo");
  });

  it("có key thì bật được brave, key lưu mã hóa nhưng đọc lại đúng", () => {
    const next = store.updateSearchSettings({
      provider: "brave",
      braveApiKey: "BSA-secret-key-123",
    });
    assert.equal(next.provider, "brave");
    assert.equal(next.braveApiKey, "BSA-secret-key-123");
  });

  it("dạng trả về API luôn masked, không bao giờ lộ key đầy đủ", () => {
    const api = store.getSearchSettingsForApi();
    assert.equal(api.hasBraveApiKey, true);
    assert.ok(!api.braveApiKeyMasked.includes("secret"), "không được lộ ruột key");
    assert.match(api.braveApiKeyMasked, /\.\.\./);
  });

  it("đổi mỗi provider (không truyền key) thì giữ nguyên key cũ", () => {
    store.updateSearchSettings({ provider: "duckduckgo" });
    assert.equal(store.getSearchSettings().braveApiKey, "BSA-secret-key-123");
    assert.equal(store.updateSearchSettings({ provider: "brave" }).provider, "brave");
  });

  it("xóa key thì tự hạ về duckduckgo, không kẹt ở brave với key rỗng", () => {
    const next = store.updateSearchSettings({ braveApiKey: "" });
    assert.equal(next.braveApiKey, "");
    assert.equal(next.provider, "duckduckgo");
  });

  describe("Tavily/Exa/Linkup - không có 'provider' để chọn, có key là dùng luôn", () => {
    it("nhập key Tavily/Exa/Linkup không cần chọn provider gì, đọc lại đúng nguyên văn", () => {
      const next = store.updateSearchSettings({
        tavilyApiKey: "tvly-secret",
        exaApiKey: "exa-secret",
        linkupApiKey: "linkup-secret",
      });
      assert.equal(next.tavilyApiKey, "tvly-secret");
      assert.equal(next.exaApiKey, "exa-secret");
      assert.equal(next.linkupApiKey, "linkup-secret");
      // không đụng gì tới cấu hình Brave đang có ở các test trước
      assert.equal(next.provider, "duckduckgo");
    });

    it("dạng trả về API luôn masked cho cả Tavily, Exa lẫn Linkup", () => {
      const api = store.getSearchSettingsForApi();
      assert.equal(api.hasTavilyApiKey, true);
      assert.equal(api.hasExaApiKey, true);
      assert.equal(api.hasLinkupApiKey, true);
      assert.ok(!api.tavilyApiKeyMasked.includes("secret"));
      assert.ok(!api.exaApiKeyMasked.includes("secret"));
      assert.ok(!api.linkupApiKeyMasked.includes("secret"));
    });

    it("xóa SẠCH key Tavily (tavilyApiKeyClearAll) không đụng tới key Exa/Linkup, và ngược lại", () => {
      const next = store.updateSearchSettings({ tavilyApiKeyClearAll: true });
      assert.equal(next.tavilyApiKey, "");
      assert.equal(next.exaApiKey, "exa-secret", "key Exa phải còn nguyên");
      assert.equal(next.linkupApiKey, "linkup-secret", "key Linkup phải còn nguyên");
    });
  });

  describe("Tavily/Exa/Linkup - NHIỀU key mỗi dòng 1 key, xoay vòng khi 1 key hỏng (2026-09-17)", () => {
    it("gửi key mới KHÔNG thay thế danh sách cũ - CỘNG THÊM vào (bẫy đã dính thật với ttsApiKey)", () => {
      store.updateSearchSettings({ tavilyApiKeyClearAll: true }); // dọn sạch trạng thái test trước
      store.updateSearchSettings({ tavilyApiKey: "tvly-key-1" });
      const next = store.updateSearchSettings({ tavilyApiKey: "tvly-key-2" });
      assert.equal(next.tavilyApiKey, "tvly-key-1\ntvly-key-2");
    });

    it("gửi NHIỀU dòng trong 1 lần PATCH - cộng dồn hết, không mất key cũ", () => {
      const next = store.updateSearchSettings({ tavilyApiKey: "tvly-key-3\ntvly-key-4" });
      assert.equal(next.tavilyApiKey, "tvly-key-1\ntvly-key-2\ntvly-key-3\ntvly-key-4");
    });

    it("gửi lại key đã có -> tự bỏ trùng, không lưu lặp", () => {
      const next = store.updateSearchSettings({ tavilyApiKey: "tvly-key-2" });
      assert.equal(next.tavilyApiKey, "tvly-key-1\ntvly-key-2\ntvly-key-3\ntvly-key-4");
    });

    it("tavilyApiKeyMaskedList che TỪNG key riêng, đúng số lượng đang lưu", () => {
      const api = store.getSearchSettingsForApi();
      assert.equal(api.tavilyApiKeyMaskedList.length, 4);
      assert.ok(api.tavilyApiKeyMaskedList.every((k) => !k.includes("key-")));
    });

    it("tavilyApiKeyClearAll xóa sạch rồi thêm mới lại thì bắt đầu lại từ 1 key, không hồi sinh key cũ", () => {
      store.updateSearchSettings({ tavilyApiKeyClearAll: true });
      const sauKhiXoa = store.getSearchSettingsForApi();
      assert.equal(sauKhiXoa.hasTavilyApiKey, false);
      assert.deepEqual(sauKhiXoa.tavilyApiKeyMaskedList, []);

      const next = store.updateSearchSettings({ tavilyApiKey: "tvly-key-moi" });
      assert.equal(next.tavilyApiKey, "tvly-key-moi");
    });

    it("Exa/Linkup cũng merge độc lập với Tavily, không lẫn danh sách của nhau", () => {
      store.updateSearchSettings({ exaApiKeyClearAll: true, linkupApiKeyClearAll: true });
      store.updateSearchSettings({ exaApiKey: "exa-1\nexa-2" });
      store.updateSearchSettings({ linkupApiKey: "linkup-1" });
      const next = store.getSearchSettings();
      assert.equal(next.exaApiKey, "exa-1\nexa-2");
      assert.equal(next.linkupApiKey, "linkup-1");
    });
  });
});
