import { getTuning } from "../config/runtime-tuning-settings.js";
import { createLogger } from "../shared/logger.js";
import { danhSachBai, suaBai } from "./gp-draft-store.js";
import { xepGioMoi } from "./gp-planner.js";
import { dangBaiNhap, kiemTranDang } from "./gp-publisher.js";
import { docCaiDatNhom } from "./gp-settings-store.js";

/**
 * Bộ tự đăng: mỗi 2 phút đăng bài ĐÃ DUYỆT tới giờ. Mỗi nick đăng tối đa một
 * bài mỗi vòng; trần ngày + khoảng cách kiểm lại NGAY LÚC ĐĂNG (`kiemTranDang`),
 * chưa đủ điều kiện thì để vòng sau. Bài trễ quá 3 giờ (bot tắt/khởi động lại
 * lâu) thì DỜI sang giờ trống kế tiếp chứ không đăng dồn một lượt - đăng dồn
 * nhiều nhóm cùng lúc đúng là dấu hiệu spam cần tránh.
 */

const log = createLogger("gp-poster");
const NHIP_MS = 2 * 60_000;
const TRE_TOI_DA_MS = 3 * 3_600_000;

let dangChay = false;

export async function chayVongDang(now = Date.now()): Promise<number> {
  if (!getTuning("GROUP_POST_ENABLED") || dangChay) return 0;
  dangChay = true;
  let so = 0;
  try {
    const den = danhSachBai({ status: ["da_duyet"], limit: 500 }).filter((b) => b.scheduledAt && Date.parse(b.scheduledAt) <= now);
    const daDangVongNay = new Set<string>();
    for (const b of den) {
      const cd = docCaiDatNhom(b.accountId, b.threadId);
      if (!cd.enabled) continue;
      if (now - Date.parse(b.scheduledAt!) > TRE_TOI_DA_MS) {
        suaBai(b.id, { scheduledAt: xepGioMoi(cd, b.topicKey, new Date(now), b.scheduledAt!) });
        log.info({ id: b.id, threadId: b.threadId }, "Bài trễ quá 3 giờ - dời giờ thay vì đăng dồn");
        continue;
      }
      if (daDangVongNay.has(b.accountId) || kiemTranDang(b.accountId, now)) continue;
      try {
        await dangBaiNhap(b, now);
        daDangVongNay.add(b.accountId);
        so++;
      } catch (err) {
        log.warn({ err, id: b.id }, "Không đăng được bài đã duyệt");
      }
    }
    return so;
  } finally {
    dangChay = false;
  }
}

export function batDauTuDangBai(): () => void {
  const t = setInterval(() => void chayVongDang().catch((err) => log.warn({ err }, "Vòng tự đăng lỗi")), NHIP_MS);
  t.unref();
  return () => clearInterval(t);
}
