import { randomBytes } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { dataDir } from "../config/env.js";
import { db } from "../conversation/database.js";
import { infographicSchema, type DuLieuInfographic } from "../infographic/infographic-schema.js";

/**
 * Bài nháp theo TỪNG nhóm (bảng `post_drafts`). Vòng đời:
 * cho_duyet -> (chủ bot duyệt hoặc nhóm bật tự đăng) da_duyet -> da_dang | loi;
 * bo_qua khi chủ bot bỏ. Ảnh infographic lưu `data/group-posts/<id>.png`.
 */

export type TrangThaiBai = "cho_duyet" | "da_duyet" | "da_dang" | "bo_qua" | "loi";

export type BaiNhap = {
  id: string;
  accountId: string;
  threadId: string;
  topicKey: string;
  topicTitle: string;
  source: string;
  sourceNote: string;
  body: string;
  discuss: string;
  infographic: DuLieuInfographic | null;
  hasImage: boolean;
  similarity: number;
  status: TrangThaiBai;
  scheduledAt: string | null;
  postedAt: string | null;
  error: string;
  createdAt: string;
};

type Row = {
  id: string;
  account_id: string;
  thread_id: string;
  topic_key: string;
  topic_title: string;
  source: string;
  source_note: string;
  body: string;
  discuss: string;
  infographic: string;
  has_image: number;
  similarity: number;
  status: TrangThaiBai;
  scheduled_at: string | null;
  posted_at: string | null;
  error: string;
  created_at: string;
};

function docInfographic(raw: string): DuLieuInfographic | null {
  if (!raw) return null;
  try {
    const p = infographicSchema.safeParse(JSON.parse(raw));
    return p.success ? p.data : null;
  } catch {
    return null;
  }
}

const map = (r: Row): BaiNhap => ({
  id: r.id,
  accountId: r.account_id,
  threadId: r.thread_id,
  topicKey: r.topic_key,
  topicTitle: r.topic_title,
  source: r.source,
  sourceNote: r.source_note,
  body: r.body,
  discuss: r.discuss,
  infographic: docInfographic(r.infographic),
  hasImage: r.has_image === 1,
  similarity: r.similarity,
  status: r.status,
  scheduledAt: r.scheduled_at,
  postedAt: r.posted_at,
  error: r.error,
  createdAt: r.created_at,
});

export const thuMucAnhBai = () => path.join(dataDir, "group-posts");
export const duongDanAnhBai = (id: string) => path.join(thuMucAnhBai(), `${id}.png`);

const insertStmt = db.prepare(`
  INSERT INTO post_drafts (id, account_id, thread_id, topic_key, topic_title, source, source_note, body, discuss, infographic, has_image, similarity, status, scheduled_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const getStmt = db.prepare("SELECT * FROM post_drafts WHERE id = ?");

export function taoBaiNhap(p: {
  accountId: string;
  threadId: string;
  topicKey: string;
  topicTitle: string;
  source: string;
  sourceNote: string;
  body: string;
  discuss: string;
  infographic: DuLieuInfographic | null;
  anh: Buffer | null;
  similarity: number;
  status: "cho_duyet" | "da_duyet";
  scheduledAt: string | null;
}): BaiNhap {
  const id = randomBytes(8).toString("hex");
  if (p.anh) {
    fs.mkdirSync(thuMucAnhBai(), { recursive: true });
    fs.writeFileSync(duongDanAnhBai(id), p.anh);
  }
  insertStmt.run(
    id, p.accountId, p.threadId, p.topicKey, p.topicTitle.slice(0, 200), p.source, p.sourceNote.slice(0, 500),
    p.body, p.discuss, p.infographic ? JSON.stringify(p.infographic) : "", p.anh ? 1 : 0, p.similarity, p.status, p.scheduledAt,
  );
  return layBaiNhap(id)!;
}

export function layBaiNhap(id: string): BaiNhap | null {
  const r = getStmt.get(id) as Row | undefined;
  return r ? map(r) : null;
}

export function danhSachBai(loc: { status?: TrangThaiBai[]; accountId?: string; threadId?: string; limit?: number } = {}): BaiNhap[] {
  const dk: string[] = [];
  const ts: (string | number)[] = [];
  if (loc.status?.length) {
    dk.push(`status IN (${loc.status.map(() => "?").join(",")})`);
    ts.push(...loc.status);
  }
  if (loc.accountId) (dk.push("account_id = ?"), ts.push(loc.accountId));
  if (loc.threadId) (dk.push("thread_id = ?"), ts.push(loc.threadId));
  const sql = `SELECT * FROM post_drafts ${dk.length ? `WHERE ${dk.join(" AND ")}` : ""}
    ORDER BY COALESCE(scheduled_at, created_at) ASC LIMIT ?`;
  return (db.prepare(sql).all(...ts, loc.limit ?? 200) as Row[]).map(map);
}

export function suaBai(
  id: string,
  sua: Partial<Pick<BaiNhap, "body" | "discuss" | "status" | "scheduledAt" | "postedAt" | "error" | "similarity">> & {
    infographic?: DuLieuInfographic | null;
    anh?: Buffer | null;
    msgIds?: string[];
  },
): BaiNhap | null {
  const cu = layBaiNhap(id);
  if (!cu) return null;
  const set: string[] = [];
  const ts: (string | number | null)[] = [];
  const dat = (cot: string, v: string | number | null) => (set.push(`${cot} = ?`), ts.push(v));
  if (sua.body !== undefined) dat("body", sua.body);
  if (sua.discuss !== undefined) dat("discuss", sua.discuss);
  if (sua.status !== undefined) dat("status", sua.status);
  if (sua.scheduledAt !== undefined) dat("scheduled_at", sua.scheduledAt);
  if (sua.postedAt !== undefined) dat("posted_at", sua.postedAt);
  if (sua.error !== undefined) dat("error", sua.error.slice(0, 500));
  if (sua.similarity !== undefined) dat("similarity", sua.similarity);
  if (sua.msgIds !== undefined) dat("msg_ids", JSON.stringify(sua.msgIds));
  if (sua.infographic !== undefined) dat("infographic", sua.infographic ? JSON.stringify(sua.infographic) : "");
  if (sua.anh !== undefined) {
    if (sua.anh) {
      fs.mkdirSync(thuMucAnhBai(), { recursive: true });
      fs.writeFileSync(duongDanAnhBai(id), sua.anh);
    } else fs.rmSync(duongDanAnhBai(id), { force: true });
    dat("has_image", sua.anh ? 1 : 0);
  }
  if (set.length === 0) return cu;
  set.push("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");
  db.prepare(`UPDATE post_drafts SET ${set.join(", ")} WHERE id = ?`).run(...ts, id);
  return layBaiNhap(id);
}

/** Bài (mọi nhóm) tạo trong N ngày qua, trừ bài đã bỏ - để chặn trùng nội dung */
export function baiGanDay(soNgay: number, now = Date.now()): BaiNhap[] {
  const tu = new Date(now - soNgay * 86_400_000).toISOString();
  return (db.prepare("SELECT * FROM post_drafts WHERE created_at >= ? AND status != 'bo_qua' ORDER BY created_at DESC").all(tu) as Row[]).map(map);
}

/** Bài đã xếp giờ (chưa bỏ) từ mốc `tu` - để xếp lệch giờ giữa các nhóm */
export function lichDaXep(tu: string): { accountId: string; threadId: string; topicKey: string; scheduledAt: string }[] {
  return (
    db
      .prepare("SELECT account_id, thread_id, topic_key, scheduled_at FROM post_drafts WHERE scheduled_at >= ? AND status IN ('cho_duyet','da_duyet','da_dang')")
      .all(tu) as { account_id: string; thread_id: string; topic_key: string; scheduled_at: string }[]
  ).map((r) => ({ accountId: r.account_id, threadId: r.thread_id, topicKey: r.topic_key, scheduledAt: r.scheduled_at }));
}
