import assert from "node:assert/strict";
import fs from "node:fs";
import { after, before, describe, it } from "node:test";
import type { Hono } from "hono";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let app: Hono;
let cookie: string;
let planner: typeof import("./gp-planner.js");
let settings: typeof import("./gp-settings-store.js");
let drafts: typeof import("./gp-draft-store.js");
let topics: typeof import("./gp-topic-store.js");
let database: typeof import("../conversation/database.js");
const PASSWORD = "mat-khau-dang-bai-1";
const ACC = "acc-gp";
const NHOM = "nhom-gp-1";
// 07:00 sáng giờ VN
const NOW = new Date("2026-10-05T00:00:00Z");

const BAI = (tieuDe: string, them = "") =>
  JSON.stringify({
    noiDung: `**${tieuDe}**\nMọi người ơi, hôm nay chia sẻ cách làm việc hiệu quả hơn với trợ lý AI trong công việc hằng ngày. ${them}\n- Chuẩn bị tài liệu rõ ràng\n- Giao việc cụ thể\nCác anh chị đang dùng AI cho việc gì nhất?`,
    cauHoiThaoLuan: "Mẹo nhỏ: lưu lại các câu lệnh hay dùng.",
    infographic: { mau: "checklist", tieuDe: tieuDe.slice(0, 60), muc: ["Một", "Hai", "Ba"] },
  });

before(async () => {
  dataDir = setupTestEnv({ DASHBOARD_PASSWORD: PASSWORD, BOT_TIMEZONE: "Asia/Ho_Chi_Minh" });
  database = await import("../conversation/database.js");
  planner = await import("./gp-planner.js");
  settings = await import("./gp-settings-store.js");
  drafts = await import("./gp-draft-store.js");
  topics = await import("./gp-topic-store.js");
  const { createAccount } = await import("../config/account-store.js");
  const { recordThreadActivity } = await import("../conversation/thread-store.js");
  createAccount({ id: ACC, label: "Nick thử" });
  recordThreadActivity({ accountId: ACC, threadId: NHOM, threadType: 1, displayName: "Nhóm Học AI", lastSenderName: "A" });
  const { buildDashboardApp } = await import("../server/dashboard-server.js");
  app = buildDashboardApp();
  const login = await app.request("/api/auth/login", { method: "POST", body: JSON.stringify({ password: PASSWORD }), headers: { "content-type": "application/json" } });
  cookie = login.headers.get("set-cookie")!.split(";")[0]!;
});
after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

const dungAnh = async () => Buffer.from("png-gia");

describe("soạn bài nhóm", () => {
  it("soạn từ chủ đề tự nhập: chờ duyệt, có giờ trong khung, lưu ảnh, không lặp chủ đề", async () => {
    const cd = settings.luuCaiDatNhom(ACC, NHOM, { enabled: true, sources: ["topics"], timeWindows: ["19:30-21:30"] });
    const t1 = topics.themChuDe("Dùng AI soạn email");
    topics.themChuDe("Dùng AI làm báo cáo");
    const lan: string[] = [];
    const goi = async (_s: string, p: string) => (lan.push(p), BAI(lan.length === 1 ? "Soạn email nhanh" : "Báo cáo tuần gọn gàng", "khác"));
    const a = await planner.soanMotBaiChoNhom(cd, { goi, dungAnh, now: NOW });
    assert.equal(a.status, "cho_duyet");
    assert.ok(a.hasImage && fs.existsSync(drafts.duongDanAnhBai(a.id)));
    assert.ok(a.scheduledAt && new Date(a.scheduledAt).getUTCHours() >= 12, a.scheduledAt ?? "");
    const b = await planner.soanMotBaiChoNhom(cd, { goi, dungAnh, now: NOW });
    assert.notEqual(a.topicKey, b.topicKey);
    assert.ok([a.topicKey, b.topicKey].includes(`topic:${t1.id}`));
    await assert.rejects(planner.soanMotBaiChoNhom(cd, { goi, dungAnh, now: NOW }), (e: Error) => e instanceof planner.LoiSoanBai);
  });

  it("bài quá giống bài đã có thì bắt viết lại một lần", async () => {
    const cd = settings.luuCaiDatNhom(ACC, NHOM, { autoPublish: true });
    topics.themChuDe("Chủ đề thứ ba");
    const lan: string[] = [];
    const goi = async (_s: string, p: string) => (lan.push(p), lan.length === 1 ? BAI("Soạn email nhanh") : BAI("Góc nhìn mới hoàn toàn", "Ví dụ khác hẳn về quy trình nội bộ của doanh nghiệp nhỏ."));
    const c = await planner.soanMotBaiChoNhom(cd, { goi, dungAnh, now: NOW });
    assert.equal(lan.length, 2);
    assert.match(lan[1]!, /quá giống/);
    assert.equal(c.status, "da_duyet", "nhóm bật tự đăng thì bài vào thẳng hàng đã duyệt");
  });

  it("ảnh dựng hỏng vẫn giữ bài chữ", async () => {
    const cd = settings.luuCaiDatNhom(ACC, NHOM, {});
    topics.themChuDe("Chủ đề thứ tư");
    const d = await planner.soanMotBaiChoNhom(cd, { goi: async () => BAI("Chủ đề bốn rất riêng", "nội dung riêng biệt số bốn"), dungAnh: async () => { throw new Error("chrome hỏng"); }, now: NOW });
    assert.equal(d.hasImage, false);
    assert.equal(d.infographic, null);
  });

  it("bài chờ duyệt quá giờ thì được dời sang giờ mới", () => {
    const b = drafts.danhSachBai({ status: ["cho_duyet"] })[0]!;
    drafts.suaBai(b.id, { scheduledAt: "2026-10-04T13:00:00Z" });
    assert.equal(planner.doiLichBaiQuaGio(NOW), 1);
    assert.ok(Date.parse(drafts.layBaiNhap(b.id)!.scheduledAt!) > NOW.getTime());
  });

  it("số bài cần soạn trước theo số bài/tuần", () => {
    assert.equal(planner.soBaiCan(3, 3), 2);
    assert.equal(planner.soBaiCan(1, 1), 1);
    assert.equal(planner.soBaiCan(14, 7), 14);
  });
});

describe("API đăng bài nhóm", () => {
  const goiApi = (path: string, init: RequestInit = {}) =>
    app.request(`/api/group-posts${path}`, { ...init, headers: { cookie, "content-type": "application/json", ...(init.headers ?? {}) } });

  it("bật nhóm mới phải là chủ/phó nhóm - tài khoản chưa khai chủ thì bị chặn", async () => {
    const r = await goiApi(`/groups/${ACC}/nhom-moi`, { method: "PUT", body: JSON.stringify({ enabled: true }) });
    assert.equal(r.status, 403);
    assert.match(((await r.json()) as { error: string }).error, /chưa khai chủ/);
    const sai = await goiApi(`/groups/${ACC}/${NHOM}`, { method: "PUT", body: JSON.stringify({ timeWindows: ["21:00-20:00"] }) });
    assert.equal(sai.status, 400);
  });

  it("liệt kê nhóm, duyệt / bỏ bài, ảnh bài", async () => {
    const g = (await (await goiApi("/groups")).json()) as { items: { threadId: string; soChoDuyet: number; ten: string }[] };
    const nhom = g.items.find((x) => x.threadId === NHOM)!;
    assert.equal(nhom.ten, "Nhóm Học AI");
    const ds = (await (await goiApi("/drafts?status=cho_duyet")).json()) as { items: { id: string; tenNhom: string; hasImage: boolean }[] };
    assert.equal(ds.items.length, nhom.soChoDuyet);
    const coAnh = ds.items.find((x) => x.hasImage)!;
    assert.equal((await goiApi(`/drafts/${coAnh.id}/image`)).status, 200);
    const duyet = (await (await goiApi(`/drafts/${coAnh.id}`, { method: "PATCH", body: JSON.stringify({ action: "duyet", body: "**Sửa tay**\nNội dung đã được chủ bot chỉnh lại." }) })).json()) as { status: string; body: string };
    assert.equal(duyet.status, "da_duyet");
    assert.match(duyet.body, /Sửa tay/);
  });

  it("thêm / xóa chủ đề", async () => {
    const t = (await (await goiApi("/topics", { method: "POST", body: JSON.stringify({ title: "Chủ đề qua API" }) })).json()) as { id: string };
    assert.equal((await goiApi(`/topics/${t.id}`, { method: "DELETE" })).status, 200);
    assert.equal((await goiApi("/topics", { method: "POST", body: JSON.stringify({ title: "a" }) })).status, 400);
  });
});
