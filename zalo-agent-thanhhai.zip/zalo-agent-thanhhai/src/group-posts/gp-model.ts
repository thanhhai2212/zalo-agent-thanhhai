import { streamText } from "ai";
import { modelHieuLuc, resolveLanguageModel, type ModelOverride } from "../agent/llm-provider.js";
import { reasoningProviderOptions } from "../agent/reasoning-options.js";
import { chayStream } from "../agent/stream-text-result.js";
import { nhuongChoChat } from "../insight/insight-llm.js";
import { createLogger } from "../shared/logger.js";
import type { GoiModelBai } from "./gp-generator.js";

/**
 * Gọi model soạn bài đăng nhóm: model của đúng agent, nhường chat thật trước MỖI lần gọi,
 * thử lại ít - cùng tinh thần "hiền với router" của Insight.
 */

const log = createLogger("gp-model");
const TRAN_MOI_LAN_MS = 300_000;

export function goiModelBai(agent: ModelOverride, signal?: AbortSignal): GoiModelBai {
  return async (system, prompt, maxOutputTokens) => {
    await nhuongChoChat(signal);
    signal?.throwIfAborted();
    const tran = AbortSignal.timeout(TRAN_MOI_LAN_MS);
    const { provider } = modelHieuLuc(agent);
    const kq = await chayStream(
      (onError) =>
        streamText({
          model: resolveLanguageModel(agent),
          system,
          prompt,
          maxOutputTokens,
          maxRetries: 1,
          providerOptions: reasoningProviderOptions(provider, "low"),
          abortSignal: signal ? AbortSignal.any([signal, tran]) : tran,
          onError,
        }),
      (loi) => log.warn({ err: loi }, "streamText lỗi khi soạn bài đăng nhóm"),
    );
    return kq.text;
  };
}
