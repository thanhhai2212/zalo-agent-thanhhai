import { DateTime } from "luxon";

/**
 * Chọn giờ đăng cho một bài - thuần, không đụng DB (test được với `now`/`rng`).
 *
 * Luật chống spam (docs/ke-hoach-tu-dang-bai-nhom.md):
 * - Trong khung giờ của nhóm, phút ngẫu nhiên (không đăng đúng :00 mỗi lần).
 * - Nhóm đăng tối đa `postsPerWeek` bài/tuần, rải đều: <= 7 bài/tuần thì hai bài
 *   cùng nhóm cách nhau tối thiểu floor(7 / số bài) ngày; trên 7 thì tối đa 2
 *   bài/ngày cách nhau >= 4 giờ.
 * - Mỗi nick tối đa `maxMoiNgay` bài/ngày, hai bài cùng nick (khác nhóm) cách
 *   nhau >= `khoangCachPhut`.
 * - Cùng một chủ đề không lên hai nhóm trong cùng một ngày.
 */

export type BaiDaXep = { accountId: string; threadId: string; topicKey: string; scheduledAt: string };

export type YeuCauXepGio = {
  accountId: string;
  threadId: string;
  topicKey: string;
  timeWindows: string[];
  postsPerWeek: number;
  timeZone: string;
  now: Date;
  lich: BaiDaXep[];
  maxMoiNgay: number;
  khoangCachPhut: number;
  soNgayToiDa?: number;
  rng?: () => number;
};

const ngayCua = (iso: string, tz: string) => DateTime.fromISO(iso, { zone: "utc" }).setZone(tz).toISODate()!;
const lechNgay = (a: string, b: string) => Math.abs(DateTime.fromISO(a).diff(DateTime.fromISO(b), "days").days);

export function chonGioDang(y: YeuCauXepGio): string | null {
  const rng = y.rng ?? Math.random;
  const tz = y.timeZone;
  const cungNick = y.lich.filter((b) => b.accountId === y.accountId);
  const cungNhom = cungNick.filter((b) => b.threadId === y.threadId);
  const nhieuMoiNgay = y.postsPerWeek > 7;
  const cachNgay = nhieuMoiNgay ? 0 : Math.floor(7 / Math.max(1, y.postsPerWeek));
  const som = y.now.getTime() + 20 * 60_000;
  const homNay = DateTime.fromJSDate(y.now).setZone(tz).startOf("day");

  for (let d = 0; d < (y.soNgayToiDa ?? 14); d++) {
    const ngay = homNay.plus({ days: d });
    const ngayIso = ngay.toISODate()!;
    const nhomTrongNgay = cungNhom.filter((b) => ngayCua(b.scheduledAt, tz) === ngayIso);
    if (nhieuMoiNgay ? nhomTrongNgay.length >= 2 : cungNhom.some((b) => lechNgay(ngayCua(b.scheduledAt, tz), ngayIso) < cachNgay)) continue;
    if (cungNick.filter((b) => ngayCua(b.scheduledAt, tz) === ngayIso).length >= y.maxMoiNgay) continue;
    if (y.lich.some((b) => b.topicKey === y.topicKey && b.threadId !== y.threadId && ngayCua(b.scheduledAt, tz) === ngayIso)) continue;

    const khung = [...y.timeWindows].sort(() => rng() - 0.5);
    for (const k of khung) {
      const [h1, m1] = k.slice(0, 5).split(":").map(Number) as [number, number];
      const [h2, m2] = k.slice(6).split(":").map(Number) as [number, number];
      const dau = ngay.set({ hour: h1, minute: m1 });
      const doDai = ngay.set({ hour: h2, minute: m2 }).diff(dau, "minutes").minutes;
      if (doDai <= 0) continue;
      for (let lan = 0; lan < 8; lan++) {
        const t = dau.plus({ minutes: Math.floor(rng() * doDai) });
        const ms = t.toMillis();
        if (ms < som) continue;
        const sat = cungNick.some((b) => Math.abs(Date.parse(b.scheduledAt) - ms) < y.khoangCachPhut * 60_000);
        const satNhom = nhieuMoiNgay && nhomTrongNgay.some((b) => Math.abs(Date.parse(b.scheduledAt) - ms) < 4 * 3_600_000);
        if (!sat && !satNhom) return t.toUTC().toISO({ suppressMilliseconds: true })!;
      }
    }
  }
  return null;
}
