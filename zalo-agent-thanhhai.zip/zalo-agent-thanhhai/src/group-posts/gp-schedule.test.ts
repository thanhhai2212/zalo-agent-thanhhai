import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { DateTime } from "luxon";
import { chonGioDang, type BaiDaXep, type YeuCauXepGio } from "./gp-schedule.js";
import { doGiong, giongNhat } from "./gp-similarity.js";

const TZ = "Asia/Ho_Chi_Minh";
// 07:00 sáng thứ Hai 5/10/2026 giờ VN
const NOW = new Date("2026-10-05T00:00:00Z");
const gio = (iso: string) => DateTime.fromISO(iso).setZone(TZ);

function seq(...v: number[]) {
  let i = 0;
  return () => v[i++ % v.length]!;
}

const co = (p: Partial<YeuCauXepGio> = {}): YeuCauXepGio => ({
  accountId: "a",
  threadId: "g1",
  topicKey: "t1",
  timeWindows: ["08:00-10:00"],
  postsPerWeek: 3,
  timeZone: TZ,
  now: NOW,
  lich: [],
  maxMoiNgay: 6,
  khoangCachPhut: 50,
  rng: seq(0.5),
  ...p,
});

describe("chọn giờ đăng", () => {
  it("rơi vào khung giờ của nhóm, giờ địa phương", () => {
    const t = gio(chonGioDang(co())!);
    assert.equal(t.toISODate(), "2026-10-05");
    assert.ok(t.hour >= 8 && t.hour < 10, t.toISO()!);
  });

  it("3 bài/tuần: bài kế tiếp của cùng nhóm cách tối thiểu 2 ngày", () => {
    const lich: BaiDaXep[] = [{ accountId: "a", threadId: "g1", topicKey: "x", scheduledAt: "2026-10-05T02:00:00Z" }];
    assert.equal(gio(chonGioDang(co({ lich }))!).toISODate(), "2026-10-07");
  });

  it("nhóm khác cùng nick cách tối thiểu 50 phút", () => {
    const lich: BaiDaXep[] = [{ accountId: "a", threadId: "g2", topicKey: "x", scheduledAt: "2026-10-05T02:00:00Z" }];
    const t = Date.parse(chonGioDang(co({ lich, rng: seq(0.5, 0.52, 0.9) }))!);
    assert.ok(Math.abs(t - Date.parse(lich[0]!.scheduledAt)) >= 50 * 60_000);
  });

  it("cùng chủ đề không lên hai nhóm trong cùng ngày", () => {
    const lich: BaiDaXep[] = [{ accountId: "b", threadId: "g9", topicKey: "t1", scheduledAt: "2026-10-05T03:30:00Z" }];
    assert.equal(gio(chonGioDang(co({ lich }))!).toISODate(), "2026-10-06");
  });

  it("đủ trần bài mỗi nick trong ngày thì dời sang ngày sau", () => {
    const lich: BaiDaXep[] = [{ accountId: "a", threadId: "g2", topicKey: "x", scheduledAt: "2026-10-05T13:00:00Z" }];
    assert.equal(gio(chonGioDang(co({ lich, maxMoiNgay: 1 }))!).toISODate(), "2026-10-06");
  });

  it("khung giờ đã qua thì sang ngày sau; không còn chỗ thì trả null", () => {
    const toi = new Date("2026-10-05T05:00:00Z"); // 12:00 VN
    assert.equal(gio(chonGioDang(co({ now: toi }))!).toISODate(), "2026-10-06");
    assert.equal(chonGioDang(co({ now: toi, soNgayToiDa: 1 })), null);
  });
});

describe("độ giống bài", () => {
  const a = "Cách cài 9Router trên Windows rất đơn giản, chỉ cần Node.js và một lệnh npm là xong.";
  it("bài y hệt hoặc chỉ đổi dấu là gần 1, bài viết lại khác hẳn là thấp", () => {
    assert.equal(doGiong(a, a), 1);
    assert.ok(doGiong(a, a.normalize("NFD").replace(/[̀-ͯ]/g, "")) > 0.9);
    const khac = "Muốn chạy 9Router trên máy Windows? Bạn cần Node bản mới, sau đó gõ npm install là hoàn tất.";
    assert.ok(doGiong(a, khac) < 0.3);
  });
  it("tìm bài giống nhất trong danh sách", () => {
    const kq = giongNhat(a, [{ body: "khác hẳn nội dung" }, { body: a }]);
    assert.equal(kq.doGiong, 1);
    assert.equal(kq.voi?.body, a);
  });
});
