import { randomBytes } from "node:crypto";
import { db } from "../conversation/database.js";

/** Chủ đề chủ bot tự nhập ở trang Đăng bài nhóm (bảng `post_topics`). */

export type ChuDeBai = { id: string; title: string; notes: string; createdAt: string };

type Row = { id: string; title: string; notes: string; created_at: string };
const map = (r: Row): ChuDeBai => ({ id: r.id, title: r.title, notes: r.notes, createdAt: r.created_at });

export function danhSachChuDe(): ChuDeBai[] {
  return (db.prepare("SELECT * FROM post_topics ORDER BY created_at DESC").all() as Row[]).map(map);
}

export function themChuDe(title: string, notes = ""): ChuDeBai {
  const id = randomBytes(6).toString("hex");
  db.prepare("INSERT INTO post_topics (id, title, notes) VALUES (?, ?, ?)").run(id, title.trim().slice(0, 200), notes.trim().slice(0, 2000));
  return map(db.prepare("SELECT * FROM post_topics WHERE id = ?").get(id) as Row);
}

export function xoaChuDe(id: string): boolean {
  return db.prepare("DELETE FROM post_topics WHERE id = ?").run(id).changes > 0;
}
