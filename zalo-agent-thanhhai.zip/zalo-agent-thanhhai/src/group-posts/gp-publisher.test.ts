import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import type { API } from "zca-js";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let drafts: typeof import("./gp-draft-store.js");
let publisher: typeof import("./gp-publisher.js");
let poster: typeof import("./gp-poster.js");
let settings: typeof import("./gp-settings-store.js");
let history: typeof import("../conversation/history-store.js");
let database: typeof import("../conversation/database.js");
let accountManager: typeof import("../zalo/account-manager.js");
const ACC = "acc-dang";
const NHOM = "nhom-dang-1";
const NHOM2 = "nhom-dang-2";
let gui: { threadId: string; msg: string; anh: boolean }[] = [];
let hongGui = false;

before(async () => {
  dataDir = setupTestEnv({ GROUP_POST_MAX_PER_ACCOUNT_DAY: "2", GROUP_POST_MIN_GAP_MINUTES: "50", BOT_TIMEZONE: "Asia/Ho_Chi_Minh" });
  database = await import("../conversation/database.js");
  drafts = await import("./gp-draft-store.js");
  publisher = await import("./gp-publisher.js");
  poster = await import("./gp-poster.js");
  settings = await import("./gp-settings-store.js");
  history = await import("../conversation/history-store.js");
  accountManager = await import("../zalo/account-manager.js");
  const { createAccount, getAccount } = await import("../config/account-store.js");
  createAccount({ id: ACC, label: "Nick đăng" });
  settings.luuCaiDatNhom(ACC, NHOM, { enabled: true });
  settings.luuCaiDatNhom(ACC, NHOM2, { enabled: true });
  const api = {
    getOwnId: () => "self-dang",
    listener: { on: () => {}, onConnected: () => {}, onError: () => {}, onClosed: () => {}, start: () => {}, stop: () => {} },
    sendMessage: async (p: { msg?: string; attachments?: string[] }, threadId: string) => {
      if (hongGui) throw new Error("other side closed");
      gui.push({ threadId, msg: p.msg ?? "", anh: Boolean(p.attachments?.length) });
      return { message: { msgId: `m-${gui.length}` } };
    },
  } as unknown as API;
  accountManager.attachAccount(getAccount(ACC)!, api);
});
after(() => {
  accountManager.stopAllAccounts();
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});
beforeEach(() => {
  gui = [];
  hongGui = false;
  database.db.prepare("DELETE FROM post_drafts").run();
});

const taoBai = (threadId: string, scheduledAt: string, anh = true) =>
  drafts.taoBaiNhap({
    accountId: ACC, threadId, topicKey: `t-${Math.random()}`, topicTitle: "T", source: "topics", sourceNote: "",
    body: "**Tiêu đề bài**\nNội dung bài viết hướng dẫn cho mọi người trong nhóm.", discuss: "", infographic: null,
    anh: anh ? Buffer.from("png") : null, similarity: 0, status: "da_duyet", scheduledAt,
  });

describe("đăng bài nhóm", () => {
  it("đăng ảnh trước rồi bài chữ (đã dịch markdown), ghi lịch sử, đánh dấu đã đăng", async () => {
    const b = taoBai(NHOM, "2026-10-05T01:00:00Z");
    const kq = await publisher.dangBaiNhap(b, Date.parse("2026-10-05T01:00:00Z"));
    assert.equal(kq.status, "da_dang");
    assert.deepEqual(gui.map((g) => g.anh), [true, false]);
    assert.ok(gui[1]!.msg.startsWith("Tiêu đề bài"), "dấu ** đã thành định dạng, không lộ ra chữ");
    const ls = history.getRecentMessages(ACC, NHOM, 10).map((m) => m.content);
    assert.ok(ls.some((c) => c.includes("Nội dung bài viết")));
  });

  it("giữ khoảng cách giữa 2 bài cùng nick và trần bài mỗi ngày", async () => {
    const t0 = Date.parse("2026-10-05T01:00:00Z");
    await publisher.dangBaiNhap(taoBai(NHOM, "2026-10-05T01:00:00Z"), t0);
    await assert.rejects(publisher.dangBaiNhap(taoBai(NHOM2, "2026-10-05T01:10:00Z"), t0 + 10 * 60_000), /chờ thêm khoảng 40 phút/);
    await publisher.dangBaiNhap(taoBai(NHOM2, "2026-10-05T02:00:00Z"), t0 + 60 * 60_000);
    await assert.rejects(publisher.dangBaiNhap(taoBai(NHOM, "2026-10-05T05:00:00Z"), t0 + 4 * 3_600_000), /đủ 2 bài hôm nay/);
  });

  it("chủ bot bấm Đăng ngay: bỏ qua khoảng cách và trần ngày, vẫn tính vào trần của bộ tự đăng", async () => {
    const t0 = Date.parse("2026-10-05T01:00:00Z");
    await publisher.dangBaiNhap(taoBai(NHOM, "2026-10-05T01:00:00Z"), t0);
    const kq = await publisher.dangBaiNhap(taoBai(NHOM2, "2026-10-05T01:05:00Z"), t0 + 5 * 60_000, { boQuaTran: true });
    assert.equal(kq.status, "da_dang");
    await publisher.dangBaiNhap(taoBai(NHOM, "2026-10-05T01:06:00Z"), t0 + 6 * 60_000, { boQuaTran: true });
    assert.match(publisher.kiemTranDang(ACC, t0 + 4 * 3_600_000) ?? "", /đủ 3 bài hôm nay/);
  });

  it("gửi lỗi thì đánh dấu lỗi kèm lý do, không im lặng", async () => {
    hongGui = true;
    const b = taoBai(NHOM, "2026-10-05T01:00:00Z", false);
    await assert.rejects(publisher.dangBaiNhap(b, Date.parse("2026-10-05T01:00:00Z")), publisher.LoiDangBai);
    const sau = drafts.layBaiNhap(b.id)!;
    assert.equal(sau.status, "loi");
    assert.match(sau.error, /other side closed/);
  });

  it("vòng tự đăng: đăng bài tới giờ, mỗi nick một bài mỗi vòng; trễ quá 3 giờ thì dời giờ", async () => {
    const now = Date.parse("2026-10-05T03:00:00Z");
    const toi = taoBai(NHOM, "2026-10-05T02:55:00Z");
    const cungVong = taoBai(NHOM2, "2026-10-05T02:58:00Z");
    const chuaToi = taoBai(NHOM, "2026-10-05T09:00:00Z");
    const tre = taoBai(NHOM2, "2026-10-04T20:00:00Z");
    assert.equal(await poster.chayVongDang(now), 1);
    assert.equal(drafts.layBaiNhap(toi.id)!.status, "da_dang");
    assert.equal(drafts.layBaiNhap(cungVong.id)!.status, "da_duyet", "cùng nick chỉ một bài mỗi vòng");
    assert.equal(drafts.layBaiNhap(chuaToi.id)!.status, "da_duyet");
    const tre2 = drafts.layBaiNhap(tre.id)!;
    assert.equal(tre2.status, "da_duyet");
    assert.ok(Date.parse(tre2.scheduledAt!) > now, "bài trễ được dời sang giờ mới");
  });

  it("nhóm đã tắt thì không đăng", async () => {
    settings.luuCaiDatNhom(ACC, NHOM, { enabled: false });
    await assert.rejects(publisher.dangBaiNhap(taoBai(NHOM, "2026-10-05T01:00:00Z"), Date.parse("2026-10-05T01:00:00Z")), /đang tắt/);
    settings.luuCaiDatNhom(ACC, NHOM, { enabled: true });
  });
});
