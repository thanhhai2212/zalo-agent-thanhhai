import { getAccount } from "../config/account-store.js";
import { getAgentForAccount } from "../config/agent-store.js";
import { getSearchSettings } from "../config/runtime-tool-settings.js";
import { docDuLieuInsight } from "../insight/insight-job.js";
import { nguonCuaAgent } from "../knowledge/kb-agent-binding.js";
import { layDoanCuaNguon, demDoan } from "../knowledge/kb-chunk-store.js";
import { layNguon } from "../knowledge/kb-source-store.js";
import { boDauTiengViet } from "../shared/bo-dau-tieng-viet.js";
import { searchWeb } from "../shared/web-search-providers.js";
import type { CaiDatNhom, NguonBai } from "./gp-settings-store.js";
import { danhSachChuDe } from "./gp-topic-store.js";

/**
 * Lấy MỘT tư liệu để soạn bài cho một nhóm, xoay vòng 4 nguồn đã bật:
 * - topics: chủ đề chủ bot tự nhập;
 * - insight: chủ đề gộp từ câu hỏi/nỗi đau/mong muốn của CHÍNH nhóm đó;
 * - kb: một đoạn trong Kho tri thức agent của tài khoản đọc được;
 * - web: tin mới theo mô tả nhóm (nội dung web là dữ liệu người lạ - prompt
 *   bọc riêng và bắt ghi nguồn).
 * `topicKey` dùng để không lặp chủ đề trong cùng nhóm và không lên hai nhóm cùng ngày.
 */

export type TuLieu = { source: NguonBai; key: string; title: string; material: string; note: string };

export const slug = (s: string) =>
  boDauTiengViet(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);

const tron = <T>(a: T[], rng: () => number) => [...a].sort(() => rng() - 0.5);

function tuChuDe(daDung: Set<string>, rng: () => number): TuLieu | null {
  const c = tron(danhSachChuDe(), rng).find((t) => !daDung.has(`topic:${t.id}`));
  return c ? { source: "topics", key: `topic:${c.id}`, title: c.title, material: `${c.title}\n${c.notes}`.trim(), note: "Chủ đề anh nhập" } : null;
}

function tuInsight(cd: CaiDatNhom, daDung: Set<string>, rng: () => number): TuLieu | null {
  const d = docDuLieuInsight();
  if (!d) return null;
  const y = d.y.filter((x) => x.threadId === cd.threadId && x.loai !== "co_hoi" && x.chuDeGop && x.chuDeGop !== "Khác");
  const theoChuDe = new Map<string, typeof y>();
  for (const x of y) theoChuDe.set(x.chuDeGop, [...(theoChuDe.get(x.chuDeGop) ?? []), x]);
  // Chủ đề nhiều người nhắc nhất trước, chưa dùng trong nhóm
  const ung = [...theoChuDe.entries()].filter(([ten]) => !daDung.has(`insight:${slug(ten)}`)).sort((a, b) => b[1].length - a[1].length);
  const chon = ung.slice(0, 5)[Math.floor(rng() * Math.min(5, ung.length))];
  if (!chon) return null;
  const [ten, ds] = chon;
  const viDu = ds.slice(0, 8).map((x) => `- (${x.loai}) ${x.moTa}`).join("\n");
  return {
    source: "insight",
    key: `insight:${slug(ten)}`,
    title: ten,
    material: `Chủ đề thành viên nhóm này hay nhắc: ${ten} (${ds.length} lần).\nCác ý cụ thể:\n${viDu}`,
    note: `Insight nhóm: ${ds.length} ý`,
  };
}

function tuKho(cd: CaiDatNhom, daDung: Set<string>, rng: () => number): TuLieu | null {
  const acc = getAccount(cd.accountId);
  if (!acc) return null;
  const agent = getAgentForAccount(acc.agentId);
  for (const id of tron(nguonCuaAgent(agent.id), rng)) {
    const src = layNguon(id);
    if (!src || src.trangThai !== "san_sang") continue;
    const so = demDoan(id);
    for (let lan = 0; lan < 3 && so > 0; lan++) {
      const thuTu = Math.floor(rng() * so);
      const key = `kb:${id}:${thuTu}`;
      if (daDung.has(key)) continue;
      const doan = layDoanCuaNguon(id, thuTu, 1)[0];
      if (!doan) continue;
      return { source: "kb", key, title: doan.tieuDe || src.ten, material: doan.noiDung.slice(0, 3000), note: `Kho tri thức: ${src.ten}` };
    }
  }
  return null;
}

async function tuWeb(cd: CaiDatNhom, tenNhom: string, daDung: Set<string>, tim: typeof searchWeb): Promise<TuLieu | null> {
  const s = getSearchSettings();
  const chuDe = cd.audience.trim() || tenNhom;
  const kq = await tim(`${chuDe} mẹo hướng dẫn mới nhất`, {
    maxResults: 6,
    braveApiKey: s.provider === "brave" ? s.braveApiKey : undefined,
    tavilyApiKey: s.tavilyApiKey || undefined,
    exaApiKey: s.exaApiKey || undefined,
    linkupApiKey: s.linkupApiKey || undefined,
  }).catch(() => []);
  const moi = kq.filter((r) => !daDung.has(`web:${slug(r.url)}`));
  const dau = moi[0];
  if (!dau) return null;
  const material = moi.slice(0, 4).map((r) => `- ${r.title}\n  ${r.snippet}\n  ${r.url}`).join("\n");
  return { source: "web", key: `web:${slug(dau.url)}`, title: dau.title, material, note: dau.url };
}

export async function layTuLieu(
  cd: CaiDatNhom,
  tenNhom: string,
  daDung: Set<string>,
  phu: { rng?: () => number; tim?: typeof searchWeb; uuTien?: NguonBai } = {},
): Promise<TuLieu | null> {
  const rng = phu.rng ?? Math.random;
  const nguon = tron(cd.sources, rng);
  if (phu.uuTien && nguon.includes(phu.uuTien)) nguon.sort((a) => (a === phu.uuTien ? -1 : 1));
  for (const n of nguon) {
    const t =
      n === "topics" ? tuChuDe(daDung, rng)
      : n === "insight" ? tuInsight(cd, daDung, rng)
      : n === "kb" ? tuKho(cd, daDung, rng)
      : await tuWeb(cd, tenNhom, daDung, phu.tim ?? searchWeb);
    if (t) return t;
  }
  return null;
}
