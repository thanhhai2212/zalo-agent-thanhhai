import type { DatabaseSync } from "node:sqlite";

/**
 * Lược đồ "Đăng bài nhóm" (2026-10-05, docs/ke-hoach-tu-dang-bai-nhom.md):
 * - `post_group_settings`: nhóm nào được đăng, mấy bài/tuần, khung giờ, giọng
 *   văn, tự đăng hay chờ duyệt. Chỉ bật được cho nhóm CHỦ BOT làm chủ/phó
 *   (route kiểm bằng dữ liệu Zalo thật lúc bật).
 * - `post_topics`: chủ đề chủ bot tự nhập.
 * - `post_drafts`: bài nháp theo TỪNG nhóm (mỗi nhóm một bản viết riêng), kèm
 *   giờ dự kiến và trạng thái. Ảnh infographic ở `data/group-posts/<id>.png`.
 * Không FOREIGN KEY (cùng lý do kb-schema.ts).
 */
export function taoBangDangBaiNhom(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS post_group_settings (
      account_id     TEXT NOT NULL,
      thread_id      TEXT NOT NULL,
      enabled        INTEGER NOT NULL DEFAULT 0,
      posts_per_week INTEGER NOT NULL DEFAULT 3,
      time_windows   TEXT NOT NULL DEFAULT '["08:00-10:00","19:30-21:30"]',
      tone           TEXT NOT NULL DEFAULT '',
      audience       TEXT NOT NULL DEFAULT '',
      auto_publish   INTEGER NOT NULL DEFAULT 0,
      sources        TEXT NOT NULL DEFAULT '["topics","insight","kb","web"]',
      updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      PRIMARY KEY (account_id, thread_id)
    );

    CREATE TABLE IF NOT EXISTS post_topics (
      id         TEXT PRIMARY KEY,
      title      TEXT NOT NULL,
      notes      TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS post_drafts (
      id           TEXT PRIMARY KEY,
      account_id   TEXT NOT NULL,
      thread_id    TEXT NOT NULL,
      topic_key    TEXT NOT NULL,
      topic_title  TEXT NOT NULL,
      source       TEXT NOT NULL,
      source_note  TEXT NOT NULL DEFAULT '',
      body         TEXT NOT NULL,
      discuss      TEXT NOT NULL DEFAULT '',
      infographic  TEXT NOT NULL DEFAULT '',
      has_image    INTEGER NOT NULL DEFAULT 0,
      similarity   REAL NOT NULL DEFAULT 0,
      status       TEXT NOT NULL DEFAULT 'cho_duyet'
                   CHECK (status IN ('cho_duyet', 'da_duyet', 'da_dang', 'bo_qua', 'loi')),
      scheduled_at TEXT,
      posted_at    TEXT,
      msg_ids      TEXT NOT NULL DEFAULT '',
      error        TEXT NOT NULL DEFAULT '',
      created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS idx_post_drafts_lich ON post_drafts (account_id, status, scheduled_at);
  `);
}
