import { z } from "zod";
import { infographicSchema, type DuLieuInfographic } from "../infographic/infographic-schema.js";
import { LoiTranKhung } from "../infographic/render-infographic.js";
import { createLogger } from "../shared/logger.js";
import { giongNhat, NGUONG_GIONG } from "./gp-similarity.js";
import { HE_THONG_SOAN_BAI, promptSoanBai, tieuDeCuaBai } from "./gp-prompt.js";
import type { CaiDatNhom } from "./gp-settings-store.js";
import type { TuLieu } from "./gp-sources.js";

/**
 * Soạn MỘT bài cho một nhóm từ một tư liệu: gọi model -> kiểm JSON -> chặn giống
 * bài đã có -> dựng ảnh infographic. Mỗi bước hỏng thì thử lại ĐÚNG MỘT lần kèm
 * lời nhắc cụ thể; lần hai vẫn hỏng thì lùi một bậc (bỏ ảnh, giữ bài, ghi độ
 * giống để trang duyệt cảnh báo) chứ không kẹt cả vòng soạn.
 */

const log = createLogger("gp-generator");

export type GoiModelBai = (system: string, prompt: string, maxOutputTokens: number) => Promise<string>;
export type DungAnh = (d: DuLieuInfographic) => Promise<Buffer>;

const ketQuaSchema = z.object({
  noiDung: z.string().trim().min(80).max(3000),
  cauHoiThaoLuan: z.string().trim().max(400).optional().default(""),
  infographic: z.unknown().optional(),
});

export type BaiDaSoan = {
  body: string;
  discuss: string;
  infographic: DuLieuInfographic | null;
  anh: Buffer | null;
  similarity: number;
};

function tachJson(raw: string): unknown {
  const dau = raw.indexOf("{");
  const cuoi = raw.lastIndexOf("}");
  if (dau < 0 || cuoi <= dau) return null;
  try {
    return JSON.parse(raw.slice(dau, cuoi + 1));
  } catch {
    return null;
  }
}

export async function soanBai(p: {
  cd: CaiDatNhom;
  tenNhom: string;
  tuLieu: TuLieu;
  /** Bài gần đây của MỌI nhóm (chặn trùng) - bài của nhóm này dùng thêm làm "đã đăng gần đây" */
  ganDay: { threadId: string; body: string }[];
  goi: GoiModelBai;
  dungAnh: DungAnh;
}): Promise<BaiDaSoan> {
  const tieuDeGanDay = p.ganDay.filter((b) => b.threadId === p.cd.threadId).slice(0, 10).map((b) => tieuDeCuaBai(b.body));
  let ghiChu: string | undefined;
  let tot: (z.infer<typeof ketQuaSchema> & { info: DuLieuInfographic | null; giong: number }) | null = null;

  for (let lan = 0; lan < 2; lan++) {
    const raw = await p.goi(HE_THONG_SOAN_BAI, promptSoanBai({ cd: p.cd, tenNhom: p.tenNhom, tuLieu: p.tuLieu, tieuDeGanDay, ghiChuThem: ghiChu }), 4000);
    const kq = ketQuaSchema.safeParse(tachJson(raw));
    if (!kq.success) {
      ghiChu = "Lần trước không trả đúng JSON theo định dạng. Chỉ trả MỘT khối JSON hợp lệ.";
      continue;
    }
    const info = kq.data.infographic == null ? null : infographicSchema.safeParse(kq.data.infographic);
    const giong = giongNhat(kq.data.noiDung, p.ganDay).doGiong;
    tot = { ...kq.data, info: info?.success ? info.data : null, giong };
    if (info && !info.success && lan === 0) {
      ghiChu = `Dữ liệu infographic sai giới hạn (${info.error.issues[0]?.message ?? "không hợp lệ"}). Rút ngắn chữ đúng giới hạn hoặc để null.`;
      continue;
    }
    if (giong >= NGUONG_GIONG && lan === 0) {
      ghiChu = "Bài quá giống một bài đã đăng. Viết lại khác hẳn: góc nhìn khác, ví dụ khác, câu chữ khác.";
      continue;
    }
    break;
  }
  if (!tot) throw new Error("Model không trả bài đúng định dạng sau 2 lần");

  let anh: Buffer | null = null;
  let info = tot.info;
  if (info) {
    try {
      anh = await p.dungAnh(info);
    } catch (err) {
      // Tràn khung hay Chrome lỗi: vẫn giữ bài chữ, bỏ ảnh - trang duyệt thấy bài không có ảnh
      log.warn({ err: err instanceof LoiTranKhung ? err.message : err }, "Không dựng được ảnh infographic - giữ bài chữ");
      info = null;
    }
  }
  return { body: tot.noiDung, discuss: tot.cauHoiThaoLuan, infographic: info, anh, similarity: Math.round(tot.giong * 100) / 100 };
}
