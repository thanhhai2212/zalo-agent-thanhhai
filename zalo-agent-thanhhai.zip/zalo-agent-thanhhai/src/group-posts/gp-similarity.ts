import { boDauTiengViet } from "../shared/bo-dau-tieng-viet.js";

/**
 * Đo độ giống giữa hai bài (0 = khác hẳn, 1 = y hệt) để chặn đăng nội dung
 * trùng/na ná vào nhiều nhóm - đúng dấu hiệu Zalo dùng để quét spam.
 *
 * Jaccard trên "cụm 3 từ" liên tiếp sau khi bỏ dấu, bỏ dấu câu, viết thường:
 * hai bài cùng chủ đề nhưng viết lại câu chữ sẽ chung rất ít cụm 3 từ, còn bản
 * chỉ đổi vài chữ thì chung gần hết. Không dùng model - rẻ, chắc, đo được.
 */

export const NGUONG_GIONG = 0.3;

function cumTu(s: string, n = 3): Set<string> {
  // Bỏ thẻ màu Zalo ([cam]...[/cam]) trước: tên thẻ lặp ở mọi bài sẽ đẩy độ giống lên giả
  const tu = boDauTiengViet(s.replace(/\[\/?[a-z]+\]/gi, " "))
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  const kq = new Set<string>();
  if (tu.length < n) {
    if (tu.length) kq.add(tu.join(" "));
    return kq;
  }
  for (let i = 0; i + n <= tu.length; i++) kq.add(tu.slice(i, i + n).join(" "));
  return kq;
}

export function doGiong(a: string, b: string): number {
  const x = cumTu(a);
  const y = cumTu(b);
  if (x.size === 0 || y.size === 0) return 0;
  let chung = 0;
  for (const c of x) if (y.has(c)) chung++;
  return chung / (x.size + y.size - chung);
}

/** Độ giống lớn nhất của `bai` với danh sách bài đã có, kèm bài giống nhất */
export function giongNhat<T extends { body: string }>(bai: string, daCo: T[]): { doGiong: number; voi: T | null } {
  let max = 0;
  let voi: T | null = null;
  for (const b of daCo) {
    const g = doGiong(bai, b.body);
    if (g > max) (max = g), (voi = b);
  }
  return { doGiong: max, voi };
}
