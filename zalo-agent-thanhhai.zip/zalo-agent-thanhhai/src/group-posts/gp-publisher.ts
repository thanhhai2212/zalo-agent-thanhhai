import fs from "node:fs";
import { ThreadType } from "zca-js";
import { guiFileKemCaption } from "../agent/tools/send-attachment-with-caption.js";
import { ghiChuDaGuiAnh } from "../agent/tools/sent-by-tool-note.js";
import { botTimeZone, getTuning } from "../config/runtime-tuning-settings.js";
import { appendMessage } from "../conversation/history-store.js";
import { appendSentMsgId } from "../conversation/message-recall-store.js";
import { createLogger } from "../shared/logger.js";
import { getRunningAccountKenh } from "../zalo/account-manager.js";
import { dinhDangNeuBat, lamSachTheoCauHinh } from "../zalo/prepare-outgoing-text.js";
import { replyTargetTuKenh } from "../zalo/reply-target-tu-kenh.js";
import { sendReplyInParts } from "../zalo/send-reply-in-parts.js";
import { waitForCliMsgId } from "../zalo/self-echo-registry.js";
import { danhSachBai, duongDanAnhBai, suaBai, type BaiNhap } from "./gp-draft-store.js";
import { docCaiDatNhom } from "./gp-settings-store.js";

/**
 * Đăng MỘT bài vào nhóm: ảnh infographic trước, bài chữ ngay sau (đã dịch
 * markdown thành định dạng Zalo, tin dài tự cắt đoạn). Ghi lịch sử nhóm + mã
 * tin như câu trả lời thường nên bot biết mình vừa đăng gì và `undo_message`
 * thu hồi được.
 *
 * KHÔNG dùng `deliverChatReply`: hàm đó gửi hỏng là tự nhắn câu "trục trặc kỹ
 * thuật" vào chính cuộc chat - đăng bài hỏng mà nhóm thấy câu đó là tệ hơn im.
 * Hỏng thì đánh dấu `loi` để trang duyệt hiện lý do + nút đăng lại.
 */

const log = createLogger("gp-publisher");

export class LoiDangBai extends Error {}

const ngayVN = (ms: number) => new Date(ms).toLocaleDateString("sv-SE", { timeZone: botTimeZone() });

/** Kiểm trần chống spam của NICK trước khi đăng: số bài trong ngày + khoảng cách với bài vừa đăng. */
export function kiemTranDang(accountId: string, now = Date.now()): string | null {
  const daDang = danhSachBai({ status: ["da_dang"], accountId, limit: 1000 }).filter((b) => b.postedAt);
  const homNay = daDang.filter((b) => ngayVN(Date.parse(b.postedAt!)) === ngayVN(now)).length;
  if (homNay >= getTuning("GROUP_POST_MAX_PER_ACCOUNT_DAY")) return `Nick này đã đăng đủ ${homNay} bài hôm nay (trần ở trang Cấu hình > Đăng bài nhóm).`;
  const gan = Math.max(0, ...daDang.map((b) => Date.parse(b.postedAt!)));
  const cho = gan + getTuning("GROUP_POST_MIN_GAP_MINUTES") * 60_000 - now;
  if (cho > 0) return `Nick này vừa đăng bài khác - chờ thêm khoảng ${Math.ceil(cho / 60_000)} phút để hai bài không sát nhau.`;
  return null;
}

/**
 * `boQuaTran`: chủ bot bấm "Đăng ngay" trên dashboard - quyết định của chính chủ
 * nhóm nên KHÔNG chặn bởi khoảng cách/trần ngày (2026-10-05, chủ bot yêu cầu).
 * Bộ tự đăng luôn gọi không có cờ này; bài đăng tay vẫn được tính vào trần của nó.
 */
export async function dangBaiNhap(bai: BaiNhap, now = Date.now(), opts: { boQuaTran?: boolean } = {}): Promise<BaiNhap> {
  if (!docCaiDatNhom(bai.accountId, bai.threadId).enabled) throw new LoiDangBai("Nhóm này đang tắt đăng bài.");
  const kenh = getRunningAccountKenh(bai.accountId);
  if (!kenh?.api) throw new LoiDangBai("Nick Zalo của nhóm này đang không chạy.");
  const tran = opts.boQuaTran ? null : kiemTranDang(bai.accountId, now);
  if (tran) throw new LoiDangBai(tran);

  const sach = lamSachTheoCauHinh(bai.body);
  if (sach.chan) throw new LoiDangBai("Bài bị bộ lọc an toàn chặn - sửa chữ rồi đăng lại.");
  const { text, styles } = dinhDangNeuBat(sach.text);
  const khoa = `${bai.accountId}:${bai.threadId}`;
  const api = kenh.api;

  try {
    if (bai.hasImage && fs.existsSync(duongDanAnhBai(bai.id))) {
      await guiFileKemCaption(api, khoa, bai.threadId, ThreadType.Group, duongDanAnhBai(bai.id), undefined);
      appendMessage(bai.accountId, bai.threadId, { role: "assistant", content: ghiChuDaGuiAnh(1) });
    }
    const target = replyTargetTuKenh({ kenh, threadId: bai.threadId, threadType: ThreadType.Group, threadKey: khoa });
    const kq = await sendReplyInParts(target, text, styles);
    if (kq.deliveredText) {
      const rowId = appendMessage(bai.accountId, bai.threadId, { role: "assistant", content: kq.deliveredText });
      for (const msgId of kq.sentMsgIds) void waitForCliMsgId(bai.accountId, msgId).then((cli) => cli && appendSentMsgId(rowId, msgId, cli));
    }
    if (kq.error || !kq.deliveredText) throw kq.error ?? new Error("Không gửi được chữ bài");
    log.info({ accountId: bai.accountId, threadId: bai.threadId, id: bai.id, soTin: kq.sentParts }, "Đã đăng bài nhóm");
    return suaBai(bai.id, { status: "da_dang", postedAt: new Date(now).toISOString(), msgIds: kq.sentMsgIds, error: "" })!;
  } catch (err) {
    const loi = err instanceof Error ? err.message : String(err);
    log.warn({ err, id: bai.id, threadId: bai.threadId }, "Đăng bài nhóm hỏng");
    suaBai(bai.id, { status: "loi", error: `Gửi lên Zalo hỏng: ${loi}` });
    throw new LoiDangBai(`Gửi lên Zalo hỏng: ${loi}`);
  }
}
