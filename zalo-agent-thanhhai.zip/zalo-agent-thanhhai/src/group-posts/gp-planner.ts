import { getAccount } from "../config/account-store.js";
import { getAgentForAccount } from "../config/agent-store.js";
import { botTimeZone, getTuning } from "../config/runtime-tuning-settings.js";
import { getThreadDisplayName } from "../conversation/thread-store.js";
import { thuongHieuChoAnh } from "../infographic/infographic-theme.js";
import { renderInfographic } from "../infographic/render-infographic.js";
import { createLogger } from "../shared/logger.js";
import { goiModelBai } from "./gp-model.js";
import { baiGanDay, danhSachBai, lichDaXep, suaBai, taoBaiNhap, type BaiNhap } from "./gp-draft-store.js";
import { soanBai, type DungAnh, type GoiModelBai } from "./gp-generator.js";
import { chonGioDang } from "./gp-schedule.js";
import { danhSachNhomDangBat, type CaiDatNhom, type NguonBai } from "./gp-settings-store.js";
import { layTuLieu } from "./gp-sources.js";

/**
 * Điều phối soạn bài: giữ mỗi nhóm đang bật luôn có đủ bài nháp cho
 * `GROUP_POST_PLAN_DAYS` ngày tới. Mỗi vòng soạn TỐI ĐA MỘT bài (model gọi qua
 * cùng router với chat thật - cùng tinh thần "hiền với router" của Insight).
 * Bài chờ duyệt mà quá giờ dự kiến thì dời sang giờ trống kế tiếp, không đăng.
 * Việc ĐĂNG thật là phần sau (bộ tự đăng), file này chỉ soạn + xếp giờ.
 */

const log = createLogger("gp-planner");
const NHIP_MS = 20 * 60_000;

export type PhuThuoc = { goi?: GoiModelBai; dungAnh?: DungAnh; uuTien?: NguonBai; now?: Date };

export class LoiSoanBai extends Error {}

/** Giờ trống kế tiếp cho một bài của nhóm (bỏ qua chính giờ cũ của bài đó nếu đang dời) */
export function xepGioMoi(cd: CaiDatNhom, topicKey: string, now: Date, boQuaGio?: string): string | null {
  const tu = new Date(now.getTime() - 7 * 86_400_000).toISOString();
  return chonGioDang({
    accountId: cd.accountId,
    threadId: cd.threadId,
    topicKey,
    timeWindows: cd.timeWindows,
    postsPerWeek: cd.postsPerWeek,
    timeZone: botTimeZone(),
    now,
    lich: lichDaXep(tu).filter((b) => !boQuaGio || b.scheduledAt !== boQuaGio),
    maxMoiNgay: getTuning("GROUP_POST_MAX_PER_ACCOUNT_DAY"),
    khoangCachPhut: getTuning("GROUP_POST_MIN_GAP_MINUTES"),
  });
}

/** Soạn ngay một bài cho một nhóm. Ném `LoiSoanBai` với câu dễ hiểu khi không soạn được. */
export async function soanMotBaiChoNhom(cd: CaiDatNhom, phu: PhuThuoc = {}): Promise<BaiNhap> {
  const now = phu.now ?? new Date();
  const acc = getAccount(cd.accountId);
  if (!acc) throw new LoiSoanBai("Tài khoản Zalo của nhóm này không còn.");
  const tenNhom = getThreadDisplayName(cd.accountId, cd.threadId) || cd.threadId;
  const ganDay = baiGanDay(30, now.getTime());
  const daDung = new Set(baiGanDay(60, now.getTime()).filter((b) => b.threadId === cd.threadId).map((b) => b.topicKey));
  const tuLieu = await layTuLieu(cd, tenNhom, daDung, { uuTien: phu.uuTien });
  if (!tuLieu) throw new LoiSoanBai("Hết tư liệu mới cho nhóm này: thêm chủ đề, nạp thêm Kho tri thức hoặc bật thêm nguồn.");

  const goi = phu.goi ?? goiModelBai(getAgentForAccount(acc.agentId));
  const th = thuongHieuChoAnh();
  const bai = await soanBai({ cd, tenNhom, tuLieu, ganDay, goi, dungAnh: phu.dungAnh ?? ((d) => renderInfographic(d, th)) });
  const gio = xepGioMoi(cd, tuLieu.key, now);
  const draft = taoBaiNhap({
    accountId: cd.accountId,
    threadId: cd.threadId,
    topicKey: tuLieu.key,
    topicTitle: tuLieu.title,
    source: tuLieu.source,
    sourceNote: tuLieu.note,
    body: bai.body,
    discuss: bai.discuss,
    infographic: bai.infographic,
    anh: bai.anh,
    similarity: bai.similarity,
    status: cd.autoPublish ? "da_duyet" : "cho_duyet",
    scheduledAt: gio,
  });
  log.info({ accountId: cd.accountId, threadId: cd.threadId, source: tuLieu.source, coAnh: bai.anh !== null, giong: bai.similarity, gio }, "Đã soạn bài nhóm");
  return draft;
}

/** Bài chờ duyệt đã quá giờ dự kiến -> dời sang giờ trống kế tiếp */
export function doiLichBaiQuaGio(now = new Date()): number {
  let so = 0;
  const caiDat = new Map(danhSachNhomDangBat().map((c) => [`${c.accountId}:${c.threadId}`, c]));
  for (const b of danhSachBai({ status: ["cho_duyet"] })) {
    if (!b.scheduledAt || Date.parse(b.scheduledAt) > now.getTime()) continue;
    const cd = caiDat.get(`${b.accountId}:${b.threadId}`);
    suaBai(b.id, { scheduledAt: cd ? xepGioMoi(cd, b.topicKey, now, b.scheduledAt) : null });
    so++;
  }
  return so;
}

/** Số bài nháp nhóm cần có trong khoảng soạn trước */
export const soBaiCan = (postsPerWeek: number, soNgay: number) => Math.max(1, Math.ceil((postsPerWeek * soNgay) / 7));

let dangChay = false;

/** Một vòng: dời bài quá giờ, rồi soạn tối đa một bài cho nhóm thiếu bài nhất. */
export async function chayVongSoan(phu: PhuThuoc = {}): Promise<BaiNhap | null> {
  if (!getTuning("GROUP_POST_ENABLED") || dangChay) return null;
  dangChay = true;
  try {
    const now = phu.now ?? new Date();
    doiLichBaiQuaGio(now);
    const den = now.getTime() + getTuning("GROUP_POST_PLAN_DAYS") * 86_400_000;
    const thieu = danhSachNhomDangBat()
      .map((cd) => {
        const co = danhSachBai({ status: ["cho_duyet", "da_duyet"], accountId: cd.accountId, threadId: cd.threadId }).filter(
          // Bài chưa xếp được giờ (hết chỗ trống) vẫn tính - không thì vòng sau soạn mãi
          (b) => !b.scheduledAt || Date.parse(b.scheduledAt) <= den,
        ).length;
        return { cd, thieu: soBaiCan(cd.postsPerWeek, getTuning("GROUP_POST_PLAN_DAYS")) - co };
      })
      .filter((x) => x.thieu > 0)
      .sort((a, b) => b.thieu - a.thieu);
    for (const { cd } of thieu) {
      try {
        return await soanMotBaiChoNhom(cd, { ...phu, now });
      } catch (err) {
        log.warn({ err, threadId: cd.threadId }, "Soạn bài nhóm hỏng - thử nhóm khác ở vòng sau");
      }
    }
    return null;
  } finally {
    dangChay = false;
  }
}

export function batDauHenGioDangBai(): () => void {
  const chay = () => void chayVongSoan().catch((err) => log.warn({ err }, "Vòng soạn bài nhóm lỗi"));
  const dau = setTimeout(chay, 3 * 60_000);
  const t = setInterval(chay, NHIP_MS);
  dau.unref();
  t.unref();
  // Bộ tự đăng (gp-poster.ts) nạp động: nó import ngược file này (xepGioMoi)
  let dungDang: () => void = () => {};
  void import("./gp-poster.js").then((m) => (dungDang = m.batDauTuDangBai()));
  return () => (clearTimeout(dau), clearInterval(t), dungDang());
}
