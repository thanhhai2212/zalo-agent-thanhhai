import { db } from "../conversation/database.js";

/**
 * Cài đặt đăng bài theo TỪNG nhóm (bảng `post_group_settings`). Nhóm chưa có
 * dòng nào = chưa bật, dùng giá trị mặc định.
 */

export const NGUON_BAI = ["topics", "insight", "kb", "web"] as const;
export type NguonBai = (typeof NGUON_BAI)[number];

/** "HH:MM-HH:MM", giờ bắt đầu trước giờ kết thúc, trong cùng một ngày */
export const KHUNG_GIO_RE = /^([01]\d|2[0-3]):[0-5]\d-([01]\d|2[0-3]):[0-5]\d$/;
export const khungGioHopLe = (k: string) => KHUNG_GIO_RE.test(k) && k.slice(0, 5) < k.slice(6);

export type CaiDatNhom = {
  accountId: string;
  threadId: string;
  enabled: boolean;
  postsPerWeek: number;
  timeWindows: string[];
  tone: string;
  audience: string;
  autoPublish: boolean;
  sources: NguonBai[];
};

type Row = {
  account_id: string;
  thread_id: string;
  enabled: number;
  posts_per_week: number;
  time_windows: string;
  tone: string;
  audience: string;
  auto_publish: number;
  sources: string;
};

function docMang(raw: string): string[] {
  try {
    const v = JSON.parse(raw) as unknown;
    return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

function map(r: Row): CaiDatNhom {
  const khung = docMang(r.time_windows).filter(khungGioHopLe);
  return {
    accountId: r.account_id,
    threadId: r.thread_id,
    enabled: r.enabled === 1,
    postsPerWeek: Math.min(14, Math.max(1, r.posts_per_week)),
    timeWindows: khung.length > 0 ? khung : ["08:00-10:00"],
    tone: r.tone,
    audience: r.audience,
    autoPublish: r.auto_publish === 1,
    sources: docMang(r.sources).filter((s): s is NguonBai => (NGUON_BAI as readonly string[]).includes(s)),
  };
}

export const caiDatMacDinh = (accountId: string, threadId: string): CaiDatNhom => ({
  accountId,
  threadId,
  enabled: false,
  postsPerWeek: 3,
  timeWindows: ["08:00-10:00", "19:30-21:30"],
  tone: "",
  audience: "",
  autoPublish: false,
  sources: [...NGUON_BAI],
});

const getStmt = db.prepare("SELECT * FROM post_group_settings WHERE account_id = ? AND thread_id = ?");
const upsertStmt = db.prepare(`
  INSERT INTO post_group_settings (account_id, thread_id, enabled, posts_per_week, time_windows, tone, audience, auto_publish, sources, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  ON CONFLICT (account_id, thread_id) DO UPDATE SET
    enabled = excluded.enabled, posts_per_week = excluded.posts_per_week, time_windows = excluded.time_windows,
    tone = excluded.tone, audience = excluded.audience, auto_publish = excluded.auto_publish,
    sources = excluded.sources, updated_at = excluded.updated_at
`);
const dangBatStmt = db.prepare("SELECT * FROM post_group_settings WHERE enabled = 1 ORDER BY account_id, thread_id");

export function docCaiDatNhom(accountId: string, threadId: string): CaiDatNhom {
  const r = getStmt.get(accountId, threadId) as Row | undefined;
  return r ? map(r) : caiDatMacDinh(accountId, threadId);
}

export function luuCaiDatNhom(accountId: string, threadId: string, sua: Partial<Omit<CaiDatNhom, "accountId" | "threadId">>): CaiDatNhom {
  const c = { ...docCaiDatNhom(accountId, threadId), ...sua };
  upsertStmt.run(
    accountId,
    threadId,
    c.enabled ? 1 : 0,
    Math.min(14, Math.max(1, Math.round(c.postsPerWeek))),
    JSON.stringify(c.timeWindows.filter(khungGioHopLe)),
    c.tone.trim().slice(0, 300),
    c.audience.trim().slice(0, 300),
    c.autoPublish ? 1 : 0,
    JSON.stringify(c.sources.filter((s) => (NGUON_BAI as readonly string[]).includes(s))),
  );
  return docCaiDatNhom(accountId, threadId);
}

export function danhSachNhomDangBat(): CaiDatNhom[] {
  return (dangBatStmt.all() as Row[]).map(map);
}

export type NhomCoTheDang = { accountId: string; threadId: string; ten: string; soTin: number; caiDat: CaiDatNhom };

const nhomStmt = db.prepare(`
  SELECT account_id, thread_id, display_name, message_count FROM threads
  WHERE thread_type = 1 AND (? = '' OR account_id = ?)
  ORDER BY last_message_at DESC LIMIT 300
`);

/** Mọi nhóm bot đang ở (theo history) kèm cài đặt đăng bài */
export function danhSachNhomKemCaiDat(accountId = ""): NhomCoTheDang[] {
  const rows = nhomStmt.all(accountId, accountId) as { account_id: string; thread_id: string; display_name: string; message_count: number }[];
  return rows.map((r) => ({
    accountId: r.account_id,
    threadId: r.thread_id,
    ten: r.display_name || r.thread_id,
    soTin: r.message_count,
    caiDat: docCaiDatNhom(r.account_id, r.thread_id),
  }));
}
