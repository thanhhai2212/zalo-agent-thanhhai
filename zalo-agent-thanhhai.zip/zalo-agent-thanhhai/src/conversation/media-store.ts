import fs from "node:fs";
import path from "node:path";
import { pruneOldTraces } from "../agent/agent-trace-store.js";
import type { AgentProfile } from "../config/agent-store.js";
import { dataDir } from "../config/env.js";
import { startDailyTask } from "../shared/daily-task-schedule.js";
import { downloadAudio, type DownloadedAudio } from "../shared/download-audio.js";
import { downloadDocument, type DownloadedDocument } from "../shared/download-document.js";
import { downloadImage, type DownloadedImage } from "../shared/download-image.js";
import { createLogger } from "../shared/logger.js";
import {
  extractDocumentText,
  isSupportedDocumentExtension,
} from "../documents/extract-document-text.js";
import { isSttConfigured, transcribeAudio } from "../voice/stt-client.js";
import { extensionFromFileName } from "../zalo/zalo-message-parser.js";
import { estimateImageTokens, readImageSize } from "../zalo/zalo-image-variant.js";
import { pruneExpiredImageDescriptions } from "./image-description-store.js";
import { getTuning } from "../config/runtime-tuning-settings.js";

const log = createLogger("media-store");
const mediaDir = path.join(dataDir, "media");

const EXT_BY_MEDIA_TYPE: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};
const MEDIA_TYPE_BY_EXT: Record<string, string> = {
  jpg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  gif: "image/gif",
};

/** Zalo id là số nhưng không tin tưởng: chỉ giữ ký tự an toàn cho tên file */
function sanitizeSegment(value: string): string {
  return value.replace(/[^a-zA-Z0-9_-]/g, "_") || "x";
}

export type PersistableMessage = {
  threadId: string;
  msgId: string;
  images: { url: string; localPath?: string; fallbackUrls?: string[] }[];
};

export type ImageDownloader = (url: string) => Promise<DownloadedImage | null>;

/** Chờ giữa lần tải đầu và lần thử lại cùng URL - đủ để lỗi mạng thoáng qua qua đi */
const CHO_THU_LAI_MS = 600;

/**
 * Tải ảnh của cả batch về data/media, gắn localPath vào từng ảnh tải thành công.
 * Ảnh lỗi (URL chết, quá 8MB, IP nội bộ...) không được chặn đường trả lời và
 * KHÔNG BAO GIỜ reject để caller fire-and-forget được.
 *
 * Mỗi ảnh thử tối đa 3 lần: URL chính, URL chính thêm 1 lần sau `choThuLaiMs`
 * (lỗi mạng thoáng qua), rồi biến thể dự phòng đầu tiên của CÙNG ảnh (biến thể
 * chính hết hạn/bị CDN từ chối/quá nặng). Bẫy đã dính thật 2026-09-21: bản cũ
 * thử đúng 1 lần rồi bỏ, ~20% ảnh trong nhóm mất mà không ai hay - xem
 * `download-image.ts` về lý do log phải ở mức WARN.
 *
 * `download` và `choThuLaiMs` tiêm được để test không cần mạng/không phải chờ.
 */
export async function persistBatchImages(
  accountId: string,
  messages: PersistableMessage[],
  download: ImageDownloader = downloadImage,
  choThuLaiMs: number = CHO_THU_LAI_MS,
): Promise<void> {
  for (const msg of messages) {
    for (const [index, image] of msg.images.entries()) {
      try {
        const cacUrl = [image.url, image.url, ...(image.fallbackUrls?.slice(0, 1) ?? [])];
        let downloaded: DownloadedImage | null = null;
        for (const [lan, url] of cacUrl.entries()) {
          if (lan === 1) await new Promise((r) => setTimeout(r, choThuLaiMs));
          // downloadImage thật không ném, nhưng downloader tiêm vào có thể - coi
          // lỗi ném ra như một lần thử hỏng để vẫn được thử lại
          downloaded = await download(url).catch(() => null);
          if (downloaded) break;
        }
        if (!downloaded) {
          log.warn(
            { accountId, threadId: msg.threadId, msgId: msg.msgId, soLanThu: cacUrl.length },
            "Không lưu được ảnh sau khi đã thử lại",
          );
          continue;
        }
        const ext = EXT_BY_MEDIA_TYPE[downloaded.mediaType.split(";")[0]!.trim()] ?? "jpg";
        const relPath = [
          "media",
          sanitizeSegment(accountId),
          sanitizeSegment(msg.threadId),
          `${sanitizeSegment(msg.msgId)}-${index}.${ext}`,
        ].join("/");
        const absPath = path.join(dataDir, relPath);
        fs.mkdirSync(path.dirname(absPath), { recursive: true });
        fs.writeFileSync(absPath, downloaded.data);
        image.localPath = relPath;

        // Ảnh là khoản token đắt nhất mỗi lượt - log kích thước thật + ước
        // lượng token để đo được ngay khi đổi ZALO_IMAGE_QUALITY, khỏi đoán
        const size = readImageSize(downloaded.data);
        log.info(
          {
            accountId,
            relPath,
            kb: Math.round(downloaded.data.length / 1024),
            ...(size
              ? { size: `${size.width}x${size.height}`, tokenUocLuong: estimateImageTokens(size.width, size.height) }
              : {}),
          },
          "Đã lưu ảnh nhận được",
        );
      } catch (err) {
        log.warn({ accountId, msgId: msg.msgId, err }, "Không lưu được ảnh - bỏ qua");
      }
    }
  }
}

/**
 * Ghi chú nối vào chữ trong history khi có ảnh KHÔNG lưu được. Không có nó thì
 * history chỉ ghi "[gửi kèm 1 ảnh]" y như ảnh bình thường, model không biết ảnh
 * đã mất nên khi bị hỏi đã BỊA lý do ("Zalo chỉ truyền được ký hiệu văn bản",
 * 2026-09-21) - cùng lớp bệnh với vụ tự bịa lý do khi thiếu ảnh/số trang.
 */
export function ghiChuAnhLoi(images: { localPath?: string }[]): string {
  const loi = images.filter((i) => !i.localPath).length;
  return loi > 0 ? ` [${loi} ảnh không tải về được nên bạn KHÔNG xem được nội dung ảnh này]` : "";
}

/** Đường dẫn các ảnh đã lưu thành công của 1 tin - để ghi vào cột images */
export function imagePathsOf(images: { localPath?: string }[]): string[] {
  return images.map((i) => i.localPath).filter((p): p is string => Boolean(p));
}

export type TranscribableMessage = { voiceUrl?: string; text: string };
export type AudioDownloader = (url: string) => Promise<DownloadedAudio | null>;
export type Transcriber = typeof transcribeAudio;

/**
 * Phiên âm tin nhắn THOẠI của cả batch, GHI ĐÈ `msg.text` bằng transcript (hoặc
 * 1 câu thông báo nếu không phiên âm được) - khác `persistBatchImages` (chỉ
 * gắn thêm `localPath`, không đổi nội dung tin), vì STT thay THẾ hẳn cách agent
 * hiểu tin này: sau bước này, tin thoại đi đúng đường 1 tin CHỮ bình thường
 * qua `buildCurrentTurnContent`/`historyToModelMessages` - không có "khối nội
 * dung audio" nào khác cần dựng thêm.
 *
 * Lỗi ở TỪNG tin không được làm hỏng cả batch (đúng nguyên tắc `persistBatchImages`):
 * bọc try/catch quanh mỗi tin, lỗi thì rơi về câu thông báo thay vì văng lên
 * `xuLyLuot`. Không throw bao giờ nên caller fire-and-forget/await tuỳ ý.
 *
 * `download`/`transcribe` tiêm được để test không chạm mạng thật.
 */
export async function transcribeBatchVoice(
  agent: Pick<AgentProfile, "sttBaseUrl" | "sttModel" | "sttApiKey" | "sttEnabled">,
  messages: TranscribableMessage[],
  download: AudioDownloader = downloadAudio,
  transcribe: Transcriber = transcribeAudio,
): Promise<void> {
  const cfg = { baseUrl: agent.sttBaseUrl, model: agent.sttModel, apiKey: agent.sttApiKey ?? "" };
  const daCauHinh = isSttConfigured(cfg);

  for (const msg of messages) {
    if (!msg.voiceUrl) continue;

    // Nút gạt tắt: KHÔNG xoá cấu hình, chỉ tạm ngưng - vẫn phải BÁO chứ không
    // im lặng bỏ qua (cùng lý do "chưa cấu hình" bên dưới).
    if (!agent.sttEnabled) {
      msg.text = "[Tin nhắn thoại - tính năng phiên âm (STT) đang TẮT cho agent này]";
      continue;
    }

    if (!daCauHinh) {
      msg.text = "[Tin nhắn thoại - chưa cấu hình Speech to Text cho agent này]";
      continue;
    }

    try {
      const downloaded = await download(msg.voiceUrl);
      if (!downloaded) {
        msg.text = "[Tin nhắn thoại - không tải được file âm thanh]";
        continue;
      }
      const transcript = (await transcribe(downloaded.data, downloaded.fileName, cfg)).trim();
      msg.text = transcript || "[Tin nhắn thoại - không nghe rõ nội dung]";
      log.info({ chars: transcript.length }, "Đã phiên âm tin nhắn thoại");
    } catch (err) {
      log.debug({ err }, "Lỗi phiên âm tin nhắn thoại - bỏ qua");
      msg.text = "[Tin nhắn thoại - lỗi phiên âm, xem log terminal]";
    }
  }
}

export type ReadableDocMessage = { documentUrl?: string; documentFileName?: string; text: string };
export type DocumentDownloader = (url: string) => Promise<DownloadedDocument | null>;
export type DocumentExtractor = typeof extractDocumentText;

/**
 * Trích chữ từ file người dùng gửi (PDF/Word/Excel/PowerPoint) của cả batch,
 * GHI ĐÈ `msg.text` - cùng vai trò với `transcribeBatchVoice` (mirror kiến
 * trúc: pipeline nhận diện, tải, xử lý, cập nhật msg.text để đi đúng đường tin
 * CHỮ bình thường). KHÔNG cần cấu hình per-agent (không gọi API ngoài, đọc
 * local) - khác STT, nên luôn bật cho mọi agent, không có nút gạt tắt.
 *
 * Đuôi file lấy từ `msg.documentFileName` (đã được `parseIncomingMessage` ưu
 * tiên đọc từ `propertyExt.ext`, đáng tin hơn tên hiển thị) - KHÔNG lấy từ tên
 * file sau khi tải về (`downloaded.fileName` suy từ URL CDN, thường không giữ
 * đúng đuôi gốc).
 *
 * Lỗi ở TỪNG tin không được làm hỏng cả batch (đúng nguyên tắc
 * `persistBatchImages`/`transcribeBatchVoice`): bọc try/catch quanh mỗi tin.
 *
 * `download`/`extract` tiêm được để test không chạm mạng/file thật.
 */
export async function readBatchDocuments(
  messages: ReadableDocMessage[],
  download: DocumentDownloader = downloadDocument,
  extract: DocumentExtractor = extractDocumentText,
): Promise<void> {
  for (const msg of messages) {
    if (!msg.documentUrl) continue;
    const ten = msg.documentFileName || "tài liệu";

    const ext = extensionFromFileName(msg.documentFileName ?? "");
    if (!isSupportedDocumentExtension(ext)) {
      msg.text = `[File .${ext || "?"} - định dạng chưa hỗ trợ đọc]`;
      continue;
    }

    try {
      const downloaded = await download(msg.documentUrl);
      if (!downloaded) {
        msg.text = `[File ${ten} - không tải được]`;
        continue;
      }
      const text = (await extract(downloaded.data, ext)).trim();
      msg.text =
        text ||
        (ext === "pdf"
          ? `[File PDF ${ten} - không có lớp chữ (có thể là bản scan/ảnh chụp), bot chưa đọc được nội dung dạng này]`
          : `[File ${ten} - không có nội dung chữ]`);
      log.info({ ext, chars: text.length }, "Đã đọc file đính kèm");
    } catch (err) {
      log.debug({ err }, "Lỗi đọc file đính kèm - bỏ qua");
      msg.text = `[File ${ten} - lỗi đọc nội dung, xem log terminal]`;
    }
  }
}

/**
 * Đọc ảnh đã lưu theo đường dẫn tương đối trong DB. File mất (đã bị dọn theo
 * MEDIA_RETENTION_DAYS) hoặc đường dẫn thoát khỏi data/media đều trả null.
 */
/**
 * Xóa toàn bộ ảnh đã tải của MỘT thread, trả về danh sách `relPath` vừa xóa.
 *
 * Trả danh sách chứ không trả số lượng vì `image_descriptions` khóa theo
 * `rel_path` và KHÔNG có cột account/thread - đây là đường duy nhất biết được
 * mô tả nào thuộc thread nào. Nên phải liệt kê TRƯỚC khi xóa thư mục; đảo thứ
 * tự là mất dấu và mô tả ảnh nằm lại vĩnh viễn.
 *
 * Dùng đúng `sanitizeSegment` của đường ghi, không tự ghép tay: lệch một phép
 * chuẩn hóa là xóa nhầm thư mục khác hoặc không xóa gì mà vẫn báo thành công.
 */
export function xoaMediaCuaThread(accountId: string, threadId: string): string[] {
  const thuMuc = path.join(mediaDir, sanitizeSegment(accountId), sanitizeSegment(threadId));
  let ten: string[] = [];
  try {
    ten = fs.readdirSync(thuMuc, { withFileTypes: true }).filter((e) => e.isFile()).map((e) => e.name);
  } catch {
    // Thread chưa từng có ảnh thì không có thư mục - không phải lỗi
    return [];
  }

  const relPaths = ten.map((n) =>
    ["media", sanitizeSegment(accountId), sanitizeSegment(threadId), n].join("/"),
  );
  try {
    fs.rmSync(thuMuc, { recursive: true, force: true });
  } catch (err) {
    // Xóa file hỏng (file đang mở, quyền) KHÔNG được làm hỏng cả lượt xóa: phần
    // trong DB mới là thứ quyết định bot còn nhớ gì
    log.warn({ err, accountId, threadId }, "Không xóa được thư mục ảnh của thread");
  }
  return relPaths;
}

export function loadStoredImage(relPath: string): { base64: string; mediaType: string } | null {
  try {
    const absPath = path.resolve(dataDir, relPath);
    if (!absPath.startsWith(mediaDir + path.sep)) return null;
    const data = fs.readFileSync(absPath);
    const ext = path.extname(absPath).slice(1).toLowerCase();
    return { base64: data.toString("base64"), mediaType: MEDIA_TYPE_BY_EXT[ext] ?? "image/jpeg" };
  } catch {
    return null;
  }
}

/** Xóa file media cũ hơn MEDIA_RETENTION_DAYS + gỡ thư mục rỗng. Trả về số file đã xóa. */
export function cleanupExpiredMedia(): number {
  const cutoff = Date.now() - getTuning("MEDIA_RETENTION_DAYS") * 24 * 60 * 60 * 1000;
  return removeExpiredIn(mediaDir, cutoff);
}

function removeExpiredIn(dir: string, cutoff: number): number {
  let removed = 0;
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return 0; // thư mục chưa tồn tại (chưa nhận ảnh nào)
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    try {
      if (entry.isDirectory()) {
        removed += removeExpiredIn(full, cutoff);
        if (fs.readdirSync(full).length === 0) fs.rmdirSync(full);
      } else if (fs.statSync(full).mtimeMs < cutoff) {
        fs.unlinkSync(full);
        removed++;
      }
    } catch (err) {
      log.debug({ file: full, err }, "Không dọn được file media - bỏ qua");
    }
  }
  return removed;
}

/** Dọn ngay lúc gọi + lặp lại mỗi 24h */
export function startMediaCleanupSchedule(): void {
  // Callback phải ĐỒNG BỘ: startDailyTask bọc try/catch quanh lời gọi, hàm
  // async thì promise reject lọt ra ngoài thành unhandled rejection
  startDailyTask("media-cleanup", () => {
    const removed = cleanupExpiredMedia();
    // Mô tả ảnh của sidecar dọn cùng nhịp: quá hạn thì cả pixel lẫn mô tả cùng đi
    const prunedDescriptions = pruneExpiredImageDescriptions(getTuning("MEDIA_RETENTION_DAYS"));
    // Trace step agent dọn cùng nhịp - bảng phình nhanh nhất trong DB
    const prunedTraces = pruneOldTraces();
    if (removed > 0 || prunedDescriptions > 0 || prunedTraces > 0) {
      log.info(
        { removed, prunedDescriptions, prunedTraces },
        "Đã dọn file media + mô tả ảnh + trace hết hạn",
      );
    }
  });
}
