import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

// Store mở SQLite lúc import theo DATA_DIR -> setupTestEnv trước, import động sau
let dataDir: string;
let threads: typeof import("./thread-store.js");
let history: typeof import("./history-store.js");
let database: typeof import("./database.js");
let agentStore: typeof import("../config/agent-store.js");

before(async () => {
  dataDir = setupTestEnv();
  threads = await import("./thread-store.js");
  history = await import("./history-store.js");
  database = await import("./database.js");
  agentStore = await import("../config/agent-store.js");
});

after(() => {
  history.closeHistoryStore();
  cleanupTestEnv(dataDir);
});

const activity = (threadId: string, overrides: Record<string, string> = {}) => ({
  accountId: "acc-1",
  threadId,
  threadType: 0,
  displayName: overrides.displayName ?? "Hải",
  lastSenderName: overrides.lastSenderName ?? "Hải",
});

describe("thread-store", () => {
  it("upsert tạo thread mới rồi tăng message_count các lần sau", () => {
    threads.recordThreadActivity(activity("t-dem"));
    threads.recordThreadActivity(activity("t-dem"));
    threads.recordThreadActivity(activity("t-dem"));

    const rows = threads.listThreads({ accountId: "acc-1", query: "t-dem" });
    assert.equal(rows.length, 1);
    assert.equal(rows[0]!.messageCount, 3);
    assert.equal(rows[0]!.displayName, "Hải");
  });

  it("displayName rỗng không ghi đè tên đã có", () => {
    threads.recordThreadActivity(activity("t-ten", { displayName: "Nhóm Gia Đình" }));
    threads.recordThreadActivity(activity("t-ten", { displayName: "" }));

    const rows = threads.listThreads({ accountId: "acc-1", query: "t-ten" });
    assert.equal(rows[0]!.displayName, "Nhóm Gia Đình");
  });

  it("thread chưa từng thấy mặc định bot bật", () => {
    assert.equal(threads.isBotEnabled("acc-1", "t-chua-co"), true);
  });

  it("tắt rồi bật lại bot cho thread", () => {
    threads.recordThreadActivity(activity("t-toggle"));

    assert.equal(threads.setBotEnabled("acc-1", "t-toggle", false), true);
    assert.equal(threads.isBotEnabled("acc-1", "t-toggle"), false);

    assert.equal(threads.setBotEnabled("acc-1", "t-toggle", true), true);
    assert.equal(threads.isBotEnabled("acc-1", "t-toggle"), true);
  });

  it("setBotEnabled trả false với thread không tồn tại", () => {
    assert.equal(threads.setBotEnabled("acc-1", "t-khong-ton-tai", false), false);
  });

  it("hasDisplayName + setThreadDisplayName cho group lấy tên async", () => {
    threads.recordThreadActivity({ ...activity("t-group"), displayName: "" });
    assert.equal(threads.hasDisplayName("acc-1", "t-group"), false);

    threads.setThreadDisplayName("acc-1", "t-group", "Nhóm Dev");
    assert.equal(threads.hasDisplayName("acc-1", "t-group"), true);
  });

  it("backfill dựng threads từ messages cũ, không chạy lại khi đã có dữ liệu", () => {
    // threads đã có dữ liệu từ các test trên -> backfill phải no-op
    assert.equal(threads.backfillThreadsFromMessages(), 0);
  });

  // ===== Ma trận phân quyền theo liên hệ (mỗi thread một chính sách riêng) =====

  it("mentionOverride mặc định null (theo account); set rồi đọc lại đúng giá trị", () => {
    threads.recordThreadActivity(activity("t-mention"));
    assert.equal(threads.getThreadMentionOverride("acc-1", "t-mention"), null);

    assert.equal(threads.setThreadMentionOverride("acc-1", "t-mention", "no_require"), true);
    assert.equal(threads.getThreadMentionOverride("acc-1", "t-mention"), "no_require");

    assert.equal(threads.setThreadMentionOverride("acc-1", "t-mention", null), true);
    assert.equal(threads.getThreadMentionOverride("acc-1", "t-mention"), null);
  });

  it("setThreadMentionOverride trả false với thread không tồn tại", () => {
    assert.equal(threads.setThreadMentionOverride("acc-1", "t-khong-ton-tai-2", "require"), false);
  });

  it("threadDisabledTools mặc định rỗng; set rồi đọc lại đúng danh sách", () => {
    threads.recordThreadActivity(activity("t-tools"));
    assert.deepEqual(threads.getThreadDisabledTools("acc-1", "t-tools"), []);

    assert.equal(
      threads.setThreadDisabledTools("acc-1", "t-tools", ["create_image", "send_file"]),
      true,
    );
    assert.deepEqual(
      threads.getThreadDisabledTools("acc-1", "t-tools").sort(),
      ["create_image", "send_file"],
    );
  });

  it("privacyTier mặc định 'normal'; set rồi đọc lại đúng giá trị", () => {
    threads.recordThreadActivity(activity("t-privacy"));
    assert.equal(threads.getThreadPrivacyTier("acc-1", "t-privacy"), "normal");

    assert.equal(threads.setThreadPrivacyTier("acc-1", "t-privacy", "restricted"), true);
    assert.equal(threads.getThreadPrivacyTier("acc-1", "t-privacy"), "restricted");
  });

  it("listThreads trả đủ 3 trường ma trận cho UI dựng bảng", () => {
    threads.recordThreadActivity(activity("t-full-row"));
    threads.setThreadMentionOverride("acc-1", "t-full-row", "require");
    threads.setThreadDisabledTools("acc-1", "t-full-row", ["create_image"]);
    threads.setThreadPrivacyTier("acc-1", "t-full-row", "restricted");

    const rows = threads.listThreads({ accountId: "acc-1", query: "t-full-row" });
    assert.equal(rows[0]!.mentionOverride, "require");
    assert.deepEqual(rows[0]!.disabledTools, ["create_image"]);
    assert.equal(rows[0]!.privacyTier, "restricted");
  });

  it("setThreadPermissions ghi cả 4 trường (3 quyền + agentId) trong một giao dịch", () => {
    threads.recordThreadActivity(activity("t-matrix"));
    agentStore.createAgent({ id: "agent-matrix", name: "Agent ma trận" });

    const ok = threads.setThreadPermissions({
      accountId: "acc-1",
      threadId: "t-matrix",
      botEnabled: false,
      mentionOverride: "no_require",
      disabledTools: ["create_image", "create_image"], // trùng phải dedup
      privacyTier: "restricted",
      agentId: "agent-matrix",
    });

    assert.equal(ok, true);
    assert.equal(threads.isBotEnabled("acc-1", "t-matrix"), false);
    assert.equal(threads.getThreadMentionOverride("acc-1", "t-matrix"), "no_require");
    assert.deepEqual(threads.getThreadDisabledTools("acc-1", "t-matrix"), ["create_image"]);
    assert.equal(threads.getThreadPrivacyTier("acc-1", "t-matrix"), "restricted");
    assert.equal(threads.getThreadAgentId("acc-1", "t-matrix"), "agent-matrix");
  });

  it("setThreadPermissions KHÔNG truyền agentId thì không đụng agent hiện có của thread", () => {
    threads.recordThreadActivity(activity("t-matrix-2"));
    threads.setThreadAgentId("acc-1", "t-matrix-2", "agent-cu");

    threads.setThreadPermissions({
      accountId: "acc-1",
      threadId: "t-matrix-2",
      botEnabled: true,
      mentionOverride: null,
      disabledTools: [],
      privacyTier: "normal",
    });

    assert.equal(threads.getThreadAgentId("acc-1", "t-matrix-2"), "agent-cu");
  });

  it("setThreadPermissions trả false với thread không tồn tại", () => {
    const ok = threads.setThreadPermissions({
      accountId: "acc-1",
      threadId: "t-khong-ton-tai-3",
      botEnabled: true,
      mentionOverride: null,
      disabledTools: [],
      privacyTier: "normal",
    });
    assert.equal(ok, false);
  });

  it("dữ liệu quyền của thread hỏng phải fail-closed thay vì mở quyền", () => {
    threads.recordThreadActivity(activity("t-corrupt"));
    database.db.prepare(`
      UPDATE threads
      SET mention_override = 'gia-tri-la',
          disabled_tools = '{json-hong',
          privacy_tier = 'gia-tri-la'
      WHERE account_id = 'acc-1' AND thread_id = 't-corrupt'
    `).run();

    // mention_override lạ -> coi như "require" (đòi @mention, chặt hơn null)
    assert.equal(threads.getThreadMentionOverride("acc-1", "t-corrupt"), "require");
    // disabled_tools không parse được JSON -> sentinel khóa toàn bộ tool
    assert.deepEqual(
      threads.getThreadDisabledTools("acc-1", "t-corrupt"),
      ["__deny_all_thread_tools__"],
    );
    // privacy_tier lạ -> coi như "restricted" (chặt hơn "normal")
    assert.equal(threads.getThreadPrivacyTier("acc-1", "t-corrupt"), "restricted");
  });
});

describe("listThreads lọc theo loại cuộc chat", () => {
  it("chỉ chat riêng, chỉ nhóm, hoặc cả hai", () => {
    threads.recordThreadActivity({ ...activity("t-loai-dm"), accountId: "acc-loai" });
    threads.recordThreadActivity({ ...activity("t-loai-nhom"), accountId: "acc-loai", threadType: 1 });
    const ids = (threadType?: 0 | 1) => threads.listThreads({ accountId: "acc-loai", threadType }).map((t) => t.threadId).sort();
    assert.deepEqual(ids(), ["t-loai-dm", "t-loai-nhom"]);
    assert.deepEqual(ids(0), ["t-loai-dm"]);
    assert.deepEqual(ids(1), ["t-loai-nhom"]);
  });
});
