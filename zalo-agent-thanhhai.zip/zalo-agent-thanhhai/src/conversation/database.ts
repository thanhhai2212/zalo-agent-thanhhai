import path from "node:path";
// Dùng SQLite built-in của Node (>= 22.13) - không cần native build (better-sqlite3
// yêu cầu Visual Studio Build Tools trên Windows). 1 connection dùng chung cho
// mọi store (history/thread/contact/usage) - node:sqlite là sync nên không cần pool.
import { DatabaseSync } from "node:sqlite";
import { dataDir } from "../config/env.js";
import { taoBangKnowledgeBase } from "../knowledge/kb-schema.js";
import { taoBangMcp } from "../mcp/mcp-schema.js";
import { taoBangDangBaiNhom } from "../group-posts/gp-schema.js";
import { taoBangSecondBrain } from "../second-brain/sb-schema.js";

export const db = new DatabaseSync(path.join(dataDir, "zalo-agent.db"));
db.exec("PRAGMA journal_mode = WAL;");
/**
 * `NORMAL` chứ không phải mặc định `FULL`.
 *
 * `node:sqlite` chạy ĐỒNG BỘ trong tiến trình một luồng, nên mỗi lần ghi là
 * chặn cả bot: không nhận tin mới, không chạy lượt nào khác, không phục vụ
 * dashboard. `FULL` bắt fsync ở MỌI commit, và đo thật trên máy dev:
 *
 *     synchronous=FULL      1.884 us / INSERT
 *     synchronous=NORMAL       37 us / INSERT
 *
 * Gấp 50 lần, và mỗi lượt trả lời ghi vài dòng (tin đến, tin trả lời, usage,
 * trace). Nhiều hội thoại nhắn cùng lúc thì các lần chặn đó cộng dồn.
 *
 * Đánh đổi: đi kèm WAL, `NORMAL` vẫn an toàn tuyệt đối khi tiến trình chết
 * (crash, kill, hết bộ nhớ) - WAL còn nguyên và phục hồi đủ. Chỉ khi MẤT ĐIỆN
 * đột ngột hay OS sập mới có thể mất vài giao dịch cuối. DB không bao giờ hỏng
 * ở cả hai mức. Với bot chat cá nhân, mất vài tin cuối lúc cúp điện là chấp
 * nhận được; treo cả bot 2ms mỗi lần ghi thì không.
 */
db.exec("PRAGMA synchronous = NORMAL;");

runMigrations();

function runMigrations(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
      sender_name TEXT,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS idx_messages_account_thread
      ON messages (account_id, thread_id, id);

    CREATE TABLE IF NOT EXISTS threads (
      account_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      thread_type INTEGER NOT NULL,
      display_name TEXT NOT NULL DEFAULT '',
      bot_enabled INTEGER NOT NULL DEFAULT 1,
      message_count INTEGER NOT NULL DEFAULT 0,
      last_message_at TEXT,
      last_sender_name TEXT,
      PRIMARY KEY (account_id, thread_id)
    );

    CREATE TABLE IF NOT EXISTS contacts (
      account_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      display_name TEXT NOT NULL DEFAULT '',
      first_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      last_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      message_count INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (account_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS runtime_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    -- Não của bot: persona + model override, gắn vào account qua accounts.agent_id.
    -- DB là source of truth (config/accounts.json chỉ seed 1 lần đầu).
    CREATE TABLE IF NOT EXISTS agents (
      id TEXT PRIMARY KEY,
      icon TEXT NOT NULL DEFAULT '🤖',
      name TEXT NOT NULL,
      persona TEXT NOT NULL DEFAULT '',
      model_provider TEXT,
      model_name TEXT,
      max_steps INTEGER,
      is_default INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    -- Tài khoản Zalo (kênh): policies + gắn não. N account dùng chung 1 agent được.
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY,
      label TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,
      agent_id TEXT NOT NULL,
      allowlist_mode TEXT NOT NULL DEFAULT 'all' CHECK (allowlist_mode IN ('all', 'list')),
      allowlist_user_ids TEXT NOT NULL DEFAULT '[]',
      group_require_mention INTEGER NOT NULL DEFAULT 1,
      respond_to_groups INTEGER NOT NULL DEFAULT 1,
      group_passive_listen INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    -- Memory lớp 3: fact bền do agent tự lưu qua tool save_memory.
    -- learned_in_group quyết định quy tắc inject bất đối xứng (private không ra public)
    CREATE TABLE IF NOT EXISTS memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id TEXT NOT NULL,
      subject_id TEXT NOT NULL,
      content TEXT NOT NULL,
      learned_in_thread_id TEXT NOT NULL,
      learned_in_group INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS idx_memories_account_subject
      ON memories (account_id, subject_id, id);

    -- Phiên đăng nhập dashboard. Có bản ghi thật thì logout mới thu hồi được
    -- (token HMAC stateless không xóa được), và password_fingerprint cho phép
    -- đổi DASHBOARD_PASSWORD là mọi phiên cũ hết hiệu lực ngay.
    CREATE TABLE IF NOT EXISTS dashboard_sessions (
      id TEXT PRIMARY KEY,
      secret_hash TEXT NOT NULL,
      password_fingerprint TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    );

    -- Cache mô tả ảnh do vision sidecar sinh ra (khi model chính không đọc được
    -- ảnh). Key theo đường dẫn file trong data/media - mỗi ảnh chỉ mô tả 1 lần.
    CREATE TABLE IF NOT EXISTS image_descriptions (
      rel_path TEXT PRIMARY KEY,
      description TEXT NOT NULL,
      model TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS agent_turns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      input_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      total_tokens INTEGER NOT NULL DEFAULT 0,
      steps INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS idx_agent_turns_account_created
      ON agent_turns (account_id, created_at);

    -- Trace từng step của lượt agent: model nói gì, gọi tool nào với tham số
    -- gì, provider cảnh báo gì. Không có bảng này thì bot trả lời sai chỉ còn
    -- cách suy luận ngược từ câu lỗi (đã dính vụ dò vé số và vụ imageIndex).
    -- Bảng này phình nhanh nhất trong DB nên có dọn theo AGENT_TRACE_RETENTION_DAYS.
    CREATE TABLE IF NOT EXISTS agent_steps (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      turn_id INTEGER NOT NULL,
      step_number INTEGER NOT NULL,
      text TEXT NOT NULL DEFAULT '',
      reasoning TEXT NOT NULL DEFAULT '',
      tool_calls TEXT NOT NULL DEFAULT '[]',
      tool_results TEXT NOT NULL DEFAULT '[]',
      finish_reason TEXT NOT NULL DEFAULT '',
      warnings TEXT NOT NULL DEFAULT '[]',
      input_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS idx_agent_steps_turn ON agent_steps (turn_id, step_number);
    CREATE INDEX IF NOT EXISTS idx_agent_steps_created ON agent_steps (created_at);

    -- Lịch hẹn: trạng thái HIỆN TẠI của từng job (bot tự nhắn theo lịch).
    -- Tách khỏi scheduled_job_runs (bảng NGAY DƯỚI) vì last_status ở đây chỉ
    -- nói lần chạy CUỐI - job hỏng 5 lần rồi lần 6 chạy được sẽ trông khoẻ
    -- mạnh hoàn hảo nếu không có log riêng kể lại từng lần.
    CREATE TABLE IF NOT EXISTS scheduled_jobs (
      id TEXT PRIMARY KEY,
      account_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      thread_type INTEGER NOT NULL,
      name TEXT NOT NULL,
      kind TEXT NOT NULL CHECK (kind IN ('message', 'agent')),
      payload TEXT NOT NULL,
      schedule_kind TEXT NOT NULL CHECK (schedule_kind IN ('once', 'every', 'cron')),
      run_at TEXT,
      every_minutes INTEGER,
      cron_expr TEXT,
      -- Rỗng = hiểu theo BOT_TIMEZONE tại thời điểm CHẠY (đổi cấu hình là job
      -- đổi theo ngay); có giá trị = job pin cứng đúng zone này bất kể sau
      -- này BOT_TIMEZONE đổi ra sao.
      timezone TEXT NOT NULL DEFAULT '',
      enabled INTEGER NOT NULL DEFAULT 1,
      next_run_at TEXT,
      last_run_at TEXT,
      last_status TEXT,
      last_error TEXT,
      run_count INTEGER NOT NULL DEFAULT 0,
      -- NULL = vô hạn; 'once' mặc định 1. Chạm mức này thì enabled=0 và
      -- next_run_at=NULL nhưng GIỮ NGUYÊN row - xoá hẳn (như Hermes/goclaw)
      -- làm lời nhắc đã hẹn biến mất không dấu vết.
      max_runs INTEGER,
      created_by TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    -- Vòng tick quét job đến hạn: WHERE enabled = 1 AND next_run_at <= now
    CREATE INDEX IF NOT EXISTS idx_scheduled_jobs_due ON scheduled_jobs (enabled, next_run_at);
    -- Tool list/cancel/update chỉ được thấy job của đúng (account, thread) đang chat
    CREATE INDEX IF NOT EXISTS idx_scheduled_jobs_thread ON scheduled_jobs (account_id, thread_id);

    -- Sổ ghi ĐÃ XẢY RA GÌ ở từng lần job chạy - khác scheduled_jobs.last_status
    -- vốn chỉ nói lần cuối. turn_id nối sang agent_turns cho job kind='agent',
    -- bấm thẳng sang trang Trace khi cần biết vì sao job trả lời sai.
    CREATE TABLE IF NOT EXISTS scheduled_job_runs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id TEXT NOT NULL,
      turn_id INTEGER,
      status TEXT NOT NULL CHECK (status IN ('running', 'ok', 'silent', 'skipped', 'error', 'interrupted')),
      detail TEXT NOT NULL DEFAULT '',
      delivered_chars INTEGER NOT NULL DEFAULT 0,
      started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      finished_at TEXT
    );
    -- Lịch sử của 1 job, mới nhất trước; dọn quá SCHEDULER_RUN_LOG_KEEP theo job_id
    CREATE INDEX IF NOT EXISTS idx_scheduled_job_runs_job ON scheduled_job_runs (job_id, id DESC);

    -- Đếm tin CHỦ ĐỘNG đã gửi mỗi (account, thread, ngày VN) cho trần
    -- SCHEDULER_MAX_PROACTIVE_PER_DAY - bền qua restart. CỐ Ý không đếm từ
    -- scheduled_job_runs: bảng đó bị prune xuống SCHEDULER_RUN_LOG_KEEP dòng
    -- MỖI JOB ngay mỗi lần mở lượt, nên 1 job dày (vd every 5 phút) làm dòng
    -- 'ok' buổi sáng bị xoá trong vài giờ - đếm lại tụt về 0 giữa ngày.
    CREATE TABLE IF NOT EXISTS proactive_send_counters (
      account_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      day_key TEXT NOT NULL,
      count INTEGER NOT NULL DEFAULT 0,
      notice_sent INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      PRIMARY KEY (account_id, thread_id, day_key)
    );

    -- Sổ ghi mọi lần bot CÂN NHẮC kick 1 tài khoản dồn dập/spam trong nhóm
    -- (group-flood-kick-scheduler.ts) - bền qua restart để chủ bot xem lại
    -- được khi không trực 24/7. Khác bộ đếm dồn dập (chỉ sống trong bộ nhớ,
    -- cửa sổ vài giây/phút nên restart xoá là chấp nhận được) - đây là NHẬT KÝ
    -- hành động thật đã/định thực hiện, phải bền.
    CREATE TABLE IF NOT EXISTS flood_kick_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      target_user_id TEXT NOT NULL,
      target_name TEXT NOT NULL DEFAULT '',
      message_count INTEGER NOT NULL,
      window_seconds INTEGER NOT NULL,
      vetoed INTEGER NOT NULL DEFAULT 0,
      veto_by_user_id TEXT,
      executed INTEGER NOT NULL DEFAULT 0,
      error TEXT,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      executed_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_flood_kick_log_account_thread
      ON flood_kick_log (account_id, thread_id, id DESC);

    -- Nhật ký bộ tự đánh giá tin nhóm (src/group-judge/): MỌI quyết định, kể cả
    -- im lặng, để chủ bot xem lại vì sao bot nói hoặc không nói. Chỉ giữ trích
    -- đoạn ngắn của tin; dọn theo tuổi + số dòng mỗi nhóm (judge-log-store.ts).
    CREATE TABLE IF NOT EXISTS group_judge_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id TEXT NOT NULL,
      thread_id TEXT NOT NULL,
      sender_id TEXT NOT NULL DEFAULT '',
      sender_name TEXT NOT NULL DEFAULT '',
      excerpt TEXT NOT NULL DEFAULT '',
      mode TEXT NOT NULL,
      stage TEXT NOT NULL,
      decision TEXT NOT NULL,
      reason TEXT NOT NULL DEFAULT '',
      scores TEXT,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS idx_group_judge_log_thread
      ON group_judge_log (account_id, thread_id, id DESC);
  `);

  // Tool CHẠY LỖI: AI SDK để chúng ở content dạng tool-error, không vào
  // toolResults, nên trước cột này mọi lần tool hỏng đều mất tăm khỏi trace.
  addColumnIfMissing("agent_steps", "tool_errors", "TEXT NOT NULL DEFAULT '[]'");

  // Lần chạy thứ mấy trong cùng lượt. Không có cột này thì trace của lượt có
  // retry đọc ra 1,1,2,2,3,3 và trông y hệt model lặp vô hạn. Mặc định 1 để
  // mọi dòng ghi trước đây vẫn hợp lệ.
  addColumnIfMissing("agent_steps", "attempt", "INTEGER NOT NULL DEFAULT 1");

  // Mức suy nghĩ riêng cho từng agent (NULL = theo mức mặc định chung)
  addColumnIfMissing("agents", "reasoning_effort", "TEXT");

  // DB tạo trước khi có cột sender_id: ALTER thêm (nullable - tin cũ không có id)
  addColumnIfMissing("messages", "sender_id", "TEXT");
  // Ảnh kèm tin nhắn: JSON array đường dẫn file trong data/media (tương đối DATA_DIR)
  // để lượt sau nạp lại cho model xem; NULL = tin không có ảnh
  addColumnIfMissing("messages", "images", "TEXT");
  // Memory lớp 2: rolling summary per thread
  addColumnIfMissing("threads", "summary", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("threads", "summary_covers_to_message_id", "INTEGER NOT NULL DEFAULT 0");

  // Số lần ngữ cảnh của thread bị xóa sạch. Vào khóa phiên gửi router
  // (`cache-session-id.ts`) để lần xóa nào cũng mở một phiên MỚI - cùng cách
  // goclaw gọi `ResetCLISession` và Hermes xoay `session_id` khi /reset. Không
  // xoay thì router vẫn coi đây là phiên cũ và giữ tiền tố đã cache của cuộc
  // trò chuyện vừa bị xóa. Mặc định 0 để mọi thread cũ giữ nguyên khóa đang có.
  addColumnIfMissing("threads", "context_epoch", "INTEGER NOT NULL DEFAULT 0");

  // Phản hồi tức thì: thả reaction + báo "đang nhập" khi bot bắt đầu xử lý
  addColumnIfMissing("accounts", "auto_react_enabled", "INTEGER NOT NULL DEFAULT 1");
  addColumnIfMissing("accounts", "auto_react_icon", "TEXT NOT NULL DEFAULT 'heart'");
  addColumnIfMissing("accounts", "typing_indicator_enabled", "INTEGER NOT NULL DEFAULT 1");
  // Trang Tools: JSON array key tool bị tắt per account (rỗng = bật hết).
  // Lưu danh sách TẮT thay vì BẬT để tool mới thêm vào code tự bật cho account cũ.
  addColumnIfMissing("accounts", "disabled_tools", "TEXT NOT NULL DEFAULT '[]'");

  // Lớp tool THỨ HAI, theo agent - GIAO với lớp account ở trên, không thay thế.
  // Agent khai NĂNG LỰC (agent này biết làm gì), account áp CHÍNH SÁCH (nick này
  // được phép gì); tool dùng được là phần không bên nào tắt. Nhờ vậy thêm một
  // agent mới không bao giờ nới rộng được quyền của một nick.
  //
  // Cũng lưu danh sách TẮT vì đúng lý do của dòng trên: làm danh sách BẬT thì
  // tool mới thêm vào code sẽ không tự có cho agent cũ.
  addColumnIfMissing("agents", "disabled_tools", "TEXT NOT NULL DEFAULT '[]'");

  // Trần token riêng cho agent này (NULL = theo LLM_CONTEXT_WINDOW ở Cấu hình).
  // Phải nằm ở agent chứ không chỉ ở cấu hình chung: trần phụ thuộc CỬA SỔ của
  // model, mà model đặt được theo từng agent.
  addColumnIfMissing("agents", "context_window", "INTEGER");

  // API key + base URL LLM riêng cho agent này (NULL = dùng cấu hình Providers
  // chung). `model_api_key` lưu ciphertext AES-256-GCM (cùng khóa cookie Zalo) -
  // xem `secret-cipher.ts`. Có 2 cột này thì `model_provider`/`model_name` của
  // agent mới an toàn để đổi khác cấu hình chung - trước đây `doiProviderAnToan`
  // (llm-provider.ts) luôn bỏ qua override lệch vì chưa có khóa riêng để dùng.
  addColumnIfMissing("agents", "model_base_url", "TEXT");
  addColumnIfMissing("agents", "model_api_key", "TEXT");

  // KHÔNG CÒN DÙNG từ 2026-09-25 (đã gỡ tool scrape_social_data - Apify đi qua
  // MCP). Giữ cột để DB cũ vẫn mở được; không đọc/ghi ở đâu nữa.
  // Cấu hình Apify RIÊNG từng agent cho tool scrape_social_data - mỗi "nhân sự"
  // có token + actor riêng, độc lập hoàn toàn (không dùng chung global). Token
  // mã hóa AES-256-GCM; actor ID chỉ là chuỗi định danh công khai nên không mã
  // hóa. Tool chỉ vào schema của agent khi agent này có token + ít nhất 1 actor.
  addColumnIfMissing("agents", "apify_token", "TEXT");
  addColumnIfMissing("agents", "apify_actor_facebook", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "apify_actor_tiktok", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "apify_actor_youtube", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "apify_actor_shopee", "TEXT NOT NULL DEFAULT ''");

  // Cấu hình TTS (text-to-speech) RIÊNG từng agent cho tool create_voice - mỗi
  // "nhân sự" một giọng riêng. tts_api_key mã hóa AES-256-GCM; còn lại là chuỗi
  // thường. Tool chỉ vào schema của agent khi agent có đủ base URL + model + key.
  addColumnIfMissing("agents", "tts_base_url", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "tts_model", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "tts_voice", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "tts_format", "TEXT NOT NULL DEFAULT 'mp3'");
  addColumnIfMissing("agents", "tts_api_key", "TEXT");
  // "openai-compatible" (mặc định, endpoint /v1/audio/speech - Edge TTS qua
  // 9router...) hoặc "elevenlabs" (gọi thẳng api.elevenlabs.io - hình dạng
  // request KHÁC hẳn: header xi-api-key, voice_id nằm trong URL, output_format
  // là query param chứ không phải field trong body) hoặc "vbee" (gọi thẳng
  // api.vbee.vn - BẤT ĐỒNG BỘ: POST tạo request rồi PHẢI poll để lấy audio,
  // khác hẳn 2 provider kia vốn trả audio ngay trong 1 lần gọi). Xem tts-client.ts.
  addColumnIfMissing("agents", "tts_provider", "TEXT NOT NULL DEFAULT 'openai-compatible'");
  // App-Id của Vbee - header riêng "App-Id" đi kèm access_token, KHÔNG dùng
  // cho openai-compatible/elevenlabs nên tách cột riêng thay vì nhét vào
  // tts_model/tts_voice vốn mang ý nghĩa khác ở 2 provider kia.
  addColumnIfMissing("agents", "tts_vbee_app_id", "TEXT NOT NULL DEFAULT ''");

  // Cấu hình tạo NHẠC (music generation) RIÊNG từng agent cho tool
  // create_music - 2 nhà cung cấp hình dạng KHÁC HẲN nhau (xem
  // music-generation-client.ts):
  // - "openrouter" (mặc định, tương thích ngược): google/lyria-3-pro-preview
  //   qua chat completions, modalities:["text","audio"], BẮT BUỘC stream:true.
  //   music_api_key mã hóa AES-256-GCM RIÊNG cho nhánh này.
  // - "google-ai-studio" (2026-09-16): lyria-3-clip-preview (clip 30s) hoặc
  //   lyria-3.5 (bài hát dài vài phút) qua Interactions API - DÙNG CHUNG bộ
  //   key với TTS (tts_api_key, không có cột key riêng) vì cùng 1 tài khoản
  //   Google AI Studio, đỡ người dùng phải dán lại đúng key 2 lần.
  // music_voice để trống = client tự dùng "alloy" (tên voice mặc định của cơ
  // chế audio dùng chung của OpenRouter, không có ý nghĩa với nhạc nhưng API
  // vẫn đòi field này) - KHÔNG dùng cho nhánh google-ai-studio.
  addColumnIfMissing("agents", "music_model", "TEXT NOT NULL DEFAULT 'google/lyria-3-pro-preview'");
  addColumnIfMissing("agents", "music_voice", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "music_format", "TEXT NOT NULL DEFAULT 'wav'");
  addColumnIfMissing("agents", "music_api_key", "TEXT");
  addColumnIfMissing("agents", "music_provider", "TEXT NOT NULL DEFAULT 'openrouter'");
  // Nhà cung cấp video: "openrouter" (Seedance, key riêng) hoặc "grok" (Grok Imagine qua 9Router, dùng key LLM chung).
  addColumnIfMissing("agents", "video_provider", "TEXT NOT NULL DEFAULT 'openrouter'");

  // Cấu hình tạo VIDEO (video generation) RIÊNG từng agent cho tool
  // create_video - gọi bytedance/seedance-2.0-mini qua OpenRouter Video API
  // (POST /v1/videos, BẤT ĐỒNG BỘ giống Vbee: submit rồi poll
  // /v1/videos/{id} tới completed, tải bytes ở /v1/videos/{id}/content - xem
  // video-generation-client.ts). video_api_key mã hóa AES-256-GCM. Tham số
  // sáng tạo (prompt/duration/resolution/aspect_ratio) là input CỦA TOOL, mô
  // hình tự chọn theo ngữ cảnh - không cấu hình cứng ở đây.
  addColumnIfMissing("agents", "video_model", "TEXT NOT NULL DEFAULT 'bytedance/seedance-2.0-mini'");
  addColumnIfMissing("agents", "video_api_key", "TEXT");

  // Cấu hình STT (speech-to-text) RIÊNG từng agent - phiên âm tin nhắn THOẠI
  // người dùng gửi tới thành chữ trước khi đưa vào lượt xử lý (khác TTS: đây
  // là bước TIỀN XỬ LÝ INPUT, không phải tool agent tự gọi). Chỉ 1 nhà cung
  // cấp openai-compatible (POST {baseUrl}/v1/audio/transcriptions, multipart
  // file+model - xem stt-client.ts), không cần cột provider như TTS vì hình
  // dạng request không đổi giữa các nhà cung cấp tương thích OpenAI.
  // stt_api_key mã hóa AES-256-GCM. Agent chưa cấu hình đủ base URL+model+key
  // thì tin thoại vẫn được BÁO chứ không im lặng bỏ qua như trước khi có tính
  // năng này (xem transcribeBatchVoice trong media-store.ts).
  addColumnIfMissing("agents", "stt_base_url", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "stt_model", "TEXT NOT NULL DEFAULT ''");
  addColumnIfMissing("agents", "stt_api_key", "TEXT");
  // Nút gạt bật/tắt RIÊNG, KHÔNG xoá base URL/model/key đã lưu - đổi ý bật lại
  // không phải nhập lại cấu hình. Mặc định BẬT (1): agent đã cấu hình xong từ
  // trước khi có cột này thì hành vi giữ nguyên, không cần backfill gì thêm.
  addColumnIfMissing("agents", "stt_enabled", "INTEGER NOT NULL DEFAULT 1");

  // Lượt do lịch hẹn tự bắn (source='schedule') khác lượt trả lời tin nhắn
  // (source='message') - Overview và trang Trace cần phân biệt được "có người
  // đang chat" với "job tự chạy lúc 3 giờ sáng". Mặc định 'message' để mọi
  // lượt ghi TRƯỚC khi có scheduler vẫn đúng nghĩa, không cần backfill.
  addColumnIfMissing("agent_turns", "source", "TEXT NOT NULL DEFAULT 'message'");

  // Đếm số lần THỬ GỬI THẤT BẠI LIÊN TIẾP (delivery-attempt-store.ts) - job
  // gửi hỏng chỉ bị tiêu suất chạy sau khi chạm MAX_DELIVERY_ATTEMPTS, không
  // phải ngay lần đầu (bất biến "chưa từng gửi được thì không coi là đã
  // chạy"). Mặc định 0 để mọi job cũ coi như chưa từng thử hỏng lần nào.
  addColumnIfMissing("scheduled_jobs", "delivery_attempts", "INTEGER NOT NULL DEFAULT 0");

  // Não RIÊNG cho thread này, thắng agent mặc định của account - để một account
  // (một nick Zalo) có "tính cách" khác nhau ở từng nhóm nó tham gia, thay vì
  // dùng chung một persona cho mọi nhóm. NULL = dùng agent của account như cũ,
  // nên account cũ không cần backfill gì - hành vi giữ nguyên cho tới khi ai đó
  // chủ động gán agent riêng cho một thread trên dashboard.
  addColumnIfMissing("threads", "agent_id", "TEXT");

  // UID Zalo của CHỦ tài khoản - gate cho nhóm tool "moi tin chéo thread"
  // (list_threads, read_thread): chỉ đúng người này, chỉ trong chat riêng, mới
  // được hỏi bot về nội dung nhóm khác. Rỗng = CHƯA cấu hình, tool tự chặn hết
  // (fail-closed) thay vì đoán bừa - từng thấy hai UID khác nhau cùng trùng
  // tên hiển thị trong DB thật, chứng minh không thể suy UID chủ từ tên hiển thị.
  addColumnIfMissing("accounts", "owner_user_id", "TEXT NOT NULL DEFAULT ''");

  // Cho phép bot TỰ ĐỘNG kick tài khoản bị nghi là bot rác/spam dồn dập trong
  // nhóm (group-flood-kick-scheduler.ts) - mặc định TẮT (khác auto_react_enabled
  // ở trên vốn mặc định BẬT) vì đây là hành động khó đảo ngược, ảnh hưởng người
  // thật; chủ tài khoản phải chủ động bật sau khi hiểu rõ rủi ro. Cảnh báo dồn
  // dập (tag admin thật) vẫn LUÔN chạy bất kể cột này, không cần cấu hình.
  addColumnIfMissing("accounts", "auto_kick_flood_enabled", "INTEGER NOT NULL DEFAULT 0");

  // ID của tin THẬT trên Zalo (msgId + cliMsgId server trả về khi gửi), để
  // tool undo_message thu hồi được đúng tin - `api.undo()` của zca-js đòi cả
  // hai giá trị này, không chỉ msgId. Chỉ ghi cho tin role='assistant' gửi qua
  // đường trả lời chat chính (`deliverChatReply`/`sendReplyInParts`); NULL cho
  // mọi tin khác (tin người dùng, tin do tool gửi thẳng qua enqueueSend, hoặc
  // tin gửi trước khi có cột này) - undo_message coi NULL là "không thu hồi
  // được", không đoán bừa. JSON array vì một câu trả lời dài có thể bị cắt
  // thành NHIỀU tin Zalo thật (`chiaTheoNganSachByte`) - thu hồi phải nhắm cả
  // mảng đó chứ không chỉ tin cuối.
  addColumnIfMissing("messages", "sent_msg_ids", "TEXT");

  // Ma trận phân quyền theo liên hệ (trang dashboard "Phân quyền Bot") - BA
  // lớp override riêng cho một thread/liên hệ, cùng cấp với agent_id ở trên
  // (thắng cấu hình chung của account nếu có set), xem thread-store.ts.
  //
  // mention_override: ghi đè "cần @mention mới trả lời" riêng cho 1 nhóm.
  // NULL = theo groupRequireMention của account như trước đây.
  addColumnIfMissing("threads", "mention_override", "TEXT");
  // judge_mode (2026-10-06): bộ TỰ ĐÁNH GIÁ tin nhóm không tag - NULL/'off' = tắt,
  // 'shadow' = chấm và ghi nhật ký nhưng không trả lời, 'on' = trả lời thật.
  // Chỉ có nghĩa khi nhóm đang đòi @mention. Xem src/group-judge/.
  addColumnIfMissing("threads", "judge_mode", "TEXT");
  // disabled_tools: tool bị tắt THÊM riêng cho thread này - PHÉP HỢP với
  // disabledTools của account/agent (applyThreadToolOverride, agent-loop.ts),
  // không bao giờ mở lại tool cấp trên đã khóa. '[]' = không tắt thêm gì.
  addColumnIfMissing("threads", "disabled_tools", "TEXT NOT NULL DEFAULT '[]'");
  // privacy_tier: 'restricted' lọc fact bền khỏi ngữ cảnh (thread-privacy-policy.ts)
  // VÀ khóa cứng save_memory ghi fact mới trong thread này (save-memory-tool.ts).
  addColumnIfMissing("threads", "privacy_tier", "TEXT NOT NULL DEFAULT 'normal'");
  // model_override (2026-09-28): model RIÊNG cho một cuộc chat, cùng router +
  // khóa của cấu hình chung (vd chat riêng của chủ bot chạy Claude, mọi chat
  // khác vẫn model của agent). NULL = model của agent. Xem agent-loop.ts.
  addColumnIfMissing("threads", "model_override", "TEXT");
  // effort_override (2026-10-04): mức suy nghĩ RIÊNG của một cuộc chat, chủ bot
  // đặt bằng lệnh /effort trong chat (owner-chat-commands.ts). NULL = theo agent.
  addColumnIfMissing("threads", "effort_override", "TEXT");
  // video_dm_allowed (2026-09-29): cho RIÊNG người này xin tạo video khi chat riêng
  // với bot (mặc định chỉ trong nhóm) - bật từng liên hệ ở trang Phân quyền Bot.
  addColumnIfMissing("threads", "video_dm_allowed", "INTEGER NOT NULL DEFAULT 0");
  // video_vip (2026-09-29): đặt trên dòng CHAT RIÊNG của người đó (thread_id = UID),
  // nên tra được theo senderId ở cả nhóm lẫn chat riêng.
  addColumnIfMissing("threads", "video_vip", "INTEGER NOT NULL DEFAULT 0");

  // Kho tri thức (kb_search): nguồn tài liệu -> đoạn cắt -> FTS5 bm25 -> gán
  // theo agent. Lược đồ tách sang kb-schema.ts (4 bảng + 1 ALTER) thay vì
  // viết inline như các bảng trên - khối tự đứng độc lập, không san sẻ cột
  // với bảng nào khác trong file này, tách ra giữ đúng tinh thần "dưới 200
  // dòng mỗi file" mà không phải bổ đôi một khối logic đang liền mạch.
  taoBangKnowledgeBase(db);

  // MCP client: server ngoài (URL + headers mã hóa) -> gán theo agent. Lược
  // đồ tách sang mcp-schema.ts, cùng lý do Kho tri thức ở trên.
  taoBangMcp(db);
  // Server MCP đọc dữ liệu nhạy cảm (danh sách khách...) chỉ cho chủ bot trong chat riêng
  addColumnIfMissing("mcp_servers", "chi_chu_bot", "INTEGER NOT NULL DEFAULT 0");
  // Kèm chi_chu_bot: chủ bot dùng được CẢ TRONG NHÓM (chỉ khi mọi tin của lượt đều của chủ bot)
  addColumnIfMissing("mcp_servers", "chu_trong_nhom", "INTEGER NOT NULL DEFAULT 0");
  // Server MCP đăng nhập bằng OAuth (vd Canva) thay vì token dán sẵn. `oauth_ma_hoa` là
  // JSON mã hóa {thông tin client, token, mã xác minh PKCE...} - xem mcp-oauth-store.ts.
  addColumnIfMissing("mcp_servers", "dung_oauth", "INTEGER NOT NULL DEFAULT 0");
  addColumnIfMissing("mcp_servers", "oauth_ma_hoa", "TEXT NOT NULL DEFAULT ''");
  // File bot tạo + sổ đồng bộ Notion - xem second-brain/sb-schema.ts.
  taoBangSecondBrain(db);
  // Đăng bài nhóm (cài đặt nhóm, chủ đề, bài nháp) - xem group-posts/gp-schema.ts.
  taoBangDangBaiNhom(db);

  // Kênh thứ hai: tài khoản Zalo Bot chính thức (bot-api.zaloplatforms.com),
  // KHÁC HẲN Zalo OA API - không có rủi ro khóa tài khoản, đổi lại năng lực
  // hẹp hơn (xem src/zalo-bot/nang-luc-kenh-bot.ts). 'ca_nhan' là giá trị mặc
  // định để mọi account cũ (tạo trước khi có cột này) giữ nguyên hành vi.
  // bot_token_enc mã hóa AES-256-GCM cùng khóa cookie Zalo - '' nghĩa là chưa
  // nhập token, KHÔNG NULL, để `coBotToken` (account-store.ts) so sánh gọn.
  addColumnIfMissing("accounts", "loai", "TEXT NOT NULL DEFAULT 'ca_nhan'");
  addColumnIfMissing("accounts", "bot_token_enc", "TEXT NOT NULL DEFAULT ''");
}

function addColumnIfMissing(table: string, column: string, definition: string): void {
  const cols = db.prepare(`SELECT name FROM pragma_table_info('${table}')`).all() as {
    name: string;
  }[];
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

export function closeDatabase(): void {
  db.close();
}

/**
 * Chạy trong một giao dịch. Viết tay vì `node:sqlite` KHÔNG có `db.transaction()`
 * như better-sqlite3 - gọi nhầm hàm đó là lỗi biên dịch.
 *
 * `BEGIN IMMEDIATE` chứ không phải `BEGIN`: lấy khóa ghi ngay từ đầu thay vì
 * nâng cấp giữa chừng. Cả process dùng CHUNG một connection và không có giao
 * dịch nào lồng nhau - thêm chỗ dùng mới thì phải kiểm lại điều đó.
 *
 * Trước đây định nghĩa RIÊNG trong `wipe-thread-context.ts` (chỗ đầu tiên cần
 * giao dịch trong repo) - chuyển lên đây vì `thread-store.ts`'s
 * `setThreadPermissions` (ma trận phân quyền) là chỗ dùng THỨ HAI, và hai file
 * cùng domain `conversation/` dùng chung một bản thay vì chép lại.
 */
export function trongGiaoDich<T>(viec: () => T): T {
  db.exec("BEGIN IMMEDIATE");
  try {
    const ketQua = viec();
    db.exec("COMMIT");
    return ketQua;
  } catch (err) {
    // Rollback hỏng thì nuốt: ném đè lên lỗi gốc là giấu mất nguyên nhân thật
    try {
      db.exec("ROLLBACK");
    } catch {
      /* giữ nguyên lỗi gốc */
    }
    throw err;
  }
}
