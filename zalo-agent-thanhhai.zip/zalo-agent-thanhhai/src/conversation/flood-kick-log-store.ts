import { db } from "./database.js";

/**
 * CRUD bảng `flood_kick_log` - nhật ký mọi lần bot CÂN NHẮC kick 1 tài khoản
 * bị nghi dồn dập/spam trong nhóm (`group-flood-kick-scheduler.ts`). Bền qua
 * restart để chủ bot xem lại được khi không trực 24/7 - khác bộ đếm dồn dập
 * (`group-flood-detector.ts`, chỉ sống trong bộ nhớ, cửa sổ vài giây/phút nên
 * restart xoá là chấp nhận được).
 */

export type FloodKickLogRow = {
  id: number;
  accountId: string;
  threadId: string;
  targetUserId: string;
  targetName: string;
  messageCount: number;
  windowSeconds: number;
  vetoed: boolean;
  vetoByUserId: string | null;
  executed: boolean;
  error: string | null;
  createdAt: string;
  executedAt: string | null;
};

type Row = {
  id: number;
  account_id: string;
  thread_id: string;
  target_user_id: string;
  target_name: string;
  message_count: number;
  window_seconds: number;
  vetoed: number;
  veto_by_user_id: string | null;
  executed: number;
  error: string | null;
  created_at: string;
  executed_at: string | null;
};

const toRow = (r: Row): FloodKickLogRow => ({
  id: r.id,
  accountId: r.account_id,
  threadId: r.thread_id,
  targetUserId: r.target_user_id,
  targetName: r.target_name,
  messageCount: r.message_count,
  windowSeconds: r.window_seconds,
  vetoed: r.vetoed === 1,
  vetoByUserId: r.veto_by_user_id,
  executed: r.executed === 1,
  error: r.error,
  createdAt: r.created_at,
  executedAt: r.executed_at,
});

const insertStmt = db.prepare(`
  INSERT INTO flood_kick_log (account_id, thread_id, target_user_id, target_name, message_count, window_seconds)
  VALUES (?, ?, ?, ?, ?, ?)
`);

/** Ghi lại ngay lúc BẮT ĐẦU chờ (trước khi biết kết quả) - trả về id để cập nhật sau */
export function insertFloodKickAttempt(input: {
  accountId: string;
  threadId: string;
  targetUserId: string;
  targetName: string;
  messageCount: number;
  windowSeconds: number;
}): number {
  const result = insertStmt.run(
    input.accountId,
    input.threadId,
    input.targetUserId,
    input.targetName,
    input.messageCount,
    input.windowSeconds,
  );
  return Number(result.lastInsertRowid);
}

const vetoStmt = db.prepare(
  `UPDATE flood_kick_log SET vetoed = 1, veto_by_user_id = ?, executed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?`,
);

export function markFloodKickVetoed(id: number, vetoByUserId: string): void {
  vetoStmt.run(vetoByUserId, id);
}

const executedStmt = db.prepare(
  `UPDATE flood_kick_log SET executed = 1, executed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?`,
);

export function markFloodKickExecuted(id: number): void {
  executedStmt.run(id);
}

const failedStmt = db.prepare(
  `UPDATE flood_kick_log SET error = ?, executed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?`,
);

export function markFloodKickFailed(id: number, error: string): void {
  failedStmt.run(error, id);
}

const listStmt = db.prepare(
  `SELECT * FROM flood_kick_log WHERE account_id = ? ORDER BY id DESC LIMIT ?`,
);

/** Xem lại gần đây nhất - dùng cho trang dashboard xem lại lịch sử kick */
export function listRecentFloodKicks(accountId: string, limit = 50): FloodKickLogRow[] {
  return (listStmt.all(accountId, limit) as Row[]).map(toRow);
}
