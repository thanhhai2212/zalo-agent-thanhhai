import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let store: typeof import("./flood-kick-log-store.js");
let database: typeof import("./database.js");

before(async () => {
  dataDir = setupTestEnv();
  store = await import("./flood-kick-log-store.js");
  database = await import("./database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("flood-kick-log-store", () => {
  it("insert rồi list ra đúng dòng vừa ghi, chưa vetoed/executed", () => {
    const id = store.insertFloodKickAttempt({
      accountId: "acc-1",
      threadId: "t-1",
      targetUserId: "u-1",
      targetName: "Bot Rác",
      messageCount: 6,
      windowSeconds: 20,
    });
    const rows = store.listRecentFloodKicks("acc-1", 10);
    assert.equal(rows.length, 1);
    assert.equal(rows[0]!.id, id);
    assert.equal(rows[0]!.targetUserId, "u-1");
    assert.equal(rows[0]!.vetoed, false);
    assert.equal(rows[0]!.executed, false);
    assert.equal(rows[0]!.error, null);
  });

  it("markFloodKickExecuted -> executed=true, executed_at có giá trị", () => {
    const id = store.insertFloodKickAttempt({
      accountId: "acc-2",
      threadId: "t-1",
      targetUserId: "u-1",
      targetName: "X",
      messageCount: 5,
      windowSeconds: 20,
    });
    store.markFloodKickExecuted(id);
    const row = store.listRecentFloodKicks("acc-2", 1)[0]!;
    assert.equal(row.executed, true);
    assert.ok(row.executedAt);
  });

  it("markFloodKickVetoed -> vetoed=true kèm vetoByUserId", () => {
    const id = store.insertFloodKickAttempt({
      accountId: "acc-3",
      threadId: "t-1",
      targetUserId: "u-1",
      targetName: "X",
      messageCount: 5,
      windowSeconds: 20,
    });
    store.markFloodKickVetoed(id, "admin-1");
    const row = store.listRecentFloodKicks("acc-3", 1)[0]!;
    assert.equal(row.vetoed, true);
    assert.equal(row.vetoByUserId, "admin-1");
  });

  it("markFloodKickFailed -> ghi lại đúng error", () => {
    const id = store.insertFloodKickAttempt({
      accountId: "acc-4",
      threadId: "t-1",
      targetUserId: "u-1",
      targetName: "X",
      messageCount: 5,
      windowSeconds: 20,
    });
    store.markFloodKickFailed(id, "166: thiếu quyền");
    const row = store.listRecentFloodKicks("acc-4", 1)[0]!;
    assert.equal(row.error, "166: thiếu quyền");
  });

  it("listRecentFloodKicks chỉ trả đúng account, mới nhất trước", () => {
    store.insertFloodKickAttempt({
      accountId: "acc-5",
      threadId: "t-1",
      targetUserId: "u-1",
      targetName: "A",
      messageCount: 5,
      windowSeconds: 20,
    });
    const idSau = store.insertFloodKickAttempt({
      accountId: "acc-5",
      threadId: "t-1",
      targetUserId: "u-2",
      targetName: "B",
      messageCount: 5,
      windowSeconds: 20,
    });
    store.insertFloodKickAttempt({
      accountId: "acc-khac",
      threadId: "t-1",
      targetUserId: "u-3",
      targetName: "C",
      messageCount: 5,
      windowSeconds: 20,
    });
    const rows = store.listRecentFloodKicks("acc-5", 10);
    assert.equal(rows.length, 2);
    assert.equal(rows[0]!.id, idSau, "mới nhất phải đứng đầu");
  });
});
