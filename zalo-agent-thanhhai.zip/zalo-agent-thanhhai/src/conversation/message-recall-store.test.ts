import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let history: typeof import("./history-store.js");
let recall: typeof import("./message-recall-store.js");

before(async () => {
  dataDir = setupTestEnv();
  history = await import("./history-store.js");
  recall = await import("./message-recall-store.js");
});

after(() => {
  history.closeHistoryStore();
  cleanupTestEnv(dataDir);
});

describe("message-recall-store (undo_message)", () => {
  const ID = [{ msgId: "111", cliMsgId: "222" }];

  it("getRecallableMessage trả đúng tin theo id khi có sent_msg_ids", () => {
    const rowId = history.appendMessage("acc-1", "t-undo", {
      role: "assistant",
      content: "chào bạn",
      sentMsgIds: ID,
    });

    const tin = recall.getRecallableMessage("acc-1", "t-undo", rowId);
    assert.ok(tin);
    assert.equal(tin!.content, "chào bạn");
    assert.deepEqual(tin!.sentMsgIds, ID);
  });

  it("tin của USER (role user) không bao giờ coi là thu hồi được dù có id trùng", () => {
    const rowId = history.appendMessage("acc-1", "t-undo-user", {
      role: "user",
      content: "tin người dùng",
      senderName: "Hải",
    });
    assert.equal(recall.getRecallableMessage("acc-1", "t-undo-user", rowId), undefined);
  });

  it("tin assistant KHÔNG có sent_msg_ids (vd gửi qua tool khác) -> undefined", () => {
    const rowId = history.appendMessage("acc-1", "t-undo-notool", { role: "assistant", content: "đã gửi file" });
    assert.equal(recall.getRecallableMessage("acc-1", "t-undo-notool", rowId), undefined);
  });

  it("id không tồn tại hoặc sai account/thread -> undefined, không rò dữ liệu chéo", () => {
    const rowId = history.appendMessage("acc-1", "t-undo-scope", { role: "assistant", content: "x", sentMsgIds: ID });
    assert.equal(recall.getRecallableMessage("acc-1", "t-undo-scope", 999999), undefined);
    assert.equal(recall.getRecallableMessage("acc-2", "t-undo-scope", rowId), undefined);
    assert.equal(recall.getRecallableMessage("acc-1", "thread-khac", rowId), undefined);
  });

  it("getLatestRecallableMessage lấy đúng tin GẦN NHẤT của bot còn thu hồi được, bỏ qua tin sau đó không có id", () => {
    history.appendMessage("acc-1", "t-latest", { role: "assistant", content: "tin cũ", sentMsgIds: ID });
    history.appendMessage("acc-1", "t-latest", { role: "user", content: "ok" });
    history.appendMessage("acc-1", "t-latest", { role: "assistant", content: "tin gửi qua tool khác" });

    const tin = recall.getLatestRecallableMessage("acc-1", "t-latest");
    assert.ok(tin);
    assert.equal(tin!.content, "tin cũ");
  });

  it("markMessageRecalled ghi đè content + xoá sent_msg_ids, không thu hồi lại được lần hai", () => {
    const rowId = history.appendMessage("acc-1", "t-marked", {
      role: "assistant",
      content: "nội dung gốc",
      sentMsgIds: ID,
    });
    recall.markMessageRecalled(rowId, "nội dung gốc");

    assert.equal(recall.getRecallableMessage("acc-1", "t-marked", rowId), undefined);
    const rows = history.getRecentMessages("acc-1", "t-marked", 10);
    assert.match(rows[0]!.content, /Tin đã thu hồi/);
    assert.match(rows[0]!.content, /nội dung gốc/);
  });

  describe("appendSentMsgId (vá cliMsgId đến muộn qua self-echo)", () => {
    it("row mới ghi CHƯA có sent_msg_ids -> vá 1 msgId thì trở thành thu hồi được", () => {
      const rowId = history.appendMessage("acc-1", "t-vá", { role: "assistant", content: "xin chào" });
      assert.equal(recall.getRecallableMessage("acc-1", "t-vá", rowId), undefined, "chưa vá thì chưa thu hồi được");

      recall.appendSentMsgId(rowId, "msg-1", "cli-1");

      const tin = recall.getRecallableMessage("acc-1", "t-vá", rowId);
      assert.ok(tin);
      assert.deepEqual(tin!.sentMsgIds, [{ msgId: "msg-1", cliMsgId: "cli-1" }]);
    });

    it("vá NHIỀU LẦN (câu trả lời chia nhiều tin, mỗi tin echo về một lúc khác nhau) -> cộng dồn đúng thứ tự", () => {
      const rowId = history.appendMessage("acc-1", "t-vá-nhieu", { role: "assistant", content: "câu dài" });
      recall.appendSentMsgId(rowId, "p1", "c1");
      recall.appendSentMsgId(rowId, "p2", "c2");

      const tin = recall.getRecallableMessage("acc-1", "t-vá-nhieu", rowId);
      assert.deepEqual(tin!.sentMsgIds, [
        { msgId: "p1", cliMsgId: "c1" },
        { msgId: "p2", cliMsgId: "c2" },
      ]);
    });

    it("row đã bị markMessageRecalled TRƯỚC khi echo phần còn lại tới -> vá bị BỎ QUA, không hồi sinh lại thành thu hồi được", () => {
      const rowId = history.appendMessage("acc-1", "t-vá-tre", {
        role: "assistant",
        content: "câu 2 phần",
        sentMsgIds: [{ msgId: "p1", cliMsgId: "c1" }],
      });
      // Owner thu hồi ngay khi mới có phần 1 - phần 2 chưa kịp echo về
      recall.markMessageRecalled(rowId, "câu 2 phần");
      assert.equal(recall.getRecallableMessage("acc-1", "t-vá-tre", rowId), undefined);

      // Echo của phần 2 tới muộn
      recall.appendSentMsgId(rowId, "p2", "c2");

      // Vẫn phải coi là đã thu hồi - không được sống lại
      assert.equal(recall.getRecallableMessage("acc-1", "t-vá-tre", rowId), undefined);
    });

    it("row không tồn tại (vd đã bị prune) -> không ném lỗi", () => {
      assert.doesNotThrow(() => recall.appendSentMsgId(999999, "m", "c"));
    });
  });
});
