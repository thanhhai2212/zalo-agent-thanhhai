import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

let dataDir: string;
let mod: typeof import("./memory-dashboard-list.js");

before(async () => {
  dataDir = setupTestEnv();
  const memory = await import("./memory-store.js");
  const { db } = await import("./database.js");
  mod = await import("./memory-dashboard-list.js");

  db.prepare("INSERT INTO contacts (account_id, user_id, display_name) VALUES (?, ?, ?)").run("acc-dl", "u-lan", "Nguyễn Thị Lan");
  db.prepare("INSERT INTO threads (account_id, thread_id, thread_type, display_name) VALUES (?, ?, ?, ?)").run(
    "acc-dl",
    "g-ban-hang",
    1,
    "Nhóm Bán Hàng",
  );
  memory.saveMemoryFact({ accountId: "acc-dl", subjectId: "u-lan", content: "Thích trà sữa", learnedInThreadId: "g-ban-hang", learnedInGroup: true });
  memory.saveMemoryFact({ accountId: "acc-dl", subjectId: "u-la", content: "Ở Cần Thơ", learnedInThreadId: "u-la", learnedInGroup: false });
});

after(() => cleanupTestEnv(dataDir));

describe("trí nhớ cho dashboard", () => {
  it("kèm tên người và tên cuộc chat nơi học được", () => {
    const [f] = mod.listMemoriesForDashboard({ accountId: "acc-dl", query: "trà sữa" });
    assert.equal(f?.subjectName, "Nguyễn Thị Lan");
    assert.equal(f?.learnedInName, "Nhóm Bán Hàng");
    assert.equal(f?.learnedInGroup, true);
  });

  it("người chưa có trong contacts thì tên rỗng, không làm rơi dòng", () => {
    const [f] = mod.listMemoriesForDashboard({ accountId: "acc-dl", query: "Cần Thơ" });
    assert.equal(f?.subjectId, "u-la");
    assert.equal(f?.subjectName, "");
    assert.equal(f?.learnedInName, "");
  });

  it("tìm được theo tên người và tên nhóm", () => {
    assert.equal(mod.listMemoriesForDashboard({ accountId: "acc-dl", query: "Lan" }).length, 1);
    assert.equal(mod.listMemoriesForDashboard({ accountId: "acc-dl", query: "Bán Hàng" }).length, 1);
    assert.equal(mod.listMemoriesForDashboard({ accountId: "acc-dl" }).length, 2);
  });
});
