import { db } from "./database.js";
import type { MemoryFact } from "./memory-store.js";

/**
 * Danh sách trí nhớ cho trang dashboard "Trí nhớ": giống `listMemories` nhưng
 * kèm TÊN người được nhớ (bảng contacts) và TÊN cuộc chat nơi bot học được
 * (bảng threads), và tìm được theo hai tên đó. Trước đây trang chỉ in UID trần
 * nên chủ bot không biết điều nhớ đó là về ai.
 *
 * Tách khỏi `memory-store.ts` vì đây chỉ là truy vấn hiển thị - `listMemories`
 * vẫn là hàm dùng cho backup/test, không đổi hành vi.
 */
export type MemoryFactDashboard = MemoryFact & {
  /** Tên hiển thị người được nhớ, rỗng nếu chưa từng thấy người này trong contacts */
  subjectName: string;
  /** Tên cuộc chat nơi bot học được điều này, rỗng nếu thread đã không còn */
  learnedInName: string;
};

const stmt = db.prepare(`
  SELECT m.id, m.account_id, m.subject_id, m.content, m.learned_in_thread_id, m.learned_in_group, m.created_at,
         COALESCE(c.display_name, '') AS subject_name, COALESCE(t.display_name, '') AS learned_name
  FROM memories m
  LEFT JOIN contacts c ON c.account_id = m.account_id AND c.user_id = m.subject_id
  LEFT JOIN threads t ON t.account_id = m.account_id AND t.thread_id = m.learned_in_thread_id
  WHERE (? = '' OR m.account_id = ?)
    AND (m.subject_id LIKE ? OR m.content LIKE ? OR c.display_name LIKE ? OR t.display_name LIKE ?)
  ORDER BY m.id DESC
  LIMIT ? OFFSET ?
`);

/** accountId bỏ trống = mọi account */
export function listMemoriesForDashboard(params: {
  accountId?: string;
  query?: string;
  limit?: number;
  offset?: number;
}): MemoryFactDashboard[] {
  type Row = {
    id: number; account_id: string; subject_id: string; content: string;
    learned_in_thread_id: string; learned_in_group: number; created_at: string;
    subject_name: string; learned_name: string;
  };
  const acc = params.accountId ?? "";
  const like = `%${params.query ?? ""}%`;
  const rows = stmt.all(acc, acc, like, like, like, like, params.limit ?? 50, params.offset ?? 0) as unknown as Row[];
  return rows.map((r) => ({
    id: r.id,
    accountId: r.account_id,
    subjectId: r.subject_id,
    content: r.content,
    learnedInThreadId: r.learned_in_thread_id,
    learnedInGroup: r.learned_in_group === 1,
    createdAt: r.created_at,
    subjectName: r.subject_name,
    learnedInName: r.learned_name,
  }));
}
