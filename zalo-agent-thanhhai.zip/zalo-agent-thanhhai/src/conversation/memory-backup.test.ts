import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { ThreadType } from "zca-js";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

const WINDOW = 5;

let dataDir: string;
let history: typeof import("./history-store.js");
let threads: typeof import("./thread-store.js");
let memory: typeof import("./memory-store.js");
let backup: typeof import("./memory-backup.js");

before(async () => {
  dataDir = setupTestEnv({ HISTORY_CONTEXT_LIMIT: String(WINDOW) });
  history = await import("./history-store.js");
  threads = await import("./thread-store.js");
  memory = await import("./memory-store.js");
  backup = await import("./memory-backup.js");
});

after(() => {
  history.closeHistoryStore();
  cleanupTestEnv(dataDir);
});

function seedThread(threadId: string, threadType: number, count: number): void {
  threads.recordThreadActivity({
    accountId: "acc-1",
    threadId,
    threadType,
    displayName: "Ai đó",
    lastSenderName: "Ai đó",
  });
  for (let i = 1; i <= count; i++) {
    history.appendMessage("acc-1", threadId, { role: "user", content: `tin-${i}`, senderName: "Ai đó" });
  }
}

describe("backupAccountMemory - nút Sao lưu 1-click (rẻ, không LLM)", () => {
  before(() => {
    seedThread("thread-a", ThreadType.User, WINDOW + 2);
    threads.setThreadSummary("acc-1", "thread-a", "Tóm tắt A", 0);

    seedThread("group-g", ThreadType.Group, WINDOW + 2);
    threads.setThreadSummary("acc-1", "group-g", "Tóm tắt nhóm G", 0);

    seedThread("thread-b", ThreadType.User, WINDOW + 2); // chưa có summary
  });

  it("lần đầu: thăng cấp chat 1-1 có summary, bỏ qua nhóm và thread chưa có summary", () => {
    const result = backup.backupAccountMemory("acc-1");
    assert.equal(result.promoted, 1);
    assert.equal(result.unchanged, 0);
    assert.equal(result.skippedGroups, 1);
    assert.equal(result.skippedEmpty, 1);

    const facts = memory.listMemories({ accountId: "acc-1", query: "thread-a" });
    assert.equal(facts.length, 1);
    assert.equal(facts[0]!.subjectId, "thread-a");
    assert.ok(facts[0]!.content.startsWith("[Sao lưu từ tóm tắt thread]"));
    assert.ok(facts[0]!.content.includes("Tóm tắt A"));
  });

  it("chạy lại lần 2 với summary chưa đổi -> unchanged, không tạo dòng mới", () => {
    const result = backup.backupAccountMemory("acc-1");
    assert.equal(result.promoted, 0);
    assert.equal(result.unchanged, 1);

    const facts = memory.listMemories({ accountId: "acc-1", query: "thread-a" });
    assert.equal(facts.length, 1, "không được đẻ thêm dòng trùng");
  });

  it("summary đổi -> lần backup sau tính là promoted (fact mới)", () => {
    threads.setThreadSummary("acc-1", "thread-a", "Tóm tắt A - đã cập nhật", 0);
    const result = backup.backupAccountMemory("acc-1");
    assert.equal(result.promoted, 1);

    const facts = memory.listMemories({ accountId: "acc-1", query: "thread-a" });
    assert.equal(facts.length, 2);
  });
});

describe("backupThreadDeep - nút Backup sâu (đắt, 1 lượt LLM)", () => {
  before(() => {
    seedThread("thread-sau-1-1", ThreadType.User, WINDOW + 6);
    seedThread("thread-sau-nhom", ThreadType.Group, WINDOW + 6);
    seedThread("thread-sau-rong", ThreadType.User, WINDOW - 1); // toàn bộ trong window
  });

  it("chat 1-1: ghi vào memories, KHÔNG đụng threads.summary", async () => {
    const result = await backup.backupThreadDeep("acc-1", "thread-sau-1-1", ThreadType.User, async () => "Tóm sâu 1-1");
    assert.deepEqual(result, { ok: true, savedTo: "memory", summary: "Tóm sâu 1-1" });

    const facts = memory.listMemories({ accountId: "acc-1", query: "thread-sau-1-1" });
    assert.equal(facts.length, 1);
    assert.ok(facts[0]!.content.startsWith("[Sao lưu sâu - toàn bộ lịch sử]"));
    assert.equal(threads.getThreadSummary("acc-1", "thread-sau-1-1").summary, "");
  });

  it("nhóm: ghi đè threads.summary tại chỗ, KHÔNG đụng memories", async () => {
    const result = await backup.backupThreadDeep("acc-1", "thread-sau-nhom", ThreadType.Group, async () => "Tóm sâu nhóm");
    assert.deepEqual(result, { ok: true, savedTo: "thread-summary", summary: "Tóm sâu nhóm" });

    assert.equal(threads.getThreadSummary("acc-1", "thread-sau-nhom").summary, "Tóm sâu nhóm");
    assert.equal(memory.listMemories({ accountId: "acc-1", query: "thread-sau-nhom" }).length, 0);
  });

  it("backlog rỗng -> ok:false, không gọi generate", async () => {
    let called = false;
    const result = await backup.backupThreadDeep("acc-1", "thread-sau-rong", ThreadType.User, async () => {
      called = true;
      return "x";
    });
    assert.equal(result.ok, false);
    assert.equal(called, false);
  });

  it("generate lỗi thì bắt lại, trả ok:false thay vì throw", async () => {
    const result = await backup.backupThreadDeep("acc-1", "thread-sau-1-1", ThreadType.User, async () => {
      throw new Error("router chết");
    });
    assert.equal(result.ok, false);
    if (!result.ok) assert.ok(result.error.includes("router chết"));
  });
});

describe("exportAccountGroups / importAccountGroups - phần nhóm của Export/Import", () => {
  function seedThreadAcc(accountId: string, threadId: string, threadType: number, count: number): void {
    threads.recordThreadActivity({ accountId, threadId, threadType, displayName: "X", lastSenderName: "X" });
    for (let i = 1; i <= count; i++) {
      history.appendMessage(accountId, threadId, { role: "user", content: `tin-${i}`, senderName: "X" });
    }
  }

  before(() => {
    seedThreadAcc("acc-nguon", "nhom-xuat", ThreadType.Group, WINDOW + 2);
    threads.setThreadSummary("acc-nguon", "nhom-xuat", "Tóm tắt nhóm cần xuất", 0);
    // chat 1-1 KHÔNG được lẫn vào phần export nhóm
    seedThreadAcc("acc-nguon", "dm-khong-xuat", ThreadType.User, WINDOW + 2);
    threads.setThreadSummary("acc-nguon", "dm-khong-xuat", "Tóm tắt DM", 0);
  });

  it("export: chỉ lấy nhóm có summary, không lẫn chat 1-1", () => {
    const groups = backup.exportAccountGroups("acc-nguon");
    assert.equal(groups.length, 1);
    assert.equal(groups[0]!.threadId, "nhom-xuat");
    assert.equal(groups[0]!.summary, "Tóm tắt nhóm cần xuất");
  });

  it("import vào account CHƯA từng thấy thread_id đó -> tạo dòng placeholder", () => {
    const result = backup.importAccountGroups("acc-dich-moi", backup.exportAccountGroups("acc-nguon"));
    assert.deepEqual(result, { created: 1, merged: 0 });

    assert.equal(threads.getThreadSummary("acc-dich-moi", "nhom-xuat").summary, "Tóm tắt nhóm cần xuất");
    assert.equal(threads.getThreadType("acc-dich-moi", "nhom-xuat"), ThreadType.Group);
  });

  it("import vào account ĐÃ có thread_id đó -> gộp summary, giữ nguyên coversTo hiện tại", () => {
    seedThreadAcc("acc-dich-cu", "nhom-xuat", ThreadType.Group, WINDOW + 3);
    threads.setThreadSummary("acc-dich-cu", "nhom-xuat", "Summary account đích đang có", 7);

    const result = backup.importAccountGroups("acc-dich-cu", backup.exportAccountGroups("acc-nguon"));
    assert.deepEqual(result, { created: 0, merged: 1 });

    const { summary, coversTo } = threads.getThreadSummary("acc-dich-cu", "nhom-xuat");
    assert.ok(summary.includes("Tóm tắt nhóm cần xuất"));
    assert.ok(summary.includes("Summary account đích đang có"));
    assert.equal(coversTo, 7, "coversTo của account đích không được bị đụng vào");
  });
});
