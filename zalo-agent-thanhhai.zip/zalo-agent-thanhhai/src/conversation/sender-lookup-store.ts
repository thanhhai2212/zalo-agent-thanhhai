import { db } from "./database.js";

/**
 * Tra cứu NGƯỜI GỬI trong lịch sử của một thread - nền cho tool
 * `read_person_in_thread`. Chỉ đọc, không ghi gì.
 *
 * Gộp theo `sender_id` chứ không theo tên hiển thị: một người đổi tên qua thời
 * gian vẫn là MỘT người (các tên cũ thành alias), còn hai người trùng tên hiển
 * thị là HAI người - đã thấy thật trong DB, nên không bao giờ suy người từ tên.
 * Tin cũ ghi trước khi có cột `sender_id` không có id: gộp theo tên, đánh dấu
 * `senderId = null` để tool báo thẳng là chưa biết UID.
 */

export type SenderCandidate = {
  /** UID Zalo; null với tin cũ ghi trước khi có cột sender_id */
  senderId: string | null;
  /** Tên dùng gần nhất */
  latestName: string;
  /** Mọi tên từng dùng trong thread này (kể cả tên gần nhất) */
  names: string[];
  messageCount: number;
  firstAt: string;
  lastAt: string;
};

type SenderRow = { sender_id: string | null; sender_name: string | null; n: number; first_at: string; last_at: string };

const groupStmt = db.prepare(
  `SELECT sender_id, sender_name, COUNT(*) AS n, MIN(created_at) AS first_at, MAX(created_at) AS last_at
   FROM messages
   WHERE account_id = ? AND thread_id = ? AND role = 'user'
   GROUP BY sender_id, sender_name`,
);

const byIdStmt = db.prepare(
  `SELECT created_at, content FROM messages
   WHERE account_id = ? AND thread_id = ? AND role = 'user' AND sender_id = ?
   ORDER BY id DESC LIMIT ?`,
);

const byLegacyNameStmt = db.prepare(
  `SELECT created_at, content FROM messages
   WHERE account_id = ? AND thread_id = ? AND role = 'user' AND sender_id IS NULL AND sender_name = ?
   ORDER BY id DESC LIMIT ?`,
);

/**
 * Bỏ dấu + về chữ thường để gõ "tien dung" vẫn khớp "Tiến Dũng". `đ` phải xử
 * riêng: NFD không tách được chữ này. Lặp lại ở đây thay vì import từ web/.
 */
export function chuanHoaTimKiem(s: string): string {
  return s
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/[đĐ]/g, "d")
    .toLowerCase()
    .trim();
}

function listSenders(accountId: string, threadId: string): SenderCandidate[] {
  const rows = groupStmt.all(accountId, threadId) as SenderRow[];
  const byKey = new Map<string, SenderCandidate & { latestTs: string }>();

  for (const r of rows) {
    const ten = (r.sender_name ?? "").trim() || "(không rõ tên)";
    // Tin cũ không có id: mỗi tên là một "người" riêng, khóa theo tên
    const key = r.sender_id ?? `ten:${ten}`;
    const cur = byKey.get(key);
    if (!cur) {
      byKey.set(key, {
        senderId: r.sender_id,
        latestName: ten,
        names: [ten],
        messageCount: r.n,
        firstAt: r.first_at,
        lastAt: r.last_at,
        latestTs: r.last_at,
      });
      continue;
    }
    cur.messageCount += r.n;
    if (!cur.names.includes(ten)) cur.names.push(ten);
    if (r.first_at < cur.firstAt) cur.firstAt = r.first_at;
    if (r.last_at > cur.lastAt) cur.lastAt = r.last_at;
    // Tên của lần nhắn MỚI NHẤT mới là tên hiện tại
    if (r.last_at > cur.latestTs) {
      cur.latestTs = r.last_at;
      cur.latestName = ten;
    }
  }
  return [...byKey.values()].map(({ latestTs: _bo, ...c }) => c);
}

/**
 * Tìm người theo UID (khớp chính xác) hoặc theo tên (chứa chuỗi, không phân
 * biệt dấu/hoa thường, khớp với BẤT KỲ tên nào người đó từng dùng). Sắp xếp
 * người nhắn nhiều nhất lên đầu.
 */
export function findSenders(accountId: string, threadId: string, query: string): SenderCandidate[] {
  const q = query.trim();
  if (!q) return [];
  const qChuan = chuanHoaTimKiem(q);
  return listSenders(accountId, threadId)
    .filter((c) => c.senderId === q || c.names.some((n) => chuanHoaTimKiem(n).includes(qChuan)))
    .sort((a, b) => b.messageCount - a.messageCount);
}

export type GroupMembership = {
  threadId: string;
  displayName: string;
  messageCount: number;
  lastAt: string;
};

const groupsForSenderStmt = db.prepare(`
  SELECT m.thread_id, t.display_name, COUNT(*) AS n, MAX(m.created_at) AS last_at
  FROM messages m
  JOIN threads t ON t.account_id = m.account_id AND t.thread_id = m.thread_id
  WHERE m.account_id = ? AND m.sender_id = ? AND m.role = 'user' AND t.thread_type = 1
  GROUP BY m.thread_id
  ORDER BY last_at DESC
`);

/**
 * Các NHÓM người này từng nhắn - suy từ lịch sử tin nhắn ĐÃ LƯU, KHÔNG gọi API
 * Zalo sống. Dùng cho trang Contacts (quản trị nhóm): chọn đúng nhóm để
 * kick/chặn mà không phải hỏi Zalo "người này đang ở nhóm nào" cho MỖI contact
 * hiển thị - không có API như vậy, và gọi hàng loạt sẽ tốn hàng chục request
 * mỗi lần tải trang. Chỉ gọi khi admin mở modal của ĐÚNG 1 contact cụ thể.
 *
 * Giới hạn đã biết: chỉ thấy nhóm nào người này ĐÃ TỪNG NHẮN (không phải nhóm
 * họ đang có mặt nhưng chưa gửi tin nào) và tin cũ có thể đã bị dọn theo
 * `HISTORY_MAX_MESSAGES_PER_THREAD` - không phải toàn bộ lịch sử tồn tại mãi.
 */
export function listGroupsForSender(accountId: string, senderId: string): GroupMembership[] {
  const rows = groupsForSenderStmt.all(accountId, senderId) as
    { thread_id: string; display_name: string; n: number; last_at: string }[];
  return rows.map((r) => ({
    threadId: r.thread_id,
    displayName: r.display_name,
    messageCount: r.n,
    lastAt: r.last_at,
  }));
}

export type SenderMessage = { createdAt: string; content: string };

/** Tin của ĐÚNG người này, cũ -> mới, tối đa `limit` tin gần nhất */
export function getMessagesBySender(
  accountId: string,
  threadId: string,
  sender: SenderCandidate,
  limit: number,
): SenderMessage[] {
  const rows = (
    sender.senderId
      ? byIdStmt.all(accountId, threadId, sender.senderId, limit)
      : byLegacyNameStmt.all(accountId, threadId, sender.latestName, limit)
  ) as { created_at: string; content: string }[];
  return rows.reverse().map((r) => ({ createdAt: r.created_at, content: r.content }));
}
