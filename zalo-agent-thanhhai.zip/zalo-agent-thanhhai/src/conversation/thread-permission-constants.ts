/** Sentinel nội bộ: dữ liệu quyền tool của thread hỏng thì khóa toàn bộ (fail-closed). */
export const THREAD_DENY_ALL_TOOLS = "__deny_all_thread_tools__";
