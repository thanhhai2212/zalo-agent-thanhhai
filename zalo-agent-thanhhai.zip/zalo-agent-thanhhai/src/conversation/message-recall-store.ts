import { db } from "./database.js";
import { parseSentMsgIds, type SentMessageId } from "./history-store.js";

/**
 * Đọc/sửa tin cho tool `undo_message` - tách khỏi `history-store.ts` (đúng
 * nếp tách theo NHÓM đã dùng cho `flood-kick-log-store.ts`,
 * `memory-edit-store.ts`...) để file đó không vượt ngưỡng 200 dòng.
 */

export type RecallableMessage = {
  id: number;
  content: string;
  sentMsgIds: SentMessageId[];
};

type RecallableRow = { id: number; role: "user" | "assistant"; content: string; sent_msg_ids: string | null };

function tinCoTheThuHoi(row: RecallableRow | undefined): RecallableMessage | undefined {
  if (!row || row.role !== "assistant") return undefined;
  const sentMsgIds = parseSentMsgIds(row.sent_msg_ids);
  if (!sentMsgIds) return undefined;
  return { id: row.id, content: row.content, sentMsgIds };
}

const recallableByIdStmt = db.prepare(
  `SELECT id, role, content, sent_msg_ids FROM messages
   WHERE account_id = ? AND thread_id = ? AND id = ?`,
);

/**
 * Tin CỤ THỂ (theo id, lấy từ read_thread) đủ dữ liệu để thu hồi - `undefined`
 * nếu không tồn tại, không phải tin của bot, hoặc gửi trước khi có cột
 * `sent_msg_ids` (tin cũ, hoặc gửi qua đường không capture id như tool file/ảnh).
 */
export function getRecallableMessage(
  accountId: string,
  threadId: string,
  messageId: number,
): RecallableMessage | undefined {
  const row = recallableByIdStmt.get(accountId, threadId, messageId) as RecallableRow | undefined;
  return tinCoTheThuHoi(row);
}

const recallableLatestStmt = db.prepare(
  `SELECT id, role, content, sent_msg_ids FROM messages
   WHERE account_id = ? AND thread_id = ? AND role = 'assistant' AND sent_msg_ids IS NOT NULL
   ORDER BY id DESC LIMIT 1`,
);

/** Tin GẦN NHẤT của bot trong thread còn thu hồi được - dùng khi không chỉ định messageId */
export function getLatestRecallableMessage(accountId: string, threadId: string): RecallableMessage | undefined {
  const row = recallableLatestStmt.get(accountId, threadId) as RecallableRow | undefined;
  return tinCoTheThuHoi(row);
}

/** Tiền tố đánh dấu 1 row đã bị thu hồi - dùng chung giữa ghi (markMessageRecalled) và đọc (appendSentMsgId) */
const TIEN_TO_DA_THU_HOI = "[Tin đã thu hồi";

const getSentMsgIdsStmt = db.prepare(`SELECT content, sent_msg_ids FROM messages WHERE id = ?`);
const setSentMsgIdsStmt = db.prepare(`UPDATE messages SET sent_msg_ids = ? WHERE id = ?`);

/**
 * Vá thêm `{msgId, cliMsgId}` vào 1 row đã ghi trước đó - dùng khi tiếng vọng
 * self-echo tới SAU khi `deliverChatReply` đã ghi history (xem
 * `self-echo-registry.ts`). Đọc-sửa-ghi thay vì UPDATE 1 lần: câu trả lời dài
 * bị chia nhiều tin Zalo thì mỗi tin echo về ở thời điểm khác nhau, mỗi lần
 * chỉ vá đúng 1 phần tử.
 *
 * Im lặng bỏ qua nếu row không còn (đã bị `pruneStmt` dọn) HOẶC row đã bị
 * `markMessageRecalled` đánh dấu thu hồi rồi - thiếu điều kiện sau thì 1 echo
 * tới muộn (ca chia nhiều phần, phần đầu đã thu hồi xong trước khi phần cuối
 * kịp echo) sẽ VÔ TÌNH gán lại `sent_msg_ids` cho row đã `NULL`, biến tin đã
 * thu hồi thành "lại thu hồi được lần nữa" - `sent_msg_ids IS NOT NULL` không
 * đủ để phân biệt "chưa từng có id" với "đã bị xoá id vì đã thu hồi", nên
 * phải kiểm thẳng vào content.
 */
export function appendSentMsgId(rowId: number, msgId: string, cliMsgId: string): void {
  const row = getSentMsgIdsStmt.get(rowId) as { content: string; sent_msg_ids: string | null } | undefined;
  if (!row || row.content.startsWith(TIEN_TO_DA_THU_HOI)) return;
  const hienCo = parseSentMsgIds(row.sent_msg_ids) ?? [];
  setSentMsgIdsStmt.run(JSON.stringify([...hienCo, { msgId, cliMsgId }]), rowId);
}

const markRecalledStmt = db.prepare(`UPDATE messages SET content = ?, sent_msg_ids = NULL WHERE id = ?`);

/**
 * Đánh dấu 1 tin ĐÃ THU HỒI: giữ lại nội dung gốc (có tiền tố rõ ràng) để lượt
 * sau agent còn biết mình từng nói gì và đã rút lại - xoá hẳn row thì bot mất
 * trí nhớ về việc đã lỡ lời, dễ lặp lại đúng câu vừa bị thu hồi. Xoá
 * `sent_msg_ids` để không ai gọi undo lần hai vào đúng tin đã thu hồi rồi.
 */
export function markMessageRecalled(messageId: number, originalContent: string): void {
  markRecalledStmt.run(`${TIEN_TO_DA_THU_HOI} - nội dung cũ: "${originalContent}"]`, messageId);
}
