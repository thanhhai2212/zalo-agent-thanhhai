import { ThreadType } from "zca-js";
import { saveMemoryFact } from "./memory-store.js";
import { regenerateThreadSummaryFromScratch, type SummaryGenerator } from "./thread-summarizer.js";
import {
  getThreadSummary,
  getThreadType,
  insertPlaceholderThreadWithSummary,
  listThreadsForAccount,
  setThreadSummary,
} from "./thread-store.js";

// KHÔNG chèn ngày/giờ vào tag: chạy lại "Sao lưu" nhiều lần với summary chưa
// đổi phải cho ra ĐÚNG cùng content, để `saveMemoryFact` tự nhận trùng và
// không đẻ dòng rác đè hết trần MEMORY_MAX_FACTS_PER_SUBJECT.
const TAG_RE = "[Sao lưu từ tóm tắt thread] ";
const TAG_SAU = "[Sao lưu sâu - toàn bộ lịch sử] ";

export type CheapBackupResult = {
  promoted: number;
  unchanged: number;
  skippedGroups: number;
  skippedEmpty: number;
};

/**
 * Nút "Sao lưu" 1-click trên dashboard (theo account) - RẺ, không gọi LLM.
 * Chỉ thăng cấp chat 1-1 (`ThreadType.User`): `thread_id` của DM CHÍNH LÀ UID
 * người đối diện (xác nhận từ `contact-store.ts`), nên `subject_id = threadId`
 * là khóa đúng và an toàn cho bảng `memories`. Nhóm KHÔNG thăng cấp - không có
 * "subject" hợp lệ (subject_id phải là NGƯỜI, xem `memory-store.ts`), và nhóm
 * đã có cơ hội tự nối lại qua `threads.summary` khi đổi account.
 */
export function backupAccountMemory(accountId: string): CheapBackupResult {
  const result: CheapBackupResult = { promoted: 0, unchanged: 0, skippedGroups: 0, skippedEmpty: 0 };

  for (const t of listThreadsForAccount(accountId)) {
    if (t.threadType !== ThreadType.User) {
      result.skippedGroups++;
      continue;
    }
    const { summary } = getThreadSummary(accountId, t.threadId);
    if (!summary) {
      result.skippedEmpty++;
      continue;
    }
    const ghi = saveMemoryFact({
      accountId,
      subjectId: t.threadId,
      content: TAG_RE + summary,
      learnedInThreadId: t.threadId,
      learnedInGroup: false,
    });
    if (ghi.ghi) result.promoted++;
    else result.unchanged++;
  }

  return result;
}

export type DeepBackupResult =
  | { ok: true; savedTo: "memory" | "thread-summary"; summary: string }
  | { ok: false; error: string };

/**
 * Nút "Backup sâu" trên dashboard (theo 1 thread cụ thể) - ĐẮT, 1 lượt gọi
 * LLM. Tóm tắt lại TOÀN BỘ backlog từ đầu (không cộng dồn lên summary cuộn
 * hiện có) - xem `regenerateThreadSummaryFromScratch`. Chat 1-1 ghi vào
 * `memories` (giống nút rẻ); nhóm (hoặc type -1 chưa rõ từ backfill cũ) ghi
 * ĐÈ TẠI CHỖ `threads.summary` - đúng cột đang dùng cho fold tự động, chỉ dọn
 * sạch phần bị mòn qua nhiều vòng gộp chứ không đổi cơ chế lưu.
 */
export async function backupThreadDeep(
  accountId: string,
  threadId: string,
  threadType: number,
  generate?: SummaryGenerator,
): Promise<DeepBackupResult> {
  try {
    const result = await regenerateThreadSummaryFromScratch(accountId, threadId, generate);
    if (!result) return { ok: false, error: "Chưa đủ tin nhắn để tóm tắt" };

    if (threadType === ThreadType.User) {
      saveMemoryFact({
        accountId,
        subjectId: threadId,
        content: TAG_SAU + result.summary,
        learnedInThreadId: threadId,
        learnedInGroup: false,
      });
      return { ok: true, savedTo: "memory", summary: result.summary };
    }

    setThreadSummary(accountId, threadId, result.summary, result.coversTo);
    return { ok: true, savedTo: "thread-summary", summary: result.summary };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

export type ExportedGroupSummary = {
  threadId: string;
  threadType: number;
  displayName: string;
  summary: string;
};

/**
 * Phần "nhóm" của Export - `memories` không chứa được nhóm (subject_id phải
 * là NGƯỜI), nên trí nhớ nhóm nằm ở `threads.summary` và phải xuất RIÊNG ở
 * đây để file Export mang được TRỌN VẸN cả 1-1 lẫn nhóm sang máy/DB khác -
 * không chỉ dựa vào giả định thread_id nhóm tự sống lại.
 */
export function exportAccountGroups(accountId: string): ExportedGroupSummary[] {
  return listThreadsForAccount(accountId)
    .filter((t) => t.threadType !== ThreadType.User)
    .map((t) => ({
      threadId: t.threadId,
      threadType: t.threadType,
      displayName: t.displayName,
      summary: getThreadSummary(accountId, t.threadId).summary,
    }))
    .filter((g) => g.summary !== "");
}

/**
 * Phần "nhóm" của Import - đối xứng với `exportAccountGroups`. Account đích
 * CHƯA từng thấy đúng `thread_id` đó (chưa join lại nhóm) thì tạo 1 dòng
 * "trống" giữ chỗ (`insertPlaceholderThreadWithSummary`) - join lại nhóm sau
 * này, tin thật tới sẽ tự khớp lên đúng dòng này. Đã có thread đó rồi (account
 * đích từng nhận tin từ nhóm này) thì GỘP summary thay vì ghi đè - đúng cách
 * `migrate-account-data.ts` xử lý xung đột, giữ nguyên `coversTo` hiện tại
 * (không đụng mốc đã gộp của account đích, chỉ thêm ngữ cảnh từ file backup).
 */
export function importAccountGroups(
  accountId: string,
  groups: ExportedGroupSummary[],
): { created: number; merged: number } {
  let created = 0;
  let merged = 0;

  for (const g of groups) {
    const existingType = getThreadType(accountId, g.threadId);
    if (existingType === undefined) {
      insertPlaceholderThreadWithSummary(accountId, g.threadId, g.threadType, g.displayName, g.summary);
      created++;
      continue;
    }

    const { summary: current, coversTo } = getThreadSummary(accountId, g.threadId);
    const mergedSummary = current
      ? `[Bối cảnh từ file backup]\n${g.summary}\n\n[Tiếp tục ở đây]\n${current}`.trim()
      : g.summary;
    setThreadSummary(accountId, g.threadId, mergedSummary, coversTo);
    merged++;
  }

  return { created, merged };
}
