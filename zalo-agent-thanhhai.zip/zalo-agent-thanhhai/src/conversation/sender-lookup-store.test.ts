import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

/**
 * `listGroupsForSender` - nền cho "Quản trị nhóm" ở trang Contacts (kick/chặn
 * một người khỏi đúng nhóm họ từng nhắn), suy từ lịch sử ĐÃ LƯU, không gọi API
 * Zalo sống. `chuanHoaTimKiem`/`findSenders`/`getMessagesBySender` đã được đo
 * qua `read-person-tool.test.ts` (thread-scoped), file này chỉ thêm phần MỚI:
 * truy vấn XUYÊN NHIỀU THREAD.
 */

let dataDir: string;
let store: typeof import("./sender-lookup-store.js");
let history: typeof import("./history-store.js");
let threads: typeof import("./thread-store.js");
let database: typeof import("./database.js");

before(async () => {
  dataDir = setupTestEnv();
  store = await import("./sender-lookup-store.js");
  history = await import("./history-store.js");
  threads = await import("./thread-store.js");
  database = await import("./database.js");

  threads.recordThreadActivity({
    accountId: "acc-1", threadId: "nhom-a", threadType: 1, displayName: "Nhóm A", lastSenderName: "x",
  });
  threads.recordThreadActivity({
    accountId: "acc-1", threadId: "nhom-b", threadType: 1, displayName: "Nhóm B", lastSenderName: "x",
  });
  threads.recordThreadActivity({
    accountId: "acc-1", threadId: "dm-uid-bot-la", threadType: 0, displayName: "Chat riêng", lastSenderName: "x",
  });

  // Bot lạ nhắn ở CẢ 2 nhóm lẫn 1 chat riêng - chat riêng KHÔNG được tính là "nhóm"
  history.appendMessage("acc-1", "nhom-a", { role: "user", content: "spam 1", senderName: "Bot Lạ", senderId: "uid-bot-la" });
  history.appendMessage("acc-1", "nhom-b", { role: "user", content: "spam 2", senderName: "Bot Lạ", senderId: "uid-bot-la" });
  history.appendMessage("acc-1", "dm-uid-bot-la", { role: "user", content: "chat riêng", senderName: "Bot Lạ", senderId: "uid-bot-la" });
  // Người khác chỉ nhắn ở nhóm A
  history.appendMessage("acc-1", "nhom-a", { role: "user", content: "chào", senderName: "Hải", senderId: "uid-hai" });
  // Tin bot trả lời trong nhóm A - KHÔNG được tính là "nhóm của sender"
  history.appendMessage("acc-1", "nhom-a", { role: "assistant", content: "chào bạn" });
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("listGroupsForSender", () => {
  it("trả đúng các NHÓM (không phải chat riêng) người này từng nhắn", () => {
    const groups = store.listGroupsForSender("acc-1", "uid-bot-la");
    assert.equal(groups.length, 2);
    assert.deepEqual(groups.map((g) => g.threadId).sort(), ["nhom-a", "nhom-b"]);
  });

  it("mỗi nhóm có đúng tên hiển thị + số tin", () => {
    const groups = store.listGroupsForSender("acc-1", "uid-bot-la");
    const nhomA = groups.find((g) => g.threadId === "nhom-a")!;
    assert.equal(nhomA.displayName, "Nhóm A");
    assert.equal(nhomA.messageCount, 1);
  });

  it("người chỉ nhắn 1 nhóm thì chỉ trả đúng 1 nhóm đó", () => {
    const groups = store.listGroupsForSender("acc-1", "uid-hai");
    assert.deepEqual(groups.map((g) => g.threadId), ["nhom-a"]);
  });

  it("người chưa từng nhắn ở nhóm nào (chỉ có trong contacts) -> mảng rỗng", () => {
    assert.deepEqual(store.listGroupsForSender("acc-1", "uid-chua-tung-nhan"), []);
  });

  it("account khác không lẫn kết quả dù trùng senderId", () => {
    assert.deepEqual(store.listGroupsForSender("acc-khac", "uid-bot-la"), []);
  });
});
