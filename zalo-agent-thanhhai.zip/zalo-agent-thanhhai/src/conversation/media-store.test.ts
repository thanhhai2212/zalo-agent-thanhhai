import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";

// media-store đọc dataDir từ env lúc import nên phải setupTestEnv trước, import động sau
let dataDir: string;
let store: typeof import("./media-store.js");
let database: typeof import("./database.js");
type PersistableMessage = import("./media-store.js").PersistableMessage;

// 1x1 PNG hợp lệ - đủ cho test lưu/đọc, không cần ảnh thật
const PNG_BYTES = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==",
  "base64",
);

// Downloader giả: tiêm vào persistBatchImages nên test không chạm mạng thật
const downloadOk = (mediaType = "image/png") => async () => ({ data: PNG_BYTES, mediaType });
const downloadFail = async () => null;

before(async () => {
  dataDir = setupTestEnv({ MEDIA_RETENTION_DAYS: "7" });
  store = await import("./media-store.js");
  // media-store giờ kéo theo image-description-store (DB) - phải đóng DB trước
  // khi xóa thư mục tạm, Windows khóa file đang mở nên rmSync sẽ EPERM
  database = await import("./database.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

describe("media-store", () => {
  it("persist ảnh: lưu file đúng chỗ, gắn localPath, load lại được base64", async () => {
    const msg: PersistableMessage = { threadId: "t-1", msgId: "m-100", images: [{ url: "https://z.vn/a.png" }] };

    await store.persistBatchImages("acc-1", [msg], downloadOk());

    assert.equal(msg.images[0]!.localPath, "media/acc-1/t-1/m-100-0.png");
    assert.ok(fs.existsSync(path.join(dataDir, "media/acc-1/t-1/m-100-0.png")));

    const loaded = store.loadStoredImage(msg.images[0]!.localPath!);
    assert.ok(loaded);
    assert.equal(loaded.mediaType, "image/png");
    assert.equal(loaded.base64, PNG_BYTES.toString("base64"));
  });

  it("tải lỗi thì không gắn localPath và không throw", async () => {
    const msg: PersistableMessage = {
      threadId: "t-1",
      msgId: "m-404",
      images: [{ url: "https://z.vn/die.png" }],
    };

    await store.persistBatchImages("acc-1", [msg], downloadFail);

    assert.equal(msg.images[0]!.localPath, undefined);
    assert.deepEqual(store.imagePathsOf(msg.images), []);
  });

  it("id chứa ký tự lạ bị sanitize khỏi đường dẫn", async () => {
    const msg: PersistableMessage = {
      threadId: "../thoat",
      msgId: "a/b:c",
      images: [{ url: "https://z.vn/x.jpg" }],
    };

    await store.persistBatchImages("acc-1", [msg], downloadOk("image/jpeg"));

    assert.equal(msg.images[0]!.localPath, "media/acc-1/___thoat/a_b_c-0.jpg");
  });

  it("loadStoredImage chặn đường dẫn thoát khỏi data/media", () => {
    assert.equal(store.loadStoredImage("../zalo-agent.db"), null);
    assert.equal(store.loadStoredImage("media/../zalo-agent.db"), null);
  });

  it("file không tồn tại (đã bị dọn) trả null thay vì throw", () => {
    assert.equal(store.loadStoredImage("media/acc-1/t-1/khong-co-0.jpg"), null);
  });

  it("cleanup xóa file quá hạn, giữ file mới, gỡ thư mục rỗng", async () => {
    const oldMsg: PersistableMessage = {
      threadId: "t-old",
      msgId: "m-old",
      images: [{ url: "https://z.vn/o.png" }],
    };
    const newMsg: PersistableMessage = {
      threadId: "t-new",
      msgId: "m-new",
      images: [{ url: "https://z.vn/n.png" }],
    };
    await store.persistBatchImages("acc-2", [oldMsg, newMsg], downloadOk());

    // Giả lập file cũ 8 ngày (quá MEDIA_RETENTION_DAYS=7)
    const oldAbs = path.join(dataDir, oldMsg.images[0]!.localPath!);
    const eightDaysAgo = new Date(Date.now() - 8 * 24 * 60 * 60 * 1000);
    fs.utimesSync(oldAbs, eightDaysAgo, eightDaysAgo);

    const removed = store.cleanupExpiredMedia();

    assert.ok(removed >= 1);
    assert.ok(!fs.existsSync(oldAbs));
    assert.ok(!fs.existsSync(path.dirname(oldAbs)), "thư mục rỗng phải bị gỡ");
    assert.ok(fs.existsSync(path.join(dataDir, newMsg.images[0]!.localPath!)));
  });
});

describe("transcribeBatchVoice", () => {
  const CFG = { sttBaseUrl: "https://router.test", sttModel: "gemini-3.5-flash", sttApiKey: "sk-stt", sttEnabled: true };
  const KHONG_CAU_HINH = { sttBaseUrl: "", sttModel: "", sttApiKey: null, sttEnabled: true };
  const DA_TAT = { ...CFG, sttEnabled: false };

  it("nút gạt TẮT -> báo cho biết, KHÔNG gọi tải/phiên âm (dù đã cấu hình đủ)", async () => {
    const msg = { voiceUrl: "https://z.vn/v.m4a", text: "" };
    let taiGoi = false;
    let phienAmGoi = false;
    await store.transcribeBatchVoice(
      DA_TAT,
      [msg],
      async () => {
        taiGoi = true;
        return null;
      },
      async () => {
        phienAmGoi = true;
        return "";
      },
    );
    assert.equal(msg.text, "[Tin nhắn thoại - tính năng phiên âm (STT) đang TẮT cho agent này]");
    assert.equal(taiGoi, false);
    assert.equal(phienAmGoi, false);
  });

  it("chưa cấu hình STT -> báo cho biết, KHÔNG gọi tải/phiên âm", async () => {
    const msg = { voiceUrl: "https://z.vn/v.m4a", text: "" };
    let taiGoi = false;
    let phienAmGoi = false;
    await store.transcribeBatchVoice(
      KHONG_CAU_HINH,
      [msg],
      async () => {
        taiGoi = true;
        return null;
      },
      async () => {
        phienAmGoi = true;
        return "";
      },
    );
    assert.equal(msg.text, "[Tin nhắn thoại - chưa cấu hình Speech to Text cho agent này]");
    assert.equal(taiGoi, false);
    assert.equal(phienAmGoi, false);
  });

  it("tải audio thất bại -> báo lỗi tải, không throw", async () => {
    const msg = { voiceUrl: "https://z.vn/v.m4a", text: "" };
    await store.transcribeBatchVoice(CFG, [msg], async () => null, async () => "không tới đây");
    assert.equal(msg.text, "[Tin nhắn thoại - không tải được file âm thanh]");
  });

  it("phiên âm ném lỗi -> báo lỗi phiên âm, không văng lên caller", async () => {
    const msg = { voiceUrl: "https://z.vn/v.m4a", text: "" };
    await store.transcribeBatchVoice(
      CFG,
      [msg],
      async () => ({ data: Buffer.from([1]), mediaType: "audio/mp4", fileName: "v.m4a" }),
      async () => {
        throw new Error("provider sập");
      },
    );
    assert.equal(msg.text, "[Tin nhắn thoại - lỗi phiên âm, xem log terminal]");
  });

  it("phiên âm thành công nhưng rỗng -> báo không nghe rõ", async () => {
    const msg = { voiceUrl: "https://z.vn/v.m4a", text: "" };
    await store.transcribeBatchVoice(
      CFG,
      [msg],
      async () => ({ data: Buffer.from([1]), mediaType: "audio/mp4", fileName: "v.m4a" }),
      async () => "   ",
    );
    assert.equal(msg.text, "[Tin nhắn thoại - không nghe rõ nội dung]");
  });

  it("phiên âm thành công có chữ -> text = transcript, không thêm tiền tố", async () => {
    const msg = { voiceUrl: "https://z.vn/v.m4a", text: "" };
    await store.transcribeBatchVoice(
      CFG,
      [msg],
      async () => ({ data: Buffer.from([1]), mediaType: "audio/mp4", fileName: "v.m4a" }),
      async () => "cho tôi hỏi giờ mở cửa",
    );
    assert.equal(msg.text, "cho tôi hỏi giờ mở cửa");
  });

  it("tin không có voiceUrl -> bỏ qua, giữ nguyên text", async () => {
    const msg = { text: "chào bot" };
    await store.transcribeBatchVoice(
      CFG,
      [msg],
      async () => {
        throw new Error("không được gọi");
      },
      async () => {
        throw new Error("không được gọi");
      },
    );
    assert.equal(msg.text, "chào bot");
  });
});

describe("readBatchDocuments", () => {
  it("đuôi không hỗ trợ -> báo chưa hỗ trợ, KHÔNG gọi tải/trích", async () => {
    const msg = { documentUrl: "https://z.vn/f", documentFileName: "nen.zip", text: "" };
    let taiGoi = false;
    await store.readBatchDocuments(
      [msg],
      async () => {
        taiGoi = true;
        return null;
      },
      async () => "không tới đây",
    );
    assert.equal(msg.text, "[File .zip - định dạng chưa hỗ trợ đọc]");
    assert.equal(taiGoi, false);
  });

  it("tải file thất bại -> báo lỗi tải, không throw", async () => {
    const msg = { documentUrl: "https://z.vn/f", documentFileName: "BaoCao.pdf", text: "" };
    await store.readBatchDocuments([msg], async () => null, async () => "không tới đây");
    assert.equal(msg.text, "[File BaoCao.pdf - không tải được]");
  });

  it("trích chữ ném lỗi -> báo lỗi đọc nội dung, không văng lên caller", async () => {
    const msg = { documentUrl: "https://z.vn/f", documentFileName: "BaoCao.pdf", text: "" };
    await store.readBatchDocuments(
      [msg],
      async () => ({ data: Buffer.from([1]), fileName: "f" }),
      async () => {
        throw new Error("file hỏng/mật khẩu");
      },
    );
    assert.equal(msg.text, "[File BaoCao.pdf - lỗi đọc nội dung, xem log terminal]");
  });

  it("PDF trích ra rỗng (bản scan/ảnh chụp) -> báo đúng lý do KHÁC định dạng khác", async () => {
    const msgPdf = { documentUrl: "https://z.vn/f", documentFileName: "Scan.pdf", text: "" };
    await store.readBatchDocuments([msgPdf], async () => ({ data: Buffer.from([1]), fileName: "f" }), async () => "   ");
    assert.equal(
      msgPdf.text,
      "[File PDF Scan.pdf - không có lớp chữ (có thể là bản scan/ảnh chụp), bot chưa đọc được nội dung dạng này]",
    );

    const msgXlsx = { documentUrl: "https://z.vn/f", documentFileName: "Trong.xlsx", text: "" };
    await store.readBatchDocuments([msgXlsx], async () => ({ data: Buffer.from([1]), fileName: "f" }), async () => "");
    assert.equal(msgXlsx.text, "[File Trong.xlsx - không có nội dung chữ]");
  });

  it("trích chữ thành công -> text = nội dung trích được, không thêm tiền tố", async () => {
    const msg = { documentUrl: "https://z.vn/f", documentFileName: "HopDong.docx", text: "" };
    await store.readBatchDocuments(
      [msg],
      async () => ({ data: Buffer.from([1]), fileName: "f" }),
      async () => "Điều 1: Bên A cam kết...",
    );
    assert.equal(msg.text, "Điều 1: Bên A cam kết...");
  });

  it("tin không có documentUrl -> bỏ qua, giữ nguyên text", async () => {
    const msg = { text: "chào bot" };
    await store.readBatchDocuments(
      [msg],
      async () => {
        throw new Error("không được gọi");
      },
      async () => {
        throw new Error("không được gọi");
      },
    );
    assert.equal(msg.text, "chào bot");
  });

  it("dispatch đúng đuôi cho hàm extract (pptx)", async () => {
    const msg = { documentUrl: "https://z.vn/f", documentFileName: "SlideDeck.pptx", text: "" };
    let extGoi = "";
    await store.readBatchDocuments(
      [msg],
      async () => ({ data: Buffer.from([1]), fileName: "f" }),
      async (_data, ext) => {
        extGoi = ext;
        return "Slide 1: xin chào";
      },
    );
    assert.equal(extGoi, "pptx");
    assert.equal(msg.text, "Slide 1: xin chào");
  });
});

describe("persistBatchImages - thử lại và biến thể dự phòng (bẫy 2026-09-21)", () => {
  const png = () => ({ data: PNG_BYTES, mediaType: "image/png" });

  it("lỗi thoáng qua ở lần đầu: thử lại CÙNG URL và lưu được", async () => {
    const goi: string[] = [];
    const flaky = async (url: string) => {
      goi.push(url);
      return goi.length === 1 ? null : png();
    };
    const msg: PersistableMessage = { threadId: "t-r1", msgId: "m-r1", images: [{ url: "https://z.vn/chinh.jpg" }] };
    await store.persistBatchImages("acc-1", [msg], flaky, 0);
    assert.deepEqual(goi, ["https://z.vn/chinh.jpg", "https://z.vn/chinh.jpg"]);
    assert.ok(msg.images[0]!.localPath, "lần thử lại thành công phải gắn localPath");
  });

  it("URL chính hỏng 2 lần: dùng biến thể dự phòng của CÙNG ảnh", async () => {
    const goi: string[] = [];
    const dl = async (url: string) => {
      goi.push(url);
      return url.includes("du-phong") ? png() : null;
    };
    const msg: PersistableMessage = {
      threadId: "t-r2",
      msgId: "m-r2",
      images: [{ url: "https://z.vn/chinh.jpg", fallbackUrls: ["https://z.vn/du-phong.jpg", "https://z.vn/khac.jpg"] }],
    };
    await store.persistBatchImages("acc-1", [msg], dl, 0);
    assert.deepEqual(goi, ["https://z.vn/chinh.jpg", "https://z.vn/chinh.jpg", "https://z.vn/du-phong.jpg"]);
    assert.ok(msg.images[0]!.localPath);
  });

  it("thử tối đa 3 lần rồi bỏ - không kéo dài vô hạn, KHÔNG reject", async () => {
    let n = 0;
    const msg: PersistableMessage = {
      threadId: "t-r3",
      msgId: "m-r3",
      images: [{ url: "https://z.vn/a.jpg", fallbackUrls: ["https://z.vn/b.jpg", "https://z.vn/c.jpg", "https://z.vn/d.jpg"] }],
    };
    await store.persistBatchImages("acc-1", [msg], async () => (n++, null), 0);
    assert.equal(n, 3);
    assert.equal(msg.images[0]!.localPath, undefined);
  });

  it("downloader NÉM lỗi: vẫn không reject, ảnh sau vẫn được xử lý", async () => {
    let lan = 0;
    const dl = async () => {
      lan++;
      if (lan <= 3) throw new Error("boom");
      return png();
    };
    const msg: PersistableMessage = {
      threadId: "t-r4",
      msgId: "m-r4",
      images: [{ url: "https://z.vn/hong.jpg" }, { url: "https://z.vn/tot.jpg" }],
    };
    await store.persistBatchImages("acc-1", [msg], dl, 0);
    assert.equal(msg.images[0]!.localPath, undefined);
    assert.ok(msg.images[1]!.localPath, "ảnh thứ 2 không bị ảnh thứ 1 kéo chết theo");
  });
});

describe("ghiChuAnhLoi", () => {
  it("mọi ảnh đã lưu: không ghi chú gì", () => {
    assert.equal(store.ghiChuAnhLoi([{ localPath: "media/a.jpg" }]), "");
  });

  it("có ảnh chưa lưu: ghi chú nói thẳng là KHÔNG xem được, kèm số ảnh", () => {
    const ghiChu = store.ghiChuAnhLoi([{ localPath: "media/a.jpg" }, {}, {}]);
    assert.match(ghiChu, /2 ảnh không tải về được/);
    assert.match(ghiChu, /KHÔNG xem được/);
  });
});
