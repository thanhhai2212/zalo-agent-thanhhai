import { db, trongGiaoDich } from "./database.js";
import { THREAD_DENY_ALL_TOOLS } from "./thread-permission-constants.js";

export type ThreadRow = {
  accountId: string;
  threadId: string;
  threadType: number;
  displayName: string;
  botEnabled: boolean;
  messageCount: number;
  lastMessageAt: string | null;
  lastSenderName: string | null;
  /** Agent gán riêng cho thread này, null = dùng agent của account */
  agentId: string | null;
  /** Ghi đè yêu cầu @mention riêng cho thread này, null = theo account */
  mentionOverride: "require" | "no_require" | null;
  /** Tool bị tắt THÊM riêng cho thread này (giao với account/agent, không mở lại) */
  disabledTools: string[];
  /** Mức chia sẻ thông tin nhạy cảm/bộ nhớ cho liên hệ này */
  privacyTier: "normal" | "restricted";
  /** Model riêng cho cuộc chat này (cùng router với cấu hình chung), null = model của agent */
  modelOverride: string | null;
  /** Được xin tạo video khi chat riêng (mặc định chỉ trong nhóm) */
  videoDmAllowed: boolean;
  /** VIP video: giọng Gemini như chủ bot, xin được ở cả nhóm lẫn chat riêng */
  videoVip: boolean;
  /** Mức suy nghĩ riêng của cuộc chat (lệnh /effort hoặc dashboard), null = theo agent */
  effortOverride: string | null;
  /** Bộ tự đánh giá tin nhóm không tag: off | shadow (chỉ ghi nhật ký) | on */
  judgeMode: JudgeMode;
};

const upsertStmt = db.prepare(`
  INSERT INTO threads (account_id, thread_id, thread_type, display_name, message_count,
                       last_message_at, last_sender_name)
  VALUES (?, ?, ?, ?, 1, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), ?)
  ON CONFLICT (account_id, thread_id) DO UPDATE SET
    message_count = message_count + 1,
    last_message_at = excluded.last_message_at,
    last_sender_name = excluded.last_sender_name,
    -- Tên mới chỉ ghi đè khi không rỗng (tin sau có thể thiếu tên)
    display_name = CASE WHEN excluded.display_name != '' THEN excluded.display_name
                        ELSE display_name END
`);

/** Ghi nhận 1 tin đến cho thread (tạo mới nếu chưa có). displayName rỗng = giữ tên cũ. */
export function recordThreadActivity(params: {
  accountId: string;
  threadId: string;
  threadType: number;
  displayName: string;
  lastSenderName: string;
}): void {
  upsertStmt.run(
    params.accountId,
    params.threadId,
    params.threadType,
    params.displayName,
    params.lastSenderName,
  );
}

const getStmt = db.prepare(
  "SELECT bot_enabled, display_name FROM threads WHERE account_id = ? AND thread_id = ?",
);

/** Bot có được phép trả lời thread này không. Thread chưa từng thấy = có. */
export function isBotEnabled(accountId: string, threadId: string): boolean {
  const row = getStmt.get(accountId, threadId) as { bot_enabled: number } | undefined;
  return row === undefined || row.bot_enabled === 1;
}

/**
 * Trạng thái thread cho scheduler (`proactive-send-guard.ts`) - CỐ Ý khác
 * `isBotEnabled` ở trên: hàm đó mặc định permissive cho thread lạ (đúng cho
 * TIN ĐẾN - chưa kịp ghi thread thì vẫn phải trả lời được), còn tin CHỦ ĐỘNG
 * không được nhắm vào một thread chưa từng ghi nhận trong hệ thống - trả
 * `undefined` để caller coi đó là điều kiện chặn, không phải mặc định cho qua.
 */
export function findThreadStatus(accountId: string, threadId: string): { botEnabled: boolean } | undefined {
  const row = getStmt.get(accountId, threadId) as { bot_enabled: number } | undefined;
  return row ? { botEnabled: row.bot_enabled === 1 } : undefined;
}

/** Tên hiển thị đã lưu của thread (tên nhóm / tên người); chưa có thì chuỗi rỗng. */
export function getThreadDisplayName(accountId: string, threadId: string): string {
  const row = getStmt.get(accountId, threadId) as { display_name: string } | undefined;
  return row?.display_name ?? "";
}

/** Thread group đã có tên hiển thị chưa - dùng để quyết định có gọi getGroupInfo không */
export function hasDisplayName(accountId: string, threadId: string): boolean {
  const row = getStmt.get(accountId, threadId) as { display_name: string } | undefined;
  return row !== undefined && row.display_name !== "";
}

const getTypeStmt = db.prepare("SELECT thread_type FROM threads WHERE account_id = ? AND thread_id = ?");

/** `undefined` = thread chưa tồn tại (khác với đã tồn tại nhưng type chưa rõ = -1) */
export function getThreadType(accountId: string, threadId: string): number | undefined {
  const row = getTypeStmt.get(accountId, threadId) as { thread_type: number } | undefined;
  return row?.thread_type;
}

const setEnabledStmt = db.prepare(
  "UPDATE threads SET bot_enabled = ? WHERE account_id = ? AND thread_id = ?",
);

export function setBotEnabled(accountId: string, threadId: string, enabled: boolean): boolean {
  const result = setEnabledStmt.run(enabled ? 1 : 0, accountId, threadId);
  return result.changes > 0;
}

const setNameStmt = db.prepare(
  "UPDATE threads SET display_name = ? WHERE account_id = ? AND thread_id = ?",
);

export function setThreadDisplayName(accountId: string, threadId: string, name: string): void {
  setNameStmt.run(name, accountId, threadId);
}

// ===== Agent riêng theo thread (mỗi nhóm một "tính cách") =====

const getAgentIdStmt = db.prepare(
  "SELECT agent_id FROM threads WHERE account_id = ? AND thread_id = ?",
);

/**
 * Agent GÁN RIÊNG cho thread này, hoặc `null` nếu chưa gán (dùng agent của
 * account như mặc định). Thread chưa từng thấy cũng trả `null` - đúng ý, vì
 * đó cũng là "chưa gán gì".
 */
export function getThreadAgentId(accountId: string, threadId: string): string | null {
  const row = getAgentIdStmt.get(accountId, threadId) as { agent_id: string | null } | undefined;
  return row?.agent_id ?? null;
}

const setAgentIdStmt = db.prepare(
  "UPDATE threads SET agent_id = ? WHERE account_id = ? AND thread_id = ?",
);

/** `agentId = null` gỡ gán, quay về dùng agent của account */
export function setThreadAgentId(accountId: string, threadId: string, agentId: string | null): boolean {
  const result = setAgentIdStmt.run(agentId, accountId, threadId);
  return result.changes > 0;
}

// ===== Ma trận phân quyền theo liên hệ (mỗi thread/liên hệ một chính sách riêng) =====
//
// Ba trường dưới đây đều là OVERRIDE cho một thread/liên hệ cụ thể, cùng lớp
// với agent_id ở trên (thắng cấu hình chung của account nếu có set). Nguồn:
// dashboard "Phân quyền Bot" - mỗi dòng trong ma trận là một thread.

const getMentionOverrideStmt = db.prepare(
  "SELECT mention_override FROM threads WHERE account_id = ? AND thread_id = ?",
);

export function getThreadMentionOverride(
  accountId: string,
  threadId: string,
): "require" | "no_require" | null {
  const row = getMentionOverrideStmt.get(accountId, threadId) as
    | { mention_override: string | null }
    | undefined;
  return normalizeMentionOverride(row?.mention_override);
}

const setMentionOverrideStmt = db.prepare(
  "UPDATE threads SET mention_override = ? WHERE account_id = ? AND thread_id = ?",
);

export function setThreadMentionOverride(
  accountId: string,
  threadId: string,
  value: "require" | "no_require" | null,
): boolean {
  const result = setMentionOverrideStmt.run(value, accountId, threadId);
  return result.changes > 0;
}

export type JudgeMode = "off" | "shadow" | "on";

const getJudgeModeStmt = db.prepare(
  "SELECT judge_mode FROM threads WHERE account_id = ? AND thread_id = ?",
);

/** Giá trị lạ trong DB coi như tắt - bộ này chỉ được BẬT bằng một giá trị hợp lệ. */
export function normalizeJudgeMode(raw: string | null | undefined): JudgeMode {
  return raw === "shadow" || raw === "on" ? raw : "off";
}

const setJudgeModeStmt = db.prepare(
  "UPDATE threads SET judge_mode = ? WHERE account_id = ? AND thread_id = ?",
);

export function getThreadJudgeMode(accountId: string, threadId: string): JudgeMode {
  const row = getJudgeModeStmt.get(accountId, threadId) as { judge_mode: string | null } | undefined;
  return normalizeJudgeMode(row?.judge_mode);
}

const getDisabledToolsStmt = db.prepare(
  "SELECT disabled_tools FROM threads WHERE account_id = ? AND thread_id = ?",
);

export function getThreadDisabledTools(accountId: string, threadId: string): string[] {
  const row = getDisabledToolsStmt.get(accountId, threadId) as { disabled_tools: string } | undefined;
  return row ? parseThreadDisabledTools(row.disabled_tools) : [];
}

const setDisabledToolsStmt = db.prepare(
  "UPDATE threads SET disabled_tools = ? WHERE account_id = ? AND thread_id = ?",
);

export function setThreadDisabledTools(accountId: string, threadId: string, tools: string[]): boolean {
  const result = setDisabledToolsStmt.run(JSON.stringify(tools), accountId, threadId);
  return result.changes > 0;
}

const getPrivacyTierStmt = db.prepare(
  "SELECT privacy_tier FROM threads WHERE account_id = ? AND thread_id = ?",
);

export function getThreadPrivacyTier(accountId: string, threadId: string): "normal" | "restricted" {
  const row = getPrivacyTierStmt.get(accountId, threadId) as { privacy_tier: string } | undefined;
  return row ? normalizePrivacyTier(row.privacy_tier) : "normal";
}

const setPrivacyTierStmt = db.prepare(
  "UPDATE threads SET privacy_tier = ? WHERE account_id = ? AND thread_id = ?",
);

export function setThreadPrivacyTier(
  accountId: string,
  threadId: string,
  tier: "normal" | "restricted",
): boolean {
  const result = setPrivacyTierStmt.run(tier, accountId, threadId);
  return result.changes > 0;
}

const getModelOverrideStmt = db.prepare("SELECT model_override FROM threads WHERE account_id = ? AND thread_id = ?");
const setModelOverrideStmt = db.prepare("UPDATE threads SET model_override = ? WHERE account_id = ? AND thread_id = ?");

const getEffortStmt = db.prepare("SELECT effort_override FROM threads WHERE account_id = ? AND thread_id = ?");
const setEffortStmt = db.prepare("UPDATE threads SET effort_override = ? WHERE account_id = ? AND thread_id = ?");

/** Đặt/bỏ model riêng của cuộc chat (lệnh /model của chủ bot). False nếu thread chưa có. */
export function setThreadModelOverride(accountId: string, threadId: string, model: string | null): boolean {
  return setModelOverrideStmt.run(model?.trim() || null, accountId, threadId).changes > 0;
}

/** Mức suy nghĩ riêng của cuộc chat (lệnh /effort), null = theo agent. */
export function getThreadEffortOverride(accountId: string, threadId: string): string | null {
  const row = getEffortStmt.get(accountId, threadId) as { effort_override: string | null } | undefined;
  return row?.effort_override?.trim() || null;
}

export function setThreadEffortOverride(accountId: string, threadId: string, effort: string | null): boolean {
  return setEffortStmt.run(effort?.trim() || null, accountId, threadId).changes > 0;
}

const getVideoDmStmt = db.prepare("SELECT video_dm_allowed FROM threads WHERE account_id = ? AND thread_id = ?");
const setVideoDmStmt = db.prepare("UPDATE threads SET video_dm_allowed = ? WHERE account_id = ? AND thread_id = ?");

/** Người này được xin tạo video khi chat riêng với bot (trang Phân quyền Bot). */
export function getThreadVideoDmAllowed(accountId: string, threadId: string): boolean {
  const row = getVideoDmStmt.get(accountId, threadId) as { video_dm_allowed: number } | undefined;
  return row?.video_dm_allowed === 1;
}

const getVipStmt = db.prepare("SELECT video_vip FROM threads WHERE account_id = ? AND thread_id = ? AND thread_type = 0");
const setVipStmt = db.prepare("UPDATE threads SET video_vip = ? WHERE account_id = ? AND thread_id = ?");

/** Người này (UID) là VIP video? Tra dòng chat riêng của họ - thread_id chat riêng CHÍNH LÀ UID. */
export function laVipVideo(accountId: string, uid: string): boolean {
  if (!uid) return false;
  const row = getVipStmt.get(accountId, uid) as { video_vip: number } | undefined;
  return row?.video_vip === 1;
}

/** Model riêng của cuộc chat (trang Phân quyền Bot), null = dùng model của agent. */
export function getThreadModelOverride(accountId: string, threadId: string): string | null {
  const row = getModelOverrideStmt.get(accountId, threadId) as { model_override: string | null } | undefined;
  return row?.model_override?.trim() || null;
}

const setPermissionsStmt = db.prepare(`
  UPDATE threads
  SET bot_enabled = ?, mention_override = ?, disabled_tools = ?, privacy_tier = ?
  WHERE account_id = ? AND thread_id = ?
`);

/**
 * Lưu cả ma trận của một liên hệ bằng MỘT câu UPDATE để không có trạng thái dở
 * nếu request hỏng giữa chừng.
 *
 * `agentId` optional: dashboard "Phân quyền Bot" đổi Agent cùng lúc với quyền
 * trên MỘT lần lưu. Truyền kèm thì cả hai UPDATE chạy trong CÙNG giao dịch
 * (`trongGiaoDich`, dùng chung bản đã chuyển lên `database.ts`): agentId
 * không hợp lệ (route validate trước khi gọi xuống đây) không được để lại 4
 * field quyền đã ghi dở trong khi agent thì chưa đổi.
 */
export function setThreadPermissions(params: {
  accountId: string;
  threadId: string;
  botEnabled: boolean;
  mentionOverride: "require" | "no_require" | null;
  disabledTools: string[];
  privacyTier: "normal" | "restricted";
  agentId?: string | null;
  /** undefined = giữ nguyên; null/rỗng = bỏ model riêng */
  modelOverride?: string | null;
  /** undefined = giữ nguyên */
  videoDmAllowed?: boolean;
  /** undefined = giữ nguyên */
  videoVip?: boolean;
  /** undefined = giữ nguyên; null = theo agent */
  effortOverride?: string | null;
  /** undefined = giữ nguyên */
  judgeMode?: JudgeMode;
}): boolean {
  return trongGiaoDich(() => {
    const result = setPermissionsStmt.run(
      params.botEnabled ? 1 : 0,
      params.mentionOverride,
      JSON.stringify([...new Set(params.disabledTools)]),
      params.privacyTier,
      params.accountId,
      params.threadId,
    );
    if (result.changes === 0) return false;
    if (params.agentId !== undefined) {
      setAgentIdStmt.run(params.agentId, params.accountId, params.threadId);
    }
    if (params.modelOverride !== undefined) {
      setModelOverrideStmt.run(params.modelOverride?.trim() || null, params.accountId, params.threadId);
    }
    if (params.videoDmAllowed !== undefined) {
      setVideoDmStmt.run(params.videoDmAllowed ? 1 : 0, params.accountId, params.threadId);
    }
    if (params.videoVip !== undefined) {
      setVipStmt.run(params.videoVip ? 1 : 0, params.accountId, params.threadId);
    }
    if (params.effortOverride !== undefined) {
      setEffortStmt.run(params.effortOverride, params.accountId, params.threadId);
    }
    if (params.judgeMode !== undefined) {
      setJudgeModeStmt.run(params.judgeMode === "off" ? null : params.judgeMode, params.accountId, params.threadId);
    }
    return true;
  });
}

// ===== Memory lớp 2: rolling summary =====

const getSummaryStmt = db.prepare(
  "SELECT summary, summary_covers_to_message_id FROM threads WHERE account_id = ? AND thread_id = ?",
);

export function getThreadSummary(
  accountId: string,
  threadId: string,
): { summary: string; coversTo: number } {
  const row = getSummaryStmt.get(accountId, threadId) as
    | { summary: string; summary_covers_to_message_id: number }
    | undefined;
  return { summary: row?.summary ?? "", coversTo: row?.summary_covers_to_message_id ?? 0 };
}

const setSummaryStmt = db.prepare(
  "UPDATE threads SET summary = ?, summary_covers_to_message_id = ? WHERE account_id = ? AND thread_id = ?",
);

export function setThreadSummary(
  accountId: string,
  threadId: string,
  summary: string,
  coversTo: number,
): void {
  setSummaryStmt.run(summary, coversTo, accountId, threadId);
}

const insertPlaceholderStmt = db.prepare(`
  INSERT INTO threads (account_id, thread_id, thread_type, display_name, message_count, summary, summary_covers_to_message_id)
  VALUES (?, ?, ?, ?, 0, ?, 0)
`);

/**
 * Tạo 1 dòng thread "trống" - CHƯA từng nhận tin thật (`message_count=0`,
 * `last_message_at=NULL`) - chỉ để giữ chỗ 1 bản `summary` phục hồi từ file
 * Export (tính năng Restore nhóm) khi account đích chưa từng thấy đúng
 * `thread_id` đó. Khác `recordThreadActivity` (dành cho tin THẬT, luôn bump
 * `message_count`) - dùng nhầm hàm đó ở đây sẽ bịa ra 1 lượt tin không có
 * thật. Gọi hàm này khi ĐÃ xác nhận thread chưa tồn tại (`getThreadType`
 * trả `undefined`) - trùng `(account_id, thread_id)` đã có sẽ vi phạm PRIMARY KEY.
 */
export function insertPlaceholderThreadWithSummary(
  accountId: string,
  threadId: string,
  threadType: number,
  displayName: string,
  summary: string,
): void {
  insertPlaceholderStmt.run(accountId, threadId, threadType, displayName, summary);
}

const getEpochStmt = db.prepare(
  "SELECT context_epoch FROM threads WHERE account_id = ? AND thread_id = ?",
);

/**
 * Số lần ngữ cảnh thread này đã bị xóa sạch. Vào khóa phiên gửi router để mỗi
 * lần xóa mở một phiên mới - xem `cache-session-id.ts` và cột `context_epoch`.
 *
 * Thread chưa có dòng nào (tin đầu tiên chưa ghi xong) trả 0, cùng giá trị với
 * thread chưa từng bị xóa - đúng ý, vì cả hai đều là "chưa có gì để bỏ đi".
 */
export function getThreadContextEpoch(accountId: string, threadId: string): number {
  const row = getEpochStmt.get(accountId, threadId) as { context_epoch?: number } | undefined;
  return row?.context_epoch ?? 0;
}

const listStmt = db.prepare(`
  SELECT account_id, thread_id, thread_type, display_name, bot_enabled,
         message_count, last_message_at, last_sender_name, agent_id,
         mention_override, disabled_tools, privacy_tier, model_override, video_dm_allowed, video_vip, effort_override, judge_mode
  FROM threads
  WHERE (? = '' OR account_id = ?) AND (display_name LIKE ? OR thread_id LIKE ?)
    AND (? < 0 OR thread_type = ?)
  ORDER BY last_message_at DESC
  LIMIT ? OFFSET ?
`);

/** accountId bỏ trống = mọi account (dashboard mặc định xem trộn chung) */
export function listThreads(params: {
  accountId?: string;
  query?: string;
  /** 0 = chat riêng, 1 = nhóm, bỏ trống = cả hai */
  threadType?: 0 | 1;
  limit?: number;
  offset?: number;
}): ThreadRow[] {
  const acc = params.accountId ?? "";
  const like = `%${params.query ?? ""}%`;
  type Row = {
    account_id: string; thread_id: string; thread_type: number; display_name: string;
    bot_enabled: number; message_count: number; last_message_at: string | null;
    last_sender_name: string | null; agent_id: string | null;
    mention_override: string | null; disabled_tools: string; privacy_tier: string;
    model_override: string | null; video_dm_allowed: number; video_vip: number; effort_override: string | null;
    judge_mode: string | null;
  };
  const rows = listStmt.all(
    acc, acc, like, like, params.threadType ?? -1, params.threadType ?? -1, params.limit ?? 50, params.offset ?? 0,
  ) as unknown as Row[];
  return rows.map((r) => ({
    accountId: r.account_id,
    threadId: r.thread_id,
    threadType: r.thread_type,
    displayName: r.display_name,
    botEnabled: r.bot_enabled === 1,
    messageCount: r.message_count,
    lastMessageAt: r.last_message_at,
    lastSenderName: r.last_sender_name,
    agentId: r.agent_id,
    mentionOverride: normalizeMentionOverride(r.mention_override),
    disabledTools: parseThreadDisabledTools(r.disabled_tools),
    privacyTier: normalizePrivacyTier(r.privacy_tier),
    modelOverride: r.model_override?.trim() || null,
    videoDmAllowed: r.video_dm_allowed === 1,
    videoVip: r.video_vip === 1,
    effortOverride: r.effort_override?.trim() || null,
    judgeMode: normalizeJudgeMode(r.judge_mode),
  }));
}

function normalizeMentionOverride(raw: string | null | undefined): "require" | "no_require" | null {
  if (raw === null || raw === undefined) return null;
  return raw === "no_require" ? "no_require" : "require";
}

function normalizePrivacyTier(raw: string): "normal" | "restricted" {
  return raw === "normal" ? "normal" : "restricted";
}

function parseThreadDisabledTools(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (Array.isArray(parsed) && parsed.every((value) => typeof value === "string")) {
      return parsed;
    }
  } catch {
    // Đi tiếp xuống sentinel fail-closed.
  }
  return [THREAD_DENY_ALL_TOOLS];
}

const listAllForAccountStmt = db.prepare(`
  SELECT account_id, thread_id, thread_type, display_name, bot_enabled,
         message_count, last_message_at, last_sender_name, agent_id
  FROM threads WHERE account_id = ?
`);

/**
 * Toàn bộ thread của 1 account, KHÔNG phân trang - dùng cho quét backup, không
 * phải màn Sessions/Phân quyền. Không đọc 3 cột ma trận phân quyền (không quét
 * cần tới) - trả mặc định "chưa override gì" cho đủ hình dạng `ThreadRow`.
 */
export function listThreadsForAccount(accountId: string): ThreadRow[] {
  type Row = {
    account_id: string; thread_id: string; thread_type: number; display_name: string;
    bot_enabled: number; message_count: number; last_message_at: string | null;
    last_sender_name: string | null; agent_id: string | null;
  };
  const rows = listAllForAccountStmt.all(accountId) as unknown as Row[];
  return rows.map((r) => ({
    accountId: r.account_id,
    threadId: r.thread_id,
    threadType: r.thread_type,
    displayName: r.display_name,
    botEnabled: r.bot_enabled === 1,
    messageCount: r.message_count,
    lastMessageAt: r.last_message_at,
    lastSenderName: r.last_sender_name,
    agentId: r.agent_id,
    mentionOverride: null,
    disabledTools: [],
    privacyTier: "normal",
    modelOverride: null,
    videoDmAllowed: false,
    videoVip: false,
    effortOverride: null,
    judgeMode: "off",
  }));
}

/**
 * Dựng lại bảng threads từ messages sẵn có - chạy 1 lần khi threads còn trống
 * (nâng cấp từ bản chưa có dashboard). Tên thread = sender_name của tin user
 * gần nhất; thread_type không suy ra được từ messages nên tạm để -1, tin đến
 * kế tiếp sẽ upsert đúng type.
 */
export function backfillThreadsFromMessages(): number {
  const count = (db.prepare("SELECT COUNT(*) AS n FROM threads").get() as { n: number }).n;
  if (count > 0) return 0;

  const result = db
    .prepare(`
      INSERT INTO threads (account_id, thread_id, thread_type, display_name, message_count,
                           last_message_at, last_sender_name)
      SELECT m.account_id, m.thread_id, -1,
             COALESCE((SELECT sender_name FROM messages
                       WHERE account_id = m.account_id AND thread_id = m.thread_id
                         AND role = 'user' AND sender_name IS NOT NULL
                       ORDER BY id DESC LIMIT 1), ''),
             COUNT(*), MAX(m.created_at),
             (SELECT sender_name FROM messages
              WHERE account_id = m.account_id AND thread_id = m.thread_id AND role = 'user'
              ORDER BY id DESC LIMIT 1)
      FROM messages m
      GROUP BY m.account_id, m.thread_id
    `)
    .run();
  return Number(result.changes);
}
