import { boDauTiengViet } from "../shared/bo-dau-tieng-viet.js";

/**
 * Cổng THÔ của bộ tự đánh giá tin nhóm: tin này có giống một câu hỏi / lời nhờ
 * giúp không. Mã thuần, miễn phí - tầng đầu tiên trong chuỗi rẻ -> đắt, tầng
 * nào loại là dừng và KHÔNG tốn một lượt chấm điểm nào.
 *
 * Cố ý DỄ TÍNH: chỉ vứt thứ hiển nhiên không phải (chào, "ok", "haha", chỉ có
 * link, quá ngắn). Phán đoán thật nằm ở tầng chấm điểm phía sau; ở đây lọc quá
 * tay thì câu hỏi gõ không dấu / không dấu hỏi bị bỏ lỡ mà không có dấu vết gì.
 *
 * Các cụm dưới đây là chữ ĐÃ BỎ DẤU (người ta gõ không dấu rất nhiều), và chỉ
 * khớp nguyên từ để "sao" không trúng "sao chep". Mỗi cụm là một lựa chọn
 * chuỗi cố định, không có lượng từ lồng nhau nên không dính ReDoS.
 */

const MIN_KY_TU = 8;
const MIN_TU = 3;

const URL_RE = /(?:https?:\/\/|www\.)\S+/gi;

const TU_HOI = [
  "sao", "the nao", "nhu the nao", "lam sao", "lam the nao", "tai sao", "vi sao",
  "bao nhieu", "bao lau", "bao gio", "khi nao", "luc nao", "o dau", "cho nao",
  "ai biet", "co ai", "ai co", "ai giup", "ai chi",
  "cho hoi", "xin hoi", "hoi chut", "hoi them", "muon hoi", "xin cho hoi",
  "giup", "huong dan", "chi minh", "chi giup", "tu van", "nho ai",
  "co the", "duoc khong", "duoc ko", "duoc k", "dc ko", "dc khong",
  "co khong", "co ko", "phai khong", "phai ko", "nhi", "vay", "hay la", "hay khong",
  "la gi", "la ai", "nghia la", "khac gi", "giong nhau", "nen chon", "nen dung",
  "can gi", "can phai", "bat buoc", "dang ky", "dang ki", "hoc phi", "gia ca", "cach nao",
];

// Một lựa chọn chuỗi cố định bao quanh bởi "không phải chữ/số": khớp nguyên từ,
// không dính lượng từ lồng nhau.
const TU_HOI_RE = new RegExp(`(?<![a-z0-9])(?:${TU_HOI.map((t) => t.split(" ").join(String.raw`\s+`)).join("|")})(?![a-z0-9])`);

export type KetQuaCong = { ok: true } | { ok: false; lyDo: string };

export function nhinNhuCauHoi(text: string): KetQuaCong {
  const sachLink = text.replace(URL_RE, " ").replace(/\s+/g, " ").trim();
  if (sachLink.length < MIN_KY_TU) return { ok: false, lyDo: "tin quá ngắn hoặc chỉ có link" };
  const soTu = sachLink.split(" ").filter((t) => /[\p{L}\p{N}]/u.test(t)).length;
  if (soTu < MIN_TU) return { ok: false, lyDo: "quá ít chữ" };
  if (/[?？]/.test(sachLink)) return { ok: true };
  if (TU_HOI_RE.test(boDauTiengViet(sachLink).toLowerCase())) return { ok: true };
  return { ok: false, lyDo: "không giống câu hỏi hay lời nhờ giúp" };
}
