import { db } from "../conversation/database.js";

/**
 * Nhật ký bộ tự đánh giá tin nhóm (bảng `group_judge_log`). Ghi MỌI quyết định,
 * kể cả im lặng và kể cả tin bị cổng thô loại: lỗi im lặng không để lại dấu vết
 * là loại lỗi khó tìm nhất, và chủ bot cần xem lại vì sao bot nói / không nói.
 *
 * Chỉ giữ một trích đoạn ngắn của tin (người lạ viết, nhạy cảm), và dọn theo
 * tuổi + số dòng mỗi nhóm để bảng không phình mãi trong nhóm đông.
 */

export type JudgeStage = "cong_tho" | "dieu_kien" | "han_muc" | "cham_diem" | "tra_loi";
export type JudgeDecision = "reply" | "silent" | "shadow_reply";

export type JudgeLogRow = {
  id: number;
  accountId: string;
  threadId: string;
  senderId: string;
  senderName: string;
  excerpt: string;
  mode: string;
  stage: JudgeStage;
  decision: JudgeDecision;
  reason: string;
  scores: Record<string, number> | null;
  createdAt: string;
};

const TRICH_MAX = 160;
const GIU_NGAY = 14;
const GIU_DONG_MOI_NHOM = 1000;
const DON_SAU_MOI = 200;

const insertStmt = db.prepare(`
  INSERT INTO group_judge_log (account_id, thread_id, sender_id, sender_name, excerpt, mode, stage, decision, reason, scores)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const pruneAgeStmt = db.prepare(`DELETE FROM group_judge_log WHERE created_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now', ?)`);
const pruneCountStmt = db.prepare(`
  DELETE FROM group_judge_log
  WHERE account_id = ? AND thread_id = ? AND id NOT IN (
    SELECT id FROM group_judge_log WHERE account_id = ? AND thread_id = ? ORDER BY id DESC LIMIT ?
  )
`);
let demGhi = 0;

export function ghiNhatKyJudge(input: {
  accountId: string;
  threadId: string;
  senderId: string;
  senderName: string;
  text: string;
  mode: string;
  stage: JudgeStage;
  decision: JudgeDecision;
  reason: string;
  scores?: Record<string, number> | null;
}): void {
  const trich = input.text.replace(/\s+/g, " ").trim();
  insertStmt.run(
    input.accountId,
    input.threadId,
    input.senderId,
    input.senderName.replace(/\s+/g, " ").trim().slice(0, 60),
    trich.length > TRICH_MAX ? `${trich.slice(0, TRICH_MAX - 3)}...` : trich,
    input.mode,
    input.stage,
    input.decision,
    input.reason.slice(0, 200),
    input.scores ? JSON.stringify(input.scores) : null,
  );
  demGhi += 1;
  if (demGhi % DON_SAU_MOI === 0) {
    pruneAgeStmt.run(`-${GIU_NGAY} days`);
    pruneCountStmt.run(input.accountId, input.threadId, input.accountId, input.threadId, GIU_DONG_MOI_NHOM);
  }
}

const listStmt = db.prepare(`
  SELECT * FROM group_judge_log WHERE account_id = ? AND thread_id = ? ORDER BY id DESC LIMIT ?
`);

type Row = {
  id: number; account_id: string; thread_id: string; sender_id: string; sender_name: string; excerpt: string;
  mode: string; stage: string; decision: string; reason: string; scores: string | null; created_at: string;
};

function docDiem(raw: string | null): Record<string, number> | null {
  if (!raw) return null;
  try {
    const v = JSON.parse(raw) as Record<string, unknown>;
    const out: Record<string, number> = {};
    for (const [k, x] of Object.entries(v)) if (typeof x === "number") out[k] = x;
    return out;
  } catch {
    return null;
  }
}

export function listNhatKyJudge(accountId: string, threadId: string, limit = 50): JudgeLogRow[] {
  const rows = listStmt.all(accountId, threadId, Math.min(200, Math.max(1, limit))) as unknown as Row[];
  return rows.map((r) => ({
    id: r.id,
    accountId: r.account_id,
    threadId: r.thread_id,
    senderId: r.sender_id,
    senderName: r.sender_name,
    excerpt: r.excerpt,
    mode: r.mode,
    stage: r.stage as JudgeStage,
    decision: r.decision as JudgeDecision,
    reason: r.reason,
    scores: docDiem(r.scores),
    createdAt: r.created_at,
  }));
}
