import assert from "node:assert/strict";
import { beforeEach, describe, it } from "node:test";
import { chiemSuat, datLaiHanMucChoTest, kiemHanMuc, nhanTinMotLan } from "./judge-limits.js";

const H = { moiNhomGio: 3, moiNguoiGio: 2, nghiMs: 20_000 };
const T0 = 1_000_000_000;
const PHUT = 60_000;

beforeEach(() => datLaiHanMucChoTest());

describe("hạn mức tự trả lời", () => {
  it("còn suất thì chiếm được, kiểm không tốn suất", () => {
    assert.equal(kiemHanMuc("n", "a", H, T0), null);
    assert.equal(kiemHanMuc("n", "a", H, T0), null);
    assert.equal(chiemSuat("n", "a", H, T0), null);
  });

  it("phải nghỉ giữa hai lần trong cùng nhóm", () => {
    chiemSuat("n", "a", H, T0);
    assert.match(chiemSuat("n", "b", H, T0 + 10_000) ?? "", /đang nghỉ/);
    assert.equal(chiemSuat("n", "b", H, T0 + 21_000), null);
  });

  it("trần mỗi nhóm mỗi giờ, và hết giờ thì nhả", () => {
    chiemSuat("n", "a", H, T0);
    chiemSuat("n", "b", H, T0 + 1 * PHUT);
    chiemSuat("n", "c", H, T0 + 2 * PHUT);
    assert.match(chiemSuat("n", "d", H, T0 + 3 * PHUT) ?? "", /trong nhóm này/);
    assert.equal(chiemSuat("n", "d", H, T0 + 62 * PHUT), null);
  });

  it("trần mỗi người, không ảnh hưởng người khác và nhóm khác", () => {
    chiemSuat("n", "a", H, T0);
    chiemSuat("n", "a", H, T0 + 1 * PHUT);
    assert.match(chiemSuat("n", "a", H, T0 + 2 * PHUT) ?? "", /người này/);
    assert.equal(chiemSuat("n", "b", H, T0 + 2 * PHUT), null);
    assert.equal(chiemSuat("khac", "a", H, T0 + 2 * PHUT), null);
  });

  it("một tin tới nhiều nick bot: chỉ nick đầu tiên nhận", () => {
    assert.equal(nhanTinMotLan("n", "m1", T0), true);
    assert.equal(nhanTinMotLan("n", "m1", T0 + 100), false);
    assert.equal(nhanTinMotLan("n", "m2", T0 + 100), true);
    assert.equal(nhanTinMotLan("n", "", T0), true, "tin không có id thì không chặn");
  });
});
