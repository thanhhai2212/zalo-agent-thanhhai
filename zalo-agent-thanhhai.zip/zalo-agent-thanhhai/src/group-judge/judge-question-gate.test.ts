import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { nhinNhuCauHoi } from "./judge-question-gate.js";

const ok = (t: string) => nhinNhuCauHoi(t).ok;

describe("nhinNhuCauHoi - cổng thô của bộ tự đánh giá", () => {
  it("nhận câu hỏi có dấu hỏi", () => {
    assert.equal(ok("Khóa học này học phí thế nào bạn?"), true);
    assert.equal(ok("Có ai biết cách đăng ký không?"), true);
  });

  it("nhận câu hỏi không dấu, không dấu hỏi", () => {
    assert.equal(ok("cho minh hoi hoc phi khoa nay bao nhieu"), true);
    assert.equal(ok("ai biet cach dang ky khoa hoc khong"), true);
    assert.equal(ok("huong dan minh lam bai tap voi"), true);
  });

  it("bỏ trò chuyện phiếm, chào, cảm ơn", () => {
    assert.equal(ok("haha đúng rồi"), false);
    assert.equal(ok("Chào cả nhóm buổi sáng"), false);
    assert.equal(ok("cảm ơn bạn nhiều nhé"), false);
    assert.equal(ok("tối nay mình đi ăn lẩu"), false);
  });

  it("bỏ tin quá ngắn hoặc chỉ có link", () => {
    assert.equal(nhinNhuCauHoi("ok").ok, false);
    assert.equal(nhinNhuCauHoi("https://example.com/abc?x=1").ok, false);
    assert.equal(nhinNhuCauHoi("sao vậy").ok, false, "chỉ 2 từ");
  });

  it("từ hỏi chỉ khớp nguyên từ, không khớp nằm giữa chữ khác", () => {
    assert.equal(ok("cuoc song nhieu cam xuc hom nay thoi"), false, "nhi nằm trong nhieu");
    assert.equal(ok("anh ay dang can nhac chuyen nay lau roi"), false);
  });

  it("dấu hỏi kể cả viết kiểu toàn rộng", () => {
    assert.equal(ok("học online được không？"), true);
  });
});
