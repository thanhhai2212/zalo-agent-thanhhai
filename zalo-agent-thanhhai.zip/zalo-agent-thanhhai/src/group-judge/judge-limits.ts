/**
 * Hạn mức TỰ trả lời của bộ tự đánh giá (không tính lượt được tag - lượt đó là
 * lời nhờ rõ ràng, không đi qua đây). Số nhỏ có chủ ý: nick Zalo này là người
 * thật, tự chen vào dồn dập trong nhóm vừa phiền vừa dễ bị Zalo khóa.
 *
 * Chỉ nằm trong bộ nhớ: cửa sổ là 1 giờ nên mất khi khởi động lại chỉ nới tạm
 * thời, khác bộ đếm theo NGÀY của scheduler phải bền.
 *
 * `kiem` rồi `ghi` tách riêng để gọi `kiem` TRƯỚC khi tốn lượt chấm điểm, còn
 * `chiemSuat` kiểm lại và ghi trong cùng một khối đồng bộ - hai tin tới sát nhau
 * cùng qua cổng `kiem` thì chỉ một tin giành được suất.
 */

const GIO_MS = 60 * 60_000;

export type HanMuc = { moiNhomGio: number; moiNguoiGio: number; nghiMs: number };

const lanTheoNhom = new Map<string, number[]>();
const lanTheoNguoi = new Map<string, number[]>();
const lanCuoiTheoNhom = new Map<string, number>();

function giuTrongGio(mang: number[] | undefined, bayGio: number): number[] {
  return (mang ?? []).filter((t) => bayGio - t < GIO_MS);
}

/** Lý do bị chặn, hoặc `null` nếu còn suất. */
export function kiemHanMuc(khoaNhom: string, nguoi: string, h: HanMuc, bayGio: number): string | null {
  const cuoi = lanCuoiTheoNhom.get(khoaNhom);
  if (cuoi !== undefined && bayGio - cuoi < h.nghiMs) return "vừa tự trả lời trong nhóm này, đang nghỉ giữa hai lần";
  if (giuTrongGio(lanTheoNhom.get(khoaNhom), bayGio).length >= h.moiNhomGio) return `đã đủ ${h.moiNhomGio} lần tự trả lời trong nhóm này trong 1 giờ`;
  if (giuTrongGio(lanTheoNguoi.get(`${khoaNhom}:${nguoi}`), bayGio).length >= h.moiNguoiGio) return `đã đủ ${h.moiNguoiGio} lần tự trả lời người này trong 1 giờ`;
  return null;
}

/** Kiểm lại + ghi trong một khối đồng bộ. Trả lý do bị chặn, hoặc `null` nếu đã giữ được suất. */
export function chiemSuat(khoaNhom: string, nguoi: string, h: HanMuc, bayGio: number): string | null {
  const chan = kiemHanMuc(khoaNhom, nguoi, h, bayGio);
  if (chan) return chan;
  lanCuoiTheoNhom.set(khoaNhom, bayGio);
  lanTheoNhom.set(khoaNhom, [...giuTrongGio(lanTheoNhom.get(khoaNhom), bayGio), bayGio]);
  const kn = `${khoaNhom}:${nguoi}`;
  lanTheoNguoi.set(kn, [...giuTrongGio(lanTheoNguoi.get(kn), bayGio), bayGio]);
  return null;
}

// Cùng một tin tới nhiều nick bot trong cùng nhóm: chỉ nick giành được trước trả lời.
const daNhanTin = new Map<string, number>();
const NHO_TIN_MS = 10 * 60_000;

/** `true` nếu đây là lần ĐẦU có nick nhận tin này (nick sau gọi lại sẽ nhận `false`). */
export function nhanTinMotLan(threadId: string, msgId: string, bayGio: number): boolean {
  for (const [k, t] of daNhanTin) if (bayGio - t > NHO_TIN_MS) daNhanTin.delete(k);
  if (!msgId) return true;
  const khoa = `${threadId}:${msgId}`;
  if (daNhanTin.has(khoa)) return false;
  daNhanTin.set(khoa, bayGio);
  return true;
}

/** Chỉ cho test. */
export function datLaiHanMucChoTest(): void {
  lanTheoNhom.clear();
  lanTheoNguoi.clear();
  lanCuoiTheoNhom.clear();
  daNhanTin.clear();
}
