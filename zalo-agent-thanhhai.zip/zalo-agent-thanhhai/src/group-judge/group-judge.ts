import type { AccountConfig } from "../config/account-store.js";
import { getAgentForAccount } from "../config/agent-store.js";
import { getTuning } from "../config/runtime-tuning-settings.js";
import { getRecentMessages, type StoredMessage } from "../conversation/history-store.js";
import { getThreadAgentId } from "../conversation/thread-store.js";
import { nguonCuaAgent } from "../knowledge/kb-agent-binding.js";
import { timTrongKhoTriThuc } from "../knowledge/kb-search.js";
import { createLogger } from "../shared/logger.js";
import { chamDiemThat, type ChamDiem } from "../system-one/system-one-client.js";
import { chuVuaNhanTrongNhom } from "../zalo/owner-mention-forward.js";
import type { ParsedMessage } from "../zalo/zalo-message-parser.js";
import { nhinNhuCauHoi } from "./judge-question-gate.js";
import { chiemSuat, kiemHanMuc, nhanTinMotLan, type HanMuc } from "./judge-limits.js";
import { ghiNhatKyJudge, type JudgeDecision, type JudgeStage } from "./judge-log-store.js";

/**
 * Bộ TỰ ĐÁNH GIÁ tin nhóm (2026-10-06, ý tưởng từ "bộ phán xử nhóm" của Javis OS).
 *
 * Nhóm đang đòi @tag mà bật bộ này thì tin KHÔNG tag đi qua chuỗi cổng từ rẻ tới
 * đắt, tầng nào loại là dừng và không tốn lượt chấm điểm nào:
 *   1. điều kiện cứng (mã thuần): tin tag/trả lời người khác, chủ đang nhắn...
 *   2. cổng thô: có giống câu hỏi / lời nhờ giúp không
 *   3. hạn mức: mỗi nhóm, mỗi người, khoảng nghỉ giữa hai lần
 *   4. tài liệu: agent có Kho tri thức thì phải có đoạn khớp câu hỏi, không thì
 *      im (trả lời công khai bằng trí nhớ chung là cách nhanh nhất để bịa thay chủ)
 *   5. System One chấm điểm: có phải câu hỏi thật, và (khi agent không có tài
 *      liệu) có thuộc chuyên môn của bot không.
 *
 * Nguyên tắc: SAI VỀ PHÍA IM. Lỗi, hết giờ, không chắc đều ra im; im nhầm thì
 * người hỏi tag lại, còn nói nhầm trước cả nhóm thì khó gỡ. Bộ này không viết câu
 * trả lời - nó chỉ quyết nói hay im, câu nói ra vẫn do agent của bot soạn. Tin
 * trả lời một tin CỦA BOT được coi là lời gọi rõ ràng (như tag). Mọi quyết định,
 * kể cả im, đều ghi nhật ký. Chế độ "shadow": làm đủ mọi bước và ghi nhật ký nhưng
 * KHÔNG trả lời - để chủ xem bot sẽ chen vào những tin nào trước khi bật thật.
 */

const log = createLogger("group-judge");

export type KetQuaPhanXu = { traLoi: boolean; ghiChuLuot?: string };

export type PhuThuocPhanXu = {
  chamDiem: ChamDiem;
  now: () => number;
  layNguCanh: (accountId: string, threadId: string, soTin: number) => StoredMessage[];
  agentCuaThread: (config: AccountConfig, threadId: string) => { id: string; name: string; persona: string };
  coKb: (agentId: string) => boolean;
  soDoanKb: (cauHoi: string, agentId: string) => number;
  chuVuaNhan: (threadId: string, trongMs: number, bayGio: number) => boolean;
};

const macDinh: PhuThuocPhanXu = {
  chamDiem: chamDiemThat,
  now: Date.now,
  layNguCanh: (a, t, n) => getRecentMessages(a, t, n),
  agentCuaThread: (config, threadId) => {
    const ag = getAgentForAccount(getThreadAgentId(config.id, threadId) ?? config.agentId);
    return { id: ag.id, name: ag.name, persona: ag.persona };
  },
  coKb: (agentId) => nguonCuaAgent(agentId).length > 0,
  soDoanKb: (cauHoi, agentId) => timTrongKhoTriThuc({ cauHoi, agentId, soLuong: 3 }).length,
  chuVuaNhan: chuVuaNhanTrongNhom,
};

export const CAU_HOI_PHAN_XU = {
  cauHoi:
    "Tin cần đánh giá có phải một CÂU HỎI hoặc lời nhờ giúp thật sự, mà người viết đang chờ ai đó trả lời không? (Không tính trò chuyện phiếm, than thở, đùa, báo tin, cảm ơn.)",
  lienQuan: "Câu hỏi đó có thuộc phạm vi chuyên môn của bot (xem mục Phạm vi của bot) không?",
  nguoiKhac:
    "Tin cần đánh giá có đang nói với MỘT người cụ thể khác trong nhóm (đáp lời, hỏi riêng một người, nối tiếp câu chuyện giữa hai người) chứ không phải hỏi chung cả nhóm không?",
} as const;

const cat = (s: string, n: number) => {
  const t = s.replace(/\s+/g, " ").trim();
  return t.length > n ? `${t.slice(0, n - 3)}...` : t;
};

export function dungTrangThaiChamDiem(
  agent: { name: string; persona: string },
  ngCanh: StoredMessage[],
  msg: ParsedMessage,
): string {
  const dong = ngCanh.map((m) => `${m.role === "assistant" ? "BOT" : m.senderName || "Thành viên"}: ${cat(m.content, 300)}`);
  return [
    `[Phạm vi của bot] ${agent.name}. ${cat(agent.persona, 500)}`,
    "[Cuộc trò chuyện nhóm gần đây]",
    ...(dong.length > 0 ? dong : ["(chưa có)"]),
    "[Tin cần đánh giá]",
    `${msg.senderName || "Thành viên"}: ${cat(msg.text, 600)}`,
  ].join("\n");
}

export function dungGhiChuLuot(coKb: boolean): string {
  return (
    "Không ai gọi tên bạn trong nhóm: bạn tự chen vào vì tin vừa rồi giống một câu hỏi thuộc chuyên môn của bạn. " +
    "Trả lời ngắn gọn, đúng câu hỏi, không chào hỏi dài dòng. " +
    (coKb
      ? "Hãy dùng kb_search trước và chỉ nói điều tài liệu có; tài liệu không có thì nói ngắn là chưa có thông tin, đừng đoán."
      : "Chỉ nói điều bạn thật sự biết trong phạm vi vai trò của mình; không chắc thì nói ngắn là chưa rõ, đừng đoán.")
  );
}

/** Tin có tag người khác (không tag bot) hoặc tag cả nhóm - nói với ai đó cụ thể, không phải hỏi chung. */
function dangNoiVoiNguoiKhac(msg: ParsedMessage): string | null {
  const raw = msg.rawData as { mentions?: unknown; quote?: { ownerId?: unknown } };
  if (Array.isArray(raw.mentions) && raw.mentions.length > 0) return "tin có tag người khác hoặc tag cả nhóm";
  if (raw.quote && raw.quote.ownerId !== undefined) return "đang trả lời tin của người khác";
  return null;
}

/** Tin trả lời một tin CỦA BOT: lời gọi rõ ràng, như tag. */
export function traLoiTinCuaBot(msg: ParsedMessage, selfId: string): boolean {
  const quote = (msg.rawData as { quote?: { ownerId?: unknown } }).quote;
  return !!quote && quote.ownerId !== undefined && String(quote.ownerId) === selfId;
}

export async function phanXuTinNhom(
  config: AccountConfig,
  msg: ParsedMessage,
  selfId: string,
  mode: "shadow" | "on",
  phu: Partial<PhuThuocPhanXu> = {},
): Promise<KetQuaPhanXu> {
  const d: PhuThuocPhanXu = { ...macDinh, ...phu };
  const bayGio = d.now();
  const ghi = (stage: JudgeStage, decision: JudgeDecision, reason: string, scores?: Record<string, number>) => {
    try {
      ghiNhatKyJudge({
        accountId: config.id,
        threadId: msg.threadId,
        senderId: msg.senderId,
        senderName: msg.senderName,
        text: msg.text,
        mode,
        stage,
        decision,
        reason,
        scores,
      });
    } catch (err) {
      log.warn({ err }, "Không ghi được nhật ký tự đánh giá");
    }
  };
  const im = (stage: JudgeStage, reason: string, scores?: Record<string, number>): KetQuaPhanXu => {
    ghi(stage, "silent", reason, scores);
    return { traLoi: false };
  };
  const khoaNhom = `${config.id}:${msg.threadId}`;
  const hanMuc: HanMuc = {
    moiNhomGio: getTuning("GROUP_JUDGE_MAX_PER_GROUP_HOUR"),
    moiNguoiGio: getTuning("GROUP_JUDGE_MAX_PER_PERSON_HOUR"),
    nghiMs: getTuning("GROUP_JUDGE_GAP_SECONDS") * 1000,
  };

  try {
    // 1. Điều kiện cứng.
    if (config.ownerUserId && msg.senderId === config.ownerUserId) {
      return im("dieu_kien", "tin của chủ bot (chủ đang nói chuyện với người khác)");
    }
    if (traLoiTinCuaBot(msg, selfId)) {
      if (!nhanTinMotLan(msg.threadId, msg.msgId, bayGio)) return im("dieu_kien", "nick bot khác trong nhóm đã nhận tin này");
      ghi("tra_loi", mode === "on" ? "reply" : "shadow_reply", "trả lời vào tin của bot (coi như được gọi)");
      if (mode !== "on") return { traLoi: false };
      return { traLoi: true, ghiChuLuot: dungGhiChuLuot(d.coKb(d.agentCuaThread(config, msg.threadId).id)) };
    }
    const nguoiKhac = dangNoiVoiNguoiKhac(msg);
    if (nguoiKhac) return im("dieu_kien", nguoiKhac);
    if (d.chuVuaNhan(msg.threadId, getTuning("GROUP_JUDGE_OWNER_YIELD_MINUTES") * 60_000, bayGio)) {
      return im("dieu_kien", "chủ bot đang nhắn trong nhóm - nhường chủ");
    }

    // 2. Cổng thô.
    const cong = nhinNhuCauHoi(msg.text);
    if (!cong.ok) return im("cong_tho", cong.lyDo);

    // 3. Hạn mức (kiểm sớm, chiếm suất sau cùng).
    const chan = kiemHanMuc(khoaNhom, msg.senderId, hanMuc, bayGio);
    if (chan) return im("han_muc", chan);

    // 4. Tài liệu.
    const agent = d.agentCuaThread(config, msg.threadId);
    const coKb = d.coKb(agent.id);
    if (coKb && d.soDoanKb(msg.text, agent.id) === 0) {
      return im("cham_diem", "agent có Kho tri thức nhưng không có đoạn nào khớp câu hỏi");
    }

    // 5. Chấm điểm.
    const cauHoi: Record<string, string> = { cauHoi: CAU_HOI_PHAN_XU.cauHoi, nguoiKhac: CAU_HOI_PHAN_XU.nguoiKhac };
    if (!coKb) cauHoi.lienQuan = CAU_HOI_PHAN_XU.lienQuan;
    const diem = await d.chamDiem(dungTrangThaiChamDiem(agent, d.layNguCanh(config.id, msg.threadId, 8), msg), cauHoi);
    if (!diem) return im("cham_diem", "System One không trả lời - mặc định im");
    const nguong = getTuning("GROUP_JUDGE_THRESHOLD_PERCENT") / 100;
    if ((diem.cauHoi ?? 0) < nguong) return im("cham_diem", "chưa chắc là câu hỏi thật", diem);
    if ((diem.nguoiKhac ?? 1) >= 0.5) return im("cham_diem", "có vẻ đang nói với một người cụ thể", diem);
    if (!coKb && (diem.lienQuan ?? 0) < nguong) return im("cham_diem", "ngoài phạm vi chuyên môn của bot", diem);

    // 6. Chiếm suất (đồng bộ, an toàn khi nhiều tin tới sát nhau) rồi quyết định.
    if (!nhanTinMotLan(msg.threadId, msg.msgId, bayGio)) return im("han_muc", "nick bot khác trong nhóm đã nhận tin này", diem);
    const het = chiemSuat(khoaNhom, msg.senderId, hanMuc, bayGio);
    if (het) return im("han_muc", het, diem);
    ghi(
      "tra_loi",
      mode === "on" ? "reply" : "shadow_reply",
      mode === "on" ? "đạt mọi cổng - tự trả lời" : "đạt mọi cổng - CHẠY THỬ, chưa trả lời thật",
      diem,
    );
    return mode === "on" ? { traLoi: true, ghiChuLuot: dungGhiChuLuot(coKb) } : { traLoi: false };
  } catch (err) {
    log.warn({ accountId: config.id, threadId: msg.threadId, err }, "Bộ tự đánh giá lỗi - mặc định im");
    return im("cham_diem", `lỗi nội bộ: ${err instanceof Error ? err.message : String(err)}`);
  }
}
