import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";
import type { ParsedMessage } from "../zalo/zalo-message-parser.js";

let dataDir: string;
let judge: typeof import("./group-judge.js");
let logStore: typeof import("./judge-log-store.js");
let limits: typeof import("./judge-limits.js");
let database: typeof import("../conversation/database.js");

before(async () => {
  dataDir = setupTestEnv({
    GROUP_JUDGE_THRESHOLD_PERCENT: "70",
    GROUP_JUDGE_MAX_PER_GROUP_HOUR: "6",
    GROUP_JUDGE_MAX_PER_PERSON_HOUR: "2",
    GROUP_JUDGE_GAP_SECONDS: "30",
    GROUP_JUDGE_OWNER_YIELD_MINUTES: "5",
  });
  database = await import("../conversation/database.js");
  judge = await import("./group-judge.js");
  logStore = await import("./judge-log-store.js");
  limits = await import("./judge-limits.js");
});

after(() => {
  database.closeDatabase();
  cleanupTestEnv(dataDir);
});

const SELF = "bot-uid";
const config = (id = "acc-j") => ({ id, label: "Nick test", ownerUserId: "chu", agentId: "ag" }) as import("../config/account-store.js").AccountConfig;
let msgSo = 0;
const tin = (text: string, o: Partial<ParsedMessage> = {}): ParsedMessage =>
  ({
    accountId: "acc-j",
    threadId: "nhom-1",
    threadType: 1,
    isGroup: true,
    senderId: "khach-1",
    senderName: "Mai",
    text,
    images: [],
    msgId: `m${++msgSo}`,
    cliMsgId: `c${msgSo}`,
    isSelf: false,
    mentionsMe: false,
    rawData: {},
    ...o,
  }) as ParsedMessage;

let daCham: string[];
let diem: Record<string, number> | null;
let coKb: boolean;
let soDoan: number;
let chuVuaNhan: boolean;
let now: number;
const phu = () => ({
  chamDiem: async (state: string) => {
    daCham.push(state);
    return diem;
  },
  now: () => now,
  layNguCanh: () => [
    { id: 1, role: "user" as const, content: "Chiều nay ai đi cafe không?", senderName: "Lan", createdAt: "" },
    { id: 2, role: "assistant" as const, content: "Dạ em chào cả nhóm", createdAt: "" },
  ],
  agentCuaThread: () => ({ id: "ag", name: "Trợ lý khóa học", persona: "Tư vấn khóa học tiếng Anh online." }),
  coKb: () => coKb,
  soDoanKb: () => soDoan,
  chuVuaNhan: () => chuVuaNhan,
});
const DIEM_TOT = { cauHoi: 0.95, nguoiKhac: 0.1, lienQuan: 0.9 };
const nhatKy = () => logStore.listNhatKyJudge("acc-j", "nhom-1", 50);

beforeEach(() => {
  database.db.exec("DELETE FROM group_judge_log");
  limits.datLaiHanMucChoTest();
  daCham = [];
  diem = { ...DIEM_TOT };
  coKb = false;
  soDoan = 0;
  chuVuaNhan = false;
  now = 1_800_000_000_000;
});

describe("phanXuTinNhom - chuỗi cổng", () => {
  it("câu hỏi đúng chuyên môn: trả lời, ghi nhật ký kèm điểm, dặn agent không đoán", async () => {
    const kq = await judge.phanXuTinNhom(config(), tin("Cho mình hỏi khóa này học phí bao nhiêu vậy?"), SELF, "on", phu());
    assert.equal(kq.traLoi, true);
    assert.match(kq.ghiChuLuot ?? "", /không ai gọi tên bạn/i);
    assert.doesNotMatch(kq.ghiChuLuot ?? "", /kb_search/);
    const [dong] = nhatKy();
    assert.equal(dong!.decision, "reply");
    assert.equal(dong!.scores?.cauHoi, 0.95);
    // Chấm điểm nhận phạm vi bot, ngữ cảnh gần đây và đúng tin cần đánh giá.
    assert.match(daCham[0]!, /Trợ lý khóa học/);
    assert.match(daCham[0]!, /BOT: Dạ em chào cả nhóm/);
    assert.match(daCham[0]!, /\[Tin cần đánh giá\]\nMai: Cho mình hỏi khóa này/);
  });

  it("chế độ chạy thử: làm đủ mọi bước, ghi nhật ký, nhưng KHÔNG trả lời", async () => {
    const kq = await judge.phanXuTinNhom(config(), tin("Cho mình hỏi khóa này học phí bao nhiêu vậy?"), SELF, "shadow", phu());
    assert.equal(kq.traLoi, false);
    assert.equal(nhatKy()[0]!.decision, "shadow_reply");
    assert.equal(daCham.length, 1);
  });

  it("chuyện phiếm bị cổng thô loại - không tốn lượt chấm điểm nào", async () => {
    const kq = await judge.phanXuTinNhom(config(), tin("haha đúng rồi tối nay đi ăn lẩu"), SELF, "on", phu());
    assert.equal(kq.traLoi, false);
    assert.equal(daCham.length, 0);
    assert.equal(nhatKy()[0]!.stage, "cong_tho");
  });

  it("tin tag người khác, trả lời tin người khác, tin của chủ: im, không chấm điểm", async () => {
    const hoi = "Cho mình hỏi khóa này học phí bao nhiêu vậy?";
    const a = await judge.phanXuTinNhom(config(), tin(hoi, { rawData: { mentions: [{ uid: "nguoi-khac", type: 0 }] } }), SELF, "on", phu());
    const b = await judge.phanXuTinNhom(config(), tin(hoi, { rawData: { quote: { ownerId: "nguoi-khac" } } }), SELF, "on", phu());
    const c = await judge.phanXuTinNhom(config(), tin(hoi, { senderId: "chu" }), SELF, "on", phu());
    assert.deepEqual([a.traLoi, b.traLoi, c.traLoi], [false, false, false]);
    assert.equal(daCham.length, 0);
    assert.deepEqual(nhatKy().map((d) => d.stage), ["dieu_kien", "dieu_kien", "dieu_kien"]);
  });

  it("chủ vừa nhắn trong nhóm thì nhường chủ", async () => {
    chuVuaNhan = true;
    const kq = await judge.phanXuTinNhom(config(), tin("Cho mình hỏi khóa này học phí bao nhiêu vậy?"), SELF, "on", phu());
    assert.equal(kq.traLoi, false);
    assert.match(nhatKy()[0]!.reason, /nhường chủ/);
  });

  it("trả lời vào tin CỦA BOT được coi là lời gọi rõ ràng, không cần chấm điểm", async () => {
    const kq = await judge.phanXuTinNhom(config(), tin("vậy còn gói nâng cao thì sao", { rawData: { quote: { ownerId: SELF } } }), SELF, "on", phu());
    assert.equal(kq.traLoi, true);
    assert.equal(daCham.length, 0);
  });

  it("agent có Kho tri thức: không có đoạn khớp thì im và không gọi System One; có đoạn thì dặn dùng kb_search", async () => {
    coKb = true;
    soDoan = 0;
    const hoi = "Cho mình hỏi khóa này học phí bao nhiêu vậy?";
    const im = await judge.phanXuTinNhom(config(), tin(hoi), SELF, "on", phu());
    assert.equal(im.traLoi, false);
    assert.equal(daCham.length, 0);
    assert.match(nhatKy()[0]!.reason, /Kho tri thức/);

    soDoan = 2;
    const co = await judge.phanXuTinNhom(config(), tin(hoi, { senderId: "khach-2" }), SELF, "on", phu());
    assert.equal(co.traLoi, true);
    assert.match(co.ghiChuLuot ?? "", /kb_search/);
    assert.equal(Object.keys(daCham).length, 1);
  });

  it("System One lỗi hoặc điểm thấp: mặc định im", async () => {
    const hoi = "Cho mình hỏi khóa này học phí bao nhiêu vậy?";
    diem = null;
    assert.equal((await judge.phanXuTinNhom(config(), tin(hoi), SELF, "on", phu())).traLoi, false);
    diem = { ...DIEM_TOT, cauHoi: 0.4 };
    assert.equal((await judge.phanXuTinNhom(config(), tin(hoi, { senderId: "k2" }), SELF, "on", phu())).traLoi, false);
    diem = { ...DIEM_TOT, nguoiKhac: 0.9 };
    assert.equal((await judge.phanXuTinNhom(config(), tin(hoi, { senderId: "k3" }), SELF, "on", phu())).traLoi, false);
    diem = { ...DIEM_TOT, lienQuan: 0.2 };
    assert.equal((await judge.phanXuTinNhom(config(), tin(hoi, { senderId: "k4" }), SELF, "on", phu())).traLoi, false);
    const ly = nhatKy().map((d) => d.reason).reverse();
    assert.match(ly[0]!, /System One không trả lời/);
    assert.match(ly[1]!, /chưa chắc là câu hỏi/);
    assert.match(ly[2]!, /người cụ thể/);
    assert.match(ly[3]!, /ngoài phạm vi/);
  });

  it("hạn mức: tin thứ hai sát nhau bị chặn, và đủ giờ thì được lại", async () => {
    const hoi = "Cho mình hỏi khóa này học phí bao nhiêu vậy?";
    assert.equal((await judge.phanXuTinNhom(config(), tin(hoi), SELF, "on", phu())).traLoi, true);
    now += 10_000;
    const chan = await judge.phanXuTinNhom(config(), tin(hoi, { senderId: "khach-2" }), SELF, "on", phu());
    assert.equal(chan.traLoi, false);
    assert.equal(nhatKy()[0]!.stage, "han_muc");
    now += 40_000;
    assert.equal((await judge.phanXuTinNhom(config(), tin(hoi, { senderId: "khach-3" }), SELF, "on", phu())).traLoi, true);
  });

  it("hai nick bot trong cùng nhóm cùng thấy một tin: chỉ một nick trả lời", async () => {
    const m = tin("Cho mình hỏi khóa này học phí bao nhiêu vậy?", { msgId: "chung-1" });
    const [a, b] = await Promise.all([
      judge.phanXuTinNhom(config("acc-j"), m, SELF, "on", phu()),
      judge.phanXuTinNhom(config("acc-k"), m, SELF, "on", phu()),
    ]);
    assert.equal([a, b].filter((x) => x.traLoi).length, 1);
  });

  it("lỗi bất ngờ trong bộ chấm cũng ra im, không ném lỗi", async () => {
    const kq = await judge.phanXuTinNhom(
      config(),
      tin("Cho mình hỏi khóa này học phí bao nhiêu vậy?"),
      SELF,
      "on",
      { ...phu(), chamDiem: async () => { throw new Error("hỏng giữa chừng"); } },
    );
    assert.equal(kq.traLoi, false);
    assert.match(nhatKy()[0]!.reason, /lỗi nội bộ/);
  });
});

describe("nhật ký", () => {
  it("chỉ giữ trích đoạn ngắn của tin", async () => {
    await judge.phanXuTinNhom(config(), tin(`Cho mình hỏi ${"rất dài ".repeat(60)}?`), SELF, "on", phu());
    assert.ok(nhatKy()[0]!.excerpt.length <= 160);
  });
});
