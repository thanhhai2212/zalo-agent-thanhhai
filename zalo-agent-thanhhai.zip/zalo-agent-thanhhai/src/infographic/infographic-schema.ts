import { z } from "zod";

/**
 * Dữ liệu cho một ảnh infographic. Model CHỈ điền dữ liệu theo một trong 5 mẫu
 * cố định - không viết HTML/CSS (cùng quyết định "tool tạo file chỉ nhận dữ
 * liệu" của cả repo: bot đọc tin người lạ, cho model viết mã render là mở đường
 * prompt injection thành mã chạy trong trình duyệt).
 *
 * Trần độ dài chữ ở đây là lớp chặn tràn khung THỨ NHẤT; lớp thứ hai là bộ đo
 * chiều cao lúc render (`render-infographic.ts`) tự thu nhỏ cỡ chữ.
 */

const chu = (toiDa: number) => z.string().trim().min(1).max(toiDa);

const phanChung = {
  /** Nhãn nhỏ phía trên tiêu đề, vd "HƯỚNG DẪN" hay tên series */
  nhan: chu(30).optional(),
  tieuDe: chu(90),
  phuDe: chu(160).optional(),
  /** Dòng nguồn nhỏ ở chân ảnh, vd "Nguồn: Nghị định 30/2020/NĐ-CP" */
  nguon: chu(100).optional(),
};

const muc = z.object({ tieuDe: chu(60), moTa: chu(120).optional() });

export const infographicSchema = z.discriminatedUnion("mau", [
  z.object({ mau: z.literal("cac_buoc"), ...phanChung, buoc: z.array(muc).min(3).max(6) }),
  z.object({ mau: z.literal("checklist"), ...phanChung, muc: z.array(chu(120)).min(3).max(8) }),
  z.object({
    mau: z.literal("so_sanh"),
    ...phanChung,
    trai: z.object({ nhan: chu(30), y: z.array(chu(100)).min(2).max(5) }),
    phai: z.object({ nhan: chu(30), y: z.array(chu(100)).min(2).max(5) }),
  }),
  z.object({
    mau: z.literal("so_lieu"),
    ...phanChung,
    chiSo: z.array(z.object({ so: chu(12), nhan: chu(70) })).min(2).max(4),
    ghiChu: chu(200).optional(),
  }),
  z.object({ mau: z.literal("trich_dan"), ...phanChung, cau: chu(240), tacGia: chu(60).optional() }),
]);

export type DuLieuInfographic = z.infer<typeof infographicSchema>;
export type MauInfographic = DuLieuInfographic["mau"];

/** Mô tả ngắn từng mẫu - dùng cho mô tả tool và trang dashboard */
export const MO_TA_MAU: Record<MauInfographic, string> = {
  cac_buoc: "Các bước làm (3-6 bước, mỗi bước có tiêu đề + mô tả ngắn)",
  checklist: "Danh sách kiểm tra (3-8 mục)",
  so_sanh: "So sánh hai cột (cách cũ / cách mới, nên / không nên)",
  so_lieu: "Số liệu nổi bật (2-4 con số lớn kèm nhãn)",
  trich_dan: "Một câu trích dẫn / thông điệp lớn",
};
