/**
 * Màu cho ảnh infographic từ màu thương hiệu: màu chính phải đủ đậm để chữ
 * trắng trên nút số/nhãn đạt tương phản 4,5:1 (khách có thể chọn màu rất nhạt
 * ở trang Thương hiệu), màu nhạt là màu chính pha 88% trắng cho nền phụ.
 * Cùng công thức với `web/src/shared/brand-color.ts` nhưng viết riêng vì code
 * máy chủ không import code giao diện.
 */

type Rgb = [number, number, number];

const docHex = (hex: string): Rgb => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as Rgb;
const raHex = (c: Rgb) => `#${c.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0")).join("")}`;

function doSang([r, g, b]: Rgb): number {
  const k = (v: number) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  return 0.2126 * k(r) + 0.7152 * k(g) + 0.0722 * k(b);
}

/** Tương phản của chữ trắng trên màu này */
export const tuongPhanVoiTrang = (hex: string) => 1.05 / (doSang(docHex(hex)) + 0.05);

/** Làm đậm dần tới khi chữ trắng đạt 4,5:1 */
export function mauDamDuDocChu(hex: string): string {
  if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return "#0068FF";
  let c = docHex(hex);
  for (let i = 0; i < 40 && tuongPhanVoiTrang(raHex(c)) < 4.5; i++) c = c.map((v) => v * 0.92) as Rgb;
  return raHex(c);
}

/** Màu chính pha vào nền (mặc định trắng) - nền tròn trang trí, nền dấu tick */
export function mauNhat(hex: string, tiLeNen = 0.88, nen = "#FFFFFF"): string {
  const c = docHex(/^#[0-9a-fA-F]{6}$/.test(hex) ? hex : "#0068FF");
  const b = docHex(/^#[0-9a-fA-F]{6}$/.test(nen) ? nen : "#FFFFFF");
  return raHex(c.map((v, i) => v + (b[i]! - v) * tiLeNen) as Rgb);
}
