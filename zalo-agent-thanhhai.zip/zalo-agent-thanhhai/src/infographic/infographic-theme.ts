import { docFileLogo, docThuongHieu } from "../config/branding-store.js";
import { mauDamDuDocChu, mauNhat, tuongPhanVoiTrang } from "./infographic-brand.js";
import type { ThuongHieuAnh } from "./infographic-html.js";

/**
 * Thương hiệu cho ảnh infographic lấy từ trang Thương hiệu: màu chủ đạo (làm
 * đậm cho đủ đọc chữ trắng), nền (trắng xám / ngà ấm), chữ ký chân ảnh, logo
 * nhúng thành data URI (trình duyệt dựng ảnh không đi ra mạng).
 */
export function thuongHieuChoAnh(): ThuongHieuAnh {
  const t = docThuongHieu();
  const logo = docFileLogo();
  const nenAnh = t.nen === "nga_am" ? "#F4EEE3" : "#F5F7FB";
  // Màu chủ đạo gần đen (vd Đen mực) pha vào nền ngà ra xám đục - brochure phối
  // đen mực với vàng champagne, nên dùng tông champagne cho phần trang trí
  const gocNhat = t.nen === "nga_am" && tuongPhanVoiTrang(t.mau) > 12 ? "#D4B26E" : t.mau;
  return {
    ten: t.ten,
    mau: mauDamDuDocChu(t.mau),
    mauNhat: mauNhat(gocNhat, gocNhat === t.mau ? 0.84 : 0.6, nenAnh),
    logo: logo ? `data:${logo.loai};base64,${logo.data.toString("base64")}` : null,
    nen: t.nen,
    chuKy: t.chuKyAnh,
  };
}
