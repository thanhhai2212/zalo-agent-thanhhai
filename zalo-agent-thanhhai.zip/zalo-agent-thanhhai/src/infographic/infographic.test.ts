import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { cleanupTestEnv, setupTestEnv } from "../shared/test-env-setup.js";
import { infographicSchema } from "./infographic-schema.js";
import { dungHtmlInfographic } from "./infographic-html.js";
import { mauDamDuDocChu, mauNhat, tuongPhanVoiTrang } from "./infographic-brand.js";

const th = { ten: "Shop <b>A</b>", mau: "#0057D9", mauNhat: "#E0ECFF", logo: null };

describe("schema infographic", () => {
  it("nhận đúng mẫu, chặn số mục ngoài khoảng và chữ quá dài", () => {
    assert.ok(infographicSchema.safeParse({ mau: "checklist", tieuDe: "T", muc: ["a", "b", "c"] }).success);
    assert.equal(infographicSchema.safeParse({ mau: "checklist", tieuDe: "T", muc: ["a", "b"] }).success, false);
    assert.equal(infographicSchema.safeParse({ mau: "trich_dan", tieuDe: "x".repeat(91), cau: "c" }).success, false);
    assert.equal(infographicSchema.safeParse({ mau: "ve_tu_do", tieuDe: "T" }).success, false);
  });
});

describe("HTML infographic", () => {
  it("thoát mọi chữ - chữ của model không thành thẻ", () => {
    const d = infographicSchema.parse({ mau: "checklist", tieuDe: "<script>alert(1)</script>", muc: ["<img src=x onerror=1>", "b", "c"] });
    const html = dungHtmlInfographic(d, th);
    assert.ok(!html.includes("<script>alert"));
    assert.ok(!html.includes("<img src=x"));
    assert.ok(html.includes("&lt;script&gt;"));
    assert.ok(!html.includes("<b>A</b>"));
  });

  it("không có script hay tài nguyên ngoài", () => {
    const d = infographicSchema.parse({ mau: "so_lieu", tieuDe: "T", chiSo: [{ so: "1", nhan: "a" }, { so: "2", nhan: "b" }] });
    const html = dungHtmlInfographic(d, th);
    assert.ok(!/<script/i.test(html));
    assert.ok(!/(src|href)="https?:/i.test(html));
  });
});

describe("màu thương hiệu cho ảnh", () => {
  it("màu quá nhạt được làm đậm tới khi chữ trắng đọc rõ", () => {
    const dam = mauDamDuDocChu("#FFE066");
    assert.ok(tuongPhanVoiTrang(dam) >= 4.5, dam);
    assert.equal(mauDamDuDocChu("#0F1B2D"), "#0f1b2d");
    assert.equal(mauDamDuDocChu("xanh"), "#0068FF");
    assert.equal(mauNhat("#000000", 0.5), "#808080");
  });
});

describe("render chống tràn", () => {
  let dataDir: string;
  let render: typeof import("./render-infographic.js");
  before(async () => {
    dataDir = setupTestEnv({ CHROME_PATH: process.execPath });
    render = await import("./render-infographic.js");
  });
  after(() => cleanupTestEnv(dataDir));

  // Trình duyệt giả: phần ruột cao `cao[mat]` so với khung 600px
  const giaLap = (cao: number[]) => {
    let lan = -1;
    const dong: boolean[] = [];
    const page = {
      setJavaScriptEnabled: async () => {},
      setViewport: async () => {},
      setContent: async () => void lan++,
      $: async (sel: string) => ({ boundingBox: async () => ({ x: 0, y: 0, width: 900, height: sel === ".ruot" ? cao[lan] : 600 }) }),
      screenshot: async () => Buffer.from(`png-${lan}`),
    };
    const launch = (async () => ({ newPage: async () => page, close: async () => void dong.push(true) })) as never;
    return { launch, dong };
  };
  const d = infographicSchema.parse({ mau: "checklist", tieuDe: "T", muc: ["a", "b", "c"] });

  it("tràn ở mật độ 0 thì dựng lại ở mật độ 1", async () => {
    const { launch, dong } = giaLap([900, 580, 500]);
    assert.equal((await render.renderInfographic(d, th, launch)).toString(), "png-1");
    assert.equal(dong.length, 1);
  });

  it("tràn cả 3 mức thì báo lỗi, không gửi ảnh cắt chữ, vẫn đóng trình duyệt", async () => {
    const { launch, dong } = giaLap([900, 800, 700]);
    await assert.rejects(render.renderInfographic(d, th, launch), (e: Error) => e.name === "LoiTranKhung");
    assert.equal(dong.length, 1);
  });
});

describe("chữ ký và nền ảnh", () => {
  const d = infographicSchema.parse({ mau: "checklist", tieuDe: "T", muc: ["a", "b", "c"] });
  it("chân ảnh dùng chữ ký nếu có, kèm biểu tượng Facebook khi bắt đầu bằng fb/", () => {
    const html = dungHtmlInfographic(d, { ...th, chuKy: "fb/tenban" });
    assert.ok(html.includes("fb/tenban"));
    assert.ok(html.includes("<svg viewBox=\"0 0 24 24\" width=\"28\""));
    assert.ok(!html.includes(">Shop &lt;b&gt;A&lt;/b&gt;</span>"));
  });
  it("không có chữ ký thì dùng tên thương hiệu và chữ cái đầu", () => {
    const html = dungHtmlInfographic(d, th);
    assert.ok(html.includes("Shop &lt;b&gt;A&lt;/b&gt;"));
    assert.ok(html.includes('<div class="logo-chu">S</div>'));
  });
  it("nền ngà ấm đổi màu nền trang", () => {
    assert.ok(dungHtmlInfographic(d, { ...th, nen: "nga_am" }).includes("background:#F4EEE3"));
    assert.ok(dungHtmlInfographic(d, th).includes("background:#F5F7FB"));
  });
  it("nhận diện chữ ký Facebook", async () => {
    const { laChuKyFacebook } = await import("./infographic-html.js");
    assert.ok(laChuKyFacebook("fb/abc"));
    assert.ok(laChuKyFacebook("facebook.com/abc"));
    assert.equal(laChuKyFacebook("Shop fb/abc"), false);
  });
});
