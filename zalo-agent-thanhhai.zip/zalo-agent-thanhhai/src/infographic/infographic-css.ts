import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * CSS của ảnh infographic 1080x1350 (khổ dọc 4:5, xem trọn trên điện thoại).
 *
 * Font Be Vietnam Pro (OFL, `assets/fonts/be-vietnam-pro/`) NHÚNG THẲNG dạng
 * base64: trình duyệt render đã TẮT JS và không nên đi ra mạng, còn VPS chỉ có
 * DejaVu/Liberation - chữ tiêu đề cỡ lớn nhìn thô và dấu tiếng Việt xếp kém.
 *
 * `mat` (mật độ) 0-2: bộ đo chiều cao lúc render thấy nội dung tràn thì dựng
 * lại ở mật độ cao hơn (chữ nhỏ hơn, khoảng cách hẹp hơn).
 */

const THU_MUC_FONT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../assets/fonts/be-vietnam-pro");

let fontCss: string | null = null;
function fontFace(): string {
  if (fontCss !== null) return fontCss;
  const mot = (file: string, weight: number) => {
    const b64 = fs.readFileSync(path.join(THU_MUC_FONT, file)).toString("base64");
    return `@font-face{font-family:"BVP";font-weight:${weight};src:url(data:font/ttf;base64,${b64}) format("truetype");}`;
  };
  fontCss = [mot("BeVietnamPro-Medium.ttf", 500), mot("BeVietnamPro-Bold.ttf", 700), mot("BeVietnamPro-ExtraBold.ttf", 800)].join("");
  return fontCss;
}

/** Cỡ chữ theo mật độ: [tiêu đề, mục, mô tả] */
const CO_CHU: Record<0 | 1 | 2, [number, number, number]> = { 0: [76, 38, 29], 1: [66, 34, 26], 2: [58, 30, 23] };

/** Bảng màu nền theo thiết lập "Màu nền" ở trang Thương hiệu */
const NEN = {
  mac_dinh: { trang: "#F5F7FB", the: "#FFFFFF", chu: "#0F1B2D", phu: "#4A5568", nhat: "#8A93A3", vien: "#E5E9F0" },
  // Bộ màu Brochure Zalo Agent Business: nền ngà, thẻ giấy, chữ đen mực, viền be
  nga_am: { trang: "#F4EEE3", the: "#FBF8F2", chu: "#16130F", phu: "#5E584C", nhat: "#8C8371", vien: "#DCCFB2" },
} as const;
export type NenAnh = keyof typeof NEN;

export function cssInfographic(mau: string, mauNhat: string, mat: 0 | 1 | 2, nen: NenAnh = "mac_dinh"): string {
  const [h1, muc, mota] = CO_CHU[mat];
  const n = NEN[nen];
  const khe = [26, 20, 14][mat];
  return `${fontFace()}
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1080px;height:1350px;background:${n.trang}}
body{font-family:"BVP","DejaVu Sans",sans-serif;color:${n.chu};-webkit-font-smoothing:antialiased}
.trang{width:1080px;height:1350px;display:flex;flex-direction:column;padding:84px 80px 64px;position:relative;overflow:hidden}
.trang::before{content:"";position:absolute;right:-180px;top:-180px;width:520px;height:520px;border-radius:50%;background:${mauNhat}}
.dau{position:relative}
.nhan{display:inline-block;background:${mau};color:#fff;font-weight:800;font-size:22px;letter-spacing:.12em;padding:10px 20px;border-radius:999px;text-transform:uppercase}
h1{font-weight:800;font-size:${h1}px;line-height:1.12;letter-spacing:-.015em;margin-top:26px}
.phu-de{font-weight:500;font-size:${mota + 3}px;line-height:1.45;color:${n.phu};margin-top:18px}
.noi-dung{flex:1;min-height:0;overflow:hidden;margin-top:${khe + 18}px;position:relative;display:flex;flex-direction:column;justify-content:center}
.ruot{display:flex;flex-direction:column;gap:${khe}px}
.the{background:${n.the};border-radius:24px;padding:${28 - mat * 4}px 32px;box-shadow:0 2px 0 rgba(15,27,45,.04),0 12px 32px rgba(15,27,45,.06);display:flex;gap:24px;align-items:flex-start}
.so{flex:none;width:${64 - mat * 6}px;height:${64 - mat * 6}px;border-radius:18px;background:${mau};color:#fff;font-weight:800;font-size:${muc}px;display:flex;align-items:center;justify-content:center}
.tieu-de-muc{font-weight:700;font-size:${muc}px;line-height:1.25}
.mo-ta{font-weight:500;font-size:${mota}px;line-height:1.45;color:${n.phu};margin-top:8px}
.dau-tick{flex:none;width:${52 - mat * 4}px;height:${52 - mat * 4}px;border-radius:50%;background:${mauNhat};display:flex;align-items:center;justify-content:center}
.dau-tick svg{width:60%;height:60%}
.hai-cot{display:grid;grid-template-columns:1fr 1fr;gap:${khe}px}
.cot{background:${n.the};border-radius:24px;padding:30px 28px;box-shadow:0 12px 32px rgba(15,27,45,.06);display:flex;flex-direction:column;gap:${khe - 4}px}
.cot-dau{font-weight:800;font-size:${muc}px;padding-bottom:14px;border-bottom:3px solid ${n.vien}}
.cot.tot .cot-dau{color:${mau};border-color:${mau}}
.cot.xau .cot-dau{color:${n.nhat}}
.y{display:flex;gap:14px;font-weight:500;font-size:${mota + 1}px;line-height:1.4}
.y svg{flex:none;width:30px;height:30px;margin-top:2px}
.luoi-so{display:grid;grid-template-columns:1fr 1fr;gap:${khe}px}
.o-so{background:${n.the};border-radius:24px;padding:34px 30px;box-shadow:0 12px 32px rgba(15,27,45,.06)}
.o-so b{display:block;font-weight:800;font-size:${h1 + 16}px;line-height:1;color:${mau};letter-spacing:-.02em}
.o-so span{display:block;font-weight:700;font-size:${mota + 1}px;line-height:1.4;color:${n.phu};margin-top:14px}
.ghi-chu{font-weight:500;font-size:${mota}px;line-height:1.5;color:${n.phu};margin-top:${khe}px}
.trich{display:flex;flex-direction:column;justify-content:center;height:100%;padding:0 10px}
.trich .ngoac{font-weight:800;font-size:200px;line-height:.8;color:${mau}}
.trich p{font-weight:800;font-size:${h1 - 8}px;line-height:1.25;letter-spacing:-.01em}
.trich .tac-gia{font-weight:700;font-size:${muc - 4}px;color:${n.phu};margin-top:30px}
.chan{display:flex;align-items:center;justify-content:space-between;gap:24px;margin-top:28px;padding-top:24px;border-top:2px solid ${n.vien};position:relative}
.thuong-hieu{display:flex;align-items:center;gap:14px;font-weight:800;font-size:26px}
.logo{width:48px;height:48px;border-radius:12px;object-fit:cover}
.logo-chu{width:48px;height:48px;border-radius:12px;background:${mau};color:#fff;font-weight:800;font-size:24px;display:flex;align-items:center;justify-content:center}
.nguon{font-weight:500;font-size:20px;color:${n.nhat};text-align:right;max-width:560px}`;
}
