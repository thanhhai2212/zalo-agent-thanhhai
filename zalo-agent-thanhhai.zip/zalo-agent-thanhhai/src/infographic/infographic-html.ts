import { thoatHtml as e } from "../documents/render-pdf-html.js";
import { cssInfographic, type NenAnh } from "./infographic-css.js";
import type { DuLieuInfographic } from "./infographic-schema.js";

/**
 * Dựng HTML cho ảnh infographic từ DỮ LIỆU đã qua schema. Mọi chữ đều qua
 * `thoatHtml` - chữ do model viết (từ tin người lạ, nội dung web) không bao giờ
 * thành thẻ HTML. Trang không có script, không có tài nguyên ngoài (font + logo
 * nhúng sẵn), và trình duyệt render còn TẮT JS.
 */

export type ThuongHieuAnh = {
  ten: string;
  /** Màu chủ đạo đã đủ đậm để chữ trắng đọc rõ */
  mau: string;
  /** Màu nhạt cùng tông cho nền phụ */
  mauNhat: string;
  /** Logo dạng data URI (PNG/JPEG/WebP), null thì dùng chữ cái đầu */
  logo: string | null;
  /** Nền ảnh, mặc định trắng xám */
  nen?: NenAnh;
  /** Chữ ở chân ảnh (vd "fb/tenban"); thiếu thì dùng `ten` */
  chuKy?: string;
};

/** Chữ ký kiểu "fb/..." hoặc "facebook.com/..." thì kèm biểu tượng Facebook thay cho chữ cái đầu */
export const laChuKyFacebook = (s: string) => /^(fb|facebook(\.com)?)\s*\//i.test(s.trim());
const FB = (mau: string) =>
  `<div class="logo-chu" style="background:${mau}"><svg viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M13.5 21v-7.6h2.6l.4-3h-3V8.5c0-.9.3-1.5 1.5-1.5h1.6V4.3c-.3 0-1.2-.1-2.3-.1-2.3 0-3.9 1.4-3.9 4v2.2H7.8v3h2.6V21h3.1z"/></svg></div>`;

const TICK = (mau: string) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="${mau}" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`;
const NHAN = `<svg viewBox="0 0 24 24" fill="none" stroke="#B4BCC8" stroke-width="3" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg>`;

function ruot(d: DuLieuInfographic, th: ThuongHieuAnh): string {
  switch (d.mau) {
    case "cac_buoc":
      return d.buoc
        .map(
          (b, i) =>
            `<div class="the"><div class="so">${i + 1}</div><div><div class="tieu-de-muc">${e(b.tieuDe)}</div>${b.moTa ? `<div class="mo-ta">${e(b.moTa)}</div>` : ""}</div></div>`,
        )
        .join("");
    case "checklist":
      return d.muc.map((m) => `<div class="the"><div class="dau-tick">${TICK(th.mau)}</div><div class="tieu-de-muc">${e(m)}</div></div>`).join("");
    case "so_sanh": {
      const cot = (c: { nhan: string; y: string[] }, tot: boolean) =>
        `<div class="cot ${tot ? "tot" : "xau"}"><div class="cot-dau">${e(c.nhan)}</div>${c.y.map((y) => `<div class="y">${tot ? TICK(th.mau) : NHAN}<span>${e(y)}</span></div>`).join("")}</div>`;
      return `<div class="hai-cot">${cot(d.trai, false)}${cot(d.phai, true)}</div>`;
    }
    case "so_lieu":
      return `<div class="luoi-so">${d.chiSo.map((c) => `<div class="o-so"><b>${e(c.so)}</b><span>${e(c.nhan)}</span></div>`).join("")}</div>${d.ghiChu ? `<div class="ghi-chu">${e(d.ghiChu)}</div>` : ""}`;
    case "trich_dan":
      return `<div class="trich"><div class="ngoac">“</div><p>${e(d.cau)}</p>${d.tacGia ? `<div class="tac-gia">${e(d.tacGia)}</div>` : ""}</div>`;
  }
}

export function dungHtmlInfographic(d: DuLieuInfographic, th: ThuongHieuAnh, mat: 0 | 1 | 2 = 0): string {
  const chuKy = th.chuKy?.trim() || th.ten;
  const logo = th.logo
    ? `<img class="logo" src="${e(th.logo)}" alt="">`
    : laChuKyFacebook(chuKy)
      ? FB(th.mau)
      : `<div class="logo-chu">${e((th.ten.trim()[0] ?? "Z").toUpperCase())}</div>`;
  return `<!doctype html><html lang="vi"><head><meta charset="utf-8"><style>${cssInfographic(th.mau, th.mauNhat, mat, th.nen)}</style></head><body>
<div class="trang">
  <div class="dau">
    ${d.nhan ? `<span class="nhan">${e(d.nhan)}</span>` : ""}
    <h1>${e(d.tieuDe)}</h1>
    ${d.phuDe ? `<div class="phu-de">${e(d.phuDe)}</div>` : ""}
  </div>
  <div class="noi-dung"><div class="ruot">${ruot(d, th)}</div></div>
  <div class="chan">
    <div class="thuong-hieu">${logo}<span>${e(chuKy)}</span></div>
    ${d.nguon ? `<div class="nguon">${e(d.nguon)}</div>` : ""}
  </div>
</div></body></html>`;
}
