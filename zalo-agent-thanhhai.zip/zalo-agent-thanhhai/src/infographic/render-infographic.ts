import puppeteer from "puppeteer-core";
import { timChrome } from "../documents/chrome-finder.js";
import { getTuning } from "../config/runtime-tuning-settings.js";
import { dungHtmlInfographic, type ThuongHieuAnh } from "./infographic-html.js";
import type { DuLieuInfographic } from "./infographic-schema.js";

/**
 * Chụp ảnh infographic PNG 1080x1350 bằng Chrome đã cài (cùng khuôn an toàn
 * với `render-pdf.ts`: TẮT JS trước khi nạp nội dung, không `--no-sandbox`,
 * luôn đóng trình duyệt trong `finally`).
 *
 * Chống tràn khung: đo chiều cao THẬT của phần nội dung (`.ruot`) so với vùng
 * chứa (`.noi-dung`) bằng hộp DOM của CDP - chạy được kể cả khi JS trang đã
 * tắt. Tràn thì dựng lại ở mật độ cao hơn (chữ nhỏ hơn); tới mật độ 2 vẫn tràn
 * thì báo lỗi để caller rút gọn nội dung, KHÔNG gửi ảnh bị cắt chữ.
 */

export type LaunchImpl = typeof puppeteer.launch;

export class LoiTranKhung extends Error {
  constructor() {
    super("Nội dung quá dài cho một ảnh - cần rút gọn chữ hoặc bớt mục.");
    this.name = "LoiTranKhung";
  }
}

export async function renderInfographic(
  d: DuLieuInfographic,
  th: ThuongHieuAnh,
  launchImpl: LaunchImpl = puppeteer.launch,
): Promise<Buffer> {
  const chrome = timChrome();
  if (!chrome) throw new Error("Không tìm thấy Chrome để dựng ảnh. Cài Chrome hoặc đặt biến CHROME_PATH.");
  const tranMs = getTuning("PDF_RENDER_TIMEOUT_MS");

  const browser = await launchImpl({
    executablePath: chrome,
    headless: true,
    args: ["--disable-gpu", "--disable-dev-shm-usage"],
    timeout: tranMs,
  });
  try {
    const page = await browser.newPage();
    await page.setJavaScriptEnabled(false);
    await page.setViewport({ width: 1080, height: 1350, deviceScaleFactor: 1 });

    for (const mat of [0, 1, 2] as const) {
      await page.setContent(dungHtmlInfographic(d, th, mat), { waitUntil: "load", timeout: tranMs });
      const khung = await (await page.$(".noi-dung"))?.boundingBox();
      const ruot = await (await page.$(".ruot"))?.boundingBox();
      // Dư 2px cho sai số làm tròn
      if (!khung || !ruot || ruot.height <= khung.height + 2) {
        const anh = await page.screenshot({ type: "png", clip: { x: 0, y: 0, width: 1080, height: 1350 } });
        return Buffer.from(anh);
      }
    }
    throw new LoiTranKhung();
  } finally {
    await browser.close().catch(() => undefined);
  }
}
