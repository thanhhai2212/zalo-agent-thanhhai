// Preload cho `pnpm test`: vài test import env.ts trước khi gọi setupTestEnv().
// Không có khóa này thì clone sạch (chưa có .env) đỏ nhiều file test dù code đúng.
process.env.CREDENTIALS_ENCRYPTION_KEY ??= "0".repeat(64);
