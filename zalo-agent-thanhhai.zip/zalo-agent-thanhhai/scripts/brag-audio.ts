/**
 * Tạo âm thanh cho video /brag bằng chính cấu hình của một agent: lời thuyết
 * minh (TTS của agent, thường là Gemini) từng cảnh + một bản nhạc nền (cấu hình
 * tạo nhạc của agent). Chạy TRÊN VPS, nơi có key đã lưu - key không rời máy chủ.
 *
 *   corepack pnpm exec tsx scripts/brag-audio.ts <spec.json> <thư mục ra>
 *
 * spec.json: { "agentId": "...", "voice": "Charon",
 *              "scenes": [{ "id": "01", "text": "lời đọc" }],
 *              "musicPrompt": "mô tả nhạc, tiếng Anh" }
 * Ra: <id>.<ext> cho từng cảnh, music.<ext>, và result.json (file + lỗi nếu có).
 * Cảnh đã có file thì bỏ qua, nên chạy lại chỉ làm phần còn thiếu.
 */
import fs from "node:fs/promises";
import path from "node:path";
import { musicConfigCua } from "../src/agent/tools/create-music-tool.js";
import { getAgent } from "../src/config/agent-store.js";
import { generateMusic } from "../src/music/music-generation-client.js";
import { generateSpeech } from "../src/voice/tts-client.js";

type Spec = { agentId: string; voice?: string; scenes: { id: string; text: string }[]; musicPrompt?: string };

const [specPath, outDir] = process.argv.slice(2);
if (!specPath || !outDir) {
  console.error("Dùng: tsx scripts/brag-audio.ts <spec.json> <thư mục ra>");
  process.exit(1);
}
const spec = JSON.parse(await fs.readFile(specPath, "utf8")) as Spec;
const agent = getAgent(spec.agentId);
if (!agent) {
  console.error(`Không có agent "${spec.agentId}"`);
  process.exit(1);
}
await fs.mkdir(outDir, { recursive: true });
const daCo = await fs.readdir(outDir);
const nghi = (ms: number) => new Promise((r) => setTimeout(r, ms));
const ketQua: { voice: Record<string, string>; music: string | null; loi: string[] } = { voice: {}, music: null, loi: [] };

const ttsCfg = {
  provider: agent.ttsProvider,
  baseUrl: agent.ttsBaseUrl,
  model: agent.ttsModel,
  voice: spec.voice || agent.ttsVoice,
  format: agent.ttsFormat,
  apiKey: agent.ttsApiKey ?? "",
  appId: agent.ttsVbeeAppId,
};

for (const s of spec.scenes) {
  const cu = daCo.find((f) => f.startsWith(`${s.id}.`));
  if (cu) {
    ketQua.voice[s.id] = cu;
    continue;
  }
  // Gói miễn phí Gemini TTS: 3 lượt/phút mỗi key - thử lại chậm, tối đa 3 lần.
  for (let lan = 1; ; lan++) {
    try {
      const v = await generateSpeech(s.text, ttsCfg);
      const ten = `${s.id}.${v.ext}`;
      await fs.writeFile(path.join(outDir, ten), v.data);
      ketQua.voice[s.id] = ten;
      break;
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (lan >= 3 || (err as { hetLuotNgay?: boolean }).hetLuotNgay) {
        ketQua.loi.push(`giọng ${s.id}: ${msg.slice(0, 200)}`);
        break;
      }
      await nghi(25_000);
    }
  }
}

if (spec.musicPrompt) {
  const cu = daCo.find((f) => f.startsWith("music."));
  if (cu) ketQua.music = cu;
  else {
    try {
      const m = await generateMusic(spec.musicPrompt, musicConfigCua(agent));
      ketQua.music = `music.${m.ext}`;
      await fs.writeFile(path.join(outDir, ketQua.music), m.data);
    } catch (err) {
      ketQua.loi.push(`nhạc: ${(err instanceof Error ? err.message : String(err)).slice(0, 200)}`);
    }
  }
}

await fs.writeFile(path.join(outDir, "result.json"), JSON.stringify(ketQua, null, 2));
console.log(JSON.stringify(ketQua));
process.exit(ketQua.loi.length ? 2 : 0);
