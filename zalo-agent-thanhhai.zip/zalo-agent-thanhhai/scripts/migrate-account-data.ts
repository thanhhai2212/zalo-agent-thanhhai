// Di chuyển dữ liệu (lịch sử/memory/contacts) từ 1 account Zalo CŨ sang 1
// account Zalo MỚI - dùng khi đổi SIM/tài khoản phụ (bị Zalo khóa/quét) mà
// vẫn muốn Agent giữ được trí nhớ liên tục thay vì bắt đầu lại từ số 0.
//
// Hướng dẫn đầy đủ (các bước làm, bảng nào chuyển được, cách xử lý xung đột):
// docs/account-migration-guide.md
//
// GIỚI HẠN THẬT (đọc trước khi chạy, đừng kỳ vọng sai):
// - `agents` (persona/model/tool) KHÔNG cần script này - chỉ cần trỏ account
//   mới sang đúng agent_id cũ trên dashboard (mục Accounts), xong ngay, tách
//   biệt hoàn toàn với trí nhớ hội thoại.
// - `memories`/`contacts` khóa theo UID của NGƯỜI ĐỐI DIỆN (subject_id/
//   user_id) - UID đó KHÔNG đổi dù bot đổi tài khoản, nên di chuyển ở đây
//   LUÔN ĐÚNG, không phụ thuộc thread_id.
// - `messages`/`threads` khóa theo `thread_id` do CHÍNH ZALO cấp. Nhóm
//   thường giữ nguyên thread_id dù đổi thành viên (suy luận hợp lý từ cách
//   Zalo tổ chức group, CHƯA xác nhận 100% bằng cách đọc source zca-js - nếu
//   sai thì phần threads chỉ đơn giản không tự nối lại, không hư hại gì),
//   còn chat riêng (1-1) gần như chắc chắn đổi thread_id theo QUAN HỆ với
//   từng account. Tức là: lịch sử NHÓM có cơ hội tự "sống lại" khi account
//   mới join đúng nhóm đó và bot đọc lịch sử; lịch sử CHAT RIÊNG gần như
//   chắc chắn nằm im vô hại (KHÔNG bị xóa, chỉ đơn giản account mới không
//   bao giờ nhìn thấy vì thread_id không khớp bất kỳ tin nào nó nhận sau này).
//
// Mặc định chạy DRY-RUN (chỉ đếm/in ra, KHÔNG ghi gì). Thêm --apply mới ghi
// thật. An toàn chạy lại nhiều lần (idempotent theo từng dòng): dòng nào đã
// chuyển account_id rồi thì lần sau không còn thấy dưới account cũ nữa.
//
// Dùng: pnpm migrate-account <old-account-id> <new-account-id> [--apply]

import { closeDatabase, db } from "../src/conversation/database.js";

const [oldId, newId, ...rest] = process.argv.slice(2);
const apply = rest.includes("--apply");

if (!oldId || !newId) {
  console.error("Cách dùng: pnpm migrate-account <old-account-id> <new-account-id> [--apply]");
  process.exit(1);
}
if (oldId === newId) {
  console.error("Account cũ và account mới không được trùng nhau.");
  process.exit(1);
}

function accountExists(id: string): boolean {
  return Boolean(db.prepare("SELECT 1 FROM accounts WHERE id = ?").get(id));
}

if (!accountExists(oldId)) {
  console.error(`Account cũ "${oldId}" không tồn tại trong DB - kiểm tra lại id (xem trang Accounts trên dashboard).`);
  process.exit(1);
}
if (!accountExists(newId)) {
  console.error(
    `Account mới "${newId}" chưa tồn tại. Tạo account đó trên dashboard TRƯỚC (đăng nhập QR bằng SIM/tài khoản mới, gán Agent), rồi mới chạy script này.`,
  );
  process.exit(1);
}

console.log(`\n${apply ? "ĐANG GHI THẬT" : "DRY-RUN (chỉ xem trước, CHƯA ghi gì)"}: "${oldId}" -> "${newId}"\n`);

// ===== 1) memories - PK là `id` riêng, (account_id, subject_id) KHÔNG unique
//     nên không có xung đột: UPDATE thẳng an toàn. =====
type CountRow = { n: number };
const memories = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE account_id = ?").get(oldId) as CountRow;
console.log(`memories: ${memories.n} dòng sẽ chuyển sang account mới`);
if (apply && memories.n > 0) {
  db.prepare("UPDATE memories SET account_id = ? WHERE account_id = ?").run(newId, oldId);
}

// ===== 2) contacts - PRIMARY KEY (account_id, user_id) NÊN CÓ xung đột nếu
//     người đó đã từng nhắn cho account mới rồi. Ưu tiên giữ bản MỚI (đang
//     hiệu lực, first_seen/last_seen đúng với account mới), chỉ chuyển
//     những contact account mới CHƯA từng gặp. =====
const contactsConflict = db
  .prepare(
    `SELECT COUNT(*) AS n FROM contacts o
     WHERE o.account_id = ? AND EXISTS (
       SELECT 1 FROM contacts x WHERE x.account_id = ? AND x.user_id = o.user_id
     )`,
  )
  .get(oldId, newId) as CountRow;
const contactsMovable = db
  .prepare(
    `SELECT COUNT(*) AS n FROM contacts o
     WHERE o.account_id = ? AND NOT EXISTS (
       SELECT 1 FROM contacts x WHERE x.account_id = ? AND x.user_id = o.user_id
     )`,
  )
  .get(oldId, newId) as CountRow;
console.log(
  `contacts: ${contactsMovable.n} dòng sẽ chuyển, ${contactsConflict.n} dòng BỎ QUA (account mới đã có contact đó - giữ bản mới)`,
);
if (apply && contactsMovable.n > 0) {
  db.prepare(
    `UPDATE contacts SET account_id = ?
     WHERE account_id = ? AND NOT EXISTS (
       SELECT 1 FROM contacts x WHERE x.account_id = ? AND x.user_id = contacts.user_id
     )`,
  ).run(newId, oldId, newId);
}

// ===== 3) messages - PK là `id` riêng, không có xung đột: UPDATE thẳng =====
const messages = db.prepare("SELECT COUNT(*) AS n FROM messages WHERE account_id = ?").get(oldId) as CountRow;
console.log(`messages: ${messages.n} dòng sẽ chuyển sang account mới`);
if (apply && messages.n > 0) {
  db.prepare("UPDATE messages SET account_id = ? WHERE account_id = ?").run(newId, oldId);
}

// ===== 4) threads - PRIMARY KEY (account_id, thread_id) NÊN CÓ xung đột nếu
//     account mới đã có mặt trong ĐÚNG thread đó (group giữ nguyên thread_id
//     là ca hay gặp nhất). Xung đột thì GỘP summary cũ vào summary mới thay
//     vì mất hẳn ngữ cảnh, rồi xóa dòng cũ. Không xung đột thì chuyển thẳng
//     (chỉ thật sự "sống lại" về sau nếu account mới có tin trùng thread_id). =====
type ThreadRow = { thread_id: string; display_name: string; summary: string | null };
const threadsConflict = db
  .prepare(
    `SELECT o.thread_id, o.display_name, o.summary FROM threads o
     WHERE o.account_id = ? AND EXISTS (
       SELECT 1 FROM threads x WHERE x.account_id = ? AND x.thread_id = o.thread_id
     )`,
  )
  .all(oldId, newId) as ThreadRow[];
const threadsMovable = db
  .prepare(
    `SELECT COUNT(*) AS n FROM threads o
     WHERE o.account_id = ? AND NOT EXISTS (
       SELECT 1 FROM threads x WHERE x.account_id = ? AND x.thread_id = o.thread_id
     )`,
  )
  .get(oldId, newId) as CountRow;
console.log(
  `threads: ${threadsMovable.n} dòng chuyển thẳng, ${threadsConflict.length} dòng GỘP summary vào thread trùng thread_id của account mới`,
);
if (apply) {
  if (threadsMovable.n > 0) {
    db.prepare(
      `UPDATE threads SET account_id = ?
       WHERE account_id = ? AND NOT EXISTS (
         SELECT 1 FROM threads x WHERE x.account_id = ? AND x.thread_id = threads.thread_id
       )`,
    ).run(newId, oldId, newId);
  }
  const getNewSummary = db.prepare("SELECT summary FROM threads WHERE account_id = ? AND thread_id = ?");
  const setSummary = db.prepare("UPDATE threads SET summary = ? WHERE account_id = ? AND thread_id = ?");
  const deleteOld = db.prepare("DELETE FROM threads WHERE account_id = ? AND thread_id = ?");
  for (const t of threadsConflict) {
    const newSummary = (getNewSummary.get(newId, t.thread_id) as { summary: string | null } | undefined)?.summary ?? "";
    const merged = t.summary
      ? `[Bối cảnh từ tài khoản cũ, trước khi đổi SIM]\n${t.summary}\n\n[Tiếp tục sau khi đổi tài khoản]\n${newSummary}`.trim()
      : newSummary;
    setSummary.run(merged, newId, t.thread_id);
    deleteOld.run(oldId, t.thread_id);
    console.log(`  - gộp summary nhóm "${t.display_name || t.thread_id}"`);
  }
}

console.log(apply ? "\nĐã ghi xong." : "\nDry-run xong - thêm --apply để ghi thật.");
closeDatabase();
