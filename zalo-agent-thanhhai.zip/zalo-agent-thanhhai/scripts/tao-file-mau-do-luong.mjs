// Tạo file Excel MẪU để thử khâu đo lường: node scripts/tao-file-mau-do-luong.mjs
// Số liệu là BỊA (đánh dấu [MẪU] ở mỗi tiêu đề), chỉ để kiểm quy trình đọc file và lập báo cáo.
// Cột theo đúng kiểu file xuất từ Meta Business Suite / TikTok Analytics nhập tay.
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const require = createRequire(import.meta.url);
const ExcelJS = require("exceljs");

const N = null;
// ngày, kênh, định dạng, trụ cột, tiêu đề, tiếp cận, lượt xem, thích, bình luận, chia sẻ, lưu, click, đơn
const BAI = [
  ["06/10/2026", "TikTok", "video ngắn", "Minh bạch hậu trường", "POV: Xem lô Cầu Đất ra lò hôm nay", N, 8400, 612, 45, 88, 140, 60, 4],
  ["06/10/2026", "Facebook", "video ngắn", "Minh bạch hậu trường", "Lô rang đầu tiên ra lò", 2100, 1650, 96, 14, 11, 9, 22, 1],
  ["07/10/2026", "Facebook", "bài viết", "Câu chuyện Cầu Đất", "Cầu Đất ở đâu mà cà phê ngon vậy?", 1350, N, 58, 9, 4, 6, 8, 0],
  ["08/10/2026", "TikTok", "video ngắn", "Kiến thức cà phê", "Rang vừa khác rang đậm chỗ nào", N, 5200, 310, 22, 31, 95, 14, 0],
  ["08/10/2026", "Facebook", "carousel", "Kiến thức cà phê", "5 dấu hiệu nhận ra cà phê pha trộn", 3100, N, 142, 18, 52, 77, 31, 2],
  ["09/10/2026", "Facebook", "ảnh đơn", "Minh bạch hậu trường", "Nhật ký lô rang #1", 980, N, 33, 4, 1, 2, 6, 1],
  ["10/10/2026", "TikTok", "video ngắn", "Tương tác cộng đồng", "Cà phê buổi sáng của bạn trông thế nào", N, 3900, 188, 74, 9, 12, 5, 0],
  ["13/10/2026", "Facebook", "video ngắn", "Câu chuyện Cầu Đất", "Chuyện lần đầu lên Cầu Đất", 1750, N, 71, 12, 6, 5, 10, 0],
  ["13/10/2026", "TikTok", "video ngắn", "Câu chuyện Cầu Đất", "Cầu Đất 1.500m, vì sao Arabica khác", N, 4100, 205, 17, 25, 60, 9, 0],
  ["14/10/2026", "Facebook", "carousel", "Kiến thức cà phê", "Bảo quản cà phê đúng cách", 2650, N, 120, 15, 41, 88, 18, 0],
  ["15/10/2026", "TikTok", "video ngắn", "Minh bạch hậu trường", "Vì sao mình ghi ngày rang lên mỗi túi", N, 9800, 702, 61, 120, 210, 75, 6],
  ["16/10/2026", "Facebook", "bài viết", "Bán hàng tự nhiên", "Arabica rang vừa, đang có lô mới", 1600, N, 28, 6, 1, 2, 40, 5],
  ["17/10/2026", "TikTok", "video ngắn", "Tương tác cộng đồng", "Thử thách pha phin 3 phút", N, 6300, 355, 98, 27, 40, 11, 0],
  ["20/10/2026", "Facebook", "video ngắn", "Minh bạch hậu trường", "Một buổi sáng rang cà phê", 2300, N, 130, 19, 16, 20, 25, 2],
  ["22/10/2026", "TikTok", "video ngắn", "Kiến thức cà phê", "Arabica và Robusta, uống thử mới biết", N, 4800, 260, 31, 29, 70, 12, 0],
  ["24/10/2026", "TikTok", "video ngắn", "Bán hàng tự nhiên", "Đặt cà phê lần đầu từ inbox đến nhận hàng", N, 3300, 90, 12, 5, 11, 52, 4],
  // Bài mới đăng, chưa có số: để trống (không phải 0) để thử xử lý ô thiếu.
  ["27/10/2026", "Facebook", "bài viết", "Câu chuyện Cầu Đất", "Mùa thu hoạch năm nay", N, N, N, N, N, N, N, N],
  ["28/10/2026", "TikTok", "video ngắn", "Minh bạch hậu trường", "Tại sao không rang sẵn tồn kho nhiều", N, N, N, N, N, N, N, N],
];

const wb = new ExcelJS.Workbook();
const so = wb.addWorksheet("Số liệu");
so.addRow([
  "Ngày", "Kênh", "Định dạng", "Trụ cột", "Tiêu đề bài", "Lượt tiếp cận", "Lượt xem",
  "Thích", "Bình luận", "Chia sẻ", "Lưu", "Click", "Đơn hàng",
]);
for (const b of BAI) so.addRow([b[0], b[1], b[2], b[3], `[MẪU] ${b[4]}`, ...b.slice(5)]);
so.getRow(1).font = { bold: true };
so.columns.forEach((c, i) => (c.width = [12, 11, 12, 22, 46, 14, 11, 8, 11, 9, 7, 8, 11][i]));

const hd = wb.addWorksheet("Hướng dẫn");
[
  ["DỮ LIỆU MẪU, KHÔNG PHẢN ÁNH THỰC TẾ"],
  ["Toàn bộ số trong sheet \"Số liệu\" là số bịa, chỉ để thử quy trình đo lường của bot."],
  [""],
  ["Cột", "Ý nghĩa"],
  ["Lượt tiếp cận", "Số người thấy bài (Facebook). TikTok thường không có cột này, dùng Lượt xem."],
  ["Lượt xem", "Số lượt xem video (TikTok, video Facebook)."],
  ["Thích / Bình luận / Chia sẻ / Lưu", "Số tương tác của bài."],
  ["Click / Đơn hàng", "Số click vào link và số đơn từ bài (nếu có theo dõi)."],
  ["Ô để trống", "Bài mới đăng chưa có số. Để TRỐNG, đừng điền 0: thiếu số khác với số 0."],
].forEach((r) => hd.addRow(r));
hd.getRow(1).font = { bold: true, color: { argb: "FFC00000" } };
hd.getColumn(1).width = 34;
hd.getColumn(2).width = 80;

const dich = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "docs", "mau");
fs.mkdirSync(dich, { recursive: true });
const file = path.join(dich, "so-lieu-mau-hat-moc.xlsx");
await wb.xlsx.writeFile(file);
console.log("Đã tạo", file, `(${BAI.length} bài, 2 bài chưa có số)`);
