/**
 * Chẩn đoán cài đặt + vận hành Zalo Agent, có thể tự sửa lỗi an toàn.
 *
 *   corepack pnpm zalo-doctor          chỉ kiểm tra, không sửa gì
 *   corepack pnpm zalo-doctor --fix    kiểm tra rồi sửa những mục sửa được
 *   (Docker) docker compose exec zalo-agent corepack pnpm zalo-doctor
 *
 * Không in khóa hay mật khẩu đang có. Xem các bước ở src/doctor/doctor-checks.ts.
 */
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { docEnvFile, kiemCaiDat, kiemDangChay, kiemDuLieu, kiemRouter, kiemUngDungDienThoai, type KetQuaKiem } from "../src/doctor/doctor-checks.js";

const goc = process.cwd();
const fileEnv = path.join(goc, ".env");
// Biến trong .env nạp vào process.env (không đè biến đã đặt sẵn, giống bot lúc
// chạy) - để các bước dò như tìm Chrome qua CHROME_PATH thấy đúng giá trị bot dùng.
for (const [k, v] of Object.entries(docEnvFile(fileEnv))) if (process.env[k] === undefined) process.env[k] = v;
const env: Record<string, string> = {};
for (const [k, v] of Object.entries(process.env)) if (v !== undefined) env[k] = v;
const mt = { goc, env };
const sua = process.argv.includes("--fix");

const nhan = { ok: "\x1b[32m[OK] \x1b[0m", canh: "\x1b[33m[!!] \x1b[0m", loi: "\x1b[31m[LỖI]\x1b[0m" } as const;
const in1 = (k: KetQuaKiem) => console.log(`  ${nhan[k.muc]} ${k.ten}${k.chiTiet ? ` - ${k.chiTiet}` : ""}`);

const ketQua: KetQuaKiem[] = [];
const nhom = (ten: string, ds: KetQuaKiem[]) => {
  console.log(`\n${ten}`);
  ds.forEach(in1);
  ketQua.push(...ds);
};

console.log("=== Zalo Agent doctor ===");
nhom("Cài đặt", kiemCaiDat(mt));
let duLieu: KetQuaKiem[] = [];
try {
  duLieu = kiemDuLieu(mt);
} catch (err) {
  duLieu = [{ ten: "Cơ sở dữ liệu", muc: "loi", chiTiet: `không mở được: ${err instanceof Error ? err.message : String(err)}` }];
}
nhom("Dữ liệu và cấu hình", duLieu);

const fileDb = path.join(path.resolve(goc, env.DATA_DIR || "./data"), "zalo-agent.db");
let baseUrl = env.LLM_BASE_URL ?? "";
if (fs.existsSync(fileDb)) {
  try {
    const db = new DatabaseSync(fileDb, { readOnly: true });
    baseUrl = (db.prepare("SELECT value FROM runtime_settings WHERE key = 'llm_base_url'").get() as { value: string } | undefined)?.value ?? baseUrl;
    db.close();
  } catch {
    /* đã báo ở bước dữ liệu */
  }
}
const dangChay = await kiemDangChay(mt);
if (baseUrl) dangChay.push(await kiemRouter(baseUrl, fs.existsSync("/.dockerenv")));
nhom("Đang chạy", dangChay);
nhom("Ứng dụng điện thoại (không bắt buộc)", kiemUngDungDienThoai(mt));

const loi = ketQua.filter((k) => k.muc === "loi").length;
const suaDuoc = ketQua.filter((k) => k.muc !== "ok" && k.sua);
console.log("");
if (sua && suaDuoc.length) {
  console.log("Đang sửa:");
  for (const k of suaDuoc) {
    try {
      console.log(`  -> ${k.ten}: ${k.sua!()}`);
    } catch (err) {
      console.log(`  -> ${k.ten}: KHÔNG sửa được (${err instanceof Error ? err.message : String(err)})`);
    }
  }
  console.log("Chạy lại 'corepack pnpm zalo-doctor' để kiểm tra kết quả.");
} else if (suaDuoc.length) {
  console.log(`Có ${suaDuoc.length} mục tự sửa được - chạy: corepack pnpm zalo-doctor --fix`);
}
console.log(loi ? `Còn ${loi} lỗi (dòng [LỖI] ở trên).` : "Không có lỗi.");
process.exit(loi ? 1 : 0);
